/**
 * داده نمونه — مطابق ساختار APK
 * اجرا: bunx tsx prisma/seed.ts (یا bun prisma/seed.ts)
 */
import { PrismaClient } from "@prisma/client";
import { SERVICE_TYPE_DEFAULTS, DEFAULT_BRANDS } from "../src/lib/types";

const db = new PrismaClient();

function iso(y: number, m: number, d: number): Date {
  return new Date(`${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}T00:00:00.000Z`);
}

async function main() {
  // پاک‌سازی
  await db.record.deleteMany();
  await db.reminder.deleteMany();
  await db.vehicle.deleteMany();
  await db.brandModel.deleteMany();
  await db.serviceType.deleteMany();

  // انواع سرویس — همراه نوع (خدماتی/تعویض قطعه) و سرویس‌های مکمل
  for (let i = 0; i < SERVICE_TYPE_DEFAULTS.length; i++) {
    const t = SERVICE_TYPE_DEFAULTS[i];
    await db.serviceType.create({
      data: {
        label: t.label,
        value: t.label,
        order: i,
        isDefault: true,
        separateCost: t.kind === "PART",
        kind: t.kind,
        complementary: JSON.stringify(t.complementary ?? []),
      },
    });
  }

  // برندها — عیناً همگام با DEFAULT_BRANDS در src/lib/types.ts
  for (const b of DEFAULT_BRANDS) {
    await db.brandModel.create({
      data: { name: b.name, models: JSON.stringify(b.models), isCustom: b.name === "شخصی" },
    });
  }

  // خودروها
  const peugeot = await db.vehicle.create({
    data: {
      brand: "ایران خودرو",
      model: "پژو ۲۰۶ تیپ ۵",
      year: 1395,
      yearType: "JALALI",
      plate: "22 ب 457 ایران 11",
      color: "سفید",
      fuelType: "GASOLINE",
      transmission: "MANUAL",
      status: "ACTIVE",
      mileage: 158480,
      purchasePrice: 950_000_000,
      purchaseDate: iso(2024, 6, 15),
      notes: null,
      isDefault: true,
    },
  });

  const tiba = await db.vehicle.create({
    data: {
      brand: "سایپا",
      model: "تیبا ۲",
      year: 1400,
      yearType: "JALALI",
      plate: "14 د 632 ایران 85",
      color: "نقره‌ای",
      fuelType: "CNG",
      transmission: "MANUAL",
      status: "ACTIVE",
      mileage: 69630,
      isDefault: false,
    },
  });

  /* ---------------- سوخت‌ها (باک کامل → محاسبه مصرف) ---------------- */
  const fuels = [
    { v: peugeot.id, d: iso(2026, 3, 6), km: 153500, liters: 44.0, cost: 1_050_000, full: true, station: "پمپ بنزین ولیعصر" },
    { v: peugeot.id, d: iso(2026, 4, 11), km: 154100, liters: 47.0, cost: 1_150_000, full: true, station: "پمپ بنزین ولیعصر" },
    { v: peugeot.id, d: iso(2026, 5, 2), km: 154700, liters: 45.0, cost: 1_080_000, full: true, station: "پمپ بنزین سعادت‌آباد" },
    { v: peugeot.id, d: iso(2026, 5, 24), km: 155300, liters: 50.0, cost: 1_200_000, full: true, station: "پمپ بنزین ولیعصر" },
    { v: peugeot.id, d: iso(2026, 6, 15), km: 155900, liters: 46.0, cost: 1_110_000, full: true, station: "پمپ بنزین سعادت‌آباد" },
    { v: peugeot.id, d: iso(2026, 7, 6), km: 156500, liters: 44.0, cost: 1_060_000, full: true, station: "پمپ بنزین ولیعصر" },
    { v: peugeot.id, d: iso(2026, 7, 27), km: 157100, liters: 47.0, cost: 1_130_000, full: true, station: "پمپ بنزین سعادت‌آباد" },
    { v: peugeot.id, d: iso(2026, 8, 17), km: 157700, liters: 45.0, cost: 1_080_000, full: true, station: "پمپ بنزین ولیعصر" },
    { v: peugeot.id, d: iso(2026, 9, 2), km: 158300, liters: 46.0, cost: 1_100_000, full: true, station: "پمپ بنزین سعادت‌آباد" },
    { v: tiba.id, d: iso(2026, 3, 6), km: 67000, liters: 34.0, cost: 680_000, full: true, station: "پمپ بنزین شهرک" },
    { v: tiba.id, d: iso(2026, 4, 7), km: 67500, liters: 36.0, cost: 720_000, full: true, station: "پمپ بنزین شهرک" },
    { v: tiba.id, d: iso(2026, 4, 26), km: 68000, liters: 35.0, cost: 700_000, full: true, station: "پمپ بنزین شهرک" },
    { v: tiba.id, d: iso(2026, 5, 20), km: 68500, liters: 42.0, cost: 840_000, full: true, station: null },
    { v: tiba.id, d: iso(2026, 6, 23), km: 69100, liters: 40.0, cost: 800_000, full: true, station: "پمپ بنزین شهرک" },
  ];
  for (const f of fuels) {
    await db.record.create({
      data: {
        type: "FUEL",
        vehicleId: f.v,
        date: f.d,
        mileage: f.km,
        cost: f.cost,
        liters: f.liters,
        pricePerLiter: Math.round(f.cost / f.liters),
        fullTank: f.full,
        prevRegistered: true,
        station: f.station,
      },
    });
  }

  /* ---------------- سرویس‌ها ---------------- */
  // روغن کامل با فیلترها (هزینه تفکیکی + سرویس‌های مکمل)
  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: peugeot.id,
      date: iso(2026, 4, 30),
      mileage: 154500,
      title: "تعویض روغن موتور",
      costMode: "SEPARATE",
      partsCost: 1_200_000,
      laborCost: 250_000,
      hasOilFilter: true,
      oilFilterCost: 180_000,
      hasAirFilter: true,
      airFilterCost: 90_000,
      complementary: JSON.stringify([
        { name: "فیلتر روغن", price: 180_000 },
        { name: "فیلتر هوا", price: 90_000 },
        { name: "تنظیم باد", price: 0 },
      ]),
      cost: 1_720_000,
      provider: "مرکز خدمات آریا",
      description: "روغن توتال کوانتوم 10W40",
      nextDueKm: 159500,
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: peugeot.id,
      date: iso(2026, 3, 16),
      mileage: 153550,
      title: "تعویض فیلتر هوا",
      costMode: "TOTAL",
      cost: 320_000,
      provider: "تعمیرگاه خیابان ولیعصر",
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: peugeot.id,
      date: iso(2026, 5, 25),
      mileage: 155350,
      title: "تعویض لنت ترمز",
      costMode: "SEPARATE",
      partsCost: 2_400_000,
      laborCost: 350_000,
      cost: 2_750_000,
      provider: "ترمزسازی رستمی",
      description: "لنت ایکسبرگ",
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: peugeot.id,
      date: iso(2026, 6, 13),
      mileage: 156150,
      title: "تعویض تسمه تایم",
      costMode: "TOTAL",
      cost: 8_500_000,
      provider: "مکانیک تخصصی سمپاد",
      description: "تسمه الیسه + واترپمپ گاتس",
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: tiba.id,
      date: iso(2026, 5, 22),
      mileage: 68400,
      title: "تعویض شمع‌ها",
      costMode: "TOTAL",
      cost: 900_000,
      provider: "تعمیرگاه محله",
      description: "شمع NGK",
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: tiba.id,
      date: iso(2026, 4, 14),
      mileage: 68200,
      title: "تعمیر گیربکس",
      costMode: "TOTAL",
      cost: 2_200_000,
      provider: "کلاچ‌سازی مرکزی",
      description: "دیسک و صفحه و بلبرینگ",
    },
  });

  await db.record.create({
    data: {
      type: "SERVICE",
      vehicleId: tiba.id,
      date: iso(2025, 11, 25),
      mileage: 65800,
      title: "تعویض روغن موتور",
      costMode: "SEPARATE",
      partsCost: 1_150_000,
      laborCost: 250_000,
      hasOilFilter: true,
      oilFilterCost: 120_000,
      complementary: JSON.stringify([{ name: "فیلتر روغن", price: 120_000 }]),
      cost: 1_520_000,
      provider: "تعمیرگاه محله",
    },
  });

  /* ---------------- کیلومتر ---------------- */
  await db.record.create({
    data: {
      type: "ODOMETER",
      vehicleId: peugeot.id,
      date: iso(2026, 2, 15),
      mileage: 155000,
      description: "تنظیم کیلومترشمار پس از تعویض باتری",
    },
  });
  await db.record.create({
    data: {
      type: "ODOMETER",
      vehicleId: peugeot.id,
      date: iso(2026, 9, 2),
      mileage: 158480,
      description: null,
    },
  });
  await db.record.create({
    data: {
      type: "ODOMETER",
      vehicleId: tiba.id,
      date: iso(2026, 9, 2),
      mileage: 69630,
      description: null,
    },
  });

  /* ---------------- یادداشت‌ها ---------------- */
  await db.record.create({
    data: {
      type: "NOTE",
      vehicleId: peugeot.id,
      date: iso(2026, 6, 20),
      noteTitle: "صدای غیرعادی جلو",
      noteBody: "در سرعت بالای ۸۰، صدای تق‌تق از چرخ جلو راست شنیده می‌شود — احتمالاً بلبرینگ.",
    },
  });
  await db.record.create({
    data: {
      type: "NOTE",
      vehicleId: tiba.id,
      date: iso(2026, 7, 1),
      noteTitle: "گارانتی",
      noteBody: "گارانتی ۳ ساله تا خرداد ۱۴۰۶ فعال است — تلفن نمایندگی: ۰۲۱-۵۵۴۴۳۳۲۲",
    },
  });

  /* ---------------- یادآورها ---------------- */
  await db.reminder.create({
    data: {
      vehicleId: peugeot.id,
      title: "سرویس بعدی روغن موتور",
      kind: "KM",
      dueKm: 159500,
      repeatKind: "NONE",
      status: "ACTIVE",
    },
  });
  await db.reminder.create({
    data: {
      vehicleId: peugeot.id,
      title: "تمدید بیمه شخص ثالث",
      kind: "DATE",
      dueDate: iso(2026, 8, 25),
      repeatKind: "YEARLY",
      status: "ACTIVE",
    },
  });
  await db.reminder.create({
    data: {
      vehicleId: peugeot.id,
      title: "معاینه فنی",
      kind: "DATE",
      dueDate: iso(2026, 10, 10),
      repeatKind: "YEARLY",
      status: "ACTIVE",
    },
  });
  await db.reminder.create({
    data: {
      vehicleId: tiba.id,
      title: "تعویض روغن گیربکس",
      kind: "KM",
      dueKm: 72000,
      repeatKind: "NONE",
      status: "ACTIVE",
    },
  });
  await db.reminder.create({
    data: {
      vehicleId: tiba.id,
      title: "چرخ‌لی و بالانس",
      kind: "DATE",
      dueDate: iso(2025, 8, 20),
      repeatKind: "YEARLY",
      status: "ACTIVE",
    },
  });

  console.log("✓ داده نمونه ساخته شد");
  console.log(`  - خودروها: ۲ (پژو ۲۰۶، تیبا ۲)`);
  console.log(`  - رکوردها: ${await db.record.count()}`);
  console.log(`  - یادآورها: ${await db.reminder.count()}`);
  console.log(`  - برندها: ${await db.brandModel.count()}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
