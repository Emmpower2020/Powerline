# شروع سریع — بستهٔ کامل پروژهٔ «همراه خودرو»

> **ابتدا `PROJECT-HANDOFF.md` را بخوانید** — سند انتقال کامل پروژه است (معماری، قراردادها، هندسهٔ صحنه، تاریخچهٔ باگ‌ها و چک‌لیست بازسازی). این فایل فقط «اجرا در ۵ دقیقه» است.

## این بسته چیست؟

پروژهٔ کامل اپ اندرویدی «همراه خودرو» (مدیریت سرویس خودرو — فارسی/RTL): سورس وب (Next.js 16)، لایهٔ جاوا (پل OAuth/فایربیس)، خط بیلد APK بدون Gradle، keystore امضا، شبیه‌ساز تست E2E، اسکریپت‌های راه‌اندازی سرور فایربیس و مستندات.

## پیش‌نیازها

- **bun** (اجرای وب و اسکریپت‌ها)
- **Java 17+** (فقط برای بیلد dex/APK)
- برای بیلد APK: **Android build-tools r34** — دانلود و استخراج:
  ```bash
  mkdir -p /home/z/apk-build/bt
  curl -fL -o bt.zip https://dl.google.com/android/repository/build-tools_r34-linux.zip
  unzip -q bt.zip -d /home/z/apk-build/bt-extract
  mv /home/z/apk-build/bt-extract/android-14 /home/z/apk-build/bt/android-14
  # جارهای بیلد (ecj/smali/…) داخل همین بسته در ریشه هستند؛ به /home/z/apk-build/tools کپی کنید
  ```

## اجرای وب (محیط توسعه)

```bash
bun install
bun run db:push        # ساخت دیتابیس SQLite از prisma/schema.prisma
bun run dev            # http://localhost:3000
```

## شبیه‌ساز اندروید (تست E2E بدون گوشی)

```bash
cd mini-services/apk-mock && bun run dev   # پورت 3031 — همان بیلدی که داخل APK می‌رود را سرو می‌کند
```
سناریوهای خطا (غیرفعال‌بودن API، دیتابیس نبودن، …) با `window.__CLOUD_SIM` — جزئیات در PROJECT-HANDOFF.md بخش ۱۴.

## بازسازی APK

```bash
apk-build/build-web-only.sh          # ۱) بیلد استاتیک وب → www-final (+ سینک با شبیه‌ساز)
apk-build/build-dex-v395.sh          # ۲) فقط اگر جاوا عوض شده باشد (ecj→d8→smali)
apk-build/build-apk-v396.sh          # ۳) بسته‌بندی + جراحی مانیفست + امضا (نسخه/patch را جدید کن)
scripts/place-apk.sh hamrah-khodro-vX.Y.Z.apk X.Y.Z
```
⚠️ `hamrah-khodro-v3.9.0.apk` پایهٔ بیلد است — **هرگز حذفش نکنید**.

## سرور پشتیبان (Firebase) از صفر

```bash
# کلید Service Account را از کنسول بگیرید و در config/service-account.json بگذارید، بعد:
bun run scripts/firebase-new-project.ts config/service-account.json --apply
# همه‌چیز خودکار: APIها + اپ اندروید + SHA-1 + ورود گوگل + دیتابیس + قوانین + تست E2E + پچ سورس
```

## رمزها و شناسه‌ها

| مورد | مقدار |
|---|---|
| keystore | `android-keys/hk-release.keystore` |
| alias / رمز | `hamrah` / `hamrah-khodro-2026` |
| پکیج | `com.zai.hamrahkhodro` |
| پروژهٔ فایربیس فعلی | `hamrahprj` |

## نگاشت مسیرها

| پوشه | توضیح |
|---|---|
| `src/` | سورس وب (قلب: `app/page.tsx` + `lib/types.ts` + `lib/persian.ts`) |
| `apk-build/` | جاوا (asyncsrc395) + اسکریپت‌های بیلد + dex نهایی |
| `mini-services/apk-mock/` | شبیه‌ساز E2E + بیلد استاتیک نهایی (www-final) |
| `scripts/` | راه‌اندازی/تشخیص فایربیس + توزیع APK |
| `docs/` | راهنماهای کنسول و انتشار |
| `PROJECT-HANDOFF.md` | **سند انتقال کامل — از اینجا شروع کنید** |
