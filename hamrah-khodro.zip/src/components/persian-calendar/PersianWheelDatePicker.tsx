"use client";

/**
 * انتخاب‌گر تاریخ شمسی با سه ستون اسکرولی (Wheel Picker)
 * بر اساس ماژول آپلودی کاربر — چیدمان RTL: [روز] [ماه] [سال]
 * دکمه‌ها: [لغو] [برو به امروز] [تأیید]
 */

import * as React from "react";
import {
  type PersianDate,
  PERSIAN_MONTHS,
  fa,
  jalaaliMonthLength,
  todayJalali,
} from "@/lib/persian";

/* --------------------------- استایل‌های داخلی --------------------------- */

const STYLE_ID = "persian-wheel-date-picker-styles";

function ensureStyles() {
  if (typeof document === "undefined") return;
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
@keyframes pwdpFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes pwdpFadeOut { from { opacity: 1; } to { opacity: 0; } }
@keyframes pwdpSlideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
@keyframes pwdpSlideDown { from { transform: translateY(0); } to { transform: translateY(100%); } }
.pwdp-overlay-in  { animation: pwdpFadeIn .22s ease both; }
.pwdp-overlay-out { animation: pwdpFadeOut .22s ease both; }
.pwdp-sheet-in    { animation: pwdpSlideUp .3s cubic-bezier(.22,.61,.36,1) both; }
.pwdp-sheet-out   { animation: pwdpSlideDown .26s cubic-bezier(.22,.61,.36,1) both; }
.pwdp-wheel {
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
  overscroll-behavior: contain;
}
.pwdp-wheel::-webkit-scrollbar { width: 0; height: 0; display: none; }
.pwdp-wheel-item {
  scroll-snap-align: center;
  will-change: opacity, transform;
  transition: opacity .12s ease;
}
`;
  document.head.appendChild(style);
}

/* ------------------------------ ستون چرخشی ------------------------------ */

interface WheelItem {
  value: number;
  label: string;
}

interface WheelColumnProps {
  items: WheelItem[];
  value: number;
  onChange: (v: number) => void;
  itemHeight?: number;
  visibleCount?: number;
  accent?: string;
}

function WheelColumn({
  items,
  value,
  onChange,
  itemHeight = 44,
  visibleCount = 5,
  accent = "#12A594",
}: WheelColumnProps) {
  const listRef = React.useRef<HTMLDivElement>(null);
  const itemRefs = React.useRef<(HTMLDivElement | null)[]>([]);
  const rafRef = React.useRef<number | null>(null);
  const scrollEndTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const programmatic = React.useRef(false);
  const isPointerDown = React.useRef(false);
  const lastPointerUpAt = React.useRef(0);
  const [snapOn, setSnapOn] = React.useState(true);

  const containerHeight = itemHeight * visibleCount;
  const pad = (containerHeight - itemHeight) / 2;

  const selectedIndex = React.useMemo(
    () => Math.max(0, items.findIndex((it) => it.value === value)),
    [items, value],
  );

  const updateVisuals = React.useCallback(
    (scrollTop: number) => {
      const center = Math.round(scrollTop / itemHeight);
      itemRefs.current.forEach((el, i) => {
        if (!el) return;
        const distance = Math.abs(i - center);
        let opacity: number;
        let scale: number;
        if (distance === 0) {
          opacity = 1;
          scale = 1;
        } else if (distance === 1) {
          opacity = 0.5;
          scale = 0.9;
        } else if (distance === 2) {
          opacity = 0.26;
          scale = 0.82;
        } else {
          opacity = 0.1;
          scale = 0.76;
        }
        el.style.opacity = String(opacity);
        el.style.transform = `scale(${scale})`;
        el.style.fontWeight = distance === 0 ? "700" : "400";
        el.style.color = distance === 0 ? accent : "";
      });
    },
    [itemHeight, accent],
  );

  const snapToNearest = React.useCallback(
    (smooth: boolean) => {
      const el = listRef.current;
      if (!el) return;
      const idx = Math.round(el.scrollTop / itemHeight);
      const clamped = Math.max(0, Math.min(items.length - 1, idx));
      const target = clamped * itemHeight;
      if (Math.abs(el.scrollTop - target) > 0.5) {
        programmatic.current = true;
        el.scrollTo({ top: target, behavior: smooth ? "smooth" : "auto" });
        window.setTimeout(() => {
          programmatic.current = false;
        }, 400);
      }
      const item = items[clamped];
      if (item && item.value !== value) {
        onChange(item.value);
      }
    },
    [itemHeight, items, value, onChange],
  );

  React.useLayoutEffect(() => {
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = selectedIndex * itemHeight;
    updateVisuals(selectedIndex * itemHeight);
     
  }, []);

  React.useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const target = selectedIndex * itemHeight;
    if (Math.abs(el.scrollTop - target) > 0.5) {
      programmatic.current = true;
      setSnapOn(false);
      el.scrollTo({ top: target, behavior: "smooth" });
      updateVisuals(target);
      const t = window.setTimeout(() => {
        programmatic.current = false;
        setSnapOn(true);
      }, 420);
      return () => window.clearTimeout(t);
    }
     
  }, [selectedIndex, itemHeight]);

  const handlePointerDown = React.useCallback(() => {
    isPointerDown.current = true;
    setSnapOn(false);
  }, []);

  const handlePointerUp = React.useCallback(() => {
    if (!isPointerDown.current) return;
    isPointerDown.current = false;
    lastPointerUpAt.current = Date.now();
    setSnapOn(true);
  }, []);

  React.useEffect(() => {
    const onUp = () => {
      if (isPointerDown.current) {
        isPointerDown.current = false;
        lastPointerUpAt.current = Date.now();
        setSnapOn(true);
      }
    };
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, []);

  const handleScroll = React.useCallback(() => {
    const el = listRef.current;
    if (!el) return;
    const top = el.scrollTop;
    if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => updateVisuals(top));

    if (programmatic.current) return;

    const sinceUp = Date.now() - lastPointerUpAt.current;
    const isMomentum = sinceUp < 800;

    if (!isPointerDown.current && !isMomentum) {
      setSnapOn(false);
    }

    if (scrollEndTimer.current) clearTimeout(scrollEndTimer.current);
    scrollEndTimer.current = setTimeout(() => {
      if (!isPointerDown.current) {
        setSnapOn(true);
        snapToNearest(true);
      }
    }, 110);
  }, [updateVisuals, snapToNearest]);

  React.useEffect(() => {
    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      if (scrollEndTimer.current) clearTimeout(scrollEndTimer.current);
    };
  }, []);

  return (
    <div
      className="pwdp-wheel relative overflow-y-auto"
      style={{
        height: containerHeight,
        paddingTop: pad,
        paddingBottom: pad,
        scrollSnapType: snapOn ? "y mandatory" : "none",
        touchAction: "pan-y",
      }}
      ref={listRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onScroll={handleScroll}
    >
      {items.map((it, i) => (
        <div
          key={it.value}
          ref={(el) => {
            itemRefs.current[i] = el;
          }}
          className="pwdp-wheel-item flex items-center justify-center text-foreground"
          style={{
            height: itemHeight,
            fontSize: itemHeight > 40 ? 18 : 16,
            scrollSnapAlign: "center",
          }}
        >
          {it.label}
        </div>
      ))}
    </div>
  );
}

/* ---------------------------- انتخاب‌گر اصلی ---------------------------- */

export interface PersianWheelDatePickerProps {
  open: boolean;
  value?: PersianDate | null;
  onConfirm: (date: PersianDate) => void;
  onCancel?: () => void;
  minYear?: number;
  maxYear?: number;
  accentColor?: string;
  title?: string;
}

export function PersianWheelDatePicker({
  open,
  value,
  onConfirm,
  onCancel,
  minYear = 1380,
  maxYear = 1450,
  accentColor = "#12A594",
  title = "انتخاب تاریخ",
}: PersianWheelDatePickerProps) {
  const accent = accentColor;
  const ITEM_H = 44;
  const VISIBLE = 5;

  const today = React.useMemo(() => todayJalali(), []);

  const [draft, setDraft] = React.useState<PersianDate>(() => value ?? today);

  React.useEffect(() => {
    if (open) {
      setDraft(value ?? today);
    }
  }, [open, value, today]);

  React.useEffect(() => {
    ensureStyles();
  }, []);

  const [render, setRender] = React.useState(open);
  const [closing, setClosing] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setRender(true);
      setClosing(false);
    } else if (render) {
      setClosing(true);
      const t = window.setTimeout(() => {
        setRender(false);
        setClosing(false);
      }, 260);
      return () => window.clearTimeout(t);
    }
     
  }, [open]);

  React.useEffect(() => {
    if (!render) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [render]);

  React.useEffect(() => {
    if (!render) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCancel?.();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [render, onCancel]);

  const years = React.useMemo<WheelItem[]>(() => {
    const arr: WheelItem[] = [];
    for (let y = minYear; y <= maxYear; y++) {
      arr.push({ value: y, label: fa(y) });
    }
    return arr;
  }, [minYear, maxYear]);

  const months = React.useMemo<WheelItem[]>(
    () => PERSIAN_MONTHS.map((m, i) => ({ value: i + 1, label: m })),
    [],
  );

  const maxDay = jalaaliMonthLength(draft.jy, draft.jm);
  const days = React.useMemo<WheelItem[]>(() => {
    const arr: WheelItem[] = [];
    for (let d = 1; d <= maxDay; d++) {
      arr.push({ value: d, label: fa(d) });
    }
    return arr;
  }, [maxDay]);

  const setDay = React.useCallback((d: number) => setDraft((p) => ({ ...p, jd: d })), []);
  const setMonth = React.useCallback((m: number) => {
    setDraft((p) => {
      const ml = jalaaliMonthLength(p.jy, m);
      return { ...p, jm: m, jd: Math.min(p.jd, ml) };
    });
  }, []);
  const setYear = React.useCallback((y: number) => {
    setDraft((p) => {
      const ml = jalaaliMonthLength(y, p.jm);
      return { ...p, jy: y, jd: Math.min(p.jd, ml) };
    });
  }, []);

  const goToToday = React.useCallback(() => setDraft(today), [today]);
  const doConfirm = React.useCallback(() => onConfirm(draft), [draft, onConfirm]);
  const doCancel = React.useCallback(() => onCancel?.(), [onCancel]);

  if (!render) return null;

  const pad = (ITEM_H * VISIBLE - ITEM_H) / 2;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        className={"absolute inset-0 bg-black/50 " + (closing ? "pwdp-overlay-out" : "pwdp-overlay-in")}
        onClick={doCancel}
      />

      <div
        className={
          "relative z-10 w-full max-w-md rounded-t-3xl bg-card text-card-foreground shadow-2xl sm:rounded-3xl " +
          (closing ? "pwdp-sheet-out" : "pwdp-sheet-in")
        }
      >
        <div className="flex justify-center pt-3">
          <div className="h-1.5 w-10 rounded-full bg-border" />
        </div>

        <div className="px-4 pb-2 pt-3 text-center">
          <div className="text-[15px] font-semibold text-foreground">{title}</div>
          <div className="mt-1 text-lg font-bold" style={{ color: accent }}>
            {fa(draft.jd)} {PERSIAN_MONTHS[draft.jm - 1]} {fa(draft.jy)}
          </div>
        </div>

        <div className="px-3 py-2">
          <div className="mb-1 grid grid-cols-3 gap-2 px-2 text-center text-[12px] font-medium text-muted-foreground">
            <div>روز</div>
            <div>ماه</div>
            <div>سال</div>
          </div>
          <div className="relative grid grid-cols-3 gap-2">
            <div
              className="pointer-events-none absolute inset-x-0 rounded-xl border bg-muted/50"
              style={{
                top: pad,
                height: ITEM_H,
                borderColor: accent + "73",
                boxShadow: `0 0 0 3px ${accent}1f, inset 0 0 0 1px ${accent}14`,
              }}
            />
            <WheelColumn items={days} value={draft.jd} onChange={setDay} itemHeight={ITEM_H} visibleCount={VISIBLE} accent={accent} />
            <WheelColumn items={months} value={draft.jm} onChange={setMonth} itemHeight={ITEM_H} visibleCount={VISIBLE} accent={accent} />
            <WheelColumn items={years} value={draft.jy} onChange={setYear} itemHeight={ITEM_H} visibleCount={VISIBLE} accent={accent} />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 px-4 pb-6 pt-3">
          <button
            type="button"
            onClick={doCancel}
            className="h-12 rounded-xl border border-border bg-background text-[15px] font-medium text-foreground transition-colors active:scale-[.98]"
          >
            لغو
          </button>
          <button
            type="button"
            onClick={goToToday}
            className="h-12 rounded-xl border border-border bg-background text-[15px] font-medium text-foreground transition-colors active:scale-[.98]"
          >
            برو به امروز
          </button>
          <button
            type="button"
            onClick={doConfirm}
            className="h-12 rounded-xl text-[15px] font-semibold text-white shadow-sm transition-transform active:scale-[.98]"
            style={{ backgroundColor: accent }}
          >
            تأیید
          </button>
        </div>
      </div>
    </div>
  );
}

export default PersianWheelDatePicker;
