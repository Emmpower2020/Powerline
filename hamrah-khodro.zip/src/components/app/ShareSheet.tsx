"use client";

/**
 * شیت «اشتراک‌گذاری سوابق» — خروجی متنی سوابق به تفکیک خودرو و مرتب (قدیمی→جدید،
 * یعنی آخرین سرویس همیشه پایین‌ترین سطر فایل است):
 *  - انتخاب محدوده: همهٔ اطلاعات یا N رکورد اخیر
 *  - دو حالت خروجی: «فایل جدید» و «افزودن به فایل قبلی» (فقط رکوردهای جدید از آخرین خروجی —
 *    تا کاربر در برنامهٔ مقصد (مثل Samsung Note) به انتهای فایل قبلی بچسباند)
 *  - ارسال به‌صورت «فایل متنی» از طریق اشتراک سیستم (Samsung Notes و…)، دانلود یا کپی متن
 */

import * as React from "react";
import { Copy, FileDown, FilePlus2, History, Loader2, RotateCcw, Share2 } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  fa,
  faNum,
  formatJalaliNumericISO,
  PERSIAN_MONTHS,
  PERSIAN_WEEKDAYS,
  plateDisplay,
  todayJalali,
} from "@/lib/persian";
import type { RecordItem, VehicleItem } from "@/lib/types";
import { BottomSheet } from "./BottomSheet";
import { SubmitButton } from "./fields";
import { useToast } from "@/hooks/use-toast";

const LAST_EXPORT_KEY = "hamrah-khodro-last-export";

/** دامنهٔ خروجی — همه یا N رکورد اخیر */
const SCOPE_OPTIONS = [
  { value: "all", label: "همهٔ اطلاعات" },
  { value: "10", label: "۱۰ اخیر" },
  { value: "20", label: "۲۰ اخیر" },
  { value: "50", label: "۵۰ اخیر" },
];

/* ------------------------------ متن خروجی ------------------------------ */

function nowStamp(): string {
  const now = new Date();
  const j = todayJalali();
  const time = `${fa(now.getHours())}:${fa(String(now.getMinutes()).padStart(2, "0"))}`;
  return `${PERSIAN_WEEKDAYS[now.getDay()]} ${fa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]} ${fa(j.jy)} — ساعت ${time}`;
}

function exportFileName(prefix = "hamrah-khodro"): string {
  const j = todayJalali();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${prefix}-${j.jy}-${p(j.jm)}-${p(j.jd)}.txt`;
}

/** بلوک متنی یک رکورد — سطرها با تورفتگی */
function recordBlock(r: RecordItem): string {
  const lines: string[] = [];
  const head =
    r.type === "SERVICE"
      ? r.title || "سرویس"
      : r.type === "FUEL"
        ? r.fullTank
          ? "سوخت‌گیری (باک کامل)"
          : "سوخت‌گیری (نیم‌بند)"
        : r.type === "NOTE"
          ? `یادداشت: ${r.noteTitle || "بدون عنوان"}`
          : "ثبت کیلومتر";
  lines.push(`▪ ${formatJalaliNumericISO(r.date)} | ${head}`);
  const detail: string[] = [];
  if (r.mileage !== null) detail.push(`کارکرد: ${faNum(r.mileage)} کیلومتر`);
  if (r.cost !== null && r.cost > 0) detail.push(`هزینه: ${faNum(r.cost)} تومان`);
  if (r.type === "FUEL") {
    if (r.liters !== null) detail.push(`${faNum(r.liters, 1)} لیتر${r.pricePerLiter ? ` (${faNum(r.pricePerLiter)} تومان/لیتر)` : ""}`);
    if (r.consumption !== null) detail.push(`مصرف: ${faNum(r.consumption, 1)}`);
    if (r.station) detail.push(r.station);
  }
  if (r.type === "SERVICE") {
    if ((r.complementary?.length ?? 0) > 0) {
      detail.push(`مکمل: ${r.complementary.map((c) => (c.price ? `${c.name} ${faNum(c.price)}` : c.name)).join(" + ")}`);
    }
    if (r.provider) detail.push(`مرکز: ${r.provider}`);
    if (r.nextDueDate || r.nextDueKm) {
      const parts: string[] = [];
      if (r.nextDueDate) parts.push(`تاریخ ${formatJalaliNumericISO(r.nextDueDate)}`);
      if (r.nextDueKm) parts.push(`کارکرد ${faNum(r.nextDueKm)}`);
      detail.push(`سرویس بعدی: ${parts.join(" / ")}`);
    }
  }
  if (r.type === "NOTE" && r.noteBody) detail.push(r.noteBody);
  for (const d of detail) lines.push(`   ${d}`);
  return lines.join("\n");
}

/** متن کامل خروجی — گروه‌بندی بر اساس خودرو، مرتب صعودی (آخرین رکورد پایین) */
function buildExportText(opts: {
  records: RecordItem[];
  vehicles: VehicleItem[];
  scope: string;
  append: boolean;
  lastExportAt: number | null;
}): { text: string; count: number; vehicleCount: number } {
  const { records, vehicles, scope, append, lastExportAt } = opts;

  // مرتب‌سازی نزولی بر اساس تاریخ (و زمان ثبت) → بعد صعودی برای خروجی
  const byDateDesc = [...records].sort(
    (a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)
  );
  let picked: RecordItem[];
  if (append) {
    const cut = lastExportAt ?? 0;
    picked = byDateDesc.filter((r) => new Date(r.createdAt).getTime() > cut);
  } else if (scope !== "all") {
    picked = byDateDesc.slice(0, Number(scope));
  } else {
    picked = byDateDesc;
  }
  const asc = [...picked].sort(
    (a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt)
  );

  const out: string[] = [];
  if (append) {
    out.push("➕ همراه خودرو — افزودنی از آخرین خروجی");
    out.push(`این بخش را به انتهای فایل متنی قبلی اضافه کنید (${fa(asc.length)} رکورد جدید)`);
    out.push(`🗓 ${nowStamp()}`);
    out.push("");
  } else {
    out.push("🚗 همراه خودرو — سوابق خودروها");
    out.push(`🗓 ${nowStamp()}`);
    const scopeLabel =
      scope === "all" ? "همهٔ اطلاعات" : `${fa(scope)} رکورد اخیر`;
    out.push(`📦 ${scopeLabel} — ${fa(asc.length)} رکورد`);
    out.push("");
  }

  // گروه‌بندی بر اساس خودرو (به تفکیک) — مرتب
  let count = 0;
  let vehicleCount = 0;
  for (const v of vehicles) {
    const list = asc.filter((r) => r.vehicleId === v.id);
    if (list.length === 0) continue;
    vehicleCount++;
    const plate = v.plate ? ` — ${plateDisplay(v.plate)}` : "";
    out.push(`━━━━━━━━━━━━━━━━━━━━`);
    out.push(`🚙 ${v.name}${plate}`);
    out.push(`━━━━━━━━━━━━━━━━━━━━`);
    for (const r of list) {
      out.push(recordBlock(r));
      count++;
    }
    out.push("");
  }

  if (count === 0) {
    out.push("رکوردی برای خروجی نیست.");
  } else {
    out.push("──────────────────");
    out.push(`✓ مجموع: ${fa(count)} رکورد در ${fa(vehicleCount)} خودرو — آخرین رکورد پایین فایل است`);
  }
  return { text: out.join("\n"), count, vehicleCount };
}

/* ------------------------------ شیت اصلی ------------------------------ */

export function ShareSheet({
  open,
  onClose,
  records,
  vehicles,
}: {
  open: boolean;
  onClose: () => void;
  records: RecordItem[];
  vehicles: VehicleItem[];
}) {
  const { toast } = useToast();
  const [scope, setScope] = React.useState("all");
  const [append, setAppend] = React.useState(false);
  const [lastExportAt, setLastExportAt] = React.useState<number | null>(null);
  const [busy, setBusy] = React.useState<"copy" | "share" | null>(null);

  React.useEffect(() => {
    if (!open) return;
    setScope("all");
    setAppend(false);
    try {
      const raw = localStorage.getItem(LAST_EXPORT_KEY);
      setLastExportAt(raw ? Number(raw) : null);
    } catch {
      setLastExportAt(null);
    }
  }, [open]);

  const exportData = React.useMemo(
    () => buildExportText({ records, vehicles, scope, append, lastExportAt }),
    [records, vehicles, scope, append, lastExportAt]
  );

  const lastExportLabel = React.useMemo(() => {
    if (!lastExportAt) return null;
    const d = new Date(lastExportAt);
    return `${PERSIAN_WEEKDAYS[d.getDay()]} — ${fa(d.getHours())}:${fa(String(d.getMinutes()).padStart(2, "0"))}`;
  }, [lastExportAt]);

  const markExported = () => {
    const now = Date.now();
    try {
      localStorage.setItem(LAST_EXPORT_KEY, String(now));
    } catch {
      /* ignore */
    }
    setLastExportAt(now);
  };

  /** کپی متن در حافظه */
  const copyText = async () => {
    setBusy("copy");
    try {
      await navigator.clipboard.writeText(exportData.text);
      toast({ title: "کپی شد ✓", description: `${fa(exportData.count)} رکورد — آمادهٔ چسباندن در برنامهٔ مقصد` });
      if (append) markExported();
    } catch {
      toast({ title: "خطا", description: "کپی انجام نشد", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  /** ارسال به‌صورت فایل متنی — از طریق اشتراک سیستم (مثل Samsung Note) یا دانلود */
  const shareFile = async () => {
    setBusy("share");
    try {
      const fileName = exportFileName(append ? "hamrah-khodro-additions" : "hamrah-khodro");
      const file = new File([exportData.text], fileName, { type: "text/plain" });
      const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
      if (typeof nav.share === "function" && nav.canShare?.({ files: [file] })) {
        await nav.share({ files: [file], title: "سوابق خودروها" });
        toast({
          title: "ارسال شد ✓",
          description: "برنامهٔ مقصد (مثل Samsung Note) را انتخاب و ذخیره کنید",
        });
      } else {
        // دانلود فایل متنی — سپس از برنامهٔ دلخواه باز/الحاق کنید
        const blob = new Blob([exportData.text], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
        toast({
          title: "فایل متنی ساخته شد ✓",
          description: `${fileName} — در برنامهٔ مقصد باز و به فایل قبلی الحاق کنید`,
        });
      }
      if (append) markExported();
    } catch {
      /* لغو اشتراک توسط کاربر */
    } finally {
      setBusy(null);
    }
  };

  const resetExportPoint = () => {
    try {
      localStorage.removeItem(LAST_EXPORT_KEY);
    } catch {
      /* ignore */
    }
    setLastExportAt(null);
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="اشتراک‌گذاری سوابق"
      subtitle="خروجی متنی به تفکیک خودرو — آخرین رکورد پایین فایل"
      footer={
        <div className="flex flex-col gap-2">
          <SubmitButton onClick={shareFile} disabled={busy !== null || exportData.count === 0}>
            {busy === "share" ? <Loader2 className="size-5 animate-spin" /> : <Share2 className="size-5" />}
            ارسال فایل متنی
          </SubmitButton>
          <button
            type="button"
            onClick={copyText}
            disabled={busy !== null || exportData.count === 0}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-input bg-card text-[16px] font-bold text-foreground transition-all active:scale-[.98] disabled:opacity-50"
          >
            {busy === "copy" ? <Loader2 className="size-5 animate-spin" /> : <Copy className="size-5" />}
            کپی متن
          </button>
        </div>
      }
    >
      {/* حالت خروجی: فایل جدید یا افزودنی به فایل قبلی */}
      <div className="mb-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setAppend(false)}
          className={cn(
            "flex flex-col items-center gap-1 rounded-2xl border-2 p-3 text-center transition-all active:scale-[.97]",
            !append ? "border-primary bg-primary/8" : "border-border bg-card"
          )}
        >
          <FilePlus2 className={cn("size-6", !append ? "text-primary" : "text-muted-foreground")} />
          <span className={cn("text-[13px] font-bold", !append ? "text-primary" : "text-foreground")}>فایل جدید</span>
          <span className="text-[10.5px] leading-4 text-muted-foreground">همه یا N رکورد اخیر</span>
        </button>
        <button
          type="button"
          onClick={() => setAppend(true)}
          className={cn(
            "flex flex-col items-center gap-1 rounded-2xl border-2 p-3 text-center transition-all active:scale-[.97]",
            append ? "border-primary bg-primary/8" : "border-border bg-card"
          )}
        >
          <History className={cn("size-6", append ? "text-primary" : "text-muted-foreground")} />
          <span className={cn("text-[13px] font-bold", append ? "text-primary" : "text-foreground")}>افزودن به فایل قبلی</span>
          <span className="text-[10.5px] leading-4 text-muted-foreground">فقط رکوردهای جدید</span>
        </button>
      </div>

      {append && (
        <div className="mb-3 rounded-2xl border border-primary/30 bg-primary/5 px-4 py-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[12.5px] leading-6 text-muted-foreground">
              {lastExportAt ? (
                <>
                  آخرین خروجی: <b className="text-foreground">{lastExportLabel}</b> — از آن زمان{" "}
                  <b className="text-primary">{fa(exportData.count)}</b> رکورد جدید دارید.
                </>
              ) : (
                "هنوز خروجی نگرفته‌اید — ابتدا «فایل جدید» را بگیرید تا نقطهٔ الحاق ثبت شود."
              )}
            </span>
            {lastExportAt && (
              <button
                type="button"
                onClick={resetExportPoint}
                aria-label="بازنشانی نقطهٔ الحاق"
                className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground active:scale-95"
              >
                <RotateCcw className="size-4" />
              </button>
            )}
          </div>
          {exportData.count === 0 && lastExportAt && (
            <p className="mt-1 text-[12px] font-bold text-amber-700 dark:text-amber-300">
              رکورد جدیدی از آخرین خروجی نیست.
            </p>
          )}
        </div>
      )}

      {/* انتخاب محدوده — فقط برای فایل جدید */}
      {!append && (
        <div className="mb-3">
          <p className="mb-1.5 px-1 text-[12.5px] font-bold text-foreground">انتخاب محدوده</p>
          <div className="flex gap-1.5 overflow-x-auto pb-1" style={{ scrollbarWidth: "thin" }}>
            {SCOPE_OPTIONS.map((s) => (
              <button
                key={s.value}
                type="button"
                onClick={() => setScope(s.value)}
                className={cn(
                  "shrink-0 rounded-full px-3.5 py-2 text-[12.5px] font-bold transition-colors active:scale-95",
                  scope === s.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground active:bg-primary/15"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* پیش‌نمایش متن */}
      <div className="mb-2 overflow-hidden rounded-2xl border border-border bg-card">
        <div className="flex items-center justify-between gap-2 border-b border-border/70 bg-muted/40 px-3.5 py-2">
          <span className="flex items-center gap-1.5 text-[11.5px] font-bold text-muted-foreground">
            <FileDown className="size-3.5" />
            پیش‌نمایش فایل متنی
          </span>
          <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
            {fa(exportData.count)} رکورد — {fa(exportData.vehicleCount)} خودرو
          </span>
        </div>
        <pre
          dir="rtl"
          className="max-h-56 overflow-y-auto whitespace-pre-wrap break-words px-3.5 py-3 text-right text-[11.5px] font-medium leading-6 text-foreground"
        >
          {exportData.text}
        </pre>
      </div>

      <p className="pb-2 text-center text-[11.5px] leading-6 text-muted-foreground">
        رکوردها به تفکیک خودرو و به ترتیب زمانی مرتب می‌شوند — آخرین سرویس همیشه پایین‌ترین سطر است تا
        افزودنی‌ها به انتهای فایل قبلی بچسبند.
      </p>
    </BottomSheet>
  );
}
