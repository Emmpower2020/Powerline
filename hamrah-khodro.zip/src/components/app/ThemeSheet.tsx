"use client";

/**
 * شیت انتخاب تم برنامه — ۴ تم زیبا و کم‌خستگی
 */

import * as React from "react";
import { Check, Moon, Sun, Sunset, Trees } from "lucide-react";
import { cn } from "@/lib/utils";
import { applyTheme, getStoredTheme, THEMES, type ThemeDef, type ThemeId } from "@/lib/theme";
import { BottomSheet } from "./BottomSheet";

const THEME_ICONS: Record<ThemeId, React.ElementType> = {
  emerald: Sun,
  midnight: Moon,
  sand: Sunset,
  forest: Trees,
};

function ThemeCard({
  def,
  active,
  onPick,
}: {
  def: ThemeDef;
  active: boolean;
  onPick: () => void;
}) {
  const Icon = THEME_ICONS[def.id];
  const p = def.preview;
  return (
    <button
      type="button"
      onClick={onPick}
      aria-pressed={active}
      className={cn(
        "flex flex-col overflow-hidden rounded-2xl border-2 text-right transition-all active:scale-[.97]",
        active
          ? "border-primary shadow-lg shadow-primary/15"
          : "border-border/80 hover:border-primary/40"
      )}
    >
      {/* پیش‌نمایش بصری تم */}
      <div className="relative p-3" style={{ background: p.bg }}>
        <div
          className="flex h-16 items-center gap-2 rounded-xl px-3"
          style={{ background: p.card, border: `1px solid ${p.line}` }}
        >
          <span
            className="flex size-9 shrink-0 items-center justify-center rounded-lg"
            style={{ background: p.primary }}
          >
            <Icon className="size-5" style={{ color: p.primaryFg }} strokeWidth={2.2} />
          </span>
          <span className="flex min-w-0 flex-1 flex-col gap-1.5">
            <span className="h-2 w-3/4 rounded-full" style={{ background: p.text, opacity: 0.85 }} />
            <span className="h-2 w-1/2 rounded-full" style={{ background: p.sub, opacity: 0.7 }} />
          </span>
          <span
            className="h-6 w-10 shrink-0 rounded-md"
            style={{ background: p.primary, opacity: 0.9 }}
          />
        </div>
        {active && (
          <span className="absolute left-4 top-4 flex size-6 items-center justify-center rounded-full bg-primary shadow-md">
            <Check className="size-4" style={{ color: p.primaryFg }} strokeWidth={3} />
          </span>
        )}
      </div>

      {/* نام و توضیح */}
      <div className="flex flex-col bg-card p-3">
        <span className="flex items-center gap-2">
          <Icon className="size-4 text-primary" />
          <span className={cn("text-[15px] font-bold", active ? "text-primary" : "text-foreground")}>
            {def.name}
          </span>
          {def.dark && (
            <span className="rounded-full bg-muted px-2 py-0.5 text-[10.5px] font-bold text-muted-foreground">
              تیره
            </span>
          )}
        </span>
        <span className="mt-1 text-[12px] leading-5 text-muted-foreground">{def.desc}</span>
      </div>
    </button>
  );
}

export function ThemeSheet({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [theme, setTheme] = React.useState<ThemeId>("emerald");

  React.useEffect(() => {
    if (open) setTheme(getStoredTheme());
  }, [open]);

  const pick = (id: ThemeId) => {
    applyTheme(id);
    setTheme(id);
  };

  return (
    <BottomSheet open={open} onClose={onClose} title="تم برنامه" subtitle="رنگ و حالت ظاهری — بلافاصله اعمال می‌شود">
      <div className="grid grid-cols-2 gap-3">
        {THEMES.map((t) => (
          <ThemeCard key={t.id} def={t} active={theme === t.id} onPick={() => pick(t.id)} />
        ))}
      </div>
      <p className="mt-3 pb-1 text-center text-[12px] leading-6 text-muted-foreground">
        انتخاب شما ذخیره می‌شود و در اجرای بعدی هم همین تم باز می‌شود.
      </p>
    </BottomSheet>
  );
}
