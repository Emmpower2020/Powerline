"use client";

/**
 * کادر «همهٔ فایل‌های پروژه» — شیت دانلود فایل‌ها + دکمهٔ دسترسی سریع
 * طبق مادهٔ ۴-۴ کتاب قانون: فایل‌ها از مسیر عمومی (public/) سرو می‌شوند و
 * دکمهٔ دانلود در خود سایت (همهٔ تب‌ها + تنظیمات) در دسترس است.
 */

import * as React from "react";
import {
  BookOpen,
  Braces,
  Download,
  FileJson,
  FolderDown,
  Image as ImageIcon,
  Loader2,
  Package,
  Smartphone,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { faNum } from "@/lib/persian";
import { APP_VERSION } from "@/lib/types";
import { BottomSheet } from "./BottomSheet";

export interface DownloadFile {
  name: string;
  path: string;
  size: number;
  label: string;
  desc: string;
  kind: "APK" | "ZIP" | "JSON" | "IMAGE" | "DOC";
  order: number;
  live: boolean;
}

/* -------------------- اندازهٔ فایل به فارسی -------------------- */

function formatSize(bytes: number): string {
  if (bytes <= 0) return "زنده";
  if (bytes < 1024) return `${faNum(bytes)} بایت`;
  if (bytes < 1024 * 1024) return `${faNum(Math.round(bytes / 1024))} کیلوبایت`;
  return `${faNum(bytes / (1024 * 1024), 1)} مگابایت`;
}

const KIND_ICONS: Record<DownloadFile["kind"], React.ElementType> = {
  APK: Smartphone,
  ZIP: Package,
  JSON: FileJson,
  IMAGE: ImageIcon,
  DOC: BookOpen,
};

/* -------------------- دکمهٔ دسترسی سریع (همهٔ تب‌ها) -------------------- */

export function FilesButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="فایل‌های پروژه — دانلود"
      title="فایل‌های پروژه"
      className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary/12 text-primary transition-all hover:bg-primary/20 active:scale-95"
    >
      <FolderDown className="size-5" strokeWidth={2} />
    </button>
  );
}

/* -------------------- بج نسخهٔ APK -------------------- */

/** نسخهٔ APK از نام فایل نسخه‌دار (hamrah-khodro-vX.Y.Z.apk) استخراج می‌شود */
function apkVersion(name: string): string | null {
  const m = /^hamrah-khodro-v(\d+\.\d+\.\d+)\.apk$/.exec(name);
  return m ? m[1] : null;
}

/* -------------------- ردیف فایل -------------------- */

function FileRow({ file }: { file: DownloadFile }) {
  const Icon = KIND_ICONS[file.kind] ?? BookOpen;
  const isApk = file.kind === "APK";
  const version = apkVersion(file.name);
  const isOriginal = file.name === "hamrah-khodro-original.apk";
  const isNewest = isApk && version !== null && file.order < 2 && !isOriginal;

  return (
    <a
      href={file.path}
      download={file.name}
      className={cn(
        "flex w-full items-center gap-3.5 rounded-2xl border p-4 text-right shadow-sm transition-all active:scale-[.98]",
        isApk
          ? "border-primary/45 bg-primary/8 hover:border-primary/60"
          : "border-border/80 bg-card hover:border-primary/40"
      )}
    >
      {/* آیکون یا بندانگشتی تصویر */}
      {file.kind === "IMAGE" ? (
         
        <img
          src={file.path}
          alt={file.label}
          className="size-12 shrink-0 rounded-xl border border-border/70 object-cover"
        />
      ) : (
        <span
          className={cn(
            "flex size-12 shrink-0 items-center justify-center rounded-xl",
            isApk ? "bg-primary/15" : "bg-primary/10"
          )}
        >
          <Icon className={cn("text-primary", isApk ? "size-6" : "size-5")} strokeWidth={2} />
        </span>
      )}

      {/* نام و توضیح */}
      <span className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="flex items-center gap-1.5">
          <span className="truncate text-[16px] font-bold text-foreground">{file.label}</span>
          {isApk && (
            <span
              className={cn(
                "shrink-0 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                isNewest
                  ? "bg-primary text-primary-foreground"
                  : "bg-primary/15 text-primary"
              )}
            >
              {isOriginal ? "اصلی" : version ? `v${version}${isNewest ? " · جدید" : ""}` : "ساخته‌شده"}
            </span>
          )}
        </span>
        <span className="truncate text-[12px] text-muted-foreground">{file.desc}</span>
        <span className="mt-0.5 text-[11.5px] font-bold tabular-nums text-muted-foreground/80">
          {formatSize(file.size)}
        </span>
      </span>

      {/* دکمهٔ دانلود */}
      <span
        className={cn(
          "flex size-11 shrink-0 items-center justify-center rounded-xl text-[12px] font-extrabold",
          isApk
            ? "bg-primary text-primary-foreground"
            : "bg-primary/12 text-primary"
        )}
      >
        <Download className="size-5" strokeWidth={2.2} />
      </span>
    </a>
  );
}

/* -------------------- شیت اصلی -------------------- */

export function FilesSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [files, setFiles] = React.useState<DownloadFile[] | null>(null);
  const [failed, setFailed] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setFiles(null);
    setFailed(false);
    fetch("/api/files")
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setFiles(Array.isArray(d.files) ? d.files : []);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [open]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="فایل‌های پروژه"
      subtitle="همهٔ فایل‌های قابل دانلود"
      maxHeight="max-h-[85dvh]"
      footer={
        <div className="flex items-center justify-between gap-2 text-[11.5px] font-bold text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Braces className="size-3.5" />
            نسخهٔ {APP_VERSION}
          </span>
          <span>لینک فایل‌ها در چت و مسیر عمومی سایت هم موجود است</span>
        </div>
      }
    >
      {/* بارگذاری */}
      {files === null && !failed && (
        <div className="flex flex-col items-center gap-3 py-14">
          <Loader2 className="size-8 animate-spin text-primary" />
          <p className="text-[14px] font-bold text-muted-foreground">در حال دریافت فهرست فایل‌ها...</p>
        </div>
      )}

      {/* خطا */}
      {failed && (
        <div className="flex flex-col items-center gap-3 py-14 text-center">
          <p className="text-[15px] font-bold text-foreground">فهرست فایل‌ها دریافت نشد</p>
          <button
            type="button"
            onClick={() => {
              setFailed(false);
              setFiles(null);
              fetch("/api/files")
                .then((r) => r.json())
                .then((d) => setFiles(Array.isArray(d.files) ? d.files : []))
                .catch(() => setFailed(true));
            }}
            className="h-11 rounded-xl bg-primary px-6 text-[14px] font-bold text-primary-foreground transition-all active:scale-95"
          >
            تلاش دوباره
          </button>
        </div>
      )}

      {/* فهرست */}
      {files !== null && (
        <div className="flex flex-col gap-2.5 pb-2">
          {files.map((f) => (
            <FileRow key={f.path} file={f} />
          ))}
          {files.length === 0 && (
            <p className="py-12 text-center text-[15px] text-muted-foreground">
              فایلی برای دانلود موجود نیست
            </p>
          )}
        </div>
      )}
    </BottomSheet>
  );
}
