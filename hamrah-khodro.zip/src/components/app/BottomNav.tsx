"use client";

/**
 * نوار ناوبری پایین + دکمه شناور افزودن
 */

import * as React from "react";
import { Bell, ChartLine, History, Plus, Settings2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";

export type TabKey = "reports" | "records" | "reminders" | "settings";

const TABS: { key: TabKey; label: string; icon: React.ElementType }[] = [
  { key: "reports", label: "گزارشات", icon: ChartLine },
  { key: "records", label: "سوابق", icon: History },
  { key: "reminders", label: "یادآورها", icon: Bell },
  { key: "settings", label: "تنظیمات", icon: Settings2 },
];

export function BottomNav({
  active,
  onChange,
  remindersBadge,
  onAdd,
}: {
  active: TabKey;
  onChange: (t: TabKey) => void;
  remindersBadge: number;
  onAdd: () => void;
}) {
  return (
    <nav
      aria-label="ناوبری اصلی"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-border/70 bg-background/95 backdrop-blur-md"
    >
      <div className="relative mx-auto flex max-w-md items-stretch justify-between px-2 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1.5">
        {TABS.slice(0, 2).map((t) => (
          <NavItem key={t.key} tab={t} active={active === t.key} onClick={() => onChange(t.key)} />
        ))}

        {/* دکمه شناور افزودن */}
        <div className="relative w-20">
          <button
            type="button"
            onClick={onAdd}
            aria-label="افزودن رکورد جدید"
            className="absolute -top-6 right-1/2 flex size-16 translate-x-1/2 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 ring-4 ring-background transition-transform active:scale-90"
          >
            <Plus className="size-8" strokeWidth={2.5} />
          </button>
        </div>

        {TABS.slice(2).map((t) => (
          <NavItem
            key={t.key}
            tab={t}
            active={active === t.key}
            badge={t.key === "reminders" ? remindersBadge : 0}
            onClick={() => onChange(t.key)}
          />
        ))}
      </div>
    </nav>
  );
}

function NavItem({
  tab,
  active,
  badge,
  onClick,
}: {
  tab: { key: TabKey; label: string; icon: React.ElementType };
  active: boolean;
  badge?: number;
  onClick: () => void;
}) {
  const Icon = tab.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex h-14 min-w-[4.5rem] flex-1 flex-col items-center justify-center gap-1 rounded-xl transition-colors active:scale-95",
        active ? "text-primary" : "text-muted-foreground"
      )}
    >
      <span className="relative">
        <span
          className={cn(
            "flex items-center justify-center rounded-full px-4 py-1 transition-colors",
            active && "bg-primary/12"
          )}
        >
          <Icon className="size-[22px]" strokeWidth={active ? 2.2 : 1.8} />
        </span>
        {badge !== undefined && badge > 0 && (
          <span className="absolute -left-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white ring-2 ring-background">
            {fa(Math.min(badge, 99))}
          </span>
        )}
      </span>
      <span className={cn("text-[12px]", active ? "font-bold" : "font-medium")}>{tab.label}</span>
    </button>
  );
}
