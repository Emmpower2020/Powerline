"use client";

/**
 * فیلدهای فرم موبایل‌پسند — طراحی بازسازی‌شده از تصویر مرجع کاربر:
 *  - فیلدهای تک‌ردیفی (inline): عنوان بیرون کادر در سمت راست، کادر کوچک‌تر (≈ دو سوم عرض) سمت چپ
 *  - فیلدهای چندردیفی (block): عنوان بالای محتوا داخل کادر — برای گریدها و محتوای چندخطی
 *  - دور کادرها حاشیهٔ رنگی تم (border-input) + فوکوس با اکسنت
 *  - همهٔ لیست‌ها/فیلترها از شیت کشیدنیِ جستجوپذیر (PickerSheet + BottomSheet) استفاده می‌کنند
 */

import * as React from "react";
import { CalendarDays, Check, ChevronDown, Loader2, Plus, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { en, faNum, fa, formatJalali, normFa, todayJalali, toJalaali, jalaliToISO, type PersianDate } from "@/lib/persian";
import { PersianWheelDatePicker } from "@/components/persian-calendar/PersianWheelDatePicker";
import { BottomSheet } from "./BottomSheet";
import { useToast } from "@/hooks/use-toast";

/* ───────────────────────── FieldCtx ───────────────────────── */

/** فرزندان داخل Field بدون حاشیهٔ خودشان رندر می‌شوند (حاشیه از والد می‌آید) */
const FieldCtx = React.createContext(false);
const useInField = () => React.useContext(FieldCtx);

/* ─────────────────────────── Field ─────────────────────────── */

export function Field({
  label,
  hint,
  required,
  children,
  className,
  layout = "inline",
}: {
  label: string;
  hint?: string;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
  /** inline: عنوان بیرون کادر سمت راست و کادر (≈ دو سوم عرض) سمت چپ — block: عنوان بالای محتوا داخل کادر (گرید/چندردیفی) */
  layout?: "inline" | "block";
}) {
  if (layout === "inline") {
    // عنوان بیرون از کادر، سمت راست — کادر کوچک‌تر (≈ دو سوم عرض صفحه) سمت چپ
    return (
      <div className={cn("mb-2.5", className)}>
        <div className="flex items-center gap-2">
          <label className="w-[34%] shrink-0 text-[13.5px] font-bold leading-[1.4] text-foreground">
            {label}
            {required && <span className="text-destructive">*</span>}
          </label>
          <FieldCtx.Provider value={true}>
            <div
              className={cn(
                "flex min-h-[54px] min-w-0 flex-1 flex-wrap items-center gap-2.5 gap-y-2 rounded-2xl border border-input bg-card px-3.5 py-2 transition-all",
                "focus-within:border-primary focus-within:shadow-[0_0_0_3px] focus-within:shadow-primary/15"
              )}
            >
              {children}
            </div>
          </FieldCtx.Provider>
        </div>
        {hint && <p className="mt-1.5 text-[11.5px] leading-5 text-muted-foreground">{hint}</p>}
      </div>
    );
  }
  return (
    <div className={cn("mb-2.5", className)}>
      <div
        className={cn(
          "w-full rounded-2xl border border-input bg-card px-3.5 py-3 transition-all",
          "focus-within:border-primary focus-within:shadow-[0_0_0_3px] focus-within:shadow-primary/15"
        )}
      >
        <FieldCtx.Provider value={true}>
          <label className="mb-2 flex items-center gap-1 text-[13.5px] font-bold leading-5 text-foreground">
            {label}
            {required && <span className="text-destructive">*</span>}
          </label>
          <div className="flex w-full flex-col gap-2">{children}</div>
        </FieldCtx.Provider>
      </div>
      {hint && <p className="mt-1.5 text-[11.5px] leading-5 text-muted-foreground">{hint}</p>}
    </div>
  );
}

/* ─────────────────────── GridCell — خانه‌های گرید ۲×۲ ─────────────────────── */

/**
 * خانهٔ فشردهٔ گرید ۲×۲ مطابق موکاپ کاربر: عنوان + آیکون + مقدار همه درون یک کادر کوتاه تک‌ردیفی.
 * نمونه: خودرو 🚗 تیبا ۲ ˅ | تاریخ 📅 ۱۴۰۵/۰۹/۱۴ | کارکرد ⚙ ۱۶۲٬۵۰۰ | نوع سرویس 🏷 تعویض روغن موتور ˅
 * اگر onClick بدهید کل کادر دکمه می‌شود (برای انتخاب‌گرها)؛ در غیر این صورت کادر ورودی است.
 */
export function GridCell({
  label,
  icon: Icon,
  onClick,
  chevron = false,
  ariaLabel,
  children,
  className,
}: {
  label: string;
  icon: React.ElementType;
  onClick?: () => void;
  chevron?: boolean;
  ariaLabel?: string;
  children?: React.ReactNode;
  className?: string;
  /** label خالی = بدون عنوان کوچک — برای خانه‌هایی که خودِ مقدار/جای‌نگهدار معنا را می‌رسانند */
  /** (مثل نوع سرویس: جای‌نگهدار «نوع سرویس» → نام کامل سرویس) */
}) {
  const cls = cn(
    "flex h-12 min-w-0 items-center gap-1.5 rounded-xl border bg-card px-2.5 text-right transition-all",
    onClick ? "border-input active:scale-[.98] active:bg-muted/50" : "border-input focus-within:border-primary focus-within:shadow-[0_0_0_3px] focus-within:shadow-primary/15",
    className
  );
  const inner = (
    <>
      {label ? (
        <span className="shrink-0 text-[11px] font-bold leading-none text-muted-foreground">{label}</span>
      ) : null}
      <Icon className="size-4 shrink-0 text-primary" strokeWidth={2.2} />
      <span className="flex min-w-0 flex-1 items-center gap-1">{children}</span>
      {chevron && <ChevronDown className="size-3.5 shrink-0 text-muted-foreground" />}
    </>
  );
  if (onClick) {
    return (
      <button type="button" onClick={onClick} aria-label={ariaLabel ?? label} className={cls}>
        {inner}
      </button>
    );
  }
  return <div className={cls}>{inner}</div>;
}

/* ────────────────────────── TextInput ────────────────────────── */

export function TextInput({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  const inline = useInField();
  if (inline) {
    return (
      <input
        dir="auto"
        className={cn(
          "h-11 w-full bg-transparent text-right text-[15.5px] text-foreground placeholder:font-normal placeholder:text-muted-foreground/70 focus:outline-none",
          className
        )}
        {...props}
      />
    );
  }
  return (
    <input
      dir="auto"
      className={cn(
        "h-12 w-full rounded-2xl border border-input bg-card px-4 text-[15.5px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:shadow-[0_0_0_3px] focus:shadow-primary/15",
        className
      )}
      {...props}
    />
  );
}

/* ────────────────────────── TextArea ────────────────────────── */

export function TextArea({
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const inline = useInField();
  if (inline) {
    return (
      <textarea
        dir="auto"
        rows={2}
        className={cn(
          "w-full resize-none bg-transparent py-1.5 text-right text-[15px] leading-7 text-foreground placeholder:font-normal placeholder:text-muted-foreground/70 focus:outline-none",
          className
        )}
        {...props}
      />
    );
  }
  return (
    <textarea
      dir="auto"
      rows={2}
      className={cn(
        "w-full resize-none rounded-2xl border border-input bg-card px-4 py-3 text-[15px] leading-7 text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:shadow-[0_0_0_3px] focus:shadow-primary/15",
        className
      )}
      {...props}
    />
  );
}

/* ───────────────────────── NumberInput ───────────────────────── */

interface NumberInputProps {
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder?: string;
  suffix?: string;
  decimal?: boolean;
  /** نمایش بدون جداکنندهٔ هزارگان — برای اعدادی مثل سال */
  plain?: boolean;
  min?: number;
  max?: number;
  autoFocus?: boolean;
  className?: string;
}

/** ورودی عددی با نمایش اعداد فارسی و جداکننده هزارگان — صفر نمایش داده نمی‌شود
 * ⭐ v3.9.0: «واردکردن عدد» واقعاً ممکن شد (بازخورد کاربر: «توی یادآور نمی‌توان کیلومتر را وارد کرد»):
 *  - با فوکوس، کل عدد «انتخاب» می‌شود → نخستین رقم تایپی همهٔ مقدار قبلی (پیشنهاد خودکار)
 *    را یک‌جا جایگزین می‌کند (قبلاً رقم به انتهای ۱۷۲٬۵۰۰ می‌چسبید و عدد نجومی می‌شد)
 *  - حین تایپ فقط ارقام بدون جداکنندهٔ هزارگان نمایش داده می‌شود (جداکننده + جابه‌جایی
 *    مکرر مکان‌نما، ویرایش را روی گوشی عملاً ناممکن می‌کرد)؛ بعد از blur فرمت کامل برمی‌گردد */
export function NumberInput({
  value,
  onChange,
  placeholder,
  suffix,
  decimal = false,
  plain = false,
  min = 0,
  max = 1_000_000_000_000,
  autoFocus,
  className,
}: NumberInputProps) {
  const [focused, setFocused] = React.useState(false);
  // متن خام برای تایپ روان (ارقام لاتین)
  const [raw, setRaw] = React.useState<string>(() => (value === null ? "" : String(value)));
  const inputRef = React.useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (!focused) setRaw(value === null ? "" : String(value));
  }, [value, focused]);

  // ⭐ v3.9.0: با فوکوس، کل مقدار انتخاب می‌شود — تایپ بلافاصله جایگزین می‌کند
  React.useEffect(() => {
    if (focused && inputRef.current) {
      const t = window.setTimeout(() => {
        try {
          inputRef.current?.select();
        } catch {
          /* ignore */
        }
      }, 0);
      return () => window.clearTimeout(t);
    }
  }, [focused]);

  // نمایش: بدون جداکنندهٔ هزارگان (plain — مثل سال) یا با جداکننده
  const fmt = (n: number) => (plain ? fa(n) : faNum(n, decimal ? 1 : 0));
  // ⭐ v3.9.0: حین فوکوس فقط ارقام خام (فارسی) بدون جداکنندهٔ هزارگان — ویرایش و جایگزینی ساده
  const display =
    focused && raw !== ""
      ? fa(raw)
      : focused
        ? ""
        : value === null
          ? ""
          : decimal
            ? fa(String(value))
            : fmt(value);

  const handle = (text: string) => {
    // فارسی/عربی → لاتین؛ فقط رقم و نقطه
    let t = en(text).replace(/[^\d.]/g, "");
    if (decimal) {
      const parts = t.split(".");
      t = parts.length > 1 ? parts[0] + "." + parts.slice(1).join("").slice(0, 2) : t;
    } else {
      t = t.replace(/\./g, "");
    }
    setRaw(t);
    if (t === "" || t === ".") {
      onChange(null);
      return;
    }
    const n = Number(t);
    if (Number.isFinite(n) && n >= min && n <= max) {
      onChange(decimal ? n : Math.round(n));
    }
  };

  const inline = useInField();
  if (inline) {
    return (
      <div className="flex min-w-0 flex-1 items-center justify-end gap-1.5">
        <input
          ref={inputRef}
          dir="ltr"
          inputMode={decimal ? "decimal" : "numeric"}
          autoFocus={autoFocus}
          value={display}
          placeholder={placeholder ?? ""}
          onFocus={() => setFocused(true)}
          onBlur={() => {
            setFocused(false);
            if (raw === "" || raw === ".") onChange(null);
          }}
          onChange={(e) => handle(e.target.value)}
          className={cn(
            "h-11 w-full min-w-0 bg-transparent text-right text-[16px] font-bold tabular-nums text-foreground placeholder:font-normal placeholder:text-muted-foreground/60 focus:outline-none",
            className
          )}
        />
        {suffix && (
          <span className="shrink-0 text-[12.5px] font-medium text-muted-foreground">{suffix}</span>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <input
        ref={inputRef}
        dir="ltr"
        inputMode={decimal ? "decimal" : "numeric"}
        autoFocus={autoFocus}
        value={display}
        placeholder={placeholder ?? ""}
        onFocus={() => setFocused(true)}
        onBlur={() => {
          setFocused(false);
          if (raw === "" || raw === ".") onChange(null);
        }}
        onChange={(e) => handle(e.target.value)}
        className={cn(
          "h-12 w-full rounded-2xl border border-input bg-card px-4 text-center text-[16.5px] font-bold tabular-nums text-foreground placeholder:font-normal placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:shadow-[0_0_0_3px] focus:shadow-primary/15",
          suffix ? "pl-16" : "",
          className
        )}
      />
      {suffix && (
        <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[12.5px] font-medium text-muted-foreground">
          {suffix}
        </span>
      )}
    </div>
  );
}

/* ─────────────────────────── DateField ─────────────────────────── */

export function DateField({
  value,
  onChange,
  label = "تاریخ",
  title = "انتخاب تاریخ",
}: {
  value: string; // ISO
  onChange: (iso: string) => void;
  label?: string;
  title?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [draft, setDraft] = React.useState<PersianDate | null>(null);

  React.useEffect(() => {
    if (open) {
      const [y, m, d] = value.slice(0, 10).split("-").map(Number);
      setDraft(toJalaali(y, m, d));
    }
  }, [open, value]);

  return (
    <>
      <Field label={label}>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="flex h-11 w-full items-center justify-end gap-2 bg-transparent text-right text-[15.5px] font-medium text-foreground focus:outline-none"
        >
          {formatJalali(draftFor(value))}
          <CalendarDays className="size-5 shrink-0 text-primary" />
        </button>
      </Field>
      <PersianWheelDatePicker
        open={open}
        value={draft ?? draftFor(value)}
        onConfirm={(j) => {
          onChange(jalaliToISO(j));
          setOpen(false);
        }}
        onCancel={() => setOpen(false)}
        title={title}
      />
    </>
  );
}

function draftFor(iso: string): PersianDate {
  try {
    const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
    return toJalaali(y, m, d);
  } catch {
    return todayJalali();
  }
}

/* ─────────────────────────── OptionItem ─────────────────────────── */

export interface OptionItem {
  value: string;
  label: string;
  color?: string; // نقطه رنگی کنار گزینه
}

/* ──────────────────── PickerSheet — شیت انتخاب جستجوپذیر کشیدنی ──────────────────── */

/**
 * شیت عمومی انتخاب از لیست — همیشه جستجوپذیر + کشیدنی (BottomSheet).
 * برای همهٔ لیست‌ها و فیلترهای برنامه استفاده می‌شود.
 */
export function PickerSheet({
  open,
  onClose,
  title,
  subtitle,
  options,
  value,
  onChange,
  searchPlaceholder = "جستجو...",
  emptyText = "موردی یافت نشد!",
  maxHeight = "max-h-[82dvh]",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  options: OptionItem[];
  value: string | null;
  onChange: (v: string) => void;
  searchPlaceholder?: string;
  emptyText?: string;
  maxHeight?: string;
}) {
  const [q, setQ] = React.useState("");

  React.useEffect(() => {
    if (open) setQ("");
  }, [open]);

  const qTrim = q.trim();
  const filtered = qTrim
    ? options.filter((o) => o.label.includes(qTrim) || o.value.includes(qTrim))
    : options;

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={title}
      subtitle={subtitle}
      maxHeight={maxHeight}
    >
      <div className="relative mb-3">
        <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
        <input
          dir="rtl"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={searchPlaceholder}
          className="h-12 w-full rounded-2xl border border-input bg-card pr-11 pl-4 text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:shadow-[0_0_0_3px] focus:shadow-primary/15"
        />
      </div>
      <div className="max-h-[58dvh] overflow-y-auto overscroll-contain pb-2">
        {filtered.length === 0 ? (
          <p className="py-8 text-center text-[15px] text-muted-foreground">{emptyText}</p>
        ) : (
          filtered.map((o) => {
            const isSelected = o.value === value;
            return (
              <button
                key={o.value}
                type="button"
                onClick={() => {
                  onChange(o.value);
                  onClose();
                }}
                className={cn(
                  "mb-1 flex h-[52px] w-full items-center gap-2.5 rounded-xl px-3.5 text-right transition-colors active:scale-[.99]",
                  isSelected ? "bg-primary/10" : "hover:bg-muted/60"
                )}
              >
                {o.color ? (
                  <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: o.color }} />
                ) : (
                  <span
                    className={cn(
                      "size-2.5 shrink-0 rounded-full",
                      isSelected ? "bg-primary" : "bg-muted-foreground/25"
                    )}
                  />
                )}
                <span
                  className={cn(
                    "flex-1 truncate text-[16px]",
                    isSelected ? "font-bold text-primary" : "font-medium text-foreground"
                  )}
                >
                  {o.label}
                </span>
                {isSelected && <Check className="size-5 shrink-0 text-primary" />}
              </button>
            );
          })
        )}
      </div>
    </BottomSheet>
  );
}

/* ─────────────── ComboCell — خانهٔ گرید کشویی + افزودن گزینه جدید ─────────────── */

export interface ComboOption {
  value: string;
  label: string;
}

/**
 * خانهٔ کشویی گرید ۲×۲ (مشابه ثبت سرویس): کادر فشرده با عنوان + آیکون + مقدار + فلش؛
 * با لمس، شیت جستجوپذیر باز می‌شود. اگر allowAdd فعال باشد و گزینه‌ای موجود نبود،
 * همان‌جا می‌توان گزینهٔ جدید نوشت و اضافه کرد (onAdd — ذخیرهٔ دائمی بر عهدهٔ فراخواننده).
 */
export function ComboCell({
  label,
  icon: Icon,
  value,
  options,
  onPick,
  onAdd,
  sheetTitle,
  sheetSubtitle,
  sheetHeader,
  placeholder = "انتخاب کنید",
  searchPlaceholder = "جستجو...",
  emptyText = "موردی یافت نشد!",
  allowAdd = false,
  addLabel = "افزودن مورد جدید",
  cellClassName,
  listMaxH = "max-h-[312px]",
  ariaLabel,
}: {
  label: string;
  icon: React.ElementType;
  /** مقدار فعلی (value گزینه) — اگر خارج از options باشد، خودش نمایش داده می‌شود */
  value: string | null;
  options: ComboOption[];
  /** انتخاب از فهرست */
  onPick: (value: string, label: string) => void;
  /** افزودن گزینهٔ جدید — true یعنی موفق (شیت بسته می‌شود) */
  onAdd?: (text: string) => Promise<boolean> | boolean;
  sheetTitle?: string;
  sheetSubtitle?: string;
  /** محتوای اختیاری بالای جستجو (مثل کلید شمسی/میلادی سال) */
  sheetHeader?: React.ReactNode;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  allowAdd?: boolean;
  addLabel?: string;
  cellClassName?: string;
  listMaxH?: string;
  ariaLabel?: string;
}) {
  const { toast } = useToast();
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const searchRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (open) setQ("");
  }, [open]);

  const qTrim = q.trim();
  const qNorm = normFa(q);
  const filtered = qNorm
    ? options.filter((o) => normFa(o.label).includes(qNorm) || normFa(o.value).includes(qNorm))
    : options;
  const selected = options.find((o) => o.value === value);
  const exactExists = options.some((o) => o.value === qTrim);

  const doAdd = async () => {
    if (!onAdd) return;
    if (!qTrim) {
      searchRef.current?.focus();
      toast({ title: "نام گزینه را بنویسید" });
      return;
    }
    setBusy(true);
    try {
      const ok = await onAdd(qTrim);
      if (ok !== false) {
        setQ("");
        setOpen(false);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <GridCell
        label={label}
        icon={Icon}
        chevron
        onClick={() => setOpen(true)}
        ariaLabel={ariaLabel ?? `${sheetTitle ?? label} — انتخاب`}
        className={cn("h-auto min-h-12", cellClassName)}
      >
        {selected ? (
          <span className="truncate text-[13px] font-bold text-foreground">{selected.label}</span>
        ) : value ? (
          <span className="truncate text-[13px] font-bold text-foreground">{value}</span>
        ) : (
          <span className="truncate text-[13px] font-medium text-muted-foreground">{placeholder}</span>
        )}
      </GridCell>

      <BottomSheet
        open={open}
        onClose={() => setOpen(false)}
        title={sheetTitle ?? label}
        subtitle={sheetSubtitle}
        maxHeight="max-h-[85dvh]"
      >
        {sheetHeader}

        {/* جستجو */}
        <div className="relative mb-3">
          <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <input
            ref={searchRef}
            dir="rtl"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={searchPlaceholder}
            className="h-12 w-full rounded-xl border border-input bg-background pr-11 pl-4 text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary/60 focus:outline-none focus:ring-[3px] focus:ring-primary/15"
          />
        </div>

        {/* فهرست گزینه‌ها */}
        <div className={cn(listMaxH, "overflow-y-auto overscroll-contain pb-2")}>
          {filtered.length === 0 ? (
            <p className="py-8 text-center text-[15px] leading-7 text-muted-foreground">
              {emptyText}
              {allowAdd && qTrim ? <span className="block text-[13px]">«{qTrim}» را با دکمهٔ پایین اضافه کنید</span> : null}
            </p>
          ) : (
            filtered.map((o) => {
              const isSelected = o.value === value;
              return (
                <button
                  key={o.value}
                  type="button"
                  onClick={() => {
                    onPick(o.value, o.label);
                    setOpen(false);
                  }}
                  className={cn(
                    "mb-1 flex h-12 w-full items-center gap-2.5 rounded-xl px-3.5 text-right transition-colors active:scale-[.99]",
                    isSelected ? "bg-primary/10" : "hover:bg-muted/60"
                  )}
                >
                  <span
                    className={cn(
                      "size-2.5 shrink-0 rounded-full",
                      isSelected ? "bg-primary" : "bg-muted-foreground/25"
                    )}
                  />
                  <span
                    className={cn(
                      "flex-1 truncate text-[16px]",
                      isSelected ? "font-bold text-primary" : "font-medium text-foreground"
                    )}
                  >
                    {o.label}
                  </span>
                  {isSelected && <Check className="size-5 shrink-0 text-primary" />}
                </button>
              );
            })
          )}
        </div>

        {/* افزودن گزینهٔ جدید — همیشه در پایان لیست */}
        {allowAdd && (
          <button
            type="button"
            onClick={doAdd}
            disabled={busy}
            className="mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-primary/45 bg-primary/5 text-[14px] font-bold text-primary transition-colors active:bg-primary/10 disabled:opacity-50"
          >
            {busy ? <Loader2 className="size-4.5 animate-spin" /> : <Plus className="size-4.5" />}
            {qTrim && !exactExists ? `افزودن «${qTrim}»` : addLabel}
          </button>
        )}
      </BottomSheet>
    </>
  );
}

/* ───────────────────── OptionPicker — دکمه + PickerSheet ───────────────────── */

/** انتخاب‌گر گزینه‌ای — کادر با عنوان سمت راست + شیت جستجوپذیر کشیدنی */
export function OptionPicker({
  value,
  options,
  onChange,
  label,
  sheetTitle,
  placeholder = "انتخاب کنید",
  hint,
  required,
}: {
  value: string | null;
  options: OptionItem[];
  onChange: (v: string) => void;
  label?: string;
  sheetTitle?: string;
  placeholder?: string;
  hint?: string;
  required?: boolean;
}) {
  const [open, setOpen] = React.useState(false);

  const selected = options.find((o) => o.value === value);

  const trigger = (
    <button
      type="button"
      onClick={() => setOpen(true)}
      className="flex h-11 w-full items-center justify-end gap-2 bg-transparent text-right focus:outline-none"
    >
      <span
        className={cn(
          "flex min-w-0 items-center gap-2 truncate text-[15.5px]",
          selected ? "font-medium text-foreground" : "text-muted-foreground"
        )}
      >
        {selected?.color && (
          <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: selected.color }} />
        )}
        <span className="truncate">{selected ? selected.label : placeholder}</span>
      </span>
      <ChevronDown className="size-5 shrink-0 text-muted-foreground" />
    </button>
  );

  return (
    <>
      {label ? (
        <Field label={label} hint={hint} required={required}>
          {trigger}
        </Field>
      ) : (
        <div className="mb-2.5">
          <div className="flex min-h-[54px] w-full items-center gap-2.5 rounded-2xl border border-input bg-card px-3.5 py-2 transition-all focus-within:border-primary">
            {trigger}
          </div>
        </div>
      )}
      <PickerSheet
        open={open}
        onClose={() => setOpen(false)}
        title={sheetTitle ?? "انتخاب گزینه"}
        options={options}
        value={value}
        onChange={onChange}
      />
    </>
  );
}

/* ────────────────────────── SwitchRow ────────────────────────── */

export function SwitchRow({
  label,
  hint,
  checked,
  onCheckedChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="mb-2.5 flex items-center justify-between gap-4 rounded-2xl border border-input bg-card px-4 py-3">
      <div className="min-w-0">
        <div className="text-[14.5px] font-bold text-foreground">{label}</div>
        {hint && <div className="mt-0.5 text-[12px] leading-5 text-muted-foreground">{hint}</div>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onCheckedChange(!checked)}
        className={cn(
          "relative h-7 w-12 shrink-0 rounded-full transition-colors",
          checked ? "bg-primary" : "bg-input"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-6 rounded-full bg-white shadow transition-all",
            checked ? "right-0.5" : "right-[calc(100%-1.75rem)]"
          )}
        />
      </button>
    </div>
  );
}

/* ───────────────────────── SubmitButton ───────────────────────── */

export function SubmitButton({
  children,
  disabled,
  onClick,
  className,
}: {
  children: React.ReactNode;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      type="submit"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex h-13 w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-[16px] font-bold text-primary-foreground shadow-md shadow-primary/20 transition-all active:scale-[.98] disabled:opacity-50",
        className
      )}
    >
      {children}
    </button>
  );
}

/* ─────────────────────────── helper ─────────────────────────── */

export function digitsPreview(n: number | null, suffix = ""): string {
  return n === null ? "" : `${fa(faNum(n))}${suffix ? " " + suffix : ""}`;
}
