"use client";

/**
 * خوش‌آمد اولین بار — وقتی هیچ خودرویی ثبت نشده
 */

import * as React from "react";
import { Car, Plus, Fuel, Wrench, Bell, Gauge } from "lucide-react";
import { fa } from "@/lib/persian";
import { APP_NAME } from "@/lib/types";

export function Onboarding({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center px-6 py-10 text-center">
      {/* لوگو */}
      <div className="flex size-32 items-center justify-center rounded-full bg-primary/10">
        <div className="flex size-24 items-center justify-center rounded-full bg-primary/15">
          <Car className="size-12 text-primary" strokeWidth={1.8} />
        </div>
      </div>

      <h1 className="mt-6 text-[28px] font-extrabold text-foreground">{APP_NAME}</h1>
      <p className="mt-2 max-w-[300px] text-[15px] leading-8 text-muted-foreground">
        مدیریت سرویس، سوخت، یادآور و کیلومتر خودرو — ساده، سریع و همیشه همراه شما.
      </p>

      {/* قابلیت‌ها */}
      <div className="mt-8 grid w-full max-w-sm grid-cols-2 gap-2.5">
        {[
          { icon: Wrench, label: "ثبت سرویس", desc: "روغن، ترمز، تسمه..." },
          { icon: Fuel, label: "ثبت سوخت", desc: "با محاسبه مصرف" },
          { icon: Bell, label: "یادآور", desc: "تاریخ یا کیلومتر" },
          { icon: Gauge, label: "کیلومتر", desc: "به‌روز و دقیق" },
        ].map((f) => {
          const Icon = f.icon;
          return (
            <div
              key={f.label}
              className="flex flex-col items-center rounded-2xl border border-border/70 bg-card p-4 shadow-sm"
            >
              <Icon className="size-7 text-primary" strokeWidth={1.9} />
              <div className="mt-2 text-[14px] font-bold text-foreground">{f.label}</div>
              <div className="mt-0.5 text-[11.5px] text-muted-foreground">{f.desc}</div>
            </div>
          );
        })}
      </div>

      <button
        type="button"
        onClick={onAdd}
        className="mt-9 flex h-14 w-full max-w-sm items-center justify-center gap-2 rounded-2xl bg-primary text-[17px] font-bold text-primary-foreground shadow-xl shadow-primary/30 transition-transform active:scale-[.97]"
      >
        <Plus className="size-6" strokeWidth={2.5} />
        افزودن اولین خودرو
      </button>

      <p className="mt-4 text-[12px] text-muted-foreground">
        تنها یک نام و کیلومتر فعلی کافی است — {fa(1)} دقیقه کمتر!
      </p>
    </div>
  );
}
