"use client";

/**
 * فرم ثبت/ویرایش یادآور — چینش مشابه ثبت سرویس (گرید ۲×۲ فشرده):
 *  خودرو / نوع یادآوری / تاریخ هدف یا کیلومتر هدف / تکرر → عنوان (+ پیشنهادها) → یادداشت
 */

import * as React from "react";
import { Loader2, Save, Car, Bell, CalendarDays, Gauge, Repeat } from "lucide-react";
import { BottomSheet } from "./BottomSheet";
import {
  ComboCell,
  Field,
  GridCell,
  NumberInput,
  PickerSheet,
  SubmitButton,
  TextArea,
  TextInput,
} from "./fields";
import {
  fa,
  formatJalaliISO,
  formatJalaliNumericISO,
  isoToJalali,
  jalaliToISO,
  todayISO,
  faNum,
} from "@/lib/persian";
import { PersianWheelDatePicker } from "@/components/persian-calendar/PersianWheelDatePicker";
import type { ReminderItem, ReminderKind, ReminderRepeat, VehicleItem } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface ReminderFormSheetProps {
  open: boolean;
  vehicles: VehicleItem[];
  defaultVehicleId: string | null;
  initial?: ReminderItem | null;
  currentKm: number;
  onClose: () => void;
  onSaved: () => void;
}

const KIND_OPTIONS: { value: ReminderKind; label: string }[] = [
  { value: "DATE", label: "بر اساس تاریخ" },
  { value: "KM", label: "بر اساس کیلومتر" },
  { value: "BOTH", label: "تاریخ و کیلومتر (هر دو)" },
];

const REPEAT_OPTIONS: { value: ReminderRepeat; label: string }[] = [
  { value: "NONE", label: "بدون تکرار" },
  { value: "MONTHLY", label: "ماهانه" },
  { value: "YEARLY", label: "سالانه" },
];

const REPEAT_KM_OPTIONS: { value: ReminderRepeat; label: string }[] = [
  { value: "NONE", label: "بدون تکرار" },
  { value: "KM", label: "تکرار کیلومتری" },
];

const REPEAT_BOTH_OPTIONS: { value: ReminderRepeat; label: string }[] = [
  { value: "NONE", label: "بدون تکرار" },
  { value: "MONTHLY", label: "ماهانه" },
  { value: "YEARLY", label: "سالانه" },
  { value: "KM", label: "تکرار کیلومتری" },
];

const TITLE_PRESETS = [
  "سرویس بعدی روغن موتور",
  "معاینه فنی",
  "تمدید بیمه شخص ثالث",
  "تمدید بیمه بدنه",
  "تمدید پلاک",
  "تعویض لاستیک",
  "چرخ‌لی و بالانس",
];

export function ReminderFormSheet({
  open,
  vehicles,
  defaultVehicleId,
  initial,
  currentKm,
  onClose,
  onSaved,
}: ReminderFormSheetProps) {
  const { toast } = useToast();
  const isEdit = Boolean(initial);

  const [vehicleId, setVehicleId] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [kind, setKind] = React.useState<ReminderKind>("DATE");
  const [dueDate, setDueDate] = React.useState<string>(todayISO());
  const [dueKm, setDueKm] = React.useState<number | null>(null);
  const [repeatKind, setRepeatKind] = React.useState<ReminderRepeat>("NONE");
  const [repeatEveryKm, setRepeatEveryKm] = React.useState(5000);
  const [notes, setNotes] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState("");

  // شیت‌های انتخاب (گرید ۲×۲)
  const [vehiclePickerOpen, setVehiclePickerOpen] = React.useState(false);
  const [datePickerOpen, setDatePickerOpen] = React.useState(false);

  const selectedVehicle = vehicles.find((v) => v.id === vehicleId);

  React.useEffect(() => {
    if (!open) return;
    setError("");
    if (initial) {
      setVehicleId(initial.vehicleId);
      setTitle(initial.title);
      setKind(initial.kind);
      setDueDate(initial.dueDate?.slice(0, 10) ?? todayISO());
      setDueKm(initial.dueKm);
      setRepeatKind(initial.repeatKind);
      setRepeatEveryKm(initial.repeatEveryKm ?? 5000);
      setNotes(initial.notes ?? "");
    } else {
      setVehicleId(defaultVehicleId ?? vehicles[0]?.id ?? "");
      setTitle("");
      setKind("DATE");
      setDueDate(todayISO());
      setDueKm(null);
      setRepeatKind("NONE");
      setRepeatEveryKm(5000);
      setNotes("");
    }
     
  }, [open, initial]);

  // پیشنهاد کیلومتر هدف: کیلومتر فعلی + ۵۰۰۰ (یادآورهای کیلومتری و «هر دو»)
  React.useEffect(() => {
    if (open && !isEdit && dueKm === null && currentKm > 0 && (kind === "KM" || kind === "BOTH")) {
      setDueKm(Math.ceil((currentKm + 5000) / 100) * 100);
    }
  }, [kind, open]);

  // هنگام تغییر نوع به «تاریخ»، کیلومتر خالی نمی‌شود مگر در حالت ایجاد — تا ویرایش اطلاعات را از دست ندهد

  const submit = async () => {
    if (!vehicleId) return setError("خودرو را انتخاب کنید");
    if (!title.trim()) return setError("عنوان یادآور را وارد کنید");
    if (kind === "KM" && (dueKm === null || dueKm <= 0)) {
      return setError("کیلومتر هدف را وارد کنید");
    }
    if (kind === "BOTH" && (dueKm === null || dueKm <= 0)) {
      return setError("در حالت «هر دو»، کیلومتر هدف هم الزامی است");
    }

    setSaving(true);
    setError("");
    try {
      const payload: Record<string, unknown> = {
        vehicleId,
        title: title.trim(),
        kind,
        repeatKind,
        notes: notes.trim() || null,
      };
      if (kind === "DATE" || kind === "BOTH") payload.dueDate = dueDate;
      if (kind === "KM" || kind === "BOTH") {
        payload.dueKm = dueKm;
        payload.repeatEveryKm = repeatKind === "KM" ? repeatEveryKm : null;
      } else {
        payload.dueKm = null;
        payload.repeatEveryKm = null;
      }

      const res = await fetch(
        isEdit ? `/api/reminders/${initial!.id}` : "/api/reminders",
        {
          method: isEdit ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error ?? "ثبت انجام نشد");
      }

      toast({
        title: isEdit ? "یادآور ویرایش شد ✓" : "یادآور ساخته شد ✓",
        description: title.trim(),
      });
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={isEdit ? "ویرایش یادآور" : "یادآور جدید"}
      subtitle={isEdit ? undefined : "بر اساس تاریخ یا کیلومتر یادآوری می‌شود"}
      footer={
        <SubmitButton onClick={submit} disabled={saving}>
          {saving ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5" />}
          {isEdit ? "ذخیره تغییرات" : "ساخت یادآور"}
        </SubmitButton>
      }
    >
      {error && (
        <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </div>
      )}

      {/* ─── گرید ۲×۲ — فیلدهای اصلی: خودرو / نوع یادآوری / تاریخ یا کیلومتر هدف / تکرر ─── */}
      <div className="mb-3 grid grid-cols-2 gap-2">
        {vehicles.length > 1 ? (
          <GridCell
            label="خودرو"
            icon={Car}
            chevron
            onClick={() => setVehiclePickerOpen(true)}
            ariaLabel="انتخاب خودرو"
          >
            <span className="truncate text-[13px] font-bold text-foreground">
              {selectedVehicle?.name ?? "انتخاب کنید"}
            </span>
          </GridCell>
        ) : (
          <GridCell label="خودرو" icon={Car}>
            <span className="truncate text-[13px] font-bold text-foreground">
              {selectedVehicle?.name ?? "—"}
            </span>
          </GridCell>
        )}

        <ComboCell
          label="نوع یادآوری"
          icon={Bell}
          value={kind}
          options={KIND_OPTIONS.map((k) => ({ value: k.value, label: k.label }))}
          onPick={(v) => setKind(v as ReminderKind)}
          sheetTitle="نوع یادآوری"
          searchPlaceholder="جستجو..."
          placeholder="نوع"
        />

        {(kind === "DATE" || kind === "BOTH") && (
          <GridCell
            label="تاریخ هدف"
            icon={CalendarDays}
            chevron
            onClick={() => setDatePickerOpen(true)}
            ariaLabel="انتخاب تاریخ هدف"
          >
            <span className="truncate text-[13px] font-bold tabular-nums text-foreground">
              {formatJalaliNumericISO(dueDate)}
            </span>
          </GridCell>
        )}

        {(kind === "KM" || kind === "BOTH") && (
          <GridCell label="کیلومتر هدف" icon={Gauge}>
            <NumberInput
              value={dueKm}
              onChange={setDueKm}
              suffix="کیلومتر"
              max={10_000_000}
              placeholder="۱۶۵٬۰۰۰"
              className="h-9 text-[13px]"
            />
          </GridCell>
        )}

        {kind === "BOTH" ? (
          // «هر دو» — تاریخ و کیلومتر هر دو خانهٔ ردیف دوم را گرفتند؛ تکرر ردیف جدا و تمام‌عرض
          <div className="col-span-2">
            <ComboCell
              label="تکرر"
              icon={Repeat}
              value={repeatKind}
              options={REPEAT_BOTH_OPTIONS.map((r) => ({
                value: r.value,
                label: r.label,
              }))}
              onPick={(v) => setRepeatKind(v as ReminderRepeat)}
              sheetTitle="تکرر یادآور"
              searchPlaceholder="جستجو..."
              placeholder="تکرر"
            />
          </div>
        ) : (
          <ComboCell
            label="تکرر"
            icon={Repeat}
            value={repeatKind}
            options={(kind === "KM" ? REPEAT_KM_OPTIONS : REPEAT_OPTIONS).map((r) => ({
              value: r.value,
              label: r.label,
            }))}
            onPick={(v) => setRepeatKind(v as ReminderRepeat)}
            sheetTitle="تکرر یادآور"
            searchPlaceholder="جستجو..."
            placeholder="تکرر"
          />
        )}
      </div>

      {/* راهنمای کیلومتر فعلی */}
      {(kind === "KM" || kind === "BOTH") && currentKm > 0 && (
        <p className="mb-3 px-1 text-[11.5px] leading-5 text-muted-foreground">
          کیلومتر فعلی این خودرو: {faNum(currentKm)} کیلومتر
        </p>
      )}

      <Field label="عنوان یادآور" required layout="block">
        <TextInput
          dir="rtl"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="مثلاً سرویس بعدی روغن موتور"
        />
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1" style={{ scrollbarWidth: "thin" }}>
          {TITLE_PRESETS.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setTitle(p)}
              className={
                "shrink-0 rounded-full px-3 py-1.5 text-[12px] font-medium transition-colors " +
                (title === p
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground active:bg-primary/15")
              }
            >
              {p}
            </button>
          ))}
        </div>
      </Field>

      {repeatKind === "KM" && (
        <Field label="هر چند کیلومتر تکرار شود">
          <NumberInput
            value={repeatEveryKm}
            onChange={(v) => setRepeatEveryKm(v ?? 5000)}
            suffix="کیلومتر"
            max={100_000}
          />
        </Field>
      )}

      <Field label="یادداشت">
        <TextArea
          dir="rtl"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="مثلاً مدارک لازم..."
        />
      </Field>

      {isEdit && (initial?.dueDate || initial?.dueKm != null) && (
        <p className="pb-3 text-center text-[12px] text-muted-foreground">
          {initial?.dueDate ? `تاریخ هدف فعلی: ${formatJalaliISO(initial.dueDate)}` : ""}
          {initial?.dueDate && initial?.dueKm != null ? " — " : ""}
          {initial?.dueKm != null ? `کیلومتر هدف فعلی: ${faNum(initial.dueKm ?? 0)}` : ""}
        </p>
      )}

      {/* ─── شیت‌های انتخاب ─── */}
      <PickerSheet
        open={vehiclePickerOpen}
        onClose={() => setVehiclePickerOpen(false)}
        title="انتخاب خودرو"
        subtitle={`${fa(vehicles.length)} خودرو — جستجو کنید یا انتخاب کنید`}
        options={vehicles.map((v) => ({ value: v.id, label: v.name }))}
        value={vehicleId || null}
        onChange={setVehicleId}
        searchPlaceholder="جستجوی خودرو..."
      />

      <PersianWheelDatePicker
        open={datePickerOpen}
        value={isoToJalali(dueDate)}
        onConfirm={(j) => {
          setDueDate(jalaliToISO(j));
          setDatePickerOpen(false);
        }}
        onCancel={() => setDatePickerOpen(false)}
        title="تاریخ هدف یادآور"
      />
    </BottomSheet>
  );
}
