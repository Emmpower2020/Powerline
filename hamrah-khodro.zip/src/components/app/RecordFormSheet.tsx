"use client";

/**
 * فرم ثبت/ویرایش رکورد — بازطراحی طبق موکاپ تأییدشده:
 *  ─ گرید ۲×۲ فشرده برای فیلدهای اصلی (خودرو / تاریخ / کارکرد / نوع سرویس)
 *    با عنوان + آیکون + مقدارِ درون‌خطی داخل کادر کوتاه
 *  ─ سرویس: قیمت → سرویس‌های مکمل (+ افزودن مورد دلخواه) → مرکز خدمات →
 *    ثبت سرویس بعدی با ۳ نوع یادآور (کارکرد / تاریخ / هر دو) → توضیحات
 *  ─ نوار پایین چسبان: جمع کل هزینه + دکمه ثبت
 *  ─ حذف از لیست سوابق (دکمه روی هر کارت) — فرم ویرایش فقط ذخیره دارد
 *  ─ منطق ثبت (پرداخت complementary، nextDue، PART/SERVICE، سوخت و…) دست‌نخورده
 */

import * as React from "react";
import {
  Loader2,
  Save,
  Info,
  Check,
  Plus,
  X,
  Wrench,
  Cog,
  Search,
  ListChecks,
  Car,
  CalendarDays,
  Gauge,
  Tag,
  Fuel as FuelIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { BottomSheet } from "./BottomSheet";
import {
  DateField,
  Field,
  GridCell,
  NumberInput,
  PickerSheet,
  SubmitButton,
  SwitchRow,
  TextArea,
  TextInput,
} from "./fields";
import { PersianWheelDatePicker } from "@/components/persian-calendar/PersianWheelDatePicker";
import {
  fa,
  faNum,
  formatJalaliISO,
  formatJalaliNumericISO,
  isoToJalali,
  jalaliToISO,
  todayISO,
  weekdayFromISO,
} from "@/lib/persian";
import {
  type ComplementaryItem,
  type RecordItem,
  type RecordType,
  type ServiceKind,
  type ServiceTypeItem,
  type VehicleItem,
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface RecordFormSheetProps {
  open: boolean;
  mode: RecordType;
  vehicles: VehicleItem[];
  serviceTypes: ServiceTypeItem[];
  defaultVehicleId: string | null;
  currentKm: number;
  initial?: RecordItem | null;
  onClose: () => void;
  onSaved: () => void;
}

const FORM_TITLES: Record<RecordType, { create: string; edit: string }> = {
  SERVICE: { create: "ثبت سرویس", edit: "ویرایش سرویس" },
  FUEL: { create: "ثبت سوخت", edit: "ویرایش سوخت" },
  ODOMETER: { create: "ثبت کیلومتر", edit: "ویرایش کیلومتر" },
  NOTE: { create: "ثبت یادداشت", edit: "ویرایش یادداشت" },
};

const FORM_SUBMIT_LABELS: Record<RecordType, string> = {
  SERVICE: "ثبت سرویس",
  FUEL: "ثبت سوخت",
  ODOMETER: "ثبت کیلومتر",
  NOTE: "ثبت یادداشت",
};

/** نوع یادآور سرویس بعدی — سه حالت مطابق موکاپ */
type NextKind = "KM" | "DATE" | "BOTH";
const NEXT_KIND_LABELS: Record<NextKind, string> = {
  KM: "کارکرد",
  DATE: "تاریخ",
  BOTH: "هر دو",
};

/** ردیف سرویس مکمل در فرم */
interface CompRow {
  name: string;
  price: number | null;
  included: boolean;
  custom: boolean;
}

/** ساخت ردیف‌های مکمل از نام‌های تعریف‌شدهٔ نوع + موارد ذخیره‌شدهٔ رکورد */
function buildCompRows(
  defs: string[],
  saved: ComplementaryItem[]
): CompRow[] {
  const rows: CompRow[] = [];
  const usedSaved = new Set<number>();
  for (const d of defs) {
    const si = saved.findIndex((s) => s.name === d);
    if (si >= 0) {
      usedSaved.add(si);
      rows.push({ name: d, price: saved[si].price, included: true, custom: false });
    } else {
      rows.push({ name: d, price: null, included: false, custom: false });
    }
  }
  saved.forEach((s, i) => {
    if (!usedSaved.has(i) && s.name) {
      rows.push({ name: s.name, price: s.price, included: true, custom: true });
    }
  });
  return rows;
}

/* ---------------- شیت انتخاب نوع سرویس — جستجوپذیر و کشیدنی ---------------- */

function ServiceTypePickerSheet({
  open,
  onClose,
  serviceTypes,
  value,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  serviceTypes: ServiceTypeItem[];
  value: string;
  onPick: (label: string) => void;
}) {
  const { toast } = useToast();
  const [q, setQ] = React.useState("");
  const searchRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (open) setQ("");
  }, [open]);

  const qTrim = q.trim();
  const filtered = qTrim
    ? serviceTypes.filter((t) => t.label.includes(qTrim))
    : serviceTypes;
  const exactExists = serviceTypes.some((t) => t.label === qTrim);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="انتخاب نوع سرویس"
      subtitle={`${fa(serviceTypes.length)} نوع — جستجو کنید یا انتخاب کنید`}
      maxHeight="max-h-[85dvh]"
    >
      {/* جستجو */}
      <div className="relative mb-3">
        <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
        <input
          ref={searchRef}
          dir="rtl"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی نوع سرویس..."
          className="h-12 w-full rounded-xl border border-input bg-background pr-11 pl-4 text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary/60 focus:outline-none focus:ring-[3px] focus:ring-primary/15"
        />
      </div>

      {/* لیست انواع — فقط نام سرویس + آیکون + حالت انتخاب */}
      <div className="max-h-[58dvh] overflow-y-auto overscroll-contain">
        {filtered.map((t) => {
          const kind = t.kind ?? "SERVICE";
          const isSelected = t.label === value;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                onPick(t.label);
                onClose();
              }}
              className={cn(
                "mb-1 flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-right transition-colors active:scale-[.99]",
                isSelected ? "bg-primary/10" : "hover:bg-muted/60"
              )}
            >
              <span
                className={cn(
                  "flex size-10 shrink-0 items-center justify-center rounded-xl",
                  kind === "PART" ? "bg-primary/12" : "bg-teal-500/10"
                )}
              >
                {kind === "PART" ? (
                  <Wrench className="size-5 text-primary" />
                ) : (
                  <Cog className="size-5 text-teal-600 dark:text-teal-300" />
                )}
              </span>
              <span
                className={cn(
                  "flex min-w-0 flex-1 truncate text-[16px]",
                  isSelected ? "font-bold text-primary" : "font-medium text-foreground"
                )}
              >
                {t.label}
              </span>
              {isSelected && <Check className="size-5 shrink-0 text-primary" />}
            </button>
          );
        })}
        {filtered.length === 0 && (
          <p className="py-8 text-center text-[15px] text-muted-foreground">نوع سرویسی یافت نشد</p>
        )}
      </div>

      {/* افزودن سرویس جدید — همیشه در پایان لیست */}
      <button
        type="button"
        onClick={() => {
          if (!qTrim) {
            // جستجو خالی است — فوکوس روی جستجو + راهنما
            searchRef.current?.focus();
            toast({ title: "نام سرویس را بنویسید" });
            return;
          }
          // عبارت جستجو (جدید یا موجود) به‌عنوان نوع انتخاب می‌شود
          onPick(qTrim);
          onClose();
        }}
        className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-primary/45 bg-primary/5 text-[14px] font-bold text-primary transition-colors active:bg-primary/10"
      >
        <Plus className="size-4.5" />
        {qTrim && !exactExists ? `افزودن «${qTrim}» به‌عنوان سرویس جدید` : "افزودن سرویس جدید"}
      </button>
    </BottomSheet>
  );
}

export function RecordFormSheet({
  open,
  mode,
  vehicles,
  serviceTypes,
  defaultVehicleId,
  currentKm,
  initial,
  onClose,
  onSaved,
}: RecordFormSheetProps) {
  const { toast } = useToast();
  const isEdit = Boolean(initial);

  const [vehicleId, setVehicleId] = React.useState<string>("");
  const [date, setDate] = React.useState<string>(todayISO());
  const [mileage, setMileage] = React.useState<number | null>(null);
  const [cost, setCost] = React.useState<number | null>(null);

  // سرویس
  const [title, setTitle] = React.useState<string>("");
  const [kind, setKind] = React.useState<ServiceKind>("SERVICE");
  const [partsCost, setPartsCost] = React.useState<number | null>(null);
  const [laborCost, setLaborCost] = React.useState<number | null>(null);
  const [compRows, setCompRows] = React.useState<CompRow[]>([]);
  const [provider, setProvider] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [nextServiceOn, setNextServiceOn] = React.useState(false);
  const [nextKind, setNextKind] = React.useState<NextKind>("KM");
  const [nextDueKm, setNextDueKm] = React.useState<number | null>(null);
  const [nextDueDate, setNextDueDate] = React.useState<string | null>(null);

  // سوخت
  const [liters, setLiters] = React.useState<number | null>(null);
  const [fullTank, setFullTank] = React.useState(true);
  const [station, setStation] = React.useState("");
  /** قیمت هر لیتر — با هزینهٔ کل دوسویه همگام می‌شود (آخرین فیلد ویرایش‌شده مبناست) */
  const [pricePerLiter, setPricePerLiter] = React.useState<number | null>(null);
  const lastFuelEdited = React.useRef<"unit" | "total" | null>(null);

  // یادداشت
  const [noteTitle, setNoteTitle] = React.useState("");
  const [noteBody, setNoteBody] = React.useState("");

  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState("");

  // شیت‌های انتخاب (گرید ۲×۲)
  const [typePickerOpen, setTypePickerOpen] = React.useState(false);
  const [vehiclePickerOpen, setVehiclePickerOpen] = React.useState(false);
  const [datePickerOpen, setDatePickerOpen] = React.useState(false);

  /** نوع سرویس منطبق با عنوان انتخاب‌شده */
  const matchedType = React.useMemo(() => {
    const t = title.trim();
    if (!t) return null;
    return serviceTypes.find((st) => st.label === t) ?? null;
  }, [serviceTypes, title]);

  // ردیابی نوع منطبق قبلی — برای تغییر ساختار فرم هنگام تعویض نوع سرویس
  const lastTypeKey = React.useRef<string | null>(null);
  // جلوگیری از اجرای افکت تغییر نوع در همان کامیتِ باز شدن فرم (داده‌های ویرایش)
  const skipMatchedEffect = React.useRef(false);

  React.useEffect(() => {
    if (!open) return;
    setError("");
    if (initial) {
      setVehicleId(initial.vehicleId);
      setDate(initial.date.slice(0, 10));
      setMileage(initial.mileage);
      setCost(initial.cost);
      setTitle(initial.title ?? "");
      const mt = initial.title ? serviceTypes.find((st) => st.label === initial.title!.trim()) ?? null : null;
      const k: ServiceKind = mt
        ? (mt.kind ?? "SERVICE")
        : initial.costMode === "SEPARATE"
          ? "PART"
          : "SERVICE";
      setKind(k);
      setPartsCost(initial.partsCost);
      setLaborCost(initial.laborCost);
      setCompRows(buildCompRows(mt?.complementary ?? [], initial.complementary ?? []));
      lastTypeKey.current = mt?.id ?? `custom:${initial.title ?? ""}`;
      setProvider(initial.provider ?? "");
      setDescription(initial.description ?? "");
      setNextDueKm(initial.nextDueKm);
      setNextDueDate(initial.nextDueDate);
      setNextServiceOn(Boolean(initial.nextDueKm || initial.nextDueDate));
      // نوع یادآور فعلی از داده‌های رکورد
      setNextKind(
        initial.nextDueKm && initial.nextDueDate
          ? "BOTH"
          : initial.nextDueDate
            ? "DATE"
            : "KM"
      );
      setLiters(initial.liters);
      setFullTank(initial.fullTank);
      setStation(initial.station ?? "");
      setPricePerLiter(initial.pricePerLiter ?? null);
      lastFuelEdited.current = null;
      setNoteTitle(initial.noteTitle ?? "");
      setNoteBody(initial.noteBody ?? "");
    } else {
      setVehicleId(defaultVehicleId ?? vehicles[0]?.id ?? "");
      setDate(todayISO());
      setMileage(null);
      setCost(null);
      setTitle("");
      setKind("SERVICE");
      setPartsCost(null);
      setLaborCost(null);
      setCompRows([]);
      lastTypeKey.current = null;
      setProvider("");
      setDescription("");
      setNextServiceOn(false);
      setNextKind("KM");
      setNextDueKm(null);
      setNextDueDate(null);
      setLiters(null);
      setFullTank(true);
      setStation("");
      setPricePerLiter(null);
      lastFuelEdited.current = null;
      setNoteTitle("");
      setNoteBody("");
    }
    skipMatchedEffect.current = true;

  }, [open, initial, mode]);

  /* ---- تغییر ساختار فرم با تغییر نوع سرویس ---- */
  React.useEffect(() => {
    if (!open || mode !== "SERVICE") return;
    if (skipMatchedEffect.current) {
      skipMatchedEffect.current = false;
      return;
    }
    const key = matchedType?.id ?? (title.trim() ? `custom:${title.trim()}` : "empty");
    if (key === lastTypeKey.current) return;
    // تعویض نوع سرویس → ساختار قیمت‌ها و مکمل‌ها بر اساس نوع جدید بازسازی می‌شود
    lastTypeKey.current = key;
    const k: ServiceKind = matchedType?.kind ?? "SERVICE";
    setKind(k);
    setCost(null);
    setPartsCost(null);
    setLaborCost(null);
    setCompRows(buildCompRows(matchedType?.complementary ?? [], []));

  }, [matchedType, open, mode]);

  /* ---- سوخت: همگام‌سازی دوسویهٔ قیمت هر لیتر ↔ هزینهٔ کل ---- */
  /** تغییر لیتر — بر اساس آخرین فیلد ویرایش‌شده، فیلد دیگر بازمحاسبه می‌شود */
  const onLitersChange = (v: number | null) => {
    setLiters(v);
    if (v && v > 0) {
      if (lastFuelEdited.current === "unit" && pricePerLiter) setCost(Math.round(v * pricePerLiter));
      else if (lastFuelEdited.current === "total" && cost) setPricePerLiter(Math.round(cost / v));
    }
  };
  const onUnitPriceChange = (v: number | null) => {
    setPricePerLiter(v);
    lastFuelEdited.current = "unit";
    if (v && liters && liters > 0) setCost(Math.round(liters * v));
  };
  const onTotalCostChange = (v: number | null) => {
    setCost(v);
    lastFuelEdited.current = "total";
    if (v && liters && liters > 0) setPricePerLiter(Math.round(v / liters));
  };

  const vehicleOptions = vehicles.map((v) => ({ value: v.id, label: v.name }));
  const selectedVehicle = vehicles.find((v) => v.id === vehicleId);

  const validate = (): string => {
    if (!vehicleId) return "خودرو را انتخاب کنید";
    if (mode === "FUEL" && (liters === null || liters <= 0)) return "مقدار سوخت را وارد کنید";
    if (mode === "FUEL" && mileage === null) return "کارکرد را وارد کنید (برای محاسبه مصرف)";
    if (mode === "ODOMETER" && mileage === null) return "کارکرد فعلی را وارد کنید";
    if (mode === "SERVICE" && !title.trim()) return "نوع سرویس را انتخاب کنید";
    if (mode === "NOTE" && !noteBody.trim()) return "متن یادداشت را وارد کنید";
    // اعتبارسنجی یادآور سرویس بعدی — فقط در حالت ثبت جدید (در ویرایش بخش مخفی است)
    if (mode === "SERVICE" && !isEdit && nextServiceOn) {
      const needKm = nextKind === "KM" || nextKind === "BOTH";
      const needDate = nextKind === "DATE" || nextKind === "BOTH";
      if (needKm && (nextDueKm === null || nextDueKm <= 0)) return "کارکرد سرویس بعدی را وارد کنید";
      if (needDate && !nextDueDate) return "تاریخ سرویس بعدی را انتخاب کنید";
    }
    return "";
  };

  /** جمع کل هزینهٔ سرویس — قیمت اصلی (یا قطعه+دستمزد) + مکمل‌های فعال */
  const totalCost = React.useMemo(() => {
    if (mode !== "SERVICE") return cost;
    let sum = kind === "PART" ? (partsCost ?? 0) + (laborCost ?? 0) : cost ?? 0;
    for (const it of compRows) {
      if (it.included) sum += it.price ?? 0;
    }
    return sum > 0 ? sum : null;
  }, [mode, kind, cost, partsCost, laborCost, compRows]);

  const submit = async () => {
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setSaving(true);
    setError("");
    try {
      const payload: Record<string, unknown> = {
        type: mode,
        vehicleId,
        date,
        mileage,
      };

      if (mode === "SERVICE") {
        payload.title = title.trim();
        const included = compRows.filter((it) => it.included && it.name.trim());
        if (kind === "PART") {
          payload.costMode = "SEPARATE";
          payload.partsCost = partsCost;
          payload.laborCost = laborCost;
          payload.cost = totalCost;
          // سازگاری با فیلدهای قدیمی فیلتر روغن/هوا
          const oil = included.find((it) => it.name.includes("فیلتر روغن"));
          payload.hasOilFilter = Boolean(oil);
          payload.oilFilterCost = oil?.price ?? null;
          const air = included.find((it) => it.name.includes("فیلتر هوا"));
          payload.hasAirFilter = Boolean(air);
          payload.airFilterCost = air?.price ?? null;
        } else {
          payload.costMode = "TOTAL";
          payload.cost = totalCost;
          payload.partsCost = null;
          payload.laborCost = null;
          payload.hasOilFilter = false;
          payload.oilFilterCost = null;
          payload.hasAirFilter = false;
          payload.airFilterCost = null;
        }
        // سرویس‌های مکمل انجام‌شده — برای هر دو نوع (خدماتی و تعویض قطعه)
        payload.complementary = included.map((it) => ({
          name: it.name.trim(),
          price: it.price,
        }));
        payload.provider = provider.trim() || null;
        payload.description = description.trim() || null;
        if (nextServiceOn) {
          if ((nextKind === "DATE" || nextKind === "BOTH") && nextDueDate) {
            payload.nextDueDate = nextDueDate;
          }
          if ((nextKind === "KM" || nextKind === "BOTH") && nextDueKm !== null && nextDueKm > 0) {
            payload.nextDueKm = nextDueKm;
          }
        }
      } else {
        payload.cost = cost;
      }
      if (mode === "FUEL") {
        payload.liters = liters;
        payload.fullTank = fullTank;
        payload.station = station.trim() || null;
        payload.pricePerLiter = pricePerLiter;
        // اگر فقط قیمت هر لیتر وارد شده، هزینهٔ کل از روی لیتر محاسبه می‌شود
        if (payload.cost === null && pricePerLiter && liters && liters > 0) {
          payload.cost = Math.round(pricePerLiter * liters);
        }
      }
      if (mode === "ODOMETER" && description.trim()) {
        payload.description = description.trim();
      }
      if (mode === "NOTE") {
        payload.noteTitle = noteTitle.trim() || null;
        payload.noteBody = noteBody.trim();
      }

      const res = await fetch(
        isEdit ? `/api/records/${initial!.id}` : "/api/records",
        {
          method: isEdit ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error ?? "ثبت انجام نشد");
      }

      toast({
        title: isEdit ? "ویرایش شد ✓" : "ثبت شد ✓",
        description: `${FORM_TITLES[mode].create} — ${formatJalaliISO(date)}`,
      });
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  const titles = FORM_TITLES[mode];

  /* ---- ردیف سرویس مکمل ---- */
  const setRow = (i: number, patch: Partial<CompRow>) => {
    setCompRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  };
  const toggleRow = (i: number) => {
    setCompRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, included: !r.included } : r)));
  };
  const removeRow = (i: number) => setCompRows((prev) => prev.filter((_, idx) => idx !== i));
  const addCustomComp = () =>
    setCompRows((prev) => [...prev, { name: "", price: null, included: true, custom: true }]);

  /* ---- انتخاب نوع یادآور سرویس بعدی ---- */
  const pickNextKind = (k: NextKind) => {
    setNextKind(k);
    if ((k === "DATE" || k === "BOTH") && nextDueDate === null) {
      setNextDueDate(todayISO());
    }
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={isEdit ? titles.edit : titles.create}
      subtitle={
        date
          ? `${weekdayFromISO(date)} — ${formatJalaliISO(date)}`
          : undefined
      }
      maxHeight="max-h-[92dvh]"
      footer={
        <div className="flex flex-col gap-2">
          {/* جمع کل — همیشه دیده می‌شود، بالای دکمه‌ها (نوار پایین چسبان) */}
          {mode === "SERVICE" && (
            <div className="flex items-center justify-between gap-2 rounded-xl bg-primary/10 px-3.5 py-2.5">
              <span className="flex items-center gap-1.5 text-[13px] font-bold text-muted-foreground">
                <Info className="size-4 shrink-0 text-primary" />
                جمع کل هزینه
              </span>
              <span className="text-[16.5px] font-extrabold tabular-nums text-primary">
                {totalCost !== null ? `${fa(faNum(totalCost))} تومان` : "—"}
              </span>
            </div>
          )}
          <SubmitButton onClick={submit} disabled={saving} className="flex-1">
            {saving ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5" />}
            {isEdit ? "ذخیره تغییرات" : FORM_SUBMIT_LABELS[mode]}
          </SubmitButton>
        </div>
      }
    >
      {error && (
        <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </div>
      )}

      {/* ─── گرید ۲×۲ — فیلدهای اصلی: خودرو / تاریخ / کارکرد / (نوع سرویس یا مقدار سوخت) ─── */}
      <div className="mb-1.5 grid grid-cols-2 gap-2">
        {/* خودرو */}
        {vehicles.length > 1 ? (
          <GridCell
            label="خودرو"
            icon={Car}
            chevron
            onClick={() => setVehiclePickerOpen(true)}
            ariaLabel="انتخاب خودرو"
          >
            <span className="truncate text-[13px] font-bold text-foreground">
              {selectedVehicle?.name ?? "انتخاب کنید"}
            </span>
          </GridCell>
        ) : (
          <GridCell label="خودرو" icon={Car}>
            <span className="truncate text-[13px] font-bold text-foreground">
              {selectedVehicle?.name ?? "—"}
            </span>
          </GridCell>
        )}

        {/* تاریخ */}
        <GridCell
          label="تاریخ"
          icon={CalendarDays}
          chevron
          onClick={() => setDatePickerOpen(true)}
          ariaLabel="انتخاب تاریخ"
        >
          <span className="truncate text-[13px] font-bold tabular-nums text-foreground">
            {formatJalaliNumericISO(date)}
          </span>
        </GridCell>

        {/* کارکرد — ورودی عددی درون‌خطی */}
        <GridCell
          label="کارکرد"
          icon={Gauge}
          className={mode === "ODOMETER" ? "col-span-2" : undefined}
        >
          <NumberInput
            value={mileage}
            onChange={setMileage}
            placeholder="۱۶۲٬۵۰۰"
            max={10_000_000}
            className="h-9 text-[13px]"
          />
        </GridCell>

        {/* نوع سرویس — حالت اول: «نوع سرویس»؛ بعد از انتخاب: نام کامل سرویس (بدون بریدگی) */}
        {mode === "SERVICE" && (
          <GridCell
            label={title.trim() ? "نوع سرویس" : ""}
            icon={Tag}
            chevron
            onClick={() => setTypePickerOpen(true)}
            ariaLabel="انتخاب نوع سرویس"
            className="h-auto min-h-12"
          >
            {title.trim() ? (
              <span className="min-w-0 flex-1 text-[13px] font-bold leading-[1.35] text-foreground">
                {title.trim()}
              </span>
            ) : (
              <span className="text-[13px] font-medium text-muted-foreground">
                نوع سرویس
              </span>
            )}
          </GridCell>
        )}
        {mode === "FUEL" && (
          <GridCell label="مقدار سوخت" icon={FuelIcon}>
            <NumberInput
              value={liters}
              onChange={onLitersChange}
              decimal
              max={500}
              placeholder="۴۵"
              className="h-9 text-[13px]"
            />
          </GridCell>
        )}
      </div>

      {/* راهنمای کارکرد آخر */}
      {currentKm > 0 && mode !== "NOTE" && (
        <p className="mb-3 px-1 text-[11.5px] leading-5 text-muted-foreground">
          آخرین کارکرد ثبت‌شده: {faNum(currentKm)} کیلومتر
          {mode === "FUEL" && " — کارکرد در لحظهٔ سوخت‌گیری برای محاسبهٔ مصرف لازم است"}
        </p>
      )}

      {mode === "SERVICE" && (
        <>
          {/* ─── قیمت‌های اصلی بر اساس نوع ─── */}
          {kind === "PART" ? (
            <>
              <Field label="قیمت قطعه">
                <NumberInput
                  value={partsCost}
                  onChange={setPartsCost}
                  suffix="تومان"
                  placeholder="مثلاً ۸۵۰ هزار"
                />
              </Field>
              <Field label="قیمت دستمزد">
                <NumberInput
                  value={laborCost}
                  onChange={setLaborCost}
                  suffix="تومان"
                  placeholder="مثلاً ۲۰۰ هزار"
                />
              </Field>
            </>
          ) : (
            <Field
              label="قیمت سرویس"
              hint="این نوع سرویس خدماتی است — یک قیمت؛ سرویس‌های مکمل در ادامه با قیمت جدا"
            >
              <NumberInput
                value={cost}
                onChange={setCost}
                suffix="تومان"
                placeholder="مثلاً ۱٫۵ میلیون"
              />
            </Field>
          )}

          {/* ─── سرویس‌های مکمل — بعد از سرویس اصلی، همراه قیمت ─── */}
          <div className="mb-3">
            <div className="mb-1.5 flex items-center gap-1.5">
              <ListChecks className="size-4 text-primary" />
              <span className="text-[14px] font-semibold text-foreground">سرویس‌های مکمل</span>
              <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                {fa(compRows.filter((r) => r.included && r.name.trim()).length)} مورد فعال
              </span>
            </div>

            {compRows.length > 0 && (
              <div className="flex flex-col gap-1.5">
                {compRows.map((r, i) => (
                  <div
                    key={i}
                    className={cn(
                      "flex items-center gap-2 rounded-2xl border p-2 transition-colors",
                      r.included ? "border-primary/40 bg-primary/5" : "border-input bg-card"
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => toggleRow(i)}
                      role="checkbox"
                      aria-checked={r.included}
                      aria-label={`درج ${r.name || "مورد"} در سرویس`}
                      className={cn(
                        "flex size-9 shrink-0 items-center justify-center rounded-xl transition-colors",
                        r.included
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      <Check className="size-4.5" strokeWidth={2.6} />
                    </button>
                    {r.custom ? (
                      <TextInput
                        dir="rtl"
                        value={r.name}
                        onChange={(e) => setRow(i, { name: e.target.value })}
                        placeholder="نام مکمل..."
                        className="h-10 min-w-0 flex-1 text-[14px]"
                      />
                    ) : (
                      <span
                        className={cn(
                          "min-w-0 flex-1 truncate text-[14.5px]",
                          r.included ? "font-bold text-foreground" : "text-muted-foreground"
                        )}
                      >
                        {r.name}
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <NumberInput
                        value={r.price}
                        onChange={(v) => setRow(i, { price: v })}
                        placeholder="قیمت"
                        suffix="تومان"
                        className="h-10 text-[14px]"
                      />
                    </div>
                    {r.custom && (
                      <button
                        type="button"
                        onClick={() => removeRow(i)}
                        aria-label="حذف مکمل"
                        className="flex size-9 shrink-0 items-center justify-center rounded-xl text-red-500 active:bg-red-500/10"
                      >
                        <X className="size-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {compRows.length === 0 && (
              <div className="flex h-12 items-center justify-center rounded-2xl border border-dashed border-input bg-muted/40 px-3 text-[13px] text-muted-foreground">
                برای این نوع سرویس مکملی تعریف نشده — مورد دلخواه اضافه کنید
              </div>
            )}

            {/* افزودن مورد دلخواه */}
            <button
              type="button"
              onClick={addCustomComp}
              className="mt-2 flex h-11 w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-primary/45 bg-primary/5 text-[13.5px] font-bold text-primary transition-colors active:bg-primary/10"
            >
              <Plus className="size-4.5" />
              افزودن مورد دلخواه
            </button>
          </div>

          {/* ─── مرکز خدمات / تعمیرکار ─── */}
          <Field label="مرکز خدمات / تعمیرکار">
            <TextInput
              dir="rtl"
              value={provider}
              onChange={(e) => setProvider(e.target.value)}
              placeholder="مثلاً تعمیرگاه آریا..."
            />
          </Field>

          {/* ─── ثبت سرویس بعدی — سه نوع یادآور ─── */}
          {!isEdit && (
            <SwitchRow
              label="ثبت سرویس بعدی"
              hint="یادآور سرویس بعدی بر اساس کارکرد، تاریخ یا هر دو ساخته می‌شود"
              checked={nextServiceOn}
              onCheckedChange={setNextServiceOn}
            />
          )}
          {nextServiceOn && (
            <div className="mb-3">
              {/* انتخاب نوع یادآور: کارکرد / تاریخ / هر دو */}
              <div className="grid grid-cols-3 gap-1 rounded-xl bg-muted p-1">
                {(["KM", "DATE", "BOTH"] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => pickNextKind(k)}
                    aria-pressed={nextKind === k}
                    className={cn(
                      "flex h-9 items-center justify-center rounded-lg text-[13px] font-bold transition-colors active:scale-[.97]",
                      nextKind === k
                        ? "bg-card text-primary shadow-sm"
                        : "text-muted-foreground"
                    )}
                  >
                    {NEXT_KIND_LABELS[k]}
                  </button>
                ))}
              </div>

              {(nextKind === "KM" || nextKind === "BOTH") && (
                <div className="mt-2">
                  <Field label="کارکرد سرویس بعدی">
                    <NumberInput
                      value={nextDueKm}
                      onChange={setNextDueKm}
                      suffix="کیلومتر"
                      placeholder={mileage ? String(mileage + 5000) : "مثلاً ۱۶۷٬۵۰۰"}
                      max={10_000_000}
                    />
                  </Field>
                </div>
              )}
              {(nextKind === "DATE" || nextKind === "BOTH") && (
                <div className="mt-0.5">
                  <DateField
                    value={nextDueDate ?? todayISO()}
                    onChange={(d) => setNextDueDate(d)}
                    label="تاریخ سرویس بعدی"
                    title="تاریخ سرویس بعدی"
                  />
                </div>
              )}
            </div>
          )}
        </>
      )}

      {mode === "FUEL" && (
        <>
          <SwitchRow
            label="باک پر شد"
            hint="برای محاسبه مصرف، بین دو سوخت‌گیریِ باک‌کامل"
            checked={fullTank}
            onCheckedChange={setFullTank}
          />
          <Field
            label="قیمت هر لیتر"
            hint={"با وارد کردن قیمت هر لیتر، هزینهٔ کل خودکار محاسبه می‌شود — و برعکس"}
          >
            <NumberInput
              value={pricePerLiter}
              onChange={onUnitPriceChange}
              suffix="تومان"
              placeholder="مثلاً ۵۰٬۰۰۰"
            />
          </Field>
          <Field label="هزینهٔ کل">
            <NumberInput value={cost} onChange={onTotalCostChange} suffix="تومان" placeholder="مثلاً ۱٬۵۰۰٬۰۰۰" />
          </Field>
          {liters && liters > 0 && pricePerLiter ? (
            <div className="mb-3 flex items-center gap-2 rounded-xl bg-amber-500/10 px-4 py-3 text-[13px] font-medium text-amber-700 dark:text-amber-300">
              <Info className="size-4 shrink-0" />
              <span className="tabular-nums">
                {fa(liters)} لیتر × {faNum(pricePerLiter)} تومان = {""}
                {faNum(Math.round(liters * pricePerLiter))} تومان
              </span>
            </div>
          ) : null}
          <Field label="جای سوخت">
            <TextInput
              dir="rtl"
              value={station}
              onChange={(e) => setStation(e.target.value)}
              placeholder="مثلاً پمپ بنزین ولیعصر"
            />
          </Field>
        </>
      )}

      {mode === "NOTE" && (
        <>
          <Field label="عنوان">
            <TextInput
              dir="rtl"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              placeholder="مثلاً صدای غیرعادی جلو"
            />
          </Field>
          <Field label="متن یادداشت" required>
            <TextArea
              dir="rtl"
              value={noteBody}
              onChange={(e) => setNoteBody(e.target.value)}
              placeholder="هر نکته‌ای درباره خودرو..."
              rows={4}
            />
          </Field>
        </>
      )}

      {mode !== "NOTE" && (
        <Field label="توضیحات">
          <TextArea
            dir="rtl"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="نکات، قطعات، برند روغن و..."
            rows={2}
          />
        </Field>
      )}

      <div className="pb-2 pt-1 text-center text-[12px] text-muted-foreground">
        {mode === "FUEL" && "مصرف سوخت به‌صورت خودکار بین دو باکِ کامل محاسبه می‌شود"}
      </div>

      {/* ─── شیت‌های انتخاب ─── */}
      <ServiceTypePickerSheet
        open={typePickerOpen}
        onClose={() => setTypePickerOpen(false)}
        serviceTypes={serviceTypes}
        value={title.trim()}
        onPick={(label) => setTitle(label)}
      />

      <PickerSheet
        open={vehiclePickerOpen}
        onClose={() => setVehiclePickerOpen(false)}
        title="انتخاب خودرو"
        subtitle={`${fa(vehicles.length)} خودرو — جستجو کنید یا انتخاب کنید`}
        options={vehicleOptions}
        value={vehicleId || null}
        onChange={setVehicleId}
        searchPlaceholder="جستجوی خودرو..."
      />

      <PersianWheelDatePicker
        open={datePickerOpen}
        value={isoToJalali(date)}
        onConfirm={(j) => {
          setDate(jalaliToISO(j));
          setDatePickerOpen(false);
        }}
        onCancel={() => setDatePickerOpen(false)}
        title="انتخاب تاریخ"
      />
    </BottomSheet>
  );
}
