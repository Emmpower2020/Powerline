"use client";

/**
 * منوی افزودن — با لمس دکمه + باز می‌شود
 */

import { Fuel, Gauge, BellPlus, Wrench, StickyNote } from "lucide-react";
import { BottomSheet } from "./BottomSheet";
import type { RecordType } from "@/lib/types";

export type AddTarget = RecordType | "REMINDER";

const OPTIONS: { key: AddTarget; label: string; desc: string; icon: React.ElementType; color: string; bg: string }[] = [
  {
    key: "SERVICE",
    label: "ثبت سرویس",
    desc: "روغن، فیلتر، ترمز، تسمه و...",
    icon: Wrench,
    color: "#0E9F8E",
    bg: "bg-teal-500/12",
  },
  {
    key: "FUEL",
    label: "ثبت سوخت",
    desc: "لیتر، مبلغ و محاسبه مصرف",
    icon: Fuel,
    color: "#F59E0B",
    bg: "bg-amber-500/12",
  },
  {
    key: "REMINDER",
    label: "ثبت یادآوری",
    desc: "بر اساس تاریخ یا کارکرد",
    icon: BellPlus,
    color: "#EF4444",
    bg: "bg-red-500/12",
  },
  {
    key: "ODOMETER",
    label: "ثبت کیلومتر",
    desc: "به‌روزرسانی کارکرد خودرو",
    icon: Gauge,
    color: "#8B5CF6",
    bg: "bg-violet-500/12",
  },
  {
    key: "NOTE",
    label: "ثبت یادداشت",
    desc: "هر نکته‌ای درباره خودرو",
    icon: StickyNote,
    color: "#EC4899",
    bg: "bg-pink-500/12",
  },
];

export function AddMenuSheet({
  open,
  onClose,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (target: AddTarget) => void;
}) {
  return (
    <BottomSheet open={open} onClose={onClose} title="افزودن رکورد جدید" subtitle="چه چیزی می‌خواهید ثبت کنید؟">
      <div className="flex flex-col gap-2 pb-3">
        {OPTIONS.map((o) => {
          const Icon = o.icon;
          return (
            <button
              key={o.key}
              type="button"
              onClick={() => {
                onClose();
                onSelect(o.key);
              }}
              className="flex items-center gap-3.5 rounded-2xl border border-border/70 bg-card p-3.5 text-right transition-all hover:border-primary/40 active:scale-[.98]"
            >
              <span className={`flex size-12 shrink-0 items-center justify-center rounded-xl ${o.bg}`}>
                <Icon className="size-6" style={{ color: o.color }} strokeWidth={2} />
              </span>
              <span className="flex min-w-0 flex-1 flex-col">
                <span className="text-[16px] font-bold text-foreground">{o.label}</span>
                <span className="mt-0.5 truncate text-[12.5px] text-muted-foreground">{o.desc}</span>
              </span>
            </button>
          );
        })}
      </div>
    </BottomSheet>
  );
}
