"use client";

/**
 * BottomSheet عمومی — شیت پایین صفحه مطابق طراحی اپ موبایل
 * با هندل بالای شیت، بک‌دراپ، قفل اسکرول، بستن با Esc و کشیدن هندل
 * ⭐ v3.8.9: با createPortal به body منتقل می‌شود — شیت‌هایی که داخل پنل‌های
 *  کاروسل رندر می‌شوند (فیلترها/اشتراک‌گذاری/بازیابی ابری) قبلاً به‌خاطر
 *  will-change:transform ترک، به جعبهٔ ترک می‌چسبیدند: پنل شیت زیر viewport
 *  نامرئی و فقط بک‌دراپ سیاه دیده می‌شد. با پورتال، همیشه نسبت به viewport.
 */

import * as React from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useDragControls } from "framer-motion";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  /** حداکثر ارتفاع شیت */
  maxHeight?: string;
  hideHeader?: boolean;
  contentClassName?: string;
}

export function BottomSheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  maxHeight = "max-h-[88dvh]",
  hideHeader = false,
  contentClassName,
}: BottomSheetProps) {
  const dragControls = useDragControls();

  // ⭐ v3.8.9: پورتال فقط بعد از مونت کلاینت (پرهیز از ناسازگاری هیدریشن/SSG)
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    setMounted(true);
  }, []);

  // قفل اسکرول بدنه
  React.useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  // Esc
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <div
          dir="rtl"
          className="fixed inset-0 z-[80] flex items-end justify-center"
          role="dialog"
          aria-modal="true"
          aria-label={title}
        >
          {/* بک‌دراپ */}
          <motion.div
            className="absolute inset-0 bg-black/50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
          />

          {/* پنل */}
          <motion.div
            className={cn(
              "relative z-10 flex w-full max-w-md flex-col rounded-t-3xl bg-card text-card-foreground shadow-xl",
              maxHeight
            )}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 360 }}
            drag="y"
            dragListener={false}
            dragControls={dragControls}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 110 || info.velocity.y > 800) onClose();
            }}
          >
            {/* هندل + سربرگ (ناحیه کشیدن) */}
            <div
              className="shrink-0 cursor-grab touch-none select-none pb-1 pt-2"
              onPointerDown={(e) => {
                dragControls.start(e);
              }}
            >
              <div className="flex justify-center pb-1">
                <div className="h-1.5 w-10 rounded-full bg-border" />
              </div>
            </div>

            {!hideHeader && (
              <div className="flex shrink-0 items-start justify-between gap-3 px-5 pb-2 pt-1">
                <div className="min-w-0">
                  {title && (
                    <h2 className="truncate text-[17px] font-bold text-foreground">{title}</h2>
                  )}
                  {subtitle && (
                    <p className="mt-0.5 truncate text-[13px] text-muted-foreground">{subtitle}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="بستن"
                  className="flex size-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground transition-colors active:scale-95"
                >
                  <X className="size-5" />
                </button>
              </div>
            )}

            {/* محتوا */}
            <div
              className={cn(
                "min-h-0 flex-1 overflow-y-auto px-5 pb-2 overscroll-contain",
                contentClassName
              )}
            >
              {children}
            </div>

            {/* فوتر ثابت */}
            {footer && (
              <div className="shrink-0 border-t border-border bg-card px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
