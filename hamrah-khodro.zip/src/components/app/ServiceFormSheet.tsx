"use client";

/**
 * فرم ثبت/ویرایش «سرویس» — بازطراحی کامل مطابق طرح مرجع تأییدشده.
 *
 * ریشه‌یابی مشکلات نسخهٔ قبل روی اندروید و رفع کامل:
 *  ۱) زوم خودکار اندروید هنگام فوکوس ورودی‌ها (فونت < 16px) → همهٔ ورودی‌ها ۱۶px
 *  ۲) بی‌اعتباری dvh در وب‌ویوهای قدیمی → کلاس‌های sheet-h-* با فالبک vh
 *  ۳) ناترازی کادرهای گرید ۲×۲ → grid items-stretch + h-full و ساختار یکسان
 *  ۴) اهداف لمسی کوچک → همهٔ ردیف‌ها/دکمه‌ها ≥ ۴۴px
 *
 * چیدمان مطابق عکس مرجع:
 *  - گرید ۲×۲ فشرده در بالا (راست: خودرو، کارکرد / چپ: تاریخ، نوع سرویس)؛
 *    عنوان ریز + مقدار همه داخل همان کادر
 *  - ترتیب: قیمت سرویس → سرویس‌های مکمل (فیلتر هوا/روغن + دلخواه) →
 *    مرکز خدمات/تعمیرکار → ثبت سرویس بعدی → توضیحات
 *  - فوتر چسبان: جمع کل هزینه + دکمهٔ سبز «ثبت سرویس»
 *  - منطق محاسبهٔ هزینه، سازگاری با فیلدهای قدیمی و ساخت یادآور سرویس بعدی
 *    دقیقاً مانند قبل حفظ شده است (payload یکسان با API)
 */

import * as React from "react";
import {
  Banknote,
  BellRing,
  CalendarDays,
  Car,
  Check,
  CheckCircle2,
  ChevronDown,
  Cog,
  ListChecks,
  Loader2,
  Plus,
  Search,
  Tag,
  Trash2,
  Wrench,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { BottomSheet } from "./BottomSheet";
import {
  InlineFields,
  NumberInput,
  PickerSheet,
  TextArea,
  TextInput,
} from "./fields";
import { PersianWheelDatePicker } from "@/components/persian-calendar/PersianWheelDatePicker";
import {
  fa,
  faNum,
  formatJalaliISO,
  isoToJalali,
  jalaliToISO,
  todayISO,
  todayJalali,
  weekdayFromISO,
  type PersianDate,
} from "@/lib/persian";
import {
  SERVICE_KIND_LABELS,
  type ComplementaryItem,
  type RecordItem,
  type ServiceKind,
  type ServiceTypeItem,
  type VehicleItem,
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

/* ═══════════════════════════════ types ═══════════════════════════════ */

interface ServiceFormSheetProps {
  open: boolean;
  initial: RecordItem | null;
  vehicles: VehicleItem[];
  serviceTypes: ServiceTypeItem[];
  defaultVehicleId: string | null;
  currentKm: number;
  onClose: () => void;
  onSaved: () => void;
  onDeleted?: () => void;
}

/** ردیف سرویس مکمل در فرم */
interface CompRow {
  name: string;
  price: number | null;
  included: boolean;
  custom: boolean;
}

/** فقط دو گزینهٔ اصلی مکمل نمایش داده می‌شوند (طرح مرجع) */
const PRESET_COMPS = ["فیلتر هوا", "فیلتر روغن"];

/**
 * ساخت ردیف‌های مکمل — دو گزینهٔ اصلی (فیلتر هوا/فیلتر روغن) همیشه موجودند؛
 * موارد ذخیره‌شدهٔ رکورد که از این دو نیستند به‌عنوان ردیف دلخواه حفظ می‌شوند.
 */
function buildCompRows(saved: ComplementaryItem[]): CompRow[] {
  const rows: CompRow[] = PRESET_COMPS.map((name) => {
    const sv = saved.find((s) => s.name.trim() === name);
    return { name, price: sv?.price ?? null, included: Boolean(sv), custom: false };
  });
  for (const s of saved) {
    const n = s.name.trim();
    if (n && !PRESET_COMPS.includes(n)) {
      rows.push({ name: n, price: s.price, included: true, custom: true });
    }
  }
  return rows;
}

/* ═════════════════════ حالت یادآوری سرویس بعدی ═════════════════════ */

type NextServiceMode = "off" | "date" | "km" | "both";

const NEXT_MODE_OPTIONS: { value: Exclude<NextServiceMode, "off">; label: string }[] = [
  { value: "date", label: "بر اساس تاریخ" },
  { value: "km", label: "بر اساس کارکرد" },
  { value: "both", label: "بر اساس تاریخ و کارکرد (هر دو)" },
];

/** ISO → تاریخ جلالی */
function jFromISO(iso: string): PersianDate {
  try {
    return isoToJalali(iso.slice(0, 10));
  } catch {
    return todayJalali();
  }
}

/** ISO → «۱۴۰۵/۰۶/۱۴» */
function faDateISO(iso: string): string {
  const j = isoToJalali(iso.slice(0, 10));
  return `${fa(j.jy)}/${fa(String(j.jm).padStart(2, "0"))}/${fa(String(j.jd).padStart(2, "0"))}`;
}

/* ═══════════════ کادرهای دوخطی فشردهٔ فرم (≈۷۲px) ═══════════════ */

const BOX_SHELL =
  "flex h-full w-full flex-col gap-1 rounded-xl border border-input bg-card px-3 py-2 transition-all";
const BOX_FOCUS =
  "focus-within:border-primary focus-within:shadow-[0_0_0_3px] focus-within:shadow-primary/15";

function BoxLabel({ label, required }: { label: string; required?: boolean }) {
  return (
    <span className="flex items-center gap-1 text-[11px] font-bold leading-4 text-muted-foreground">
      {label}
      {required && <span className="text-destructive">*</span>}
    </span>
  );
}

/**
 * کادر ورودی دوخطی — خط اول عنوان ریز، خط دوم آیکون + ورودی (۱۶px).
 * فرزندان باید NumberInput/TextInput باشند (داخل InlineFields رندر می‌شوند).
 */
function InputBox({
  label,
  icon: Icon,
  required,
  children,
  className,
}: {
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn(BOX_SHELL, BOX_FOCUS, className)}>
      <BoxLabel label={label} required={required} />
      <div className="flex h-9 w-full min-w-0 items-center gap-1.5">
        {Icon ? <Icon className="size-[18px] shrink-0 text-primary" /> : null}
        <InlineFields>{children}</InlineFields>
      </div>
    </div>
  );
}

/**
 * کادر انتخاب دوخطی — خط اول عنوان ریز، خط دوم آیکون + مقدار + فلش.
 * بدون onClick به‌صورت کادر ایستا (غیرتعاملی) رندر می‌شود.
 */
function PickBox({
  label,
  icon: Icon,
  value,
  placeholder = "انتخاب کنید",
  withChevron = true,
  required,
  onClick,
  className,
}: {
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  value?: string | null;
  placeholder?: string;
  withChevron?: boolean;
  required?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  const labelEl = <BoxLabel label={label} required={required} />;
  const valueEl = (
    <div className="flex h-9 w-full min-w-0 items-center gap-1.5">
      {Icon ? <Icon className="size-[18px] shrink-0 text-primary" /> : null}
      <span
        className={cn(
          "min-w-0 flex-1 truncate text-[15px] font-semibold leading-6",
          value ? "text-foreground" : "font-normal text-muted-foreground/70"
        )}
      >
        {value || placeholder}
      </span>
      {withChevron && onClick ? (
        <ChevronDown className="size-4 shrink-0 text-muted-foreground/80" />
      ) : null}
    </div>
  );
  if (!onClick) {
    return (
      <div className={cn(BOX_SHELL, className)}>
        {labelEl}
        {valueEl}
      </div>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        BOX_SHELL,
        "text-right active:bg-muted/60",
        "focus-visible:border-primary focus-visible:shadow-[0_0_0_3px] focus-visible:shadow-primary/15",
        className
      )}
    >
      {labelEl}
      {valueEl}
    </button>
  );
}

/* ═══════════ شیت انتخاب نوع سرویس — جستجوپذیر و کشیدنی ═══════════ */

function ServiceTypePickerSheet({
  open,
  onClose,
  serviceTypes,
  value,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  serviceTypes: ServiceTypeItem[];
  value: string;
  onPick: (label: string) => void;
}) {
  const [q, setQ] = React.useState("");

  React.useEffect(() => {
    if (open) setQ("");
  }, [open]);

  const qTrim = q.trim();
  const filtered = qTrim
    ? serviceTypes.filter((t) => t.label.includes(qTrim))
    : serviceTypes;
  const exactExists = serviceTypes.some((t) => t.label === qTrim);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="انتخاب نوع سرویس"
      subtitle={`${fa(serviceTypes.length)} نوع — جستجو کنید یا انتخاب کنید`}
      maxHeight="sheet-h-85"
    >
      {/* جستجو */}
      <div className="relative mb-3">
        <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
        <input
          dir="rtl"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی نوع سرویس..."
          className="h-12 w-full rounded-xl border border-input bg-background pr-11 pl-4 text-[16px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary/60 focus:outline-none focus:ring-[3px] focus:ring-primary/15"
        />
      </div>

      {/* لیست انواع */}
      <div className="sheet-h-58 overflow-y-auto overscroll-contain">
        {filtered.map((t) => {
          const kind = t.kind ?? "SERVICE";
          const isSelected = t.label === value;
          const presetCount =
            t.complementary?.filter((c) => PRESET_COMPS.includes(c)).length ?? 0;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                onPick(t.label);
                onClose();
              }}
              className={cn(
                "mb-1 flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-right transition-colors active:scale-[.99]",
                isSelected ? "bg-primary/10" : "hover:bg-muted/60"
              )}
            >
              <span
                className={cn(
                  "flex size-10 shrink-0 items-center justify-center rounded-xl",
                  kind === "PART" ? "bg-primary/12" : "bg-teal-500/10"
                )}
              >
                {kind === "PART" ? (
                  <Wrench className="size-5 text-primary" />
                ) : (
                  <Cog className="size-5 text-teal-600 dark:text-teal-300" />
                )}
              </span>
              <span className="flex min-w-0 flex-1 flex-col items-start gap-1">
                <span
                  className={cn(
                    "truncate text-[16px]",
                    isSelected ? "font-bold text-primary" : "font-medium text-foreground"
                  )}
                >
                  {t.label}
                </span>
                <span className="flex flex-wrap items-center gap-1.5">
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[11px] font-bold",
                      kind === "PART"
                        ? "bg-primary/10 text-primary"
                        : "bg-teal-500/10 text-teal-700 dark:text-teal-300"
                    )}
                  >
                    {SERVICE_KIND_LABELS[kind]}
                  </span>
                  {presetCount ? (
                    <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                      {fa(presetCount)} سرویس مکمل
                    </span>
                  ) : null}
                </span>
              </span>
              {isSelected && <Check className="size-5 shrink-0 text-primary" />}
            </button>
          );
        })}
        {filtered.length === 0 && (
          <p className="py-8 text-center text-[15px] text-muted-foreground">نوع سرویسی یافت نشد</p>
        )}
      </div>

      {/* استفاده از عبارت جستجو به‌عنوان نوع دلخواه */}
      {qTrim && !exactExists && (
        <button
          type="button"
          onClick={() => {
            onPick(qTrim);
            onClose();
          }}
          className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-primary/45 bg-primary/5 text-[14px] font-bold text-primary transition-colors active:bg-primary/10"
        >
          <Plus className="size-4.5" />
          انتخاب «{qTrim}» به‌عنوان نوع دلخواه
        </button>
      )}
    </BottomSheet>
  );
}

/* ═════════════════════════════ فرم اصلی ═════════════════════════════ */

export function ServiceFormSheet({
  open,
  initial,
  vehicles,
  serviceTypes,
  defaultVehicleId,
  currentKm,
  onClose,
  onSaved,
  onDeleted,
}: ServiceFormSheetProps) {
  const { toast } = useToast();
  const isEdit = Boolean(initial);

  const [vehicleId, setVehicleId] = React.useState<string>("");
  const [date, setDate] = React.useState<string>(todayISO());
  const [mileage, setMileage] = React.useState<number | null>(null);
  const [cost, setCost] = React.useState<number | null>(null);
  const [title, setTitle] = React.useState<string>("");
  const [kind, setKind] = React.useState<ServiceKind>("SERVICE");
  const [partsCost, setPartsCost] = React.useState<number | null>(null);
  const [laborCost, setLaborCost] = React.useState<number | null>(null);
  const [compRows, setCompRows] = React.useState<CompRow[]>([]);
  const [provider, setProvider] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [nextMode, setNextMode] = React.useState<NextServiceMode>("off");
  const [nextDueKm, setNextDueKm] = React.useState<number | null>(null);
  const [nextDueDate, setNextDueDate] = React.useState<string | null>(null);

  const [saving, setSaving] = React.useState(false);
  const [deleting, setDeleting] = React.useState(false);
  const [error, setError] = React.useState("");

  // شیت‌ها و انتخاب‌گرها
  const [typePickerOpen, setTypePickerOpen] = React.useState(false);
  const [vehiclePickerOpen, setVehiclePickerOpen] = React.useState(false);
  const [dateOpen, setDateOpen] = React.useState(false);
  const [dateDraft, setDateDraft] = React.useState<PersianDate | null>(null);
  const [nextDateOpen, setNextDateOpen] = React.useState(false);
  const [nextDateDraft, setNextDateDraft] = React.useState<PersianDate | null>(null);

  /** نوع سرویس منطبق با عنوان انتخاب‌شده */
  const matchedType = React.useMemo(() => {
    const t = title.trim();
    if (!t) return null;
    return serviceTypes.find((st) => st.label === t) ?? null;
  }, [serviceTypes, title]);

  // ردیابی نوع منطبق قبلی — برای تغییر ساختار فرم هنگام تعویض نوع سرویس
  const lastTypeKey = React.useRef<string | null>(null);
  // جلوگیری از اجرای افکت تغییر نوع در همان کامیتِ باز شدن فرم (داده‌های ویرایش)
  const skipMatchedEffect = React.useRef(false);

  React.useEffect(() => {
    if (!open) return;
    setError("");
    if (initial) {
      setVehicleId(initial.vehicleId);
      setDate(initial.date.slice(0, 10));
      setMileage(initial.mileage);
      setCost(initial.cost);
      setTitle(initial.title ?? "");
      const mt = initial.title ? serviceTypes.find((st) => st.label === initial.title!.trim()) ?? null : null;
      const k: ServiceKind = mt
        ? (mt.kind ?? "SERVICE")
        : initial.costMode === "SEPARATE"
          ? "PART"
          : "SERVICE";
      setKind(k);
      setPartsCost(initial.partsCost);
      setLaborCost(initial.laborCost);
      setCompRows(buildCompRows(initial.complementary ?? []));
      lastTypeKey.current = mt?.id ?? `custom:${initial.title ?? ""}`;
      setProvider(initial.provider ?? "");
      setDescription(initial.description ?? "");
      setNextDueKm(initial.nextDueKm);
      setNextDueDate(initial.nextDueDate);
      const hadDate = Boolean(initial.nextDueDate);
      const hadKm = Boolean(initial.nextDueKm);
      setNextMode(hadDate && hadKm ? "both" : hadDate ? "date" : hadKm ? "km" : "off");
    } else {
      setVehicleId(defaultVehicleId ?? vehicles[0]?.id ?? "");
      setDate(todayISO());
      setMileage(null);
      setCost(null);
      setTitle("");
      setKind("SERVICE");
      setPartsCost(null);
      setLaborCost(null);
      setCompRows(buildCompRows([]));
      lastTypeKey.current = null;
      setProvider("");
      setDescription("");
      setNextMode("off");
      setNextDueKm(null);
      setNextDueDate(null);
    }
    skipMatchedEffect.current = true;
  }, [open, initial]);

  /* ---- تغییر ساختار فرم با تغییر نوع سرویس ---- */
  React.useEffect(() => {
    if (!open) return;
    if (skipMatchedEffect.current) {
      skipMatchedEffect.current = false;
      return;
    }
    const key = matchedType?.id ?? (title.trim() ? `custom:${title.trim()}` : "empty");
    if (key === lastTypeKey.current) return;
    // تعویض نوع سرویس → ساختار قیمت‌ها و مکمل‌ها بر اساس نوع جدید بازسازی می‌شود
    lastTypeKey.current = key;
    const k: ServiceKind = matchedType?.kind ?? "SERVICE";
    setKind(k);
    setCost(null);
    setPartsCost(null);
    setLaborCost(null);
    setCompRows(buildCompRows([]));
  }, [matchedType, open]);

  /* ---- پیش‌نویس انتخاب‌گرهای تاریخ ---- */
  React.useEffect(() => {
    if (dateOpen) setDateDraft(jFromISO(date));
  }, [dateOpen, date]);

  React.useEffect(() => {
    if (nextDateOpen && nextDueDate) setNextDateDraft(jFromISO(nextDueDate));
  }, [nextDateOpen, nextDueDate]);

  const vehicleOptions = vehicles.map((v) => ({ value: v.id, label: v.name }));
  const vehicleName = vehicles.find((v) => v.id === vehicleId)?.name ?? null;

  const validate = (): string => {
    if (!vehicleId) return "خودرو را انتخاب کنید";
    if (!title.trim()) return "نوع سرویس را انتخاب کنید";
    if ((nextMode === "date" || nextMode === "both") && !nextDueDate) {
      return "تاریخ سرویس بعدی را انتخاب کنید";
    }
    if (
      (nextMode === "km" || nextMode === "both") &&
      (nextDueKm === null || nextDueKm <= 0)
    ) {
      return "کارکرد سرویس بعدی را وارد کنید";
    }
    return "";
  };

  /** جمع کل هزینهٔ سرویس — قیمت اصلی (یا قطعه+دستمزد) + مکمل‌های فعال */
  const totalCost = React.useMemo(() => {
    let sum = kind === "PART" ? (partsCost ?? 0) + (laborCost ?? 0) : cost ?? 0;
    for (const it of compRows) {
      if (it.included) sum += it.price ?? 0;
    }
    return sum > 0 ? sum : null;
  }, [kind, cost, partsCost, laborCost, compRows]);

  /** انتخاب/لغو نوع یادآوری سرویس بعدی */
  const pickNextMode = (m: Exclude<NextServiceMode, "off">) => {
    if (nextMode === m) {
      setNextMode("off");
      return;
    }
    if ((m === "date" || m === "both") && !nextDueDate) setNextDueDate(todayISO());
    setNextMode(m);
  };

  const submit = async () => {
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setSaving(true);
    setError("");
    try {
      const payload: Record<string, unknown> = {
        type: "SERVICE",
        vehicleId,
        date,
        mileage,
        title: title.trim(),
      };
      const included = compRows.filter((it) => it.included && it.name.trim());
      if (kind === "PART") {
        payload.costMode = "SEPARATE";
        payload.partsCost = partsCost;
        payload.laborCost = laborCost;
        payload.cost = totalCost;
        // سازگاری با فیلدهای قدیمی فیلتر روغن/هوا
        const oil = included.find((it) => it.name.includes("فیلتر روغن"));
        payload.hasOilFilter = Boolean(oil);
        payload.oilFilterCost = oil?.price ?? null;
        const air = included.find((it) => it.name.includes("فیلتر هوا"));
        payload.hasAirFilter = Boolean(air);
        payload.airFilterCost = air?.price ?? null;
      } else {
        payload.costMode = "TOTAL";
        payload.cost = totalCost;
        payload.partsCost = null;
        payload.laborCost = null;
        payload.hasOilFilter = false;
        payload.oilFilterCost = null;
        payload.hasAirFilter = false;
        payload.airFilterCost = null;
      }
      // سرویس‌های مکمل انجام‌شده — برای هر دو نوع (خدماتی و تعویض قطعه)
      payload.complementary = included.map((it) => ({
        name: it.name.trim(),
        price: it.price,
      }));
      payload.provider = provider.trim() || null;
      payload.description = description.trim() || null;
      if (nextMode !== "off") {
        if ((nextMode === "date" || nextMode === "both") && nextDueDate) {
          payload.nextDueDate = nextDueDate;
        }
        if (
          (nextMode === "km" || nextMode === "both") &&
          nextDueKm !== null &&
          nextDueKm > 0
        ) {
          payload.nextDueKm = nextDueKm;
        }
      }

      const res = await fetch(
        isEdit ? `/api/records/${initial!.id}` : "/api/records",
        {
          method: isEdit ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error ?? "ثبت انجام نشد");
      }

      toast({
        title: isEdit ? "ویرایش شد ✓" : "ثبت شد ✓",
        description: `${isEdit ? "ویرایش سرویس" : "ثبت سرویس"} — ${formatJalaliISO(date)}`,
      });
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!initial || deleting) return;
    if (!confirm("این رکورد حذف شود؟")) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/records/${initial.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("حذف انجام نشد");
      toast({ title: "حذف شد", description: "رکورد سرویس حذف شد" });
      onDeleted?.();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در حذف");
    } finally {
      setDeleting(false);
    }
  };

  /* ---- ردیف سرویس مکمل ---- */
  const setRow = (i: number, patch: Partial<CompRow>) => {
    setCompRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  };
  const toggleRow = (i: number) => {
    setCompRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, included: !r.included } : r)));
  };
  const removeRow = (i: number) => setCompRows((prev) => prev.filter((_, idx) => idx !== i));
  const addCustomRow = () => {
    setCompRows((prev) => [...prev, { name: "", price: null, included: true, custom: true }]);
  };
  const activeCompCount = compRows.filter((r) => r.included && r.name.trim()).length;

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={isEdit ? "ویرایش سرویس" : "ثبت سرویس"}
      subtitle={`${weekdayFromISO(date)} — ${formatJalaliISO(date)}`}
      maxHeight="sheet-h-92"
      footer={
        <div className="flex flex-col gap-2">
          {/* جمع کل — همیشه دیده می‌شود، بالای دکمه‌ها */}
          <div className="flex h-12 items-center justify-between gap-2 rounded-xl bg-primary/10 px-4">
            <span className="flex items-center gap-1.5 text-[13px] font-bold text-muted-foreground">
              <Banknote className="size-4 shrink-0 text-primary" />
              جمع کل هزینه
            </span>
            <span className="text-[17px] font-extrabold tabular-nums text-primary">
              {totalCost !== null ? `${faNum(totalCost)} تومان` : "—"}
            </span>
          </div>
          <div className="flex gap-2">
            {isEdit && (
              <button
                type="button"
                onClick={remove}
                disabled={deleting}
                aria-label="حذف رکورد"
                className="flex h-13 w-14 shrink-0 items-center justify-center rounded-2xl border border-red-200 bg-red-50 text-red-600 transition-colors active:scale-95 disabled:opacity-50 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400"
              >
                {deleting ? <Loader2 className="size-5 animate-spin" /> : <Trash2 className="size-5" />}
              </button>
            )}
            {/* دکمهٔ سبز ثبت */}
            <button
              type="button"
              onClick={submit}
              disabled={saving}
              className="flex h-13 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary text-[16px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-all active:scale-[.98] disabled:opacity-60"
            >
              {saving ? (
                <Loader2 className="size-5 animate-spin" />
              ) : (
                <CheckCircle2 className="size-5" />
              )}
              {isEdit ? "ذخیره تغییرات" : "ثبت سرویس"}
            </button>
          </div>
        </div>
      }
    >
      {error && (
        <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </div>
      )}

      <div className="flex flex-col gap-2.5">
        {/* ۱ — چهار فیلد اصلی در گرید ۲×۲ (راست: خودرو، کارکرد / چپ: تاریخ، نوع سرویس) */}
        <div>
          <div className="grid grid-cols-2 items-stretch gap-2">
            {vehicles.length > 1 ? (
              <PickBox
                label="خودرو"
                icon={Car}
                value={vehicleName}
                onClick={() => setVehiclePickerOpen(true)}
              />
            ) : (
              <PickBox label="خودرو" icon={Car} value={vehicleName} withChevron={false} />
            )}
            <PickBox
              label="تاریخ"
              icon={CalendarDays}
              value={faDateISO(date)}
              withChevron={false}
              onClick={() => setDateOpen(true)}
            />
            <InputBox label="کارکرد" icon={Cog}>
              <NumberInput
                value={mileage}
                onChange={setMileage}
                placeholder="۱۶۲٬۵۰۰"
                max={10_000_000}
                className="h-9 text-[16px]"
              />
            </InputBox>
            <PickBox
              label="نوع سرویس"
              icon={Tag}
              value={title.trim() || null}
              required
              onClick={() => setTypePickerOpen(true)}
            />
          </div>
          {currentKm > 0 && (
            <p className="mt-1.5 px-1 text-[11px] leading-4 text-muted-foreground">
              آخرین کارکرد ثبت‌شده: {faNum(currentKm)} کیلومتر
            </p>
          )}
        </div>

        {/* ۲ — قیمت سرویس (تعویض قطعه: قیمت قطعه + دستمزد) */}
        {kind === "PART" ? (
          <div className="grid grid-cols-2 items-stretch gap-2">
            <InputBox label="قیمت قطعه" icon={Banknote}>
              <NumberInput
                value={partsCost}
                onChange={setPartsCost}
                suffix="تومان"
                placeholder="مثلاً ۸۵۰٬۰۰۰"
                className="h-9 text-[16px]"
              />
            </InputBox>
            <InputBox label="قیمت دستمزد" icon={Banknote}>
              <NumberInput
                value={laborCost}
                onChange={setLaborCost}
                suffix="تومان"
                placeholder="مثلاً ۲۰۰٬۰۰۰"
                className="h-9 text-[16px]"
              />
            </InputBox>
          </div>
        ) : (
          <div>
            <InputBox label="قیمت سرویس" icon={Banknote}>
              <NumberInput
                value={cost}
                onChange={setCost}
                suffix="تومان"
                placeholder="مثلاً ۱٬۵۰۰٬۰۰۰"
                className="h-9 text-[16px]"
              />
            </InputBox>
            <p className="mt-1.5 px-1 text-[11px] leading-4 text-muted-foreground">
              سرویس‌های مکمل در ادامه با قیمت جداگانه اضافه می‌شوند
            </p>
          </div>
        )}

        {/* ۳ — سرویس‌های مکمل — فقط دو گزینهٔ اصلی + موارد دلخواه */}
        <div className="rounded-2xl border border-input bg-card p-1.5">
          <div className="flex h-10 shrink-0 items-center gap-1.5 px-2">
            <ListChecks className="size-4 shrink-0 text-primary" />
            <span className="text-[13.5px] font-bold text-foreground">سرویس‌های مکمل</span>
            <span className="ms-auto rounded-full bg-muted px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
              {fa(activeCompCount)} مورد فعال
            </span>
          </div>
          <div className="flex flex-col gap-0.5">
            {compRows.map((r, i) => (
              <div
                key={i}
                className={cn(
                  "flex items-center gap-2 rounded-xl px-1 transition-colors",
                  r.included ? "bg-primary/[0.06]" : "bg-transparent"
                )}
              >
                {r.custom ? (
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={r.included}
                    aria-label={`${r.included ? "لغو" : "درج"} ${r.name || "مورد"}`}
                    onClick={() => toggleRow(i)}
                    className="flex size-11 shrink-0 items-center justify-center rounded-lg active:bg-muted/60"
                  >
                    <CheckPill checked={r.included} />
                  </button>
                ) : (
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={r.included}
                    aria-label={`${r.included ? "لغو" : "درج"} ${r.name}`}
                    onClick={() => toggleRow(i)}
                    className="flex h-12 min-w-0 flex-1 items-center gap-2.5 rounded-lg pr-1.5 text-right active:bg-muted/40"
                  >
                    <CheckPill checked={r.included} />
                    <span
                      className={cn(
                        "min-w-0 flex-1 truncate text-[15px]",
                        r.included ? "font-bold text-foreground" : "text-muted-foreground"
                      )}
                    >
                      {r.name}
                    </span>
                  </button>
                )}
                {r.custom && (
                  <div className="min-w-0 flex-1">
                    <InlineFields>
                      <TextInput
                        dir="rtl"
                        value={r.name}
                        onChange={(e) => setRow(i, { name: e.target.value })}
                        placeholder="نام مورد دلخواه..."
                        autoFocus={i === compRows.length - 1 && !r.name}
                        className="h-9 text-[16px]"
                      />
                    </InlineFields>
                  </div>
                )}
                <div className="w-[118px] shrink-0">
                  <InlineFields>
                    <NumberInput
                      value={r.price}
                      onChange={(v) => setRow(i, { price: v })}
                      placeholder="قیمت"
                      suffix="تومان"
                      className="h-9 text-[16px]"
                    />
                  </InlineFields>
                </div>
                {r.custom && (
                  <button
                    type="button"
                    onClick={() => removeRow(i)}
                    aria-label="حذف مورد دلخواه"
                    className="flex size-11 shrink-0 items-center justify-center rounded-lg text-red-500 active:bg-red-500/10"
                  >
                    <X className="size-[18px]" />
                  </button>
                )}
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={addCustomRow}
            className="mt-1 flex h-11 w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-primary/40 text-[13.5px] font-bold text-primary transition-colors active:bg-primary/5"
          >
            <Plus className="size-4" />
            افزودن مورد دلخواه
          </button>
        </div>

        {/* ۴ — مرکز خدمات / تعمیرکار */}
        <InputBox label="مرکز خدمات / تعمیرکار" icon={Wrench}>
          <TextInput
            dir="rtl"
            value={provider}
            onChange={(e) => setProvider(e.target.value)}
            placeholder="مثلاً تعمیرگاه آریا..."
            className="h-9 text-[16px]"
          />
        </InputBox>

        {/* ۵ — ثبت سرویس بعدی — انتخاب نوع یادآوری */}
        <div className="rounded-2xl border border-input bg-card p-1.5">
          <div className="flex h-10 shrink-0 items-center gap-1.5 px-2">
            <BellRing className="size-4 shrink-0 text-primary" />
            <span className="text-[13.5px] font-bold text-foreground">ثبت سرویس بعدی</span>
            <span
              className={cn(
                "ms-auto rounded-full px-2 py-0.5 text-[10.5px] font-bold",
                nextMode !== "off" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
              )}
            >
              {nextMode !== "off" ? "فعال" : "غیرفعال"}
            </span>
          </div>
          <div className="flex flex-col gap-0.5" role="radiogroup" aria-label="نوع یادآوری سرویس بعدی">
            {NEXT_MODE_OPTIONS.map((m) => {
              const selected = nextMode === m.value;
              return (
                <button
                  key={m.value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => pickNextMode(m.value)}
                  className={cn(
                    "flex h-11 w-full items-center gap-2.5 rounded-xl px-2.5 transition-colors active:scale-[.99]",
                    selected ? "bg-primary/10" : "hover:bg-muted/50"
                  )}
                >
                  <span
                    className={cn(
                      "flex size-5 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
                      selected ? "border-primary" : "border-muted-foreground/35"
                    )}
                  >
                    {selected && <span className="size-2 rounded-full bg-primary" />}
                  </span>
                  <span
                    className={cn(
                      "text-[15px]",
                      selected ? "font-bold text-foreground" : "font-medium text-muted-foreground"
                    )}
                  >
                    {m.label}
                  </span>
                </button>
              );
            })}
          </div>
          {nextMode === "off" ? (
            <p className="px-2.5 pb-1 pt-1.5 text-[11px] leading-4 text-muted-foreground">
              با انتخاب نوع یادآوری، سررسید سرویس بعدی به یادآورها اضافه می‌شود (برای لغو، گزینهٔ فعال را دوباره بزنید)
            </p>
          ) : (
            <div className="flex flex-col gap-2 px-1 pb-1 pt-1.5">
              {(nextMode === "date" || nextMode === "both") && (
                <PickBox
                  label="تاریخ سرویس بعدی"
                  icon={CalendarDays}
                  value={nextDueDate ? faDateISO(nextDueDate) : null}
                  withChevron={false}
                  onClick={() => setNextDateOpen(true)}
                  className="h-auto"
                />
              )}
              {(nextMode === "km" || nextMode === "both") && (
                <InputBox label="کارکرد سرویس بعدی" icon={Cog}>
                  <NumberInput
                    value={nextDueKm}
                    onChange={setNextDueKm}
                    suffix="کیلومتر"
                    placeholder={mileage ? faNum(mileage + 5000) : "۱۶۷٬۵۰۰"}
                    max={10_000_000}
                    className="h-9 text-[16px]"
                  />
                </InputBox>
              )}
            </div>
          )}
        </div>

        {/* ۶ — توضیحات */}
        <div className={cn(BOX_SHELL, BOX_FOCUS, "h-auto gap-1.5")}>
          <BoxLabel label="توضیحات" />
          <InlineFields>
            <TextArea
              dir="rtl"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="نکات، قطعات، برند روغن و..."
              rows={2}
              className="text-[16px] leading-7"
            />
          </InlineFields>
        </div>
      </div>

      {/* شیت‌ها و انتخاب‌گرهای فرم */}
      <ServiceTypePickerSheet
        open={typePickerOpen}
        onClose={() => setTypePickerOpen(false)}
        serviceTypes={serviceTypes}
        value={title.trim()}
        onPick={(label) => setTitle(label)}
      />
      {vehicles.length > 1 && (
        <PickerSheet
          open={vehiclePickerOpen}
          onClose={() => setVehiclePickerOpen(false)}
          title="انتخاب خودرو"
          maxHeight="sheet-h-82"
          options={vehicleOptions}
          value={vehicleId || null}
          onChange={setVehicleId}
        />
      )}
      <PersianWheelDatePicker
        open={dateOpen}
        value={dateDraft ?? jFromISO(date)}
        onConfirm={(j) => {
          setDate(jalaliToISO(j));
          setDateOpen(false);
        }}
        onCancel={() => setDateOpen(false)}
        title="انتخاب تاریخ"
      />
      <PersianWheelDatePicker
        open={nextDateOpen}
        value={nextDateDraft ?? jFromISO(nextDueDate ?? todayISO())}
        onConfirm={(j) => {
          setNextDueDate(jalaliToISO(j));
          setNextDateOpen(false);
        }}
        onCancel={() => setNextDateOpen(false)}
        title="تاریخ سرویس بعدی"
      />
    </BottomSheet>
  );
}

/** قرص علامت سرویس مکمل — فقط نمایشی، دکمهٔ والد عمل را انجام می‌دهد */
function CheckPill({ checked }: { checked: boolean }) {
  return (
    <span
      className={cn(
        "flex size-[22px] shrink-0 items-center justify-center rounded-[7px] border-2 transition-colors",
        checked
          ? "border-primary bg-primary text-primary-foreground"
          : "border-muted-foreground/30 bg-card text-transparent"
      )}
    >
      <Check className="size-3.5" strokeWidth={3} />
    </span>
  );
}
