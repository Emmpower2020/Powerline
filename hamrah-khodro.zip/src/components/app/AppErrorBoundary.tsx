"use client";

/**
 * ErrorBoundary سراسری (v3.8.9) — محافظ آخر در برابر کرش رندر React.
 *
 * چرا لازم است؟ اگر هنگام رندرِ داده‌ها (مثلاً پس از بازیابی ابری با فیلدی با شکل
 * غیرمنتظره) استثنایی رخ دهد، React کل درخت را از صفحه برمی‌دارد و کاربر صفحهٔ
 * خالی/مرده می‌بیند («از حالت طبیعی خارج می‌شود») تا وقتی برنامه را کامل ببندد و
 * باز کند. این مرز خطا به‌جای آن، کارت فارسی «خطای غیرمنتظره» + دکمهٔ «بارگذاری
 * دوباره» نمایش می‌دهد؛ داده‌های محلی هم دست‌نخورده‌اند (فایل data.json سمت جاوا).
 *
 * نکته: این مؤلفه فقط خطاهای «رندر» را می‌گیرد (خطای event handler ها به اینجا
 * نمی‌رسد — همان رفتار استاندارد React).
 */

import * as React from "react";
import { AlertTriangle, Loader2, RefreshCw } from "lucide-react";

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  error: Error | null;
  reloading: boolean;
}

export class AppErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { error: null, reloading: false };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // ثبت در کنسول برای عیب‌یابی (در نسخهٔ نصبی با chrome://inspect قابل مشاهده)
    try {
      console.error("[HK ErrorBoundary]", error, info.componentStack);
    } catch {
      /* ignore */
    }
  }

  private reload = () => {
    this.setState({ reloading: true });
    try {
      window.location.reload();
    } catch {
      this.setState({ reloading: false });
    }
  };

  render() {
    if (this.state.error) {
      return (
        <div dir="rtl" className="flex min-h-dvh items-center justify-center bg-background p-6">
          <div className="flex w-full max-w-sm flex-col items-center rounded-3xl border border-border/70 bg-card p-7 text-center shadow-xl">
            <span className="flex size-16 items-center justify-center rounded-full bg-red-500/10">
              <AlertTriangle className="size-8 text-red-600" strokeWidth={1.9} />
            </span>
            <h1 className="mt-4 text-[18px] font-extrabold text-foreground">خطای غیرمنتظره</h1>
            <p className="mt-2 text-[13.5px] leading-7 text-muted-foreground">
              نمایش برنامه دچار خطا شد — داده‌های شما سالم و ذخیره‌شده است. با بارگذاری
              دوباره، برنامه بدون از دست رفتن اطلاعات بالا می‌آید.
            </p>
            {typeof this.state.error.message === "string" && this.state.error.message && (
              <p dir="ltr" className="mt-3 max-h-24 w-full overflow-y-auto rounded-xl bg-muted px-3 py-2 text-left text-[11px] leading-5 text-muted-foreground">
                {this.state.error.message.slice(0, 300)}
              </p>
            )}
            <button
              type="button"
              onClick={this.reload}
              disabled={this.state.reloading}
              className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[15.5px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-all active:scale-[.97] disabled:opacity-60"
            >
              {this.state.reloading ? (
                <Loader2 className="size-5 animate-spin" />
              ) : (
                <RefreshCw className="size-5" />
              )}
              بارگذاری دوبارهٔ برنامه
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
