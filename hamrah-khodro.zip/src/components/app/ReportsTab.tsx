"use client";

/**
 * تب گزارشات — کارت‌های آماری + نمودار هزینه ماهانه و مصرف سوخت + مقایسه ماه قبل
 * + ماشین‌حساب «مصرف سوخت» بر اساس بازهٔ تاریخ یا انتخاب سوخت‌گیری‌ها.
 */

import * as React from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Calculator,
  Fuel,
  Gauge,
  Receipt,
  Wrench,
  CalendarClock,
  Droplets,
  TrendingUp,
  TrendingDown,
  ChevronDown,
  Check,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { fa, faNum, faMoneyShort, formatJalaliISO } from "@/lib/persian";
import type { RecordItem, VehicleStats } from "@/lib/types";
import { PickerSheet } from "./fields";
import { EmptyVehicles, PageHeader } from "./shared";
import { BottomSheet } from "./BottomSheet";
import { PersianWheelDatePicker } from "@/components/persian-calendar/PersianWheelDatePicker";
import { isoToJalali, jalaliToISO, todayISO, formatJalaliNumericISO } from "@/lib/persian";

interface ReportsTabProps {
  stats: VehicleStats[];
  vehicleNames: Map<string, string>;
  records: RecordItem[];
  onAddVehicle: () => void;
  onGoSettings: () => void;
}

const TEAL = "#0E9F8E";
const AMBER = "#F59E0B";
const RED = "#EF4444";
const VIOLET = "#8B5CF6";

export function ReportsTab({ stats, vehicleNames, records, onAddVehicle, onGoSettings }: ReportsTabProps) {
  const [selected, setSelected] = React.useState<string>("all");
  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [calcOpen, setCalcOpen] = React.useState(false);

  const current = React.useMemo(() => {
    if (selected === "all") {
      const monthMap = new Map<number, { label: string; service: number; fuel: number }>();
      for (const s of stats) {
        for (const m of s.monthlyCosts) {
          const existing = monthMap.get(m.monthIndex) ?? { label: m.label, service: 0, fuel: 0 };
          existing.service += m.service;
          existing.fuel += m.fuel;
          monthMap.set(m.monthIndex, existing);
        }
      }
      const monthlyCosts = Array.from(monthMap.entries())
        .sort((a, b) => a[0] - b[0])
        .map(([, v]) => ({ ...v, monthIndex: 0 }));

      const withConsumption = stats.filter((s) => s.avgConsumption !== null);
      const avgConsumption =
        withConsumption.length > 0
          ? Math.round(
              (withConsumption.reduce((sum, s) => sum + (s.avgConsumption ?? 0), 0) /
                withConsumption.length) *
                10
            ) / 10
          : null;

      return {
        vehicleId: "all",
        currentKm: Math.max(0, ...stats.map((s) => s.currentKm)),
        totalCost: stats.reduce((sum, s) => sum + s.totalCost, 0),
        monthCost: stats.reduce((sum, s) => sum + s.monthCost, 0),
        prevMonthCost: stats.reduce((sum, s) => sum + s.prevMonthCost, 0),
        serviceCount: stats.reduce((sum, s) => sum + s.serviceCount, 0),
        fuelCount: stats.reduce((sum, s) => sum + s.fuelCount, 0),
        fuelTotalLiters: Math.round(stats.reduce((sum, s) => sum + s.fuelTotalLiters, 0) * 10) / 10,
        fuelTotalCost: stats.reduce((sum, s) => sum + s.fuelTotalCost, 0),
        avgConsumption,
        lastServiceKm: null,
        monthlyCosts,
        consumptionPoints: [],
      } satisfies VehicleStats;
    }
    return stats.find((s) => s.vehicleId === selected) ?? null;
  }, [stats, selected]);

  const chartData = React.useMemo(
    () =>
      (current?.monthlyCosts ?? []).map((m) => ({
        name: m.label,
        سرویس: m.service,
        سوخت: m.fuel,
      })),
    [current]
  );

  const consumptionData = React.useMemo(
    () =>
      (current?.consumptionPoints ?? []).map((p) => ({
        name: p.label,
        مصرف: p.value,
      })),
    [current]
  );

  /** مقایسه با ماه قبل */
  const monthDiff = React.useMemo(() => {
    if (!current) return null;
    const { monthCost, prevMonthCost } = current;
    if (prevMonthCost === 0 && monthCost === 0) return null;
    const diff = monthCost - prevMonthCost;
    const pct = prevMonthCost > 0 ? Math.round((diff / prevMonthCost) * 100) : null;
    return { diff, pct, increased: diff > 0 };
  }, [current]);

  if (stats.length === 0) {
    return (
      <div>
        <PageHeader title="گزارشات" badge={`${fa(records.length)} رکورد`} />
        <div className="px-4 pb-32">
          <EmptyVehicles
            title="گزارشی برای نمایش نیست"
            desc="گزارش‌ها بر اساس خودرو و رکوردهای ثبت‌شده ساخته می‌شوند. ابتدا خودروی خود را اضافه کنید."
            onAddVehicle={onAddVehicle}
            onGoSettings={onGoSettings}
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="گزارشات" badge={`${fa(records.length)} رکورد`} />

      {/* انتخاب خودرو — شیت جستجوپذیر کشیدنی */}
      <div className="sticky top-0 z-10 bg-background/95 px-4 pb-2.5 pt-1 backdrop-blur-md">
        <button
          type="button"
          onClick={() => setPickerOpen(true)}
          className="flex h-11 w-full items-center justify-between rounded-2xl border border-input bg-card px-3.5 text-right transition-colors focus:border-primary focus:outline-none active:bg-muted/50"
        >
          <span className="truncate text-[14px] font-bold text-foreground">
            {selected === "all" ? "همه خودروها" : (vehicleNames.get(selected) ?? "خودرو")}
          </span>
          <ChevronDown className="size-4.5 shrink-0 text-muted-foreground" />
        </button>
      </div>

      <PickerSheet
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        title="انتخاب خودرو"
        subtitle={`${fa(stats.length + 1)} گزینه — جستجو کنید یا انتخاب کنید`}
        options={[
          { value: "all", label: "همه خودروها" },
          ...stats.map((s) => ({
            value: s.vehicleId,
            label: vehicleNames.get(s.vehicleId) ?? "خودرو",
          })),
        ]}
        value={selected}
        onChange={setSelected}
        searchPlaceholder="جستجوی خودرو..."
      />

      <div className="px-4 pb-32">
        {/* مقایسه با ماه قبل */}
        {monthDiff && (
          <div
            className={cn(
              "mb-3 flex items-center gap-2.5 rounded-2xl px-4 py-3",
              monthDiff.increased ? "bg-red-500/8" : "bg-emerald-500/8"
            )}
          >
            {monthDiff.increased ? (
              <TrendingUp className="size-5 shrink-0 text-red-600" />
            ) : (
              <TrendingDown className="size-5 shrink-0 text-emerald-600" />
            )}
            <span
              className={cn(
                "text-[14px] font-bold",
                monthDiff.increased ? "text-red-700" : "text-emerald-700"
              )}
            >
              {monthDiff.increased ? "افزایش" : "کاهش"} {faNum(Math.abs(monthDiff.diff))} تومان نسبت به ماه قبل
              {monthDiff.pct !== null && ` (${fa(Math.abs(monthDiff.pct))}%)`}
            </span>
          </div>
        )}

        {/* کارت‌های آماری */}
        <div className="grid grid-cols-2 gap-2.5">
          <StatCard
            icon={Receipt}
            color={TEAL}
            bg="bg-teal-500/10"
            label="هزینه این ماه"
            value={faMoneyShort(current?.monthCost ?? 0)}
            unit="تومان"
          />
          <StatCard
            icon={Gauge}
            color={VIOLET}
            bg="bg-violet-500/10"
            label={selected === "all" ? "بیشترین کارکرد" : "کارکرد فعلی"}
            value={faNum(current?.currentKm ?? 0)}
            unit="کیلومتر"
          />
          <StatCard
            icon={Droplets}
            color={AMBER}
            bg="bg-amber-500/10"
            label="میانگین مصرف"
            value={current?.avgConsumption !== null && current?.avgConsumption !== undefined ? faNum(current.avgConsumption, 1) : "—"}
            unit="لیتر/۱۰۰کیلومتر"
          />
          <StatCard
            icon={CalendarClock}
            color={RED}
            bg="bg-red-500/10"
            label="مجموع هزینه"
            value={faMoneyShort(current?.totalCost ?? 0)}
            unit="تومان"
          />
        </div>

        {/* ماشین‌حساب مصرف سوخت — بر اساس تاریخ یا انتخاب سوخت‌گیری‌ها */}
        <button
          type="button"
          onClick={() => setCalcOpen(true)}
          className="mt-3.5 flex w-full items-center gap-3.5 rounded-2xl border border-primary/40 bg-primary/8 p-4 text-right shadow-sm transition-all active:scale-[.98]"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/15">
            <Calculator className="size-5.5 text-primary" strokeWidth={2.1} />
          </span>
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="text-[15px] font-bold text-foreground">محاسبهٔ مصرف سوخت</span>
            <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">
              بر اساس بازهٔ تاریخ یا انتخاب سوخت‌گیری‌های دلخواه
            </span>
          </span>
          <ChevronDown className="size-4.5 shrink-0 -rotate-90 text-primary" />
        </button>

        {/* نمودار هزینه ماهانه */}
        <Card title="هزینه‌های ۶ ماه اخیر" icon={Wrench}>
          {chartData.every((d) => d.سرویس === 0 && d.سوخت === 0) ? (
            <EmptyChart text="هنوز هزینه‌ای ثبت نشده" />
          ) : (
            <div dir="ltr" className="h-[230px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                  <XAxis
                    dataKey="name"
                    reversed
                    tick={{ fontSize: 11, fill: "#6b7280" }}
                    tickLine={false}
                    axisLine={{ stroke: "#e5e7eb" }}
                    interval={0}
                    tickFormatter={(v: string) => v.split(" ")[0]}
                  />
                  <YAxis
                    orientation="right"
                    width={54}
                    tick={{ fontSize: 11, fill: "#6b7280" }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v: number) => faMoneyShort(v)}
                  />
                  <Tooltip
                    content={<ChartTooltip />}
                    cursor={{ fill: "rgba(14,159,142,0.06)" }}
                  />
                  <Bar dataKey="سرویس" stackId="a" fill={TEAL} radius={[0, 6, 6, 0]} maxBarSize={34} />
                  <Bar dataKey="سوخت" stackId="a" fill={AMBER} radius={[6, 6, 0, 0]} maxBarSize={34} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
          <div className="mt-2 flex items-center justify-center gap-5 text-[12px] font-medium text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-full" style={{ background: TEAL }} />
              سرویس
            </span>
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-full" style={{ background: AMBER }} />
              سوخت
            </span>
          </div>
        </Card>

        {/* نمودار مصرف سوخت */}
        {selected !== "all" && (
          <Card title="روند مصرف سوخت" icon={Fuel}>
            {consumptionData.length < 2 ? (
              <EmptyChart text="برای نمایش مصرف، حداقل دو سوخت‌گیری باک‌کامل لازم است" />
            ) : (
              <div dir="ltr" className="h-[210px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={consumptionData} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis
                      dataKey="name"
                      reversed
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={{ stroke: "#e5e7eb" }}
                    />
                    <YAxis
                      orientation="right"
                      width={40}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={false}
                      domain={["dataMin - 1", "dataMax + 1"]}
                    />
                    <Tooltip content={<ChartTooltip />} />
                    <Line
                      type="monotone"
                      dataKey="مصرف"
                      stroke={AMBER}
                      strokeWidth={2.5}
                      dot={{ r: 3.5, fill: AMBER, strokeWidth: 0 }}
                      activeDot={{ r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </Card>
        )}

        {/* جزئیات */}
        <Card title="جزئیات" icon={Receipt}>
          <dl className="divide-y divide-border/70">
            <Row label="تعداد سرویس‌ها" value={`${fa(current?.serviceCount ?? 0)} بار`} />
            <Row label="تعداد سوخت‌گیری‌ها" value={`${fa(current?.fuelCount ?? 0)} بار`} />
            <Row
              label="مجموع سوخت خریداری‌شده"
              value={`${faNum(current?.fuelTotalLiters ?? 0, 1)} لیتر`}
            />
            <Row
              label="مجموع هزینه سوخت"
              value={`${faNum(current?.fuelTotalCost ?? 0)} تومان`}
            />
            {selected !== "all" && current?.lastServiceKm !== null && current?.lastServiceKm !== undefined && (
              <Row
                label="آخرین سرویس در کارکرد"
                value={`${faNum(current.lastServiceKm)} کیلومتر`}
              />
            )}
            {records.length > 0 && (
              <Row
                label="آخرین فعالیت"
                value={formatJalaliISO(records[0].date)}
              />
            )}
          </dl>
        </Card>
      </div>

      {/* شیت ماشین‌حساب مصرف سوخت */}
      <ConsumptionSheet
        open={calcOpen}
        onClose={() => setCalcOpen(false)}
        records={records}
        vehicleNames={vehicleNames}
      />
    </div>
  );
}

/* ═════════════════════ ماشین‌حساب مصرف سوخت ═════════════════════ */

interface ConsumptionResult {
  liters: number;
  km: number;
  avg: number | null;
  fills: number;
  cost: number;
  costPerKm: number | null;
}

/** محاسبهٔ مصرف روی مجموعهٔ سوخت‌گیری‌های انتخاب‌شده — باک‌کامل به باک‌کامل */
function computeConsumption(fuels: RecordItem[]): ConsumptionResult {
  const sorted = [...fuels].sort((a, b) => a.date.localeCompare(b.date));
  let prevFull: number | null = null;
  let litersSinceFull = 0;
  let totalLiters = 0;
  let totalKm = 0;
  let fills = 0;
  for (const f of sorted) {
    litersSinceFull += f.liters ?? 0;
    if (
      f.fullTank &&
      prevFull !== null &&
      f.mileage !== null &&
      f.mileage > prevFull &&
      litersSinceFull > 0
    ) {
      totalKm += f.mileage - prevFull;
      totalLiters += litersSinceFull;
      fills++;
    }
    if (f.fullTank) {
      prevFull = f.mileage;
      litersSinceFull = 0;
    }
  }
  const cost = sorted.reduce((sum, f) => sum + (f.cost ?? 0), 0);
  const avg = totalKm > 0 && totalLiters > 0 ? (totalLiters / totalKm) * 100 : null;
  return {
    liters: Math.round(totalLiters * 10) / 10,
    km: totalKm,
    avg: avg !== null ? Math.round(avg * 10) / 10 : null,
    fills,
    cost,
    costPerKm: totalKm > 0 ? cost / totalKm : null,
  };
}

function ConsumptionSheet({
  open,
  onClose,
  records,
  vehicleNames,
}: {
  open: boolean;
  onClose: () => void;
  records: RecordItem[];
  vehicleNames: Map<string, string>;
}) {
  const fuelRecords = React.useMemo(
    () => records.filter((r) => r.type === "FUEL"),
    [records]
  );

  // خودروهایی که سوخت ثبت کرده‌اند
  const vehicleIds = React.useMemo(() => {
    const s = new Set(fuelRecords.map((r) => r.vehicleId));
    return Array.from(s);
  }, [fuelRecords]);

  const [vehicleId, setVehicleId] = React.useState<string | null>(null);
  const [vehiclePickerOpen, setVehiclePickerOpen] = React.useState(false);
  const [mode, setMode] = React.useState<"date" | "select">("date");
  const [from, setFrom] = React.useState<string>(todayISO());
  const [to, setTo] = React.useState<string>(todayISO());
  const [fromPickerOpen, setFromPickerOpen] = React.useState(false);
  const [toPickerOpen, setToPickerOpen] = React.useState(false);
  const [selectedIds, setSelectedIds] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    if (!open) return;
    const first = vehicleIds[0] ?? null;
    setVehicleId(first);
    setMode("date");
    setSelectedIds(new Set());
    const vf = fuelRecords.filter((r) => r.vehicleId === first);
    if (vf.length > 0) {
      setFrom(vf[vf.length - 1].date);
      setTo(todayISO());
    } else {
      setFrom(todayISO());
      setTo(todayISO());
    }
  }, [open, vehicleIds, fuelRecords]);

  const vehicleFuels = React.useMemo(
    () => fuelRecords.filter((r) => r.vehicleId === vehicleId),
    [fuelRecords, vehicleId]
  );

  const scoped = React.useMemo(() => {
    if (!vehicleId) return [];
    if (mode === "date") {
      return vehicleFuels.filter((r) => r.date >= from && r.date <= to);
    }
    return vehicleFuels.filter((r) => selectedIds.has(r.id));
  }, [vehicleId, mode, vehicleFuels, from, to, selectedIds]);

  const result = React.useMemo(() => computeConsumption(scoped), [scoped]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    setSelectedIds(new Set(vehicleFuels.map((r) => r.id)));
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="محاسبهٔ مصرف سوخت"
      subtitle="بر اساس بازهٔ تاریخ یا انتخاب سوخت‌گیری‌ها"
      maxHeight="max-h-[88dvh]"
    >
      {/* خودرو */}
      <button
        type="button"
        onClick={() => vehicleIds.length > 1 && setVehiclePickerOpen(true)}
        className="mb-3 flex h-12 w-full items-center justify-between rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
      >
        <span className="truncate text-[14px] font-bold text-foreground">
          {vehicleId ? (vehicleNames.get(vehicleId) ?? "خودرو") : "خودرویی با سوخت ثبت‌شده نیست"}
        </span>
        {vehicleIds.length > 1 && <ChevronDown className="size-4 shrink-0 text-muted-foreground" />}
      </button>

      {/* حالت محاسبه */}
      <div className="mb-3 grid grid-cols-2 gap-2">
        {[
          { value: "date" as const, label: "بازهٔ تاریخ" },
          { value: "select" as const, label: "انتخاب سوخت‌گیری‌ها" },
        ].map((m) => (
          <button
            key={m.value}
            type="button"
            onClick={() => setMode(m.value)}
            className={cn(
              "flex h-11 items-center justify-center rounded-xl border-2 text-[13.5px] font-bold transition-all active:scale-[.97]",
              mode === m.value ? "border-primary bg-primary/8 text-primary" : "border-border bg-card text-foreground"
            )}
          >
            {m.label}
          </button>
        ))}
      </div>

      {vehicleFuels.length === 0 ? (
        <p className="py-10 text-center text-[14px] leading-7 text-muted-foreground">
          برای این خودرو سوخت‌گیری ثبت نشده است.
        </p>
      ) : mode === "date" ? (
        <>
          {/* بازهٔ تاریخ */}
          <div className="mb-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setFromPickerOpen(true)}
              className="flex h-12 flex-col items-start justify-center rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
            >
              <span className="text-[10.5px] font-medium text-muted-foreground">از تاریخ</span>
              <span className="text-[13px] font-bold tabular-nums text-foreground">
                {formatJalaliNumericISO(from)}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setToPickerOpen(true)}
              className="flex h-12 flex-col items-start justify-center rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
            >
              <span className="text-[10.5px] font-medium text-muted-foreground">تا تاریخ</span>
              <span className="text-[13px] font-bold tabular-nums text-foreground">
                {formatJalaliNumericISO(to)}
              </span>
            </button>
          </div>
          <p className="mb-3 px-1 text-[12px] text-muted-foreground">
            {fa(scoped.length)} سوخت‌گیری در این بازه
          </p>
        </>
      ) : (
        <>
          {/* انتخاب سوخت‌گیری‌ها */}
          <div className="mb-2 flex items-center justify-between px-1">
            <p className="text-[12px] text-muted-foreground">
              {fa(selectedIds.size)} مورد انتخاب شده
            </p>
            <button
              type="button"
              onClick={selectAll}
              className="text-[12px] font-bold text-primary active:opacity-70"
            >
              انتخاب همه
            </button>
          </div>
          <div className="mb-3 max-h-64 overflow-y-auto overscroll-contain pr-1" style={{ scrollbarWidth: "thin" }}>
            {vehicleFuels.map((r) => {
              const active = selectedIds.has(r.id);
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => toggleSelect(r.id)}
                  className={cn(
                    "mb-1.5 flex w-full items-center gap-3 rounded-xl border px-3.5 py-2.5 text-right transition-colors active:scale-[.99]",
                    active ? "border-primary/50 bg-primary/8" : "border-border bg-card"
                  )}
                >
                  <span
                    className={cn(
                      "flex size-6 shrink-0 items-center justify-center rounded-full border-2",
                      active ? "border-primary bg-primary text-primary-foreground" : "border-border text-transparent"
                    )}
                  >
                    <Check className="size-3.5" strokeWidth={3} />
                  </span>
                  <span className="flex min-w-0 flex-1 flex-col">
                    <span className="text-[13.5px] font-bold tabular-nums text-foreground">
                      {formatJalaliNumericISO(r.date)}
                      {r.mileage !== null && <span className="mr-2 font-medium text-muted-foreground">{faNum(r.mileage)} کیلومتر</span>}
                    </span>
                    <span className="text-[12px] text-muted-foreground">
                      {r.liters !== null ? `${faNum(r.liters, 1)} لیتر` : "—"}
                      {r.fullTank ? " • باک کامل" : " • نیم‌بند"}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </>
      )}

      {/* نتیجه */}
      {vehicleFuels.length > 0 && (
        <div className="overflow-hidden rounded-2xl border border-primary/35 bg-primary/5">
          <div className="border-b border-primary/20 bg-primary/10 px-4 py-2.5">
            <p className="text-center text-[12.5px] font-bold text-primary">
              میانگین مصرف:{" "}
              {result.avg !== null ? `${faNum(result.avg, 1)} لیتر بر ۱۰۰ کیلومتر` : "قابل محاسبه نیست"}
            </p>
          </div>
          <dl className="divide-y divide-border/60 px-4">
            <Row label="مسافت پیموده‌شده" value={`${faNum(result.km)} کیلومتر`} />
            <Row label="سوخت مصرف‌شده" value={`${faNum(result.liters, 1)} لیتر`} />
            <Row label="تعداد بازهٔ باک‌کامل" value={`${fa(result.fills)} بازه`} />
            <Row label="هزینهٔ سوخت در این محدوده" value={`${faNum(result.cost)} تومان`} />
            {result.costPerKm !== null && (
              <Row label="هزینهٔ هر کیلومتر" value={`${faNum(Math.round(result.costPerKm))} تومان`} />
            )}
          </dl>
          {result.avg === null && scoped.length > 0 && (
            <p className="px-4 pb-3 text-center text-[11.5px] leading-5 text-muted-foreground">
              برای محاسبه، حداقل دو سوخت‌گیری «باک کامل» با کیلومتر ثبت‌شده لازم است.
            </p>
          )}
        </div>
      )}

      {/* انتخابگرهای تاریخ */}
      <PersianWheelDatePicker
        open={fromPickerOpen}
        value={isoToJalali(from)}
        onConfirm={(j) => {
          setFrom(jalaliToISO(j));
          setFromPickerOpen(false);
        }}
        onCancel={() => setFromPickerOpen(false)}
        title="از تاریخ"
      />
      <PersianWheelDatePicker
        open={toPickerOpen}
        value={isoToJalali(to)}
        onConfirm={(j) => {
          setTo(jalaliToISO(j));
          setToPickerOpen(false);
        }}
        onCancel={() => setToPickerOpen(false)}
        title="تا تاریخ"
      />

      {/* شیت انتخاب خودرو */}
      <PickerSheet
        open={vehiclePickerOpen}
        onClose={() => setVehiclePickerOpen(false)}
        title="انتخاب خودرو"
        options={vehicleIds.map((id) => ({ value: id, label: vehicleNames.get(id) ?? "خودرو" }))}
        value={vehicleId}
        onChange={setVehicleId}
        searchPlaceholder="جستجوی خودرو..."
      />
    </BottomSheet>
  );
}

/* ---------------------------- اجزای کوچک ---------------------------- */

function StatCard({
  icon: Icon,
  color,
  bg,
  label,
  value,
  unit,
}: {
  icon: React.ElementType;
  color: string;
  bg: string;
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="rounded-2xl border border-border/80 bg-card p-3.5 shadow-sm">
      <div className="flex items-center gap-2">
        <span className={cn("flex size-8 items-center justify-center rounded-lg", bg)}>
          <Icon className="size-4.5" style={{ color }} strokeWidth={2.2} />
        </span>
        <span className="truncate text-[12px] font-semibold text-muted-foreground">{label}</span>
      </div>
      <div className="mt-2.5 truncate text-[19px] font-extrabold tabular-nums text-foreground">
        {value}
      </div>
      <div className="mt-0.5 text-[11px] text-muted-foreground">{unit}</div>
    </div>
  );
}

function Card({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <section className="mt-3.5 rounded-2xl border border-border/80 bg-card p-4 shadow-sm">
      <h2 className="mb-3 flex items-center gap-2 text-[15px] font-bold text-foreground">
        <Icon className="size-5 text-primary" strokeWidth={2.2} />
        {title}
      </h2>
      {children}
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 text-[14px]">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-bold tabular-nums text-foreground">{value}</dd>
    </div>
  );
}

function EmptyChart({ text }: { text: string }) {
  return (
    <div className="flex h-[160px] items-center justify-center rounded-xl bg-muted/40 px-6 text-center text-[13px] leading-6 text-muted-foreground">
      {text}
    </div>
  );
}

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color?: string }>; label?: string }) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div dir="rtl" className="rounded-xl border border-border bg-card px-3.5 py-2.5 shadow-lg">
      <div className="mb-1 text-[12px] font-bold text-foreground">{label}</div>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2 text-[13px]">
          <span className="size-2.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-bold tabular-nums text-foreground">
            {p.name === "مصرف" ? `${faNum(p.value, 1)} لیتر/۱۰۰کیلومتر` : `${faNum(p.value)} تومان`}
          </span>
        </div>
      ))}
    </div>
  );
}
