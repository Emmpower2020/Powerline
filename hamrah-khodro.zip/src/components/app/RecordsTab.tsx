"use client";

/**
 * تب سوابق (صفحهٔ اصلی) — نوار بالای صفحه (عنوان «سوابق» + تاریخ امروز + اشتراک‌گذاری)،
 * بخش «یادآورهای نزدیک» (تاریخ یا کیلومتر نزدیک)، جستجو، فیلتر خودرو/نوع و
 * لیست گروه‌بندی‌شده بر اساس ماه.
 */

import * as React from "react";
import { Bell, ChevronDown, FileSearch, Search, Share2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa, isoToJalali, formatJalaliMonth, formatJalaliISO } from "@/lib/persian";
import type { RecordItem, RecordType, ReminderItem, VehicleItem } from "@/lib/types";
import { PickerSheet } from "./fields";
import { EmptyVehicles, PageHeader, RecordCard, computeReminderStatus, type ReminderThresholds } from "./shared";
import { ShareSheet } from "./ShareSheet";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";

interface RecordsTabProps {
  records: RecordItem[];
  vehicles: VehicleItem[];
  reminders: ReminderItem[];
  currentKmByVehicle: Map<string, number>;
  /** آستانهٔ «نزدیک» یادآورها — از تنظیمات نوتیفیکیشن */
  notifyThresholds: ReminderThresholds;
  onOpenRecord: (r: RecordItem) => void;
  onRefresh: () => void;
  onAddVehicle: () => void;
  onGoSettings: () => void;
  onGoReminders: () => void;
}

const TYPE_OPTIONS: { value: string; label: string }[] = [
  { value: "all", label: "همه" },
  { value: "SERVICE", label: "سرویس" },
  { value: "FUEL", label: "سوخت" },
  { value: "ODOMETER", label: "کیلومتر" },
  { value: "NOTE", label: "یادداشت" },
];

export function RecordsTab({
  records,
  vehicles,
  reminders,
  currentKmByVehicle,
  notifyThresholds,
  onOpenRecord,
  onRefresh,
  onAddVehicle,
  onGoSettings,
  onGoReminders,
}: RecordsTabProps) {
  const { toast } = useToast();
  const [q, setQ] = React.useState("");
  const [vehicleFilter, setVehicleFilter] = React.useState<string>("all");
  const [typeFilter, setTypeFilter] = React.useState<string>("all");
  const [sheet, setSheet] = React.useState<null | "vehicle" | "type">(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [shareOpen, setShareOpen] = React.useState(false);

  /** حذف رکورد با تأیید — دکمهٔ حذف روی هر کارت */
  const remove = async (r: RecordItem) => {
    if (busyId) return;
    const label =
      r.type === "SERVICE"
        ? r.title || "سرویس"
        : r.type === "FUEL"
          ? "سوخت‌گیری"
          : r.type === "NOTE"
            ? r.noteTitle || "یادداشت"
            : "ثبت کیلومتر";
    const ok = await confirmDialog({
      title: "حذف رکورد",
      message: `رکورد «${label}» (${formatJalaliISO(r.date)}) حذف شود؟`,
    });
    if (!ok) return;
    setBusyId(r.id);
    try {
      const res = await fetch(`/api/records/${r.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      toast({ title: "حذف شد", description: `${label} — ${formatJalaliISO(r.date)}` });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "حذف انجام نشد", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const vehicleById = React.useMemo(() => {
    const m = new Map<string, VehicleItem>();
    vehicles.forEach((v) => m.set(v.id, v));
    return m;
  }, [vehicles]);

  const filtered = React.useMemo(() => {
    const query = q.trim();
    return records.filter((r) => {
      if (vehicleFilter !== "all" && r.vehicleId !== vehicleFilter) return false;
      if (typeFilter !== "all" && r.type !== typeFilter) return false;
      if (query) {
        const vehicle = vehicleById.get(r.vehicleId)?.name ?? "";
        const hay = `${r.title ?? ""} ${r.description ?? ""} ${r.provider ?? ""} ${r.station ?? ""} ${r.noteTitle ?? ""} ${r.noteBody ?? ""} ${vehicle}`;
        if (!hay.includes(query)) return false;
      }
      return true;
    });
  }, [records, q, vehicleFilter, typeFilter, vehicleById]);

  // گروه‌بندی بر اساس ماه جلالی
  const groups = React.useMemo(() => {
    const map = new Map<string, { label: string; items: RecordItem[] }>();
    for (const r of filtered) {
      const j = isoToJalali(r.date);
      const key = `${j.jy}-${String(j.jm).padStart(2, "0")}`;
      if (!map.has(key)) {
        map.set(key, { label: formatJalaliMonth(j.jy, j.jm), items: [] });
      }
      map.get(key)!.items.push(r);
    }
    return Array.from(map.entries())
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([, g]) => g);
  }, [filtered]);

  // ─── یادآورهای نزدیک: تاریخ یا کیلومتر نزدیک (عقب‌افتاده + نزدیک) ───
  const nearReminders = React.useMemo(() => {
    const list = reminders
      .filter((r) => !r.done)
      .map((r) => ({
        r,
        st: computeReminderStatus(r, currentKmByVehicle.get(r.vehicleId) ?? 0, notifyThresholds),
      }))
      .filter((x) => x.st.status === "overdue" || x.st.status === "soon")
      .sort((a, b) => {
        const rank = { overdue: 0, soon: 1 } as const;
        return rank[a.st.status] - rank[b.st.status];
      });
    return list;
  }, [reminders, currentKmByVehicle, notifyThresholds]);

  return (
    <div>
      {/* ─── سربرگ مشترک — عنوان سوابق + تاریخ امروز + اشتراک‌گذاری ─── */}
      <PageHeader
        title="سوابق"
        action={
          <button
            type="button"
            onClick={() => setShareOpen(true)}
            className="flex h-10 shrink-0 items-center gap-1.5 rounded-full bg-white/18 px-4 text-[13px] font-bold backdrop-blur transition-all active:scale-95"
            aria-label="اشتراک‌گذاری سوابق"
          >
            <Share2 className="size-4.5" />
            اشتراک‌گذاری
          </button>
        }
      />

      {/* هنوز خودرویی ثبت نشده — راهنمای افزودن */}
      {vehicles.length === 0 ? (
        <div className="pb-32">
          <EmptyVehicles
            desc="برای ثبت سوابق سرویس و سوخت، ابتدا خودروی خود را اضافه کنید — مستقیم از همین صفحه یا از «مدیریت خودرو» در تنظیمات."
            onAddVehicle={onAddVehicle}
            onGoSettings={onGoSettings}
          />
        </div>
      ) : (
        <>
      {/* ─── یادآورهای نزدیک — تاریخ یا کیلومتر نزدیک شده ─── */}
      {nearReminders.length > 0 && (
        <section className="mt-3 px-4" aria-label="یادآورهای نزدیک">
          <div className="mb-2 flex items-center justify-between px-1">
            <h2 className="flex items-center gap-1.5 text-[13.5px] font-bold text-foreground">
              <Bell className="size-4 text-amber-600" />
              یادآورهای نزدیک
            </h2>
            <button
              type="button"
              onClick={onGoReminders}
              className="text-[12px] font-bold text-primary active:opacity-70"
            >
              مشاهدهٔ همه
            </button>
          </div>
          <div className="flex flex-col gap-2">
            {nearReminders.slice(0, 3).map(({ r, st }) => {
              const StatusIcon = st.icon;
              const vehicle = vehicleById.get(r.vehicleId);
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={onGoReminders}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-2xl border bg-card p-3 text-right shadow-sm transition-all active:scale-[.98]",
                    st.borderColor
                  )}
                >
                  <span className={cn("flex size-10 shrink-0 items-center justify-center rounded-xl", st.bg)}>
                    <StatusIcon className={cn("size-5", st.color)} strokeWidth={2.2} />
                  </span>
                  <span className="flex min-w-0 flex-1 flex-col items-start">
                    <span className="w-full truncate text-[14.5px] font-bold text-foreground">{r.title}</span>
                    <span className="flex w-full flex-wrap items-center gap-x-1.5 text-[12px] text-muted-foreground">
                      {vehicle && <span className="truncate">{vehicle.name}</span>}
                      <span className="text-border">•</span>
                      <span className={cn("font-bold", st.color)}>{st.label}</span>
                    </span>
                  </span>
                  <ChevronDown className="size-4 shrink-0 -rotate-90 text-muted-foreground" />
                </button>
              );
            })}
            {nearReminders.length > 3 && (
              <button
                type="button"
                onClick={onGoReminders}
                className="rounded-xl border border-dashed border-primary/40 py-2 text-[12.5px] font-bold text-primary active:bg-primary/8"
              >
                {fa(nearReminders.length - 3)} یادآور نزدیک دیگر…
              </button>
            )}
          </div>
        </section>
      )}

      {/* جستجو و فیلترها — ⭐ v3.8.6: دیگر چسبان نیست؛ با اسکرول از زیر نوار بالا رد می‌شود */}
      <div className="mt-3 px-4 pb-2">
        <div className="relative">
          <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <input
            dir="rtl"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در رکوردها..."
            className="h-12 w-full rounded-xl border border-input bg-card pr-11 pl-4 text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary/60 focus:outline-none focus:ring-[3px] focus:ring-primary/15"
          />
        </div>

        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setSheet("vehicle")}
            className="flex h-11 items-center justify-between rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
          >
            <span className="truncate text-[13px] font-medium text-foreground">
              {vehicleFilter === "all"
                ? "همه خودروها"
                : (vehicleById.get(vehicleFilter)?.name ?? "همه خودروها")}
            </span>
            <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
          </button>
          <button
            type="button"
            onClick={() => setSheet("type")}
            className="flex h-11 items-center justify-between rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
          >
            <span className="truncate text-[13px] font-medium text-foreground">
              {TYPE_OPTIONS.find((t) => t.value === typeFilter)?.label ?? "همه"}
            </span>
            <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
          </button>
        </div>

        <p className="mt-2 px-1 text-[12px] text-muted-foreground">
          {fa(filtered.length)} مورد
        </p>
      </div>

      {/* لیست */}
      <div className="px-4 pb-32">
        {filtered.length === 0 ? (
          <EmptyState hasRecords={records.length > 0} />
        ) : (
          groups.map((g) => (
            <section key={g.label} className="mb-4">
              <h2 className="-mx-1 mb-2 px-1 py-1 text-[13px] font-bold text-muted-foreground">
                {g.label}
                <span className="mr-2 text-[11px] font-medium text-muted-foreground/70">
                  ({fa(g.items.length)} رکورد)
                </span>
              </h2>
              <div className="flex flex-col gap-2.5">
                {g.items.map((r) => (
                  <RecordCard
                    key={r.id}
                    record={r}
                    vehicle={vehicleById.get(r.vehicleId)}
                    onEdit={() => onOpenRecord(r)}
                    onDelete={() => remove(r)}
                    busy={busyId === r.id}
                  />
                ))}
              </div>
            </section>
          ))
        )}
      </div>
        </>
      )}

      {/* شیت فیلتر خودرو — جستجوپذیر و کشیدنی */}
      <PickerSheet
        open={sheet === "vehicle"}
        onClose={() => setSheet(null)}
        title="فیلتر خودرو"
        subtitle={`${fa(vehicles.length + 1)} گزینه — جستجو کنید یا انتخاب کنید`}
        options={[
          { value: "all", label: "همه خودروها" },
          ...vehicles.map((v) => ({ value: v.id, label: v.name })),
        ]}
        value={vehicleFilter}
        onChange={setVehicleFilter}
        searchPlaceholder="جستجوی خودرو..."
      />

      {/* شیت فیلتر نوع — جستجوپذیر و کشیدنی */}
      <PickerSheet
        open={sheet === "type"}
        onClose={() => setSheet(null)}
        title="فیلتر نوع"
        options={TYPE_OPTIONS.map((t) => ({ value: t.value, label: t.label }))}
        value={typeFilter}
        onChange={setTypeFilter}
        searchPlaceholder="جستجوی نوع..."
      />

      {/* شیت اشتراک‌گذاری سوابق */}
      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        records={records}
        vehicles={vehicles}
      />
    </div>
  );
}

function EmptyState({ hasRecords }: { hasRecords: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
      <div className="flex size-28 items-center justify-center rounded-full bg-primary/8">
        <div className="flex size-20 items-center justify-center rounded-full bg-primary/12">
          <FileSearch className="size-10 text-primary/70" strokeWidth={1.6} />
        </div>
      </div>
      <h3 className="mt-5 text-[18px] font-bold text-foreground">
        {hasRecords ? "موردی یافت نشد!" : "هنوز رکوردی ثبت نشده"}
      </h3>
      <p className="mt-2 max-w-[280px] text-[14px] leading-7 text-muted-foreground">
        {hasRecords
          ? "عبارت جستجو یا فیلترها را تغییر دهید."
          : "با لمس دکمه + و افزودن نخستین سرویس، سوخت یا کیلومتر شروع کنید."}
      </p>
    </div>
  );
}
