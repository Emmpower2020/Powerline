"use client";

/**
 * فرم افزودن/ویرایش خودرو — چینش مشابه ثبت سرویس (گرید ۲×۲ فشرده):
 *  عکس (اختیاری) → برند/مدل/سال/رنگ (کشویی + افزودن گزینهٔ جدید) → پلاک ایرانی
 *  ۴ خانهٔ مستقل → کارکرد/سوخت/گیربکس/وضعیت (کشویی) → قیمت و تاریخ خرید → شاسی → توضیحات
 */

import * as React from "react";
import {
  Loader2,
  Save,
  Plus,
  X,
  Camera,
  ChevronDown,
  Check,
  Car,
  CarFront,
  CalendarDays,
  Gauge,
  Palette,
  Fuel as FuelIcon,
  Cog,
  Activity,
} from "lucide-react";
import { BottomSheet } from "./BottomSheet";
import {
  ComboCell,
  DateField,
  Field,
  GridCell,
  NumberInput,
  SubmitButton,
  TextArea,
  TextInput,
  type ComboOption,
} from "./fields";
import { en, fa, todayJalali } from "@/lib/persian";
import {
  FUEL_TYPE_LABELS,
  TRANSMISSION_LABELS,
  CAR_STATUS_LABELS,
  type BrandItem,
  type FuelType,
  type Transmission,
  type CarStatus,
  type VehicleItem,
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface VehicleFormSheetProps {
  open: boolean;
  initial?: VehicleItem | null;
  brands: BrandItem[];
  onClose: () => void;
  onSaved: (v: VehicleItem) => void;
  /** برای افزودن برند/مدل دلخواه در شیت انتخاب */
  onRefreshBrands?: () => void;
}

const CAR_COLORS = ["سفید", "مشکی", "نقره‌ای", "خاکستری", "قرمز", "آبی", "سبز", "بژ", "قهوه‌ای", "زرد"];

/** حروف پلاک ایران — کاراکتر خام (ذخیره در پلاک) + نام کامل برای نمایش (الف و…) */
const PLATE_LETTERS: { raw: string; name: string }[] = [
  { raw: "ا", name: "الف" },
  { raw: "ب", name: "ب" },
  { raw: "پ", name: "پ" },
  { raw: "ت", name: "ت" },
  { raw: "ث", name: "ث" },
  { raw: "ج", name: "ج" },
  { raw: "چ", name: "چ" },
  { raw: "ح", name: "ح" },
  { raw: "خ", name: "خ" },
  { raw: "د", name: "د" },
  { raw: "ذ", name: "ذ" },
  { raw: "ر", name: "ر" },
  { raw: "ز", name: "ز" },
  { raw: "س", name: "س" },
  { raw: "ش", name: "ش" },
  { raw: "ص", name: "ص" },
  { raw: "ض", name: "ض" },
  { raw: "ط", name: "ط" },
  { raw: "ظ", name: "ظ" },
  { raw: "ع", name: "ع" },
  { raw: "غ", name: "غ" },
  { raw: "ف", name: "ف" },
  { raw: "ق", name: "ق" },
  { raw: "ک", name: "ک" },
  { raw: "گ", name: "گ" },
  { raw: "ل", name: "ل" },
  { raw: "م", name: "م" },
  { raw: "ن", name: "ن" },
  { raw: "و", name: "و" },
  { raw: "ه", name: "ه" },
  { raw: "ی", name: "ی" },
];

/** نام کامل حرف برای نمایش در حالت بسته (ا → الف) */
const letterName = (raw: string) => PLATE_LETTERS.find((l) => l.raw === raw)?.name ?? raw;

/** تجزیهٔ یک‌بارِ رشتهٔ پلاک بیرونی به ۴ بخش (فقط برای مقدار اولیه/ویرایش — نه حین تایپ) */
function parsePlate(v: string) {
  const m = en(v || "").match(/^(\d{0,2})\s*(\S?)\s*(\d{0,3})\s*(?:ایران)?\s*(\d{0,2})/);
  return {
    left: m?.[1] ?? "",
    letter: m?.[2] ?? "",
    middle: m?.[3] ?? "",
    right: m?.[4] ?? "",
  };
}

/** ورودی پلاک ایرانی — ۴ خانهٔ کاملاً مستقل (دو رقم | حرف (دراپ‌داون) | سه رقم | کد استان)
 *  ذخیره به شکل «۱۲ ب ۳۴۵ ایران ۶۷» (ارقام فارسی) — پرش خودکار فوکوس بین خانه‌ها
 *  حین تایپ هیچ‌وقت رشتهٔ ترکیبی دوباره تجزیه نمی‌شود؛ فقط مقدار بیرونی (ویرایش) یک‌بار تجزیه می‌شود */
function PlateInput({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const [left, setLeft] = React.useState(() => parsePlate(value).left);
  const [letter, setLetter] = React.useState(() => parsePlate(value).letter);
  const [middle, setMiddle] = React.useState(() => parsePlate(value).middle);
  const [right, setRight] = React.useState(() => parsePlate(value).right);
  const [letterOpen, setLetterOpen] = React.useState(false);

  const middleRef = React.useRef<HTMLInputElement>(null);
  const rightRef = React.useRef<HTMLInputElement>(null);

  // آخرین مقداری که خودمان صادر کردیم — اگر value بیرونی با آن فرق دارد یعنی از بیرون آمده (ویرایش)
  const lastEmitted = React.useRef<string | null>(null);

  // فقط برای تغییر بیرونی (مثل باز شدن فرم ویرایش) یک‌بار تجزیه می‌کنیم
  React.useEffect(() => {
    if (value === lastEmitted.current) return;
    const p = parsePlate(value);
    setLeft(p.left);
    setLetter(p.letter);
    setMiddle(p.middle);
    setRight(p.right);
  }, [value]);

  /** هر خانه فقط استیت خودش را به‌روز می‌کند و رشتهٔ کامل را صادر می‌کند — بدون تجزیهٔ مجدد */
  const emit = (p: { left: string; letter: string; middle: string; right: string }) => {
    const hasAny = p.left !== "" || p.letter !== "" || p.middle !== "" || p.right !== "";
    const s = hasAny
      ? [p.left, p.letter, p.middle, "ایران", p.right].filter(Boolean).join(" ")
      : "";
    const out = fa(s);
    lastEmitted.current = out;
    onChange(out);
  };

  /** فقط ارقام (فارسی/لاتین → لاتین) با سقف طول */
  const digits = (raw: string, max: number) =>
    en(raw).replace(/\D/g, "").slice(0, max);

  const digitCls =
    "h-11 rounded-md bg-transparent text-center text-[21px] font-black tabular-nums text-neutral-900 placeholder:font-bold placeholder:text-neutral-300 focus:bg-neutral-900/[.06] focus:outline-none";

  const pickLetter = (raw: string) => {
    setLetter(raw);
    emit({ left, letter: raw, middle, right });
    setLetterOpen(false);
    // بعد از بسته شدن شیت، فوکوس روی سه رقم وسط
    setTimeout(() => middleRef.current?.focus(), 80);
  };

  return (
    <div className="mx-auto w-full max-w-[360px]">
      {/* بدنهٔ پلاک — سفید با قاب مشکی؛ چیدمان واقعی چپ→راست: دورقمی | حرف | سه‌رقمی | ایران+کد */}
      <div dir="ltr" className="flex w-full items-stretch overflow-hidden rounded-xl border-[3px] border-neutral-800 bg-white shadow-md">
        {/* ناحیهٔ اصلی: دورقمی | حرف (دراپ‌داون) | سه‌رقمی */}
        <div className="flex flex-1 items-center justify-center gap-2.5 px-2.5 py-2.5">
          <input
            inputMode="numeric"
            maxLength={2}
            value={fa(left)}
            onChange={(e) => {
              const d = digits(e.target.value, 2);
              setLeft(d);
              emit({ left: d, letter, middle, right });
              if (d.length === 2) setLetterOpen(true);
            }}
            placeholder="۲۶"
            className={digitCls + " w-14"}
            aria-label="دو رقم سمت چپ پلاک"
            autoComplete="off"
          />
          {/* حرف — دراپ‌داون با نام کامل حروف */}
          <button
            type="button"
            onClick={() => setLetterOpen(true)}
            aria-label="حرف پلاک — انتخاب از فهرست"
            className="flex h-11 w-12 shrink-0 items-center justify-center gap-0.5 rounded-md bg-transparent text-[19px] font-black text-neutral-900 transition-colors hover:bg-neutral-900/[.06] focus:bg-neutral-900/[.06] focus:outline-none"
          >
            {letter ? (
              <span className="leading-none">{letterName(letter)}</span>
            ) : (
              <span className="text-[15px] font-bold text-neutral-300">حرف</span>
            )}
            <ChevronDown className="size-3 text-neutral-400" strokeWidth={2.5} />
          </button>
          <input
            ref={middleRef}
            inputMode="numeric"
            maxLength={3}
            value={fa(middle)}
            onChange={(e) => {
              const d = digits(e.target.value, 3);
              setMiddle(d);
              emit({ left, letter, middle: d, right });
              if (d.length === 3) rightRef.current?.focus();
            }}
            placeholder="۳۱۷"
            className={digitCls + " w-[4.5rem]"}
            aria-label="سه رقم وسط پلاک"
            autoComplete="off"
          />
        </div>
        {/* نوار آبی سمت راست — ایران + کد استان (مثل پلاک واقعی) */}
        <div className="flex w-[74px] shrink-0 flex-col items-center justify-center gap-1 bg-[#20337a] py-2">
          <span className="text-[11px] font-bold leading-none text-white">ایران</span>
          <input
            ref={rightRef}
            inputMode="numeric"
            maxLength={2}
            value={fa(right)}
            onChange={(e) => {
              const d = digits(e.target.value, 2);
              setRight(d);
              emit({ left, letter, middle, right: d });
            }}
            placeholder="۲۹"
            className="h-8 w-12 rounded-md bg-white/95 text-center text-[16px] font-black tabular-nums text-neutral-900 placeholder:font-bold placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-white/70"
            aria-label="کد استان"
            autoComplete="off"
          />
        </div>
      </div>
      <p className="mt-1.5 text-center text-[11px] leading-4 text-muted-foreground">
        از چپ: دو رقم، حرف، سه رقم — کد استان در کادر آبی سمت راست
      </p>

      {/* شیت انتخاب حرف پلاک — ~۶ ردیف قابل مشاهده، بقیه با اسکرول */}
      <BottomSheet
        open={letterOpen}
        onClose={() => setLetterOpen(false)}
        title="حرف پلاک"
        subtitle="حرف پلاک خودرو را انتخاب کنید"
        maxHeight="max-h-[70dvh]"
      >
        <div className="max-h-[288px] overflow-y-auto overscroll-contain pb-1">
          {PLATE_LETTERS.map((l) => {
            const selected = letter === l.raw;
            return (
              <button
                key={l.raw}
                type="button"
                onClick={() => pickLetter(l.raw)}
                className={
                  "mb-1 flex h-12 w-full items-center justify-between rounded-xl px-4 text-right text-[17px] transition-colors active:scale-[.99] " +
                  (selected ? "bg-primary/10" : "hover:bg-muted/60")
                }
              >
                <span className={selected ? "font-bold text-primary" : "font-medium text-foreground"}>
                  {l.name}
                </span>
                {selected && <Check className="size-5 text-primary" />}
              </button>
            );
          })}
        </div>
      </BottomSheet>
    </div>
  );
}

export function VehicleFormSheet({
  open,
  initial,
  brands,
  onClose,
  onSaved,
  onRefreshBrands,
}: VehicleFormSheetProps) {
  const { toast } = useToast();
  const isEdit = Boolean(initial);

  const [brand, setBrand] = React.useState("");
  const [model, setModel] = React.useState("");
  /** سال‌های دلخواهِ افزودن‌شده توسط کاربر (خارج از بازهٔ پیش‌فرض) */
  const [extraYears, setExtraYears] = React.useState<number[]>([]);
  const [imageData, setImageData] = React.useState<string | null>(null);
  const [year, setYear] = React.useState<number | null>(null);
  const [yearType, setYearType] = React.useState<"JALALI" | "GREGORIAN">("JALALI");
  const [plate, setPlate] = React.useState("");
  const [noPlate, setNoPlate] = React.useState(false);
  const [vin, setVin] = React.useState("");
  const [color, setColor] = React.useState("");
  const [fuelType, setFuelType] = React.useState<FuelType>("GASOLINE");
  const [transmission, setTransmission] = React.useState<Transmission>("MANUAL");
  const [status, setStatus] = React.useState<CarStatus>("ACTIVE");
  const [mileage, setMileage] = React.useState<number | null>(null);
  const [purchasePrice, setPurchasePrice] = React.useState<number | null>(null);
  const [purchaseDate, setPurchaseDate] = React.useState<string | null>(null);
  const [notes, setNotes] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState("");

  const fileRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (!open) return;
    setError("");
    if (initial) {
      setBrand(initial.brand ?? "");
      setModel(initial.model ?? "");
      setImageData(initial.imageData ?? null);
      setYear(initial.year);
      setYearType(initial.yearType ?? "JALALI");
      setPlate(initial.plate ?? "");
      setNoPlate(!initial.plate);
      setVin(initial.vin ?? "");
      setColor(initial.color ?? "");
      setFuelType(initial.fuelType ?? "GASOLINE");
      setTransmission(initial.transmission ?? "MANUAL");
      setStatus(initial.status ?? "ACTIVE");
      setMileage(initial.mileage ?? null);
      setPurchasePrice(initial.purchasePrice);
      setPurchaseDate(initial.purchaseDate);
      setNotes(initial.notes ?? "");
      setExtraYears([]);
    } else {
      setBrand("");
      setModel("");
      setImageData(null);
      setYear(null);
      setYearType("JALALI");
      setPlate("");
      setNoPlate(false);
      setVin("");
      setColor("");
      setFuelType("GASOLINE");
      setTransmission("MANUAL");
      setStatus("ACTIVE");
      setMileage(null);
      setPurchasePrice(null);
      setPurchaseDate(null);
      setNotes("");
      setExtraYears([]);
    }
  }, [open, initial]);

  /** انتخاب عکس خودرو — کوچک‌سازی به حداکثر ۹۰۰px (طول بلندتر) و JPEG با کیفیت ۰٫۷۲ */
  const onPickImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // امکان انتخاب دوبارهٔ همان فایل
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const MAX = 900;
        const scale = Math.min(1, MAX / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, w, h);
        setImageData(canvas.toDataURL("image/jpeg", 0.72));
      };
      img.onerror = () =>
        toast({ title: "خطا", description: "عکس خوانده نشد", variant: "destructive" });
      img.src = String(reader.result);
    };
    reader.onerror = () =>
      toast({ title: "خطا", description: "عکس خوانده نشد", variant: "destructive" });
    reader.readAsDataURL(file);
  };

  /* ───────── گزینه‌های کشویی گرید ۲×۲ ───────── */

  const brandOptions: ComboOption[] = React.useMemo(
    () => brands.map((b) => ({ value: b.name, label: b.name })),
    [brands]
  );
  const currentBrand = brands.find((b) => b.name === brand);
  const modelOptions: ComboOption[] = React.useMemo(
    () => (currentBrand?.models ?? []).map((m) => ({ value: m, label: m })),
    [currentBrand]
  );

  /** سال‌های ساخت — شمسی/میلادی از قدیم تا جدید + سال‌های دلخواه کاربر */
  const yearOptions: ComboOption[] = React.useMemo(() => {
    const set = new Set<number>(extraYears);
    if (yearType === "JALALI") {
      const cy = todayJalali().jy;
      for (let y = cy + 1; y >= 1345; y--) set.add(y);
    } else {
      const cy = new Date().getFullYear();
      for (let y = cy + 1; y >= 1965; y--) set.add(y);
    }
    return [...set].sort((a, b) => b - a).map((y) => ({ value: String(y), label: fa(y) }));
  }, [yearType, extraYears]);

  const colorOptions: ComboOption[] = React.useMemo(
    () => CAR_COLORS.map((c) => ({ value: c, label: c })),
    []
  );
  const fuelOptions: ComboOption[] = React.useMemo(
    () => (Object.keys(FUEL_TYPE_LABELS) as FuelType[]).map((f) => ({ value: f, label: FUEL_TYPE_LABELS[f] })),
    []
  );
  const transmissionOptions: ComboOption[] = React.useMemo(
    () => (Object.keys(TRANSMISSION_LABELS) as Transmission[]).map((t) => ({ value: t, label: TRANSMISSION_LABELS[t] })),
    []
  );
  const statusOptions: ComboOption[] = React.useMemo(
    () => (Object.keys(CAR_STATUS_LABELS) as CarStatus[]).map((s) => ({ value: s, label: CAR_STATUS_LABELS[s] })),
    []
  );

  /* ───────── انتخاب/افزودن برند و مدل ───────── */

  /** انتخاب برند — اگر مدل فعلی جزو مدل‌های برند جدید نیست، پاک می‌شود */
  const pickBrand = (name: string) => {
    setBrand(name);
    const b = brands.find((x) => x.name === name);
    if (model && b && !b.models.includes(model)) setModel("");
  };

  /** افزودن برند جدید — ذخیرهٔ دائمی و انتخاب */
  const addBrand = async (name: string): Promise<boolean> => {
    if (brands.some((b) => b.name === name)) {
      toast({ title: "این برند موجود است", description: name });
      pickBrand(name);
      return true;
    }
    try {
      const res = await fetch("/api/brands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, models: [] }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => null);
        throw new Error(d?.error ?? "خطا");
      }
      toast({ title: "برند اضافه شد ✓", description: name });
      onRefreshBrands?.();
      setBrand(name);
      setModel("");
      return true;
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "ثبت نشد", variant: "destructive" });
      return false;
    }
  };

  /** افزودن مدل جدید به برند فعلی — ذخیرهٔ دائمی و انتخاب */
  const addModel = async (name: string): Promise<boolean> => {
    const b = brands.find((x) => x.name === brand);
    if (!b) {
      toast({ title: "ابتدا برند را انتخاب کنید" });
      return false;
    }
    if (b.models.includes(name)) {
      setModel(name);
      return true;
    }
    try {
      const res = await fetch(`/api/brands/${b.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ models: [...b.models, name] }),
      });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "مدل اضافه شد ✓", description: `${b.name} — ${name}` });
      onRefreshBrands?.();
      setModel(name);
      return true;
    } catch {
      toast({ title: "خطا", description: "ثبت نشد", variant: "destructive" });
      return false;
    }
  };

  /* ───────── سال ساخت ───────── */

  const pickYear = (v: string) => setYear(Number(en(v)));
  const addYear = (text: string): boolean => {
    const n = parseInt(en(text).replace(/\D/g, ""), 10);
    const isJ = yearType === "JALALI";
    const min = isJ ? 1300 : 1950;
    const max = isJ ? 1500 : 2050;
    if (!n || n < min || n > max) {
      toast({ title: "سال معتبر نیست", description: isJ ? "مثلاً ۱۴۰۲" : "مثلاً ۲۰۲۴" });
      return false;
    }
    setYear(n);
    setExtraYears((prev) => (prev.includes(n) ? prev : [...prev, n]));
    return true;
  };

  const submit = async () => {
    if (!model.trim()) return setError("مدل خودرو را وارد کنید");
    // پلاک فقط در صورت شروع به تایپ باید کامل باشد — الگوی کامل: دو رقم + حرف + سه رقم + کد استان
    if (!noPlate && plate.trim()) {
      const ok = /^(\d{1,2})\s+(\S{1})\s+(\d{1,3})\s+ایران\s+(\d{1,2})$/.test(en(plate));
      if (!ok) return setError("پلاک را کامل وارد کنید یا «بدون پلاک» را فعال کنید");
    }
    setSaving(true);
    setError("");
    try {
      const payload = {
        imageData: imageData ?? null,
        brand: brand.trim() || "سایر",
        model: model.trim(),
        year,
        yearType,
        plate: noPlate ? null : plate.trim() || null,
        vin: vin.trim() || null,
        color: color.trim() || null,
        fuelType,
        transmission,
        status,
        mileage: mileage ?? 0,
        purchasePrice,
        purchaseDate,
        notes: notes.trim() || null,
      };
      const res = await fetch(
        isEdit ? `/api/vehicles/${initial!.id}` : "/api/vehicles",
        {
          method: isEdit ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error ?? "ثبت انجام نشد");
      }
      const vehicle = await res.json();
      toast({
        title: isEdit ? "خودرو ویرایش شد ✓" : "خودرو اضافه شد ✓",
        description: vehicle.name,
      });
      onSaved(vehicle);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={isEdit ? "ویرایش خودرو" : "افزودن خودرو جدید"}
      subtitle="برند و مدل خودرو را انتخاب یا بنویسید"
      footer={
        <SubmitButton onClick={submit} disabled={saving}>
          {saving ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5" />}
          {isEdit ? "ذخیره تغییرات" : "افزودن خودرو"}
        </SubmitButton>
      }
    >
      {error && (
        <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </div>
      )}

      {/* عکس خودرو (اختیاری) — بالای فرم */}
      {imageData ? (
        <div className="relative mb-4 overflow-hidden rounded-2xl">
          <img
            src={imageData}
            alt="عکس خودرو"
            className="aspect-[4/3] w-full object-cover"
          />
          <button
            type="button"
            onClick={() => setImageData(null)}
            aria-label="حذف عکس خودرو"
            className="absolute left-2 top-2 flex size-9 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-sm transition-colors active:bg-black/80"
          >
            <X className="size-4.5" />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="mb-4 flex w-full items-center gap-3 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 px-4 py-4 text-right transition-colors active:bg-primary/10"
        >
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
            <Camera className="size-6" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[15px] font-bold text-foreground">عکس خودرو (اختیاری)</span>
            <span className="mt-0.5 block text-[12.5px] text-muted-foreground">افزودن عکس از گالری</span>
          </span>
        </button>
      )}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={onPickImage}
        aria-label="انتخاب عکس خودرو"
      />

      {/* ─── گرید ۲×۲ — مشخصات اصلی (کشویی + افزودن گزینهٔ جدید) ─── */}
      <div className="mb-3 grid grid-cols-2 gap-2">
        <ComboCell
          label="برند"
          icon={Car}
          value={brand || null}
          options={brandOptions}
          onPick={(v) => pickBrand(v)}
          onAdd={addBrand}
          allowAdd
          addLabel="افزودن برند جدید"
          sheetTitle="انتخاب برند"
          sheetSubtitle={`${fa(brands.length)} برند — اگر موجود نیست، همان‌جا اضافه کنید`}
          searchPlaceholder="جستجوی برند..."
          placeholder="برند"
        />
        <ComboCell
          label="مدل"
          icon={CarFront}
          value={model || null}
          options={modelOptions}
          onPick={(v) => setModel(v)}
          onAdd={addModel}
          allowAdd
          addLabel="افزودن مدل جدید"
          sheetTitle={currentBrand ? `مدل‌های ${currentBrand.name}` : "انتخاب مدل"}
          sheetSubtitle={
            currentBrand
              ? `${fa(modelOptions.length)} مدل — اگر موجود نیست، همان‌جا اضافه کنید`
              : "ابتدا برند را انتخاب کنید"
          }
          searchPlaceholder="جستجوی مدل..."
          placeholder="مدل"
          emptyText={currentBrand ? "مدلی یافت نشد — مدل دلخواه را بنویسید" : "ابتدا برند را انتخاب کنید"}
        />
        <ComboCell
          label="سال ساخت"
          icon={CalendarDays}
          value={year ? String(year) : null}
          options={yearOptions}
          onPick={(v) => pickYear(v)}
          onAdd={addYear}
          allowAdd
          addLabel="افزودن سال دیگر"
          sheetTitle="انتخاب سال ساخت"
          searchPlaceholder="جستجوی سال..."
          placeholder="سال"
          sheetHeader={
            <div className="mb-3 grid grid-cols-2 gap-1 rounded-xl bg-muted p-1">
              {(["JALALI", "GREGORIAN"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setYearType(t)}
                  className={
                    "flex h-9 items-center justify-center rounded-lg text-[13px] font-bold transition-colors active:scale-[.97] " +
                    (yearType === t ? "bg-card text-primary shadow-sm" : "text-muted-foreground")
                  }
                >
                  {t === "JALALI" ? "شمسی" : "میلادی"}
                </button>
              ))}
            </div>
          }
        />
        <ComboCell
          label="رنگ"
          icon={Palette}
          value={color || null}
          options={colorOptions}
          onPick={(v) => setColor(v)}
          onAdd={(t) => {
            setColor(t);
            return true;
          }}
          allowAdd
          addLabel="افزودن رنگ دیگر"
          sheetTitle="انتخاب رنگ"
          searchPlaceholder="جستجوی رنگ..."
          placeholder="رنگ"
        />
      </div>

      {/* پلاک */}
      <Field label="پلاک خودرو" layout="block">
        {noPlate ? (
          <button
            type="button"
            onClick={() => setNoPlate(false)}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-input bg-muted/40 text-[14px] text-muted-foreground"
          >
            <X className="size-4" />
            بدون پلاک — برای وارد کردن پلاک بزنید
          </button>
        ) : (
          <PlateInput value={plate} onChange={setPlate} />
        )}
        <button
          type="button"
          onClick={() => setNoPlate(!noPlate)}
          className="mt-2 text-[12px] font-medium text-primary"
        >
          {noPlate ? "وارد کردن پلاک" : "بدون پلاک"}
        </button>
      </Field>

      {/* ─── گرید ۲×۲ — مشخصات فنی ─── */}
      <div className="mb-3 grid grid-cols-2 gap-2">
        <GridCell label="کارکرد" icon={Gauge}>
          <NumberInput
            value={mileage}
            onChange={setMileage}
            placeholder="۱۶۲٬۵۰۰"
            max={10_000_000}
            className="h-9 text-[13px]"
          />
        </GridCell>
        <ComboCell
          label="نوع سوخت"
          icon={FuelIcon}
          value={fuelType}
          options={fuelOptions}
          onPick={(v) => setFuelType(v as FuelType)}
          sheetTitle="انتخاب نوع سوخت"
          searchPlaceholder="جستجو..."
          placeholder="سوخت"
        />
        <ComboCell
          label="گیربکس"
          icon={Cog}
          value={transmission}
          options={transmissionOptions}
          onPick={(v) => setTransmission(v as Transmission)}
          sheetTitle="انتخاب گیربکس"
          searchPlaceholder="جستجو..."
          placeholder="گیربکس"
        />
        <ComboCell
          label="وضعیت"
          icon={Activity}
          value={status}
          options={statusOptions}
          onPick={(v) => setStatus(v as CarStatus)}
          sheetTitle="وضعیت خودرو"
          searchPlaceholder="جستجو..."
          placeholder="وضعیت"
        />
      </div>

      {/* قیمت و تاریخ خرید */}
      <Field label="قیمت خرید">
        <NumberInput value={purchasePrice} onChange={setPurchasePrice} placeholder="مثلاً ۹۵۰٬۰۰۰٬۰۰۰" suffix="تومان" />
      </Field>

      {purchaseDate !== null ? (
        <DateField
          value={purchaseDate}
          onChange={(d) => setPurchaseDate(d)}
          label="تاریخ خرید"
        />
      ) : (
        <button
          type="button"
          onClick={() => setPurchaseDate(new Date().toISOString().slice(0, 10))}
          className="mb-4 flex items-center gap-1.5 text-[13px] font-medium text-primary"
        >
          <Plus className="size-4" />
          افزودن تاریخ خرید
        </button>
      )}

      {/* شماره شاسی */}
      <Field label="شماره شاسی">
        <TextInput
          dir="ltr"
          value={vin}
          onChange={(e) => setVin(e.target.value)}
          placeholder="VF3..."
        />
      </Field>

      {/* یادداشت */}
      <Field label="توضیحات">
        <TextArea
          dir="rtl"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="هر نکته‌ای درباره خودرو..."
          rows={2}
        />
      </Field>

    </BottomSheet>
  );
}
