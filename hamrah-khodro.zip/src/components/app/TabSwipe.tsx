"use client";

/**
 * TabSwipe — کاروسل واقعی تب‌ها (v3.8.7)
 *
 * خواستهٔ کاربر: «سوایپ جوری باشه وقتی صفحه رو می‌کشیم صفحه باهاش جابجا بشه و
 * صفحهٔ کناریش بیاد؛ حالت انیمیشنی بین دو تب عوض بشه» — یعنی:
 *  ۱) درگ با انگشت → صفحهٔ فعلی «زیر انگشت» حرکت می‌کند و صفحهٔ کناری از همان
 *     جهت فیزیکی خودش داخل می‌شود (بدون پرش)؛ رها کردن → با شتاب/مسافت یا
 *     جا‌به‌جا می‌شود یا نرم برمی‌گردد.
 *  ۲) تپ روی نوار پایین → همان حرکت به‌صورت انیمیشن نرم انجام می‌شود.
 *  ۳) لبه‌های ابتدا/انتها → کشِ ارتجاعی (بدون تعویض تب) و برگشت فنری.
 *
 * فیزیک (RTL): ترتیب order = ترتیب فیزیکی نوار پایین؛ اولین آیتم راست‌ترین است.
 *  - کشیدن به راست (dx>0) → محتوا راست می‌رود → تبِ فیزیکی چپ (idx+1) داخل می‌شود
 *  - کشیدن به چپ  (dx<0) → محتوا چپ می‌رود  → تبِ فیزیکی راست (idx-1) داخل می‌شود
 *
 * پیاده‌سازی: ترنسفورم مسیر حین درگ مستقیم روی DOM اعمال می‌شود (بدون رندرِ
 * React در هر حرکت → ۶۰fps روی گوشی‌های معمولی)؛ فقط مونت/آنمونت پنل همسایه
 * state است. پنل‌ها keyed هستند → بعد از commit هیچ ریمانت نمی‌شود (اسکرول/حالت
 * داخلی پنل جدید حفظ می‌شود). touch-action: pan-y → اسکرول عمودی دست مرورگر
 * می‌ماند و مرورگر با touchcancel درگ را لغو می‌کند (بدون جنگیدگی).
 * ⭐ v3.8.9: شنونده‌های لمس «native و غیرpassive» (فاز capture) شدند + آستانهٔ
 *  درگیرشدن آزادتر (|dx| > |dy|×۰٫۷۵ — حرکت قوسی شست در نیمهٔ پایین هم قبلاً
 *  می‌شود) + بعد از درگیرشدن preventDefault → مرورگر دیگر ژست را نمی‌دزدد؛
 *  نتیجه: سوایپ در تمام ارتفاع صفحه (نیمهٔ پایین هم) پایدار کار می‌کند.
 * ⭐ v3.9.0: دو رفع جدید:
 *  ۱) «سوایپ روی فضای خالی صفحه» — کانتینر حالا حداقل به ارتفاع viewport کش می‌آید
 *     (flex-col + min-height)؛ قبلاً ارتفاع کانتینر = ارتفاع محتوا بود و نواحی خالی
 *     پایین صفحه (بدون آیتم) بیرون از کانتینر بودند و سوایپ آنجا کاری نمی‌کرد.
 *  ۲) «اسکرول‌خوردن حین سوایپ» — هنگام درگیرشدن، scrollY قفل می‌شود و در تمام طول
 *     درگ به همان جایگاه برمی‌گردد (کمی اسکرول مقدماتی مرورگر خنثی می‌شود) و موقعیت
 *     ذخیره‌شدهٔ تبِ ترک‌شده هم تمیز می‌ماند.
 */
import * as React from "react";

/** جهت همسایه: +1 = تب بعدی در order (فیزیکی چپ در RTL)؛ -1 = قبلی (فیزیکی راست) */
type SwipeDir = 1 | -1;

export interface TabSwipeHandle {
  /** رفتن انیمیشنی به تب مشخص (تاب نوار پایین / میان‌برهای درون‌برنامه) */
  goTo: (next: string) => void;
}

const SWIPE_GUARD =
  "input, textarea, select, [contenteditable='true'], [data-no-swipe], [role='dialog'], [role='menu']";

export function TabSwipe<T extends string>({
  order,
  active,
  onCommit,
  renderPanel,
  handleRef,
}: {
  /** ترتیب فیزیکی تب‌ها — RTL: آیتم اول راست‌ترین */
  order: readonly T[];
  /** تب فعال (منبع حقیقت والد) */
  active: T;
  /** قطعی شدن تب جدید — بعد از پایان انیمیشن/درگ صدا زده می‌شود */
  onCommit: (next: T) => void;
  /** رندر محتوای پنل یک تب */
  renderPanel: (tab: T) => React.ReactNode;
  /** دستگیرهٔ goTo برای والد (تپ نوار پایین) */
  handleRef?: React.RefObject<TabSwipeHandle | null>;
}) {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const trackRef = React.useRef<HTMLDivElement>(null);
  const widthRef = React.useRef(0);
  const [width, setWidth] = React.useState(0);

  /** پنل همسایهٔ درگ/انیمیشن (null = فقط تب فعال) */
  const [view, setView] = React.useState<{ target: T; dir: SwipeDir } | null>(null);
  const viewRef = React.useRef(view);
  const activeRef = React.useRef(active);
  React.useEffect(() => {
    viewRef.current = view;
  }, [view]);
  React.useEffect(() => {
    activeRef.current = active;
  }, [active]);

  const dxRef = React.useRef(0);
  const draggingRef = React.useRef(false);
  const engagedRef = React.useRef(false);
  const animatingRef = React.useRef(false);
  const touchRef = React.useRef<{ x: number; y: number; t: number } | null>(null);
  const finishTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  /* ⭐ v3.9.0: اسکرولِ صفحه هنگام شروع درگ قفل می‌شود — حین سوایپ، صفحه نه پایین
   *  می‌رود نه «کمی اسکرول می‌خورد»؛ مقدار ذخیره‌شده برای حافظهٔ اسکرول تب هم همین است */
  const scrollLockRef = React.useRef<number | null>(null);

  /* اندازه‌گیری عرض ستون برنامه (پنل‌ها با px عرض دقیق می‌گیرند) */
  React.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const measure = () => {
      const w = el.clientWidth;
      widthRef.current = w;
      setWidth(w);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const reducedMotion = React.useCallback(() => {
    try {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch {
      return false;
    }
  }, []);

  /**
   * اعمال ترنسفورم روی مسیر:
   *  - dir=+1 → فرزندها [فعلی، همسایه]؛ پایه 0% (فعلی در دید)
   *  - dir=-1 → فرزندها [همسایه، فعلی]؛ پایه 50% عرض مسیر = یک پنل (فعلی در دید)
   *  - dir=null → تک‌پنل (کشِ لبه) — فقط جابه‌جایی px
   */
  const apply = React.useCallback((dir: SwipeDir | null, dx: number, transition: boolean) => {
    const el = trackRef.current;
    if (!el) return;
    el.style.transition = transition ? "transform 280ms cubic-bezier(0.22, 0.61, 0.36, 1)" : "none";
    if (dir === null) {
      el.style.transform = `translateX(${dx}px)`;
    } else {
      const base = dir === 1 ? "0%" : "50%";
      el.style.transform = `translateX(calc(${base} + ${dx}px))`;
    }
  }, []);

  /* بعد از هر تغییر view: وضعیت اولیهٔ ترنسفورم قبل از نقاشی اعمال شود (بدون فلش) */
  React.useLayoutEffect(() => {
    if (view) apply(view.dir, dxRef.current, false);
    else apply(null, 0, false);
  }, [view, apply]);

  /* ─── پایان درگ/انیمیشن: قطعی (commit) یا برگشت نرم ─── */
  const finalize = React.useCallback(
    (commit: boolean) => {
      const v = viewRef.current;
      if (!v) {
        // کشِ لبه → برگشت فنری به صفر
        if (reducedMotion()) {
          apply(null, 0, false);
          return;
        }
        apply(null, 0, true);
        if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
        finishTimerRef.current = setTimeout(() => apply(null, 0, false), 320);
        return;
      }
      if (reducedMotion()) {
        if (commit) onCommit(v.target);
        setView(null);
        return;
      }
      const W = widthRef.current || 320;
      const end = commit ? (v.dir === 1 ? W : -W) : 0;
      apply(v.dir, end, true);
      animatingRef.current = true;
      if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
      finishTimerRef.current = setTimeout(() => {
        animatingRef.current = false;
        if (commit) onCommit(v.target);
        setView(null);
      }, 340);
    },
    [onCommit, apply, reducedMotion]
  );

  /* ─── سوایپ دنبال‌کنندهٔ انگشت — ⭐ v3.8.9: شنونده‌های native غیرpassive ─── */
  const onTouchStart = (e: React.TouchEvent) => {
    if (animatingRef.current || draggingRef.current) {
      touchRef.current = null;
      return;
    }
    if (e.touches.length !== 1) {
      touchRef.current = null;
      return;
    }
    const el = e.target as HTMLElement | null;
    // داخل فرم/ورودی/شیت/دیالوگ سوایپ فعال نمی‌شود
    if (el?.closest(SWIPE_GUARD)) {
      touchRef.current = null;
      return;
    }
    touchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() };
    engagedRef.current = false;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    const st = touchRef.current;
    if (!st) return;
    const dx = e.touches[0].clientX - st.x;
    const dy = e.touches[0].clientY - st.y;
    if (!engagedRef.current) {
      // ⭐ v3.8.9: آستانهٔ درگیرشدن آزادتر — حرکت قوسی شست (نیمهٔ پایین صفحه)
      // هم سوایپ شمرده می‌شود (تا ~۵۵ درجه انحراف عمودی)
      if (Math.abs(dx) < 12 || Math.abs(dx) < Math.abs(dy) * 0.75) {
        // قصد عمودی واضح → رد شو؛ اسکرول مال مرورگر است
        if (Math.abs(dy) >= 14 && Math.abs(dy) > Math.abs(dx) * 1.6) {
          touchRef.current = null;
        }
        return;
      }
      engagedRef.current = true;
      draggingRef.current = true;
      dxRef.current = 0;
      // ⭐ v3.9.0: اسکرول فعلی صفحه قفل — حرکت افقی دیگر صفحه را نمی‌لغزاند
      try {
        scrollLockRef.current = window.scrollY;
      } catch {
        scrollLockRef.current = null;
      }
      const idx = order.indexOf(activeRef.current);
      const target =
        dx > 0
          ? idx + 1 < order.length
            ? order[idx + 1]
            : null
          : idx - 1 >= 0
            ? order[idx - 1]
            : null;
      if (target != null) {
        // همسایه مونت می‌شود؛ ترنسفورم اولیه در layout effect با dx=0 اعمال می‌شود
        setView({ target, dir: dx > 0 ? 1 : -1 });
      }
      return;
    }
    // ⭐ v3.9.0: اگر مرورگر در همان لحظات اول کمی اسکرول کرده باشد، به جایگاه قفل برگردد
    if (scrollLockRef.current !== null) {
      try {
        if (Math.abs(window.scrollY - scrollLockRef.current) > 0.5) {
          window.scrollTo(0, scrollLockRef.current);
        }
      } catch {
        /* ignore */
      }
    }
    // ادامهٔ درگ — مستقیم روی DOM (بدون رندر React در هر حرکت)
    dxRef.current = dx;
    const v = viewRef.current;
    if (v) apply(v.dir, dx, false);
    else apply(null, dx * 0.3, false); // مقاومت کشِ لبه
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    const st = touchRef.current;
    touchRef.current = null;
    if (!st || !engagedRef.current) return;
    engagedRef.current = false;
    draggingRef.current = false;
    const dx = e.changedTouches[0].clientX - st.x;
    const dt = Math.max(1, Date.now() - st.t);
    const W = widthRef.current || 320;
    const v = viewRef.current;
    const velocity = Math.abs(dx) / dt; // px بر میلی‌ثانیه
    const commit = !!v && (Math.abs(dx) > W * 0.32 || (velocity > 0.55 && Math.abs(dx) > 40));
    // ⭐ v3.9.0: پیش از قطعی‌شدن تب، صفحه به جایگاه قفل‌شده برمی‌گردد — تبِ ترک‌شده
    // دقیقاً همان‌جایی که کاربر سوایپ را شروع کرد ذخیره می‌شود (نه کمی اسکرول‌شده)
    if (scrollLockRef.current !== null) {
      try {
        window.scrollTo(0, scrollLockRef.current);
      } catch {
        /* ignore */
      }
      scrollLockRef.current = null;
    }
    finalize(commit);
  };

  const onTouchCancel = () => {
    touchRef.current = null;
    if (engagedRef.current) {
      engagedRef.current = false;
      draggingRef.current = false;
      if (scrollLockRef.current !== null) {
        try {
          window.scrollTo(0, scrollLockRef.current);
        } catch {
          /* ignore */
        }
      }
      finalize(false);
    }
    scrollLockRef.current = null;
  };

  /* ⭐ v3.8.9: اتصال شنونده‌های native غیرpassive در فاز capture:
   *  - passive:false → اجازهٔ preventDefault هنگام درگیرشدن افقی (مرورگر ژست را
   *    برای اسکرول عمودی نمی‌دزدد — مشکل سوایپ در نیمهٔ پایین گوشی)
   *  - capture → حتی اگر فرزندی (مثل نمودار) رویداد را stopPropagation کند هم
   *    می‌رسد؛ عناصر SWIPE_GUARD همان‌جا رد می‌شوند */
  const startFn = React.useRef(onTouchStart);
  const moveFn = React.useRef(onTouchMove);
  const endFn = React.useRef(onTouchEnd);
  const cancelFn = React.useRef(onTouchCancel);
  React.useEffect(() => {
    startFn.current = onTouchStart;
    moveFn.current = onTouchMove;
    endFn.current = onTouchEnd;
    cancelFn.current = onTouchCancel;
  });

  React.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const opts: AddEventListenerOptions = { passive: false, capture: true };
    const onStart = (e: TouchEvent) => startFn.current(e as unknown as React.TouchEvent);
    const onMove = (e: TouchEvent) => {
      // اگر درگ افقی درگیر شده، پیش‌فرض را بلاک کن — مرورگر نباید اسکرول را ببرد
      if (engagedRef.current && draggingRef.current) {
        if (e.cancelable) e.preventDefault();
      }
      moveFn.current(e as unknown as React.TouchEvent);
    };
    const onEnd = (e: TouchEvent) => endFn.current(e as unknown as React.TouchEvent);
    const onCancel = () => cancelFn.current();
    el.addEventListener("touchstart", onStart, opts);
    el.addEventListener("touchmove", onMove, opts);
    el.addEventListener("touchend", onEnd, opts);
    el.addEventListener("touchcancel", onCancel, opts);
    return () => {
      el.removeEventListener("touchstart", onStart, opts);
      el.removeEventListener("touchmove", onMove, opts);
      el.removeEventListener("touchend", onEnd, opts);
      el.removeEventListener("touchcancel", onCancel, opts);
    };
  }, []);

  /* ─── رفتن انیمیشنی با تپ نوار پایین ─── */
  const goTo = React.useCallback(
    (nextRaw: string) => {
      const next = nextRaw as T;
      if (draggingRef.current || animatingRef.current) return; // انگشت/انیمیشن جاری
      if (next === activeRef.current) return;
      const idx = order.indexOf(activeRef.current);
      const nIdx = order.indexOf(next);
      if (idx === -1 || nIdx === -1) return;
      const dir: SwipeDir = nIdx > idx ? 1 : -1;
      dxRef.current = 0;
      setView({ target: next, dir });
      animatingRef.current = true;
      // دو rAF: اول ترنسفورم اولیه (dx=0، بدون transition) نقاشی شود، بعد مقصد با transition
      requestAnimationFrame(() =>
        requestAnimationFrame(() => {
          const v = viewRef.current;
          if (!v || v.target !== next) {
            animatingRef.current = false;
            return;
          }
          if (reducedMotion()) {
            animatingRef.current = false;
            onCommit(next);
            setView(null);
            return;
          }
          const W = widthRef.current || 320;
          apply(v.dir, v.dir === 1 ? W : -W, true);
          if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
          finishTimerRef.current = setTimeout(() => {
            animatingRef.current = false;
            onCommit(next);
            setView(null);
          }, 340);
        })
      );
    },
    [order, onCommit, apply, reducedMotion]
  );

  React.useEffect(() => {
    if (handleRef) handleRef.current = { goTo };
  }, [handleRef, goTo]);

  React.useEffect(() => {
    return () => {
      if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
    };
  }, []);

  /* ─── رندر: ترتیب فرزندها = چیدمان فیزیکی (RTL: اولی راست‌ترین) ─── */
  const panelStyle = (): React.CSSProperties => ({
    width: width > 0 ? `${width}px` : "100%",
    flex: "none",
  });

  const panels: React.ReactNode[] = [];
  if (view && view.dir === -1) {
    panels.push(
      <div key={view.target} style={panelStyle()}>
        {renderPanel(view.target)}
      </div>
    );
    panels.push(
      <div key={active} style={panelStyle()}>
        {renderPanel(active)}
      </div>
    );
  } else if (view && view.dir === 1) {
    panels.push(
      <div key={active} style={panelStyle()}>
        {renderPanel(active)}
      </div>
    );
    panels.push(
      <div key={view.target} style={panelStyle()}>
        {renderPanel(view.target)}
      </div>
    );
  } else {
    panels.push(
      <div key={active} style={panelStyle()}>
        {renderPanel(active)}
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="hk-swipe relative flex w-full flex-col overflow-x-clip"
      style={{ touchAction: "pan-y", minHeight: "calc(100dvh - 6rem)" }}
      data-swipe-root=""
    >
      <div
        ref={trackRef}
        className="flex w-max flex-1 items-stretch"
        style={{ willChange: "transform" }}
      >
        {panels}
      </div>
    </div>
  );
}
