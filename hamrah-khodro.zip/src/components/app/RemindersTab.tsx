"use client";

/**
 * تب یادآورها — کارت‌های وضعیت‌دار (گذشته/نزدیک/فعال/انجام‌شده)
 * ⭐ v3.8.6: فیلتر شبیه سوابق — جستجو + فیلتر خودرو + فیلتر وضعیت (باقیمانده/انجام‌شده)
 */

import * as React from "react";
import { BellOff, Check, ChevronDown, Loader2, Pencil, Search, Trash2, Undo2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa, formatJalaliISO, faNum } from "@/lib/persian";
import type { ReminderItem, VehicleItem } from "@/lib/types";
import { computeReminderStatus, EmptyVehicles, PageHeader, type ReminderThresholds } from "./shared";
import { PickerSheet } from "./fields";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";

interface RemindersTabProps {
  reminders: ReminderItem[];
  vehicles: VehicleItem[];
  currentKmByVehicle: Map<string, number>;
  /** آستانهٔ «نزدیک» یادآورها — از تنظیمات نوتیفیکیشن */
  notifyThresholds: ReminderThresholds;
  onRefresh: () => void;
  onEdit: (r: ReminderItem) => void;
  onAdd: () => void;
  onAddVehicle: () => void;
  onGoSettings: () => void;
}

type Bucket = "overdue" | "soon" | "ok" | "done";

const STATUS_OPTIONS: { value: string; label: string }[] = [
  { value: "all", label: "همه" },
  { value: "remaining", label: "باقیمانده" },
  { value: "done", label: "انجام‌شده" },
];

const BUCKET_TITLES: Record<Bucket, { title: string; desc: string }> = {
  overdue: { title: "عقب‌افتاده", desc: "گذشته‌اند و باید انجام شوند" },
  soon: { title: "نزدیک", desc: "در چند روز/کیلومتر آینده" },
  ok: { title: "فعال", desc: "به زمانشان نزدیک نیستند" },
  done: { title: "انجام‌شده", desc: "پیش‌تر انجام شده‌اند" },
};

export function RemindersTab({
  reminders,
  vehicles,
  currentKmByVehicle,
  notifyThresholds,
  onRefresh,
  onEdit,
  onAdd,
  onAddVehicle,
  onGoSettings,
}: RemindersTabProps) {
  const { toast } = useToast();
  const [busyId, setBusyId] = React.useState<string | null>(null);

  // ⭐ v3.8.6: فیلترها — شبیه تب سوابق (جستجو + خودرو + وضعیت)
  const [q, setQ] = React.useState("");
  const [vehicleFilter, setVehicleFilter] = React.useState<string>("all");
  const [statusFilter, setStatusFilter] = React.useState<string>("all");
  const [sheet, setSheet] = React.useState<null | "vehicle" | "status">(null);

  const vehicleById = React.useMemo(() => {
    const m = new Map<string, VehicleItem>();
    vehicles.forEach((v) => m.set(v.id, v));
    return m;
  }, [vehicles]);

  // دسته‌بندی — ⭐ v3.8.6: روی لیستِ فیلترشده (جستجو/خودرو/وضعیت) اعمال می‌شود
  const filtered = React.useMemo(() => {
    const query = q.trim();
    return reminders.filter((r) => {
      if (vehicleFilter !== "all" && r.vehicleId !== vehicleFilter) return false;
      if (statusFilter === "done" && !r.done) return false;
      if (statusFilter === "remaining" && r.done) return false;
      if (query) {
        const vehicle = vehicleById.get(r.vehicleId)?.name ?? "";
        const hay = `${r.title} ${r.notes ?? ""} ${vehicle}`;
        if (!hay.includes(query)) return false;
      }
      return true;
    });
  }, [reminders, q, vehicleFilter, statusFilter, vehicleById]);

  const buckets = React.useMemo(() => {
    const result: Record<Bucket, ReminderItem[]> = { overdue: [], soon: [], ok: [], done: [] };
    for (const r of filtered) {
      const st = computeReminderStatus(r, currentKmByVehicle.get(r.vehicleId) ?? 0, notifyThresholds);
      result[st.status].push(r);
    }
    // مرتب‌سازی: نزدیک‌ترین اول
    const sortByDue = (a: ReminderItem, b: ReminderItem) => {
      const va = a.kind === "DATE" ? (a.dueDate ?? "") : String(a.dueKm ?? 0).padStart(10, "0");
      const vb = b.kind === "DATE" ? (b.dueDate ?? "") : String(b.dueKm ?? 0).padStart(10, "0");
      return va.localeCompare(vb);
    };
    result.overdue.sort((a, b) => sortByDue(a, b));
    result.soon.sort((a, b) => sortByDue(a, b));
    result.ok.sort((a, b) => sortByDue(a, b));
    result.done.sort((a, b) => (b.doneAt ?? "").localeCompare(a.doneAt ?? ""));
    return result;

  }, [filtered, currentKmByVehicle, notifyThresholds]);

  const activeCount = reminders.filter((r) => !r.done).length;

  const toggleDone = async (r: ReminderItem) => {
    setBusyId(r.id);
    try {
      const res = await fetch(`/api/reminders/${r.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ done: !r.done }),
      });
      if (!res.ok) throw new Error();
      toast({
        title: r.done ? "بازگشایی شد" : "انجام شد ✓",
        description: r.title,
      });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "عملیات انجام نشد", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const remove = async (r: ReminderItem) => {
    const ok = await confirmDialog({
      title: "حذف یادآور",
      message: `یادآور «${r.title}» حذف شود؟`,
    });
    if (!ok) return;
    setBusyId(r.id);
    try {
      const res = await fetch(`/api/reminders/${r.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      toast({ title: "حذف شد", description: r.title });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "حذف انجام نشد", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const order: Bucket[] = ["overdue", "soon", "ok", "done"];

  return (
    <div>
      {/* ─── سربرگ مشترک — عنوان + تاریخ امروز + شمار یادآورهای فعال ─── */}
      <PageHeader
        title="یادآورها"
        badge={activeCount > 0 ? `${fa(activeCount)} فعال` : undefined}
      />

      {/* ⭐ v3.8.6: جستجو و فیلترها — شبیه تب سوابق */}
      {vehicles.length > 0 && reminders.length > 0 && (
        <div className="mt-3 px-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
            <input
              dir="rtl"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="جستجو در یادآورها..."
              className="h-12 w-full rounded-xl border border-input bg-card pr-11 pl-4 text-[15px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary/60 focus:outline-none focus:ring-[3px] focus:ring-primary/15"
            />
          </div>

          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setSheet("vehicle")}
              className="flex h-11 items-center justify-between rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
            >
              <span className="truncate text-[13px] font-medium text-foreground">
                {vehicleFilter === "all"
                  ? "همه خودروها"
                  : (vehicleById.get(vehicleFilter)?.name ?? "همه خودروها")}
              </span>
              <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
            </button>
            <button
              type="button"
              onClick={() => setSheet("status")}
              className="flex h-11 items-center justify-between rounded-xl border border-input bg-card px-3.5 text-right active:bg-muted/50"
            >
              <span className="truncate text-[13px] font-medium text-foreground">
                {STATUS_OPTIONS.find((t) => t.value === statusFilter)?.label ?? "همه"}
              </span>
              <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
            </button>
          </div>

          <p className="mt-2 px-1 text-[12px] text-muted-foreground">
            {fa(filtered.length)} مورد
          </p>
        </div>
      )}

      {/* شیت فیلتر خودرو */}
      <PickerSheet
        open={sheet === "vehicle"}
        onClose={() => setSheet(null)}
        title="فیلتر خودرو"
        subtitle={`${fa(vehicles.length + 1)} گزینه — جستجو کنید یا انتخاب کنید`}
        options={[
          { value: "all", label: "همه خودروها" },
          ...vehicles.map((v) => ({ value: v.id, label: v.name })),
        ]}
        value={vehicleFilter}
        onChange={setVehicleFilter}
        searchPlaceholder="جستجوی خودرو..."
      />

      {/* شیت فیلتر وضعیت — باقیمانده/انجام‌شده */}
      <PickerSheet
        open={sheet === "status"}
        onClose={() => setSheet(null)}
        title="فیلتر وضعیت"
        options={STATUS_OPTIONS.map((t) => ({ value: t.value, label: t.label }))}
        value={statusFilter}
        onChange={setStatusFilter}
      />

      <div className="px-4 pb-32">
        {vehicles.length === 0 ? (
          <EmptyVehicles
            title="یادآور به خودرو متصل است"
            desc="یادآورهای سرویس، بیمه و معاینه برای خودرو ثبت می‌شوند. ابتدا خودروی خود را اضافه کنید."
            onAddVehicle={onAddVehicle}
            onGoSettings={onGoSettings}
          />
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
            <div className="flex size-28 items-center justify-center rounded-full bg-primary/8">
              <div className="flex size-20 items-center justify-center rounded-full bg-primary/12">
                <BellOff className="size-10 text-primary/70" strokeWidth={1.6} />
              </div>
            </div>
            <h3 className="mt-5 text-[18px] font-bold text-foreground">موردی یافت نشد</h3>
            <p className="mt-2 max-w-[280px] text-[14px] leading-7 text-muted-foreground">
              عبارت جستجو یا فیلترها را تغییر دهید.
            </p>
          </div>
        ) : (
          order.map((b) => {
            if (buckets[b].length === 0) return null;
            return (
              <section key={b} className="mb-5">
                <div className="mb-2 flex items-center gap-2 px-1">
                  <h2 className="text-[14px] font-bold text-foreground">{BUCKET_TITLES[b].title}</h2>
                  <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                    {fa(buckets[b].length)}
                  </span>
                </div>
                <div className="flex flex-col gap-2.5">
                  {buckets[b].map((r) => {
                    const st = computeReminderStatus(r, currentKmByVehicle.get(r.vehicleId) ?? 0, notifyThresholds);
                    const StatusIcon = st.icon;
                    const vehicle = vehicleById.get(r.vehicleId);
                    const busy = busyId === r.id;
                    return (
                      <div
                        key={r.id}
                        className={cn(
                          "rounded-2xl border bg-card p-4 shadow-sm transition-all",
                          st.borderColor,
                          r.done && "opacity-70"
                        )}
                      >
                        <div className="flex items-start gap-3">
                          <span className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", st.bg)}>
                            <StatusIcon className={cn("size-5.5", st.color)} strokeWidth={2.2} />
                          </span>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <h3
                                className={cn(
                                  "text-[16px] font-bold leading-6 text-foreground",
                                  r.done && "line-through decoration-muted-foreground/50"
                                )}
                              >
                                {r.title}
                              </h3>
                              <span
                                className={cn(
                                  "shrink-0 rounded-full px-2.5 py-1 text-[12px] font-bold",
                                  st.bg,
                                  st.color
                                )}
                              >
                                {st.label}
                              </span>
                            </div>

                            <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] text-muted-foreground">
                              {vehicle && <span>{vehicle.name}</span>}
                              {r.dueDate && (
                                <>
                                  <span className="text-border">•</span>
                                  <span>{formatJalaliISO(r.dueDate)}</span>
                                </>
                              )}
                              {r.dueKm !== null && (
                                <>
                                  <span className="text-border">•</span>
                                  <span className="tabular-nums">کیلومتر {faNum(r.dueKm)}</span>
                                </>
                              )}
                              {r.repeatKind !== "NONE" && (
                                <>
                                  <span className="text-border">•</span>
                                  <span>
                                    {r.repeatKind === "MONTHLY"
                                      ? "تکرار ماهانه"
                                      : r.repeatKind === "YEARLY"
                                        ? "تکرار سالانه"
                                        : `هر ${faNum(r.repeatEveryKm ?? 5000)} کیلومتر`}
                                  </span>
                                </>
                              )}
                            </div>

                            {r.notes && (
                              <p className="mt-1.5 truncate text-[13px] leading-6 text-muted-foreground">
                                {r.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* اکشن‌ها */}
                        <div className="mt-3 flex items-center gap-2 border-t border-border/60 pt-3">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => toggleDone(r)}
                            className={cn(
                              "flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl text-[14px] font-bold transition-all active:scale-95 disabled:opacity-50",
                              r.done
                                ? "bg-muted text-muted-foreground"
                                : "bg-primary/12 text-primary"
                            )}
                          >
                            {busy ? (
                              <Loader2 className="size-4 animate-spin" />
                            ) : r.done ? (
                              <Undo2 className="size-4" />
                            ) : (
                              <Check className="size-4" />
                            )}
                            {r.done ? "بازگشایی" : "انجام شد"}
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => onEdit(r)}
                            aria-label="ویرایش یادآور"
                            className="flex size-10 items-center justify-center rounded-xl bg-muted text-muted-foreground transition-all active:scale-95"
                          >
                            <Pencil className="size-4" />
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => remove(r)}
                            aria-label="حذف یادآور"
                            className="flex size-10 items-center justify-center rounded-xl bg-red-500/10 text-red-600 transition-all active:scale-95"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })
        )}

        {reminders.length > 0 && (
          <button
            type="button"
            onClick={onAdd}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-primary/40 text-[15px] font-bold text-primary transition-colors active:bg-primary/8"
          >
            یادآور جدید
          </button>
        )}
      </div>
    </div>
  );
}
