"use client";

/**
 * آموزش اولیهٔ برنامه (v3.9.6) — ۴ اسلاید کامل‌صفحه (فقط بار اولِ بدون-خودرو؛ با هر
 * خروج — «رد کردن» یا «شروع» — پرچم hk-onboarded ثبت می‌شود):
 *  ۱) خوش‌آمد — صحنهٔ متحرک «جادهٔ واقعی»: دیوار آجری با شعار اسپری‌شدهٔ
 *     «زن زندگی آزادی» + تبلیغ اسپری‌شدهٔ «همراه خودرو» کنار همان شعار (⭐ v3.9.6) +
 *     درخت سرو + نیمکت پارک با دو دخترِ کنار هم با موهای بازِ چندلایهٔ بادخورده +
 *     گربهٔ نشسته روی زمین + خودروی کلاسیک با چراغ‌های روشن —
 *     جاده و مناظر به‌صورت پیوسته و بی‌پرش حرکت می‌کنند (شیفت دقیقاً یک دورهٔ الگو).
 *  ۲) سوایپ بین صفحه‌ها (نمایش متحرک جهت حرکت)
 *  ۳) پشتیبان‌گیری با حساب گوگل
 *  ۴) افزودن نخستین خودرو (دکمهٔ مستقیم)
 *
 * انیمیشن‌ها فقط transform/opacity هستند (کامپوزیتور — روان در WebView) و در
 * prefers-reduced-motion خاموش می‌شوند.
 */

import * as React from "react";
import { Car, CloudUpload, KeyRound, MoveHorizontal, ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";

const ONBOARDED_KEY = "hamrah-khodro-onboarded";

/** آیا آموزش قبلاً دیده/رد شده؟ */
export function isOnboarded(): boolean {
  try {
    return localStorage.getItem(ONBOARDED_KEY) === "1";
  } catch {
    return false;
  }
}

function markOnboarded(): void {
  try {
    localStorage.setItem(ONBOARDED_KEY, "1");
  } catch {
    /* ignore */
  }
}

/* ═══════════════════════════ اجزای صحنهٔ جاده (اسلاید ۱) ═══════════════════════════ */

/** درخت سرو (ستونی — مثل سروهای ایرانی) */
function CedarTree({ height, className }: { height: number; className?: string }) {
  // ۱۴ ردیف فلک سرو — از نوک باریک تا پایین پهن‌تر (viewBox 60×150)
  const rows: { y: number; w: number }[] = [];
  const widths = [7, 10, 13, 15, 17, 19, 21, 22, 23, 24, 24, 25, 25, 24];
  widths.forEach((w, i) => rows.push({ y: 8 + i * 8.2, w }));
  return (
    <svg
      viewBox="0 0 60 150"
      style={{ height }}
      className={cn("shrink-0", className)}
      aria-hidden
      focusable="false"
    >
      <defs>
        <linearGradient id="hk-cedar-g" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#41805F" />
          <stop offset="0.55" stopColor="#2E6247" />
          <stop offset="1" stopColor="#23503B" />
        </linearGradient>
      </defs>
      {/* نوک درخت */}
      <path d="M30 0 C32.5 3 33 6 30.5 9 L29.5 9 C27 6 27.5 3 30 0 Z" fill="#377050" />
      {/* ردیف‌های فلک — هر ردیف با لبهٔ روشنِ بالا برای حجم */}
      {rows.map((r, i) => {
        const x = 30 - r.w / 2 + (i % 2 === 0 ? -1.4 : 1.4);
        return (
          <g key={i}>
            <rect x={x} y={r.y} width={r.w} height={8.4} rx={4.2} fill="url(#hk-cedar-g)" />
            <rect x={x + 1.5} y={r.y + 0.8} width={Math.max(r.w - 3, 3)} height={2.6} rx={1.3} fill="#4C8E6B" opacity={0.55} />
          </g>
        );
      })}
      {/* تنه و ریشه */}
      <path d="M27.5 118 L32.5 118 L33.5 138 L36.5 143 L23.5 143 L26.5 138 Z" fill="#5E4A34" />
      <ellipse cx="30" cy="144" rx="15" ry="3" fill="#1E2A33" opacity={0.55} />
    </svg>
  );
}

/** چراغ خیابانی با هالهٔ روشن */
function StreetLamp({ h = 86 }: { h?: number }) {
  return (
    <div className="absolute flex flex-col items-center" style={{ height: h }} aria-hidden>
      <div
        className="relative size-[13px] rounded-full bg-[#FFE3A6]"
        style={{ boxShadow: "0 0 14px 6px rgba(255,207,125,0.55), 0 0 34px 16px rgba(255,190,110,0.22)" }}
      />
      <div className="h-[7px] w-[3px] rounded-b bg-[#2B333E]" />
      <div className="w-[3px] flex-1 rounded-b bg-[#2B333E]" />
      <div className="h-[3px] w-[16px] rounded bg-[#2B333E]" />
    </div>
  );
}

/** نیمکت پارک (نیم‌رخ — تخته‌های چوبی + پایه‌های آهنی خم‌دار + دستهٔ آرنج) */
function ParkBench({ width = 150 }: { width?: number }) {
  return (
    <svg viewBox="0 0 150 64" style={{ width }} className="shrink-0" aria-hidden focusable="false">
      {/* پایه‌های آهنی خم‌دار */}
      <g fill="#333B46" stroke="#262D37" strokeWidth="1">
        <path d="M14 60 L14 38 C14 35 16 33 19 33 C22 33 24 35 24 38 L24 60 L20 60 L20 39 C20 37.8 19.4 37 19 37 C18.6 37 18 37.8 18 39 L18 60 Z" />
        <path d="M126 60 L126 38 C126 35 128 33 131 33 C134 33 136 35 136 38 L136 60 L132 60 L132 39 C132 37.8 131.4 37 131 37 C130.6 37 130 37.8 130 39 L130 60 Z" />
        {/* تیر زیر نشیمن */}
        <rect x="20" y="44" width="110" height="4" rx="2" />
      </g>
      {/* تختهٔ نشیمن — چوب گرم با شیار */}
      <rect x="4" y="28" width="142" height="9" rx={4.5} fill="#9A6B41" stroke="#6E4A2C" strokeWidth="0.8" />
      <rect x="7" y="29.5" width="136" height="2.2" rx="1.1" fill="#C09059" opacity={0.8} />
      <path d="M34 32 L34 33.4 M64 32 L64 33.4 M94 32 L94 33.4 M124 32 L124 33.4" stroke="#6E4A2C" strokeWidth="0.9" opacity="0.7" />
      {/* ریل‌های پشتی (دو تختهٔ افقی تمام‌طول) */}
      <rect x="8" y="4" width="134" height="6.5" rx={3.2} fill="#8F6138" stroke="#6E4A2C" strokeWidth="0.8" />
      <rect x="8" y="13" width="134" height="6.5" rx={3.2} fill="#9A6B41" stroke="#6E4A2C" strokeWidth="0.8" />
      <rect x="10" y="5.2" width="130" height="1.8" rx="0.9" fill="#C09059" opacity={0.8} />
      {/* پایه‌های عمودی پشتی */}
      <rect x="24" y="7" width="4" height="23" rx="2" fill="#333B46" />
      <rect x="72" y="7" width="4" height="23" rx="2" fill="#333B46" />
      <rect x="120" y="7" width="4" height="23" rx="2" fill="#333B46" />
      {/* دستهٔ آرنج چپ */}
      <path d="M7 28 C2 26 0.5 20 4 15.5" stroke="#333B46" strokeWidth="3.2" fill="none" strokeLinecap="round" />
      {/* سایهٔ روی زمین */}
      <ellipse cx="75" cy="62" rx="70" ry="3" fill="#1E2A33" opacity={0.5} />
    </svg>
  );
}

/** گربهٔ خیابانی — نشسته روی زمین با ژست طبیعی (پنجه‌های جلو صاف، دُم حلقه‌زده جلو) */
function StreetCat({ width = 58 }: { width?: number }) {
  return (
    <svg viewBox="0 0 64 58" style={{ width }} className="shrink-0" aria-hidden focusable="false">
      <defs>
        <linearGradient id="hk-cat-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#E0A66B" />
          <stop offset="1" stopColor="#C88A52" />
        </linearGradient>
      </defs>
      {/* سایهٔ زمین */}
      <ellipse cx="31" cy="55.5" rx="25" ry="2.6" fill="#1E2A33" opacity={0.5} />
      {/* دُم — روی زمین، حلقه‌زده جلوی پنجه‌ها */}
      <path
        d="M45 42 C55 44.5 57.5 50 51 52.5 C41 55.8 25 55 13.5 52.5"
        fill="none"
        stroke="#C88A52"
        strokeWidth="5.4"
        strokeLinecap="round"
      />
      {/* ران/کفل عقب — گرد و برجسته */}
      <ellipse cx="41" cy="39.5" rx="14.5" ry="13.5" fill="url(#hk-cat-g)" stroke="#8A5A32" strokeWidth="1" />
      {/* تنه — سینه رو به چپ، پشت به ران */}
      <path
        d="M15.5 15.5
           C11.5 19 10 25 10.8 31.5
           C11.5 37.5 14 42.5 18 45.5
           L33 45.5
           C31.5 38 32.5 29.5 35.5 23
           C31 18.5 25.5 15.5 20.5 14.5
           C18.5 14.2 16.8 14.6 15.5 15.5 Z"
        fill="url(#hk-cat-g)"
        stroke="#8A5A32"
        strokeWidth="1"
        strokeLinejoin="round"
      />
      {/* پنجه‌های جلو — صاف روی زمین */}
      <rect x="10" y="28" width="7.2" height="23.5" rx="3.6" fill="#D69A5F" stroke="#8A5A32" strokeWidth="0.9" />
      <line x1="13.6" y1="34" x2="13.6" y2="49" stroke="#B1723F" strokeWidth="0.9" />
      {/* گوش‌ها */}
      <path d="M9.5 9.5 L7.5 2 L14 7 Z" fill="#C88A52" stroke="#8A5A32" strokeWidth="0.8" strokeLinejoin="round" />
      <path d="M17 7.5 L19.5 1 L22.5 8.5 Z" fill="#C88A52" stroke="#8A5A32" strokeWidth="0.8" strokeLinejoin="round" />
      {/* سر */}
      <circle cx="15.5" cy="12" r="8" fill="url(#hk-cat-g)" stroke="#8A5A32" strokeWidth="1" />
      <path d="M9.8 7.5 L9 4 L12.2 6.8 Z" fill="#B98052" />
      <path d="M18 7 L19 3.8 L21 7.2 Z" fill="#B98052" />
      {/* صورت — چشم آرام + بینی + سبیل */}
      <path
        d="M10.5 12.5 C12 13.7 13.8 13.7 15 12.6 M16.8 12.3 C18.2 13.5 20 13.5 21.2 12.4"
        stroke="#7A4E28"
        strokeWidth="1.1"
        fill="none"
        strokeLinecap="round"
      />
      <path d="M14.6 16.4 L16.4 17.8 L14.8 19.2 L13.2 17.8 Z" fill="#8A5232" />
      <path
        d="M16.4 17.8 L22.5 16.6 M16.4 17.8 L22.8 19.6 M13.2 17.8 L7.4 16.6 M13.2 17.8 L7.2 19.6"
        stroke="rgba(250,240,225,0.75)"
        strokeWidth="0.75"
        strokeLinecap="round"
      />
      {/* راه‌راه‌های پُرهای ران */}
      <path
        d="M43 30 C45.5 34 46.5 39 46 44 M48 33 C50 36.5 50.5 40.5 50 44.5"
        stroke="#B1723F"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
}

/** شعار اسپری‌شده روی دیوار آجری — «زن زندگی آزادی» با لبه‌های ناهموار رنگ‌افشانی و چکه */
function WallGraffiti() {
  return (
    <svg
      viewBox="0 0 216 88"
      className="absolute bottom-[2px] left-[84px] h-[84px] w-[216px]"
      aria-hidden
      focusable="false"
    >
      <defs>
        <filter id="hk-grf" x="-12%" y="-12%" width="124%" height="124%">
          <feTurbulence type="fractalNoise" baseFrequency="0.16 0.95" numOctaves="2" seed="11" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="3.4" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <filter id="hk-grf-mist" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2.6" />
        </filter>
      </defs>
      <g transform="rotate(-2.6 108 44)">
        {/* هالهٔ مهِ اسپری پشت متن */}
        <text
          x="108"
          y="38"
          textAnchor="middle"
          fontSize="19.5"
          fontWeight="900"
          fill="#F4F1E9"
          opacity="0.3"
          filter="url(#hk-grf-mist)"
        >
          زن زندگی آزادی
        </text>
        {/* متن اصلی + قلم‌زن + چکه‌ها — با لبه‌های اسپری */}
        <g filter="url(#hk-grf)">
          <text x="108" y="38" textAnchor="middle" fontSize="19.5" fontWeight="900" fill="#F4F1E9">
            زن زندگی آزادی
          </text>
          <path
            d="M34 47 C72 53.5 146 53.5 184 44.5"
            stroke="#F4F1E9"
            strokeWidth="3.2"
            fill="none"
            strokeLinecap="round"
            opacity="0.92"
          />
          <path d="M49 49.5 C49.6 55 48.6 59 49.2 64" stroke="#F4F1E9" strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.85" />
          <path d="M97 51.5 C97.5 57 96.8 61 97.3 67" stroke="#F4F1E9" strokeWidth="2.1" fill="none" strokeLinecap="round" opacity="0.8" />
          <path d="M152 48.5 C152.4 53 151.7 56 152.2 60" stroke="#F4F1E9" strokeWidth="2.3" fill="none" strokeLinecap="round" opacity="0.85" />
        </g>
      </g>
    </svg>
  );
}

/** تبلیغِ اسپری‌شدهٔ «همراه خودرو» روی دیوار — (⭐ v3.9.6 درخواست کاربر:
 *  معرفی برنامه هم مثل شعار «زن زندگی آزادی» با اسپری روی دیوار باشد)
 *  قاب و ماشینک و متن‌ها همه رنگ‌افشانی‌اند: قاب نارنجی-کهربایی + متن کرم
 *  + چکه‌های رنگ + هالهٔ مهِ اسپری — همان زبان بصری شعار کناری */
function WallGraffitiAd() {
  return (
    <svg
      viewBox="0 0 92 84"
      className="absolute bottom-[2px] left-[306px] h-[84px] w-[92px]"
      aria-hidden
      focusable="false"
    >
      <defs>
        <filter id="hk-grf-ad" x="-12%" y="-12%" width="124%" height="124%">
          <feTurbulence type="fractalNoise" baseFrequency="0.17 0.9" numOctaves="2" seed="29" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="2.9" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <filter id="hk-grf-ad-mist" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2.4" />
        </filter>
      </defs>
      <g transform="rotate(-2.2 46 42)">
        {/* هالهٔ مهِ اسپری پشت قاب و عنوان */}
        <g filter="url(#hk-grf-ad-mist)" opacity="0.28">
          <path
            d="M8 6 C20 5.2 40 4.8 60 5.4 C72 5.7 84 6 85.5 9 C86.3 16 86.6 28 86 40 C85.7 52 86.3 64 85.4 74 C84.6 77.6 80 78.4 74 78.6 C58 79 38 79.2 20 78.8 C13 78.6 6.6 78.4 5.8 74.6 C5 66 5.4 52 5.6 40 C5.8 28 5.2 16 6 10 C6.4 8 7 6.2 8 6 Z"
            fill="none"
            stroke="#F5A53C"
            strokeWidth="4.5"
          />
          <text x="46" y="22" textAnchor="middle" fontSize="13" fontWeight="900" fill="#F4F1E9">
            همراه خودرو
          </text>
        </g>

        {/* لایهٔ اصلی اسپری — قاب دست‌پاش + ماشینک + متن‌های کج‌وکوله (سبک دیوارنویسی) */}
        <g filter="url(#hk-grf-ad)">
          {/* قاب دست‌پاش — گوشه‌ها و لبه‌ها ناهموار مثل اسپری واقعی */}
          <path
            d="M8 6 C20 5.2 40 4.8 60 5.4 C72 5.7 84 6 85.5 9 C86.3 16 86.6 28 86 40 C85.7 52 86.3 64 85.4 74 C84.6 77.6 80 78.4 74 78.6 C58 79 38 79.2 20 78.8 C13 78.6 6.6 78.4 5.8 74.6 C5 66 5.4 52 5.6 40 C5.8 28 5.2 16 6 10 C6.4 8 7 6.2 8 6 Z"
            fill="rgba(245,165,60,0.08)"
            stroke="#F5A53C"
            strokeWidth="2.4"
          />
          {/* دستِ دومِ هنرمند — بخشی از قاب دوباره‌پاشی شده (کمی جابجا) */}
          <path
            d="M10.5 6.6 C24 5.8 44 5.4 62 6 M86.2 14 C86.5 24 86.2 34 85.9 44 M84.9 62 C85.2 68 85 73 84.4 76.2"
            fill="none"
            stroke="#F5A53C"
            strokeWidth="1.5"
            opacity="0.5"
          />

          {/* عنوان — کمی کج مثل دیوارنویسی */}
          <text x="46" y="22" textAnchor="middle" fontSize="13" fontWeight="900" fill="#F4F1E9" transform="rotate(1.4 46 19)">
            همراه خودرو
          </text>

          {/* ماشینک اسپری‌شده — سدان کلاسیک رو به چپ، کمی چرخیده */}
          <g transform="translate(21 27) rotate(-2.4 23 12)">
            <path
              d="M4 19 C2.5 18.8 1.5 17.5 1.5 15.5 C1.5 12.5 3.5 10.5 7 10 L12 9.4 C14 4.2 17.5 2.6 22 2.6 L27.5 2.6 C31 2.6 33.6 4.4 35.6 8.2 L38 11.6 C41 12.2 43 14 43 16.6 L43 17.4 C43 18.6 42 19.4 40.6 19.4 L36.6 19.4 A4.6 4.6 0 0 0 27.4 19.4 L14.2 19.4 A4.6 4.6 0 0 0 5 19.4 Z"
              fill="#F4F1E9"
            />
            <path d="M13.5 9.6 C15 5.8 17.5 4.2 21 4.2 L25.5 4.2 L25.5 11.2 L11.8 11.2 Z" fill="#C88A3C" opacity="0.92" />
            <path d="M27.5 4.2 L29.5 4.2 C32 4.2 34 5.8 35.6 8.8 L36.6 11.2 L27.5 11.2 Z" fill="#C88A3C" opacity="0.92" />
            <path d="M6 13.5 C18 12.2 30 12.4 40 14.5" stroke="rgba(245,165,60,0.6)" strokeWidth="0.8" fill="none" />
            <circle cx="42" cy="13.8" r="1.7" fill="#F5A53C" />
            <circle cx="10" cy="19.8" r="4.1" fill="#191D24" />
            <circle cx="10" cy="19.8" r="1.7" fill="#F5A53C" opacity="0.9" />
            <circle cx="31.5" cy="19.8" r="4.1" fill="#191D24" />
            <circle cx="31.5" cy="19.8" r="1.7" fill="#F5A53C" opacity="0.9" />
          </g>

          {/* زیرعنوان — با کجی متفاوت */}
          <text x="46" y="60" textAnchor="middle" fontSize="6.2" fontWeight="700" fill="#F4F1E9" opacity="0.95" transform="rotate(-1 46 58)">
            دفترچهٔ سرویس خودرو
          </text>

          {/* سه نقطهٔ اسپری بین زیرعنوان و فراخوان */}
          <circle cx="36" cy="65.5" r="0.9" fill="#F5A53C" opacity="0.75" />
          <circle cx="46" cy="66" r="1" fill="#F5A53C" opacity="0.8" />
          <circle cx="56" cy="65.5" r="0.9" fill="#F5A53C" opacity="0.75" />

          {/* فراخوان + قلم‌زن زیرش */}
          <text x="46" y="74.5" textAnchor="middle" fontSize="7.2" fontWeight="800" fill="#F5A53C" transform="rotate(1.8 46 72)">
            نصب رایگان
          </text>
          <path d="M30 77 C40 78.8 52 78.8 62 76.9" stroke="#F5A53C" strokeWidth="1.3" fill="none" strokeLinecap="round" opacity="0.85" />

          {/* چکه‌های رنگ از قاب و عنوان */}
          <path d="M24 79.5 C24.4 81.5 23.8 83 24.2 84" stroke="#F5A53C" strokeWidth="1.6" fill="none" strokeLinecap="round" opacity="0.85" />
          <path d="M46 79.5 C46.3 81 45.9 82.5 46.2 83.5" stroke="#F4F1E9" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.75" />
          <path d="M68 79 C68.4 81 67.9 82.5 68.3 83.8" stroke="#F5A53C" strokeWidth="1.8" fill="none" strokeLinecap="round" opacity="0.8" />
          <path d="M60 24.6 C60.3 27 59.8 29 60.1 30.6" stroke="#F4F1E9" strokeWidth="1.3" fill="none" strokeLinecap="round" opacity="0.8" />
        </g>

        {/* ذرات مهِ اسپری دور قاب */}
        <g fill="#F5A53C">
          <circle cx="3.5" cy="18" r="1" opacity="0.4" />
          <circle cx="1.8" cy="34" r="0.8" opacity="0.3" />
          <circle cx="89" cy="22" r="1" opacity="0.35" />
          <circle cx="90.5" cy="48" r="0.8" opacity="0.3" />
          <circle cx="4" cy="60" r="0.9" opacity="0.35" />
        </g>
      </g>
    </svg>
  );
}

/** دخترِ کتاب‌خوان روی نیمکت — موی بلندِ بازِ چندلایه که در نسیم موج می‌خورد
 *  (⭐ v3.9.6: صورت واضح‌تر و قشنگ‌تر — ابرو/مژه/لپ‌های گلی + تارهای موی جدا
 *   که هرکدام با فاز و دورهٔ خودشان در باد می‌رقصند)
 *  (هندسی: باسن روی سطح نشیمن نیمکت ~۳۶px بالاتر از زمین، پاها آویزان نزدیک زمین) */
function BenchGirlReader({ height = 104 }: { height?: number }) {
  return (
    <svg viewBox="0 0 72 102" style={{ height }} className="shrink-0" aria-hidden focusable="false">
      {/* پنل پشتی موی بلند باز — بنفش-مشکی عمیق */}
      <path
        className="hk-ob-hair"
        d="M30.5 8
           C35 10.5 37 15 37.5 20.5
           C38.3 28 39.3 36 38.6 44
           C38 51 39.5 58 38.8 65
           C38.5 68.5 39.2 71 38 73.5
           C34.8 72.8 31.8 73.6 29.4 75.2
           C31.4 67.5 31.8 59 31 50.5
           C30.3 42.5 29.2 34 27 27.5
           C25.3 22.3 25.8 16 27.8 11.5 Z"
        fill="#221B2E"
        stroke="#161122"
        strokeWidth="0.5"
      />
      {/* تارهای جداگانهٔ مو که در باد می‌رقصند — هر تار فاز خودش را دارد */}
      <g className="hk-ob-lock-a">
        <path
          d="M35 9.5 C39.5 13 41.5 18.5 42 24.5 C43 32.5 44 41.5 43.3 50 C42.7 58 44.3 65.5 43 73"
          stroke="#3A3054"
          strokeWidth="2.6"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      <g className="hk-ob-lock-b">
        <path
          d="M31.5 8.5 C36 12 38 17.5 38.5 23.5 C39.5 31.5 40.5 40 39.8 48.5 C39.2 56 40.8 63.5 39.5 70.5"
          stroke="#161122"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      <g className="hk-ob-lock-c">
        <path
          d="M33.2 10 C37.6 13.6 39.6 19 40.1 25 C40.9 33 41.6 41.5 40.9 49.5"
          stroke="#574A78"
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
          opacity="0.9"
        />
      </g>
      {/* برقِ مو (روتوی روشن روی پنل) */}
      <path
        className="hk-ob-hair"
        d="M34.5 12 C36.2 16 37 21 37 26.5 C37.1 34 36.6 42 35.8 49"
        stroke="#4A3F66"
        strokeWidth="1.4"
        fill="none"
        strokeLinecap="round"
        opacity="0.8"
      />
      {/* تار موی جلو — ریخته روی سینه (نشانهٔ موی باز) */}
      <path
        className="hk-ob-hair-f"
        d="M18.8 12
           C17.2 18 16.8 25.5 18 32
           C18.6 35.5 18.4 39 17.6 41.5
           L20.2 42
           C21.2 37 21.4 31.5 20.8 26.5
           C20.4 22 20.4 17 21 13 Z"
        fill="#221B2E"
      />
      {/* تارهای رهاشده در نسیم */}
      <g className="hk-ob-loose-a">
        <path d="M44 16 C47 15 49 16.5 50.5 19" stroke="#3A3054" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      </g>
      <g className="hk-ob-loose-b">
        <path d="M43 38 C46.5 36.5 48.5 38 50 41" stroke="#3A3054" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      </g>
      {/* سر — نیم‌رخ به چپ با خط دور واضح */}
      <ellipse cx="25.5" cy="14.5" rx="8.4" ry="9" fill="#EAC49B" stroke="#D9A97E" strokeWidth="0.6" />
      {/* کلاه‌مو (بالای سر) */}
      <path
        d="M17.2 13.5 C17.2 7 21.3 3.4 25.7 3.4 C30.2 3.4 33.9 7 34 13.5 C34 14.6 33.9 15.6 33.6 16.6 L17.6 16.6 C17.3 15.6 17.2 14.6 17.2 13.5 Z"
        fill="#221B2E"
        stroke="#161122"
        strokeWidth="0.5"
      />
      {/* چتری جلو — دو تار جدا برای خط موی طبیعی‌تر */}
      <path d="M18.6 8.6 C17.5 12 17.4 16 18.4 19.6 L20.8 18.2 C20 15 20 11.6 20.8 9 Z" fill="#221B2E" />
      <path d="M28.8 4.8 C31.4 6.2 32.9 9.2 33.1 13.2 L30.9 13.8 C30.9 10.6 30.1 8.1 28.5 6.2 Z" fill="#221B2E" />
      {/* ── صورت واضح‌تر (⭐ v3.9.6): ابرو + چشمِ مژه‌دار + لپِ گلی + لبخند ── */}
      <path d="M18.7 10.9 C19.9 10.1 21.5 10 22.7 10.6" stroke="#3A2C1E" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      <path d="M19.6 13 C20.9 14.1 22.6 14.1 23.7 13.1" stroke="#4A3524" strokeWidth="1.05" fill="none" strokeLinecap="round" />
      <path d="M19.2 12.7 L18.3 12 M24 12.9 L24.9 12.3" stroke="#4A3524" strokeWidth="0.75" fill="none" strokeLinecap="round" />
      <path d="M17.3 15.9 C17 16.5 17.1 17 17.6 17.3" stroke="#D9A97E" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      <ellipse cx="21.7" cy="17.1" rx="2.1" ry="1.2" fill="#E89A8A" opacity="0.35" />
      <path d="M19.4 19 C20.4 19.8 21.7 19.7 22.5 18.9" stroke="#C0674F" strokeWidth="0.95" fill="none" strokeLinecap="round" />
      <path d="M19.9 19.7 C20.6 20.2 21.6 20.2 22.2 19.8" stroke="#B55D47" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      {/* بلوز سبزآبی — بالاتنه با خمِ ملایم به جلو + یقه */}
      <path
        d="M20.5 21.5
           C24.5 19.5 29.5 19.5 32.5 21.5
           C35.5 25.5 36.5 31.5 36.5 37.5
           C36.5 43.5 36 49.5 35 54.5
           C34.7 57.5 33.5 59.5 31 59.5
           L24.5 59.5
           C22 59.5 20.6 57.5 20.4 54.5
           C20.1 47.5 19.7 39.5 19.9 32.5
           C20 28.5 20 24.5 20.5 21.5 Z"
        fill="#4F7F7A"
        stroke="#3D6560"
        strokeWidth="0.6"
      />
      <path d="M23.5 21.2 C25.5 22.4 28.5 22.4 30.5 21.2" stroke="#6BA39C" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      {/* بازو به سمت کتاب + دست */}
      <path d="M22 25.5 C17.5 29.5 14 34.5 12.5 40.5 L16 42.5 C17.8 37.5 20.8 33 24.5 30 Z" fill="#4F7F7A" stroke="#3D6560" strokeWidth="0.5" />
      <circle cx="14.2" cy="42" r="2.6" fill="#EAC49B" stroke="#D9A97E" strokeWidth="0.5" />
      {/* کتاب باز روی پا */}
      <path d="M2.5 47.5 C6 45 10 45 13 47.5 L13 56 C10 53.8 6 53.8 2.5 56.5 Z" fill="#F2EADA" stroke="#B9AE93" strokeWidth="0.8" />
      <path d="M13 47.5 C16 45.2 20 45.4 23 48 L23 56.5 C20 54.2 16 54.2 13 56 Z" fill="#EFE7D2" stroke="#B9AE93" strokeWidth="0.8" />
      <path
        d="M4.5 51 C7 49.8 9.5 49.8 12 51.2 M4.5 53.5 C7 52.3 9.5 52.3 12 53.7 M14.5 51 C17 49.9 19.5 50 21.5 51.5 M14.5 53.5 C17 52.4 19.5 52.5 21.5 54"
        stroke="#C9BFA5"
        strokeWidth="0.75"
        fill="none"
      />
      {/* ران‌ها روی نشیمن (۳۶px بالاتر از زمین) + دامن روی زانو */}
      <path
        d="M22.5 54
           C16.5 56.5 11.5 58.5 9 61.5
           C7.5 63.5 8 66 10.5 66.5
           L30 66.5
           C32 64 32.5 60.5 31 57 Z"
        fill="#45716D"
        stroke="#365A56"
        strokeWidth="0.5"
      />
      {/* ساق‌های آویزان + کفش‌ها (نزدیک زمین) */}
      <path d="M12 64.5 C11.4 72 11 82 11.2 92" stroke="#3A3440" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d="M18 65 C17.7 73 17.5 83 17.7 93" stroke="#312B38" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d="M8.6 90.5 C7 93.5 8.4 96 11.8 96.3 L13.8 96.3 L13.8 91 Z" fill="#4A2E24" />
      <path d="M15.2 91.5 C13.8 94.3 15.3 96.7 18.6 96.9 L20.5 96.9 L20.5 92 Z" fill="#3E2620" />
      {/* چین دامن */}
      <path d="M17 57.5 C18 60 18.5 62.5 18 65 M23 56.5 C24 59.5 24.5 62 24 65" stroke="rgba(25,50,48,0.4)" strokeWidth="1" fill="none" />
    </svg>
  );
}

/** دخترِ همراه — کنارِ کتاب‌خوان روی نیمکت، موی بلند بازِ بلوطی چندلایه که در
 *  نسیم موج می‌خورد (⭐ v3.9.6: صورت واضح‌تر و قشنگ‌تر + تارهای مو با باد)، دست‌ها روی پا */
function BenchGirlFriend({ height = 100 }: { height?: number }) {
  return (
    <svg viewBox="0 0 72 100" style={{ height }} className="shrink-0" aria-hidden focusable="false">
      {/* پنل پشتی موی بلند باز — بلوطی گرم */}
      <path
        className="hk-ob-hair"
        d="M31 9
           C35.5 11.5 38 16 38.5 22
           C39.5 30 41 38.5 40.3 47
           C39.7 55 41.5 63 40.6 70.5
           C40.3 73.5 41 76 39.8 78.5
           C36.2 77.8 32.8 79 30 80.8
           C32.4 71.5 32.8 62 32 53
           C31.3 44.5 30 35.5 27.8 27.5
           C25.8 21.5 26.2 14.5 28.4 10.5 Z"
        fill="#4A3323"
        stroke="#362516"
        strokeWidth="0.5"
      />
      {/* تارهای جداگانهٔ مو که در باد می‌رقصند — هر تار فاز خودش را دارد */}
      <g className="hk-ob-lock-a">
        <path
          d="M35.5 10 C40 13.5 42.5 19 43 25 C44 33.5 45.5 42.5 44.8 51.5 C44.2 59.5 46 67 44.7 74.5"
          stroke="#6B4E36"
          strokeWidth="2.6"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      <g className="hk-ob-lock-b">
        <path
          d="M32 9 C36.5 12.5 39 18 39.5 24 C40.5 32 42 40.5 41.3 49 C40.7 56.5 42.5 64 41.2 71"
          stroke="#362516"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      <g className="hk-ob-lock-c">
        <path
          d="M33.8 10.5 C38.2 14 40.7 19.5 41.2 25.5 C42 33.5 42.7 42 42 50.5"
          stroke="#7D5E42"
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
          opacity="0.9"
        />
      </g>
      {/* برقِ مو (روتوی روشن روی پنل) */}
      <path
        className="hk-ob-hair"
        d="M35 13 C36.8 17 37.6 22 37.6 27.5 C37.7 35 37.2 43 36.4 50"
        stroke="#7D5E42"
        strokeWidth="1.4"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      {/* تار موی جلو — ریخته روی سینه (نشانهٔ موی باز) */}
      <path
        className="hk-ob-hair-f"
        d="M19.5 12.5
           C17.8 19 17.3 27 18.6 34
           C19.2 37.5 19 41 18.2 44
           L20.8 44.5
           C21.8 39.5 22 34 21.4 28.5
           C21 24 21 19 21.5 14.5 Z"
        fill="#4A3323"
      />
      {/* تارهای رهاشده در نسیم */}
      <g className="hk-ob-loose-a">
        <path d="M46 18 C49 17 51 18.5 52.5 21.5" stroke="#6B4E36" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      </g>
      <g className="hk-ob-loose-b">
        <path d="M45 42 C48.5 40.5 50.5 42 52 45" stroke="#6B4E36" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      </g>
      {/* سر — نیم‌رخ به چپ، کمی متمایل به دوستش، با خط دور واضح */}
      <ellipse cx="26" cy="15" rx="8.4" ry="9" fill="#E8BF95" stroke="#D6A276" strokeWidth="0.6" />
      {/* کلاه‌مو */}
      <path
        d="M17.7 14 C17.7 7.5 21.8 3.9 26.2 3.9 C30.7 3.9 34.4 7.5 34.5 14 C34.5 15.1 34.4 16.1 34.1 17.1 L18.1 17.1 C17.8 16.1 17.7 15.1 17.7 14 Z"
        fill="#4A3323"
        stroke="#362516"
        strokeWidth="0.5"
      />
      {/* چتری جلو — دو تار جدا برای خط موی طبیعی‌تر */}
      <path d="M19.2 9 C18.1 12.5 18 16.5 19 20 L21.4 18.6 C20.6 15.5 20.6 12 21.4 9.4 Z" fill="#4A3323" />
      <path d="M29.4 5.4 C32 6.8 33.5 9.8 33.7 13.8 L31.5 14.4 C31.5 11.2 30.7 8.7 29.1 6.8 Z" fill="#4A3323" />
      {/* ── صورت واضح‌تر (⭐ v3.9.6): ابرو + چشمِ مژه‌دار + لپِ گلی + لبخند ── */}
      <path d="M19.1 11.4 C20.3 10.6 21.9 10.5 23.1 11.1" stroke="#42301E" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      <path d="M20 13.5 C21.3 14.6 23 14.6 24.1 13.6" stroke="#4A3524" strokeWidth="1.05" fill="none" strokeLinecap="round" />
      <path d="M19.6 13.2 L18.7 12.5 M24.4 13.4 L25.3 12.8" stroke="#4A3524" strokeWidth="0.75" fill="none" strokeLinecap="round" />
      <path d="M17.7 16.4 C17.4 17 17.5 17.5 18 17.8" stroke="#D6A276" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      <ellipse cx="22.1" cy="17.6" rx="2.1" ry="1.2" fill="#E89A8A" opacity="0.35" />
      <path d="M19.8 19.5 C21 20.7 22.8 20.6 23.9 19.6" stroke="#C0674F" strokeWidth="0.95" fill="none" strokeLinecap="round" />
      <path d="M20.4 20.2 C21.1 20.7 22.1 20.7 22.7 20.3" stroke="#B55D47" strokeWidth="0.7" fill="none" strokeLinecap="round" />
      {/* پیراهن آجری — بالاتنه + یقه */}
      <path
        d="M21 22
           C25 20 30 20 33 22
           C36 26 37 32 37 38
           C37 44 36.5 50 35.5 55
           C35.2 58 34 60 31.5 60
           L25 60
           C22.5 60 21.1 58 20.9 55
           C20.6 48 20.2 40 20.4 33
           C20.5 29 20.5 25.5 21 22 Z"
        fill="#9C5B54"
        stroke="#824A44"
        strokeWidth="0.6"
      />
      <path d="M24 21.8 C26 23 29 23 31 21.8" stroke="#B9766C" strokeWidth="0.9" fill="none" strokeLinecap="round" />
      {/* بازوها جمع شده و دست‌ها روی پا */}
      <path d="M22.5 26 C18 30 15 35 14 41 L17.5 43 C19.3 38 22 33.5 25.5 30.5 Z" fill="#9C5B54" stroke="#824A44" strokeWidth="0.5" />
      <path d="M32 26 C29.5 31 27.5 37 27 42.5 L30.5 43.5 C31.5 38.5 33.5 34 36 30.5 Z" fill="#8A4E48" stroke="#824A44" strokeWidth="0.5" />
      <circle cx="15.6" cy="42.5" r="2.5" fill="#E8BF95" stroke="#D6A276" strokeWidth="0.5" />
      <circle cx="28.8" cy="43.5" r="2.5" fill="#E8BF95" stroke="#D6A276" strokeWidth="0.5" />
      {/* ران‌ها روی نشیمن + دامن */}
      <path
        d="M23 54.5
           C17 57 12 59 9.5 62
           C8 64 8.5 66.5 11 67
           L30.5 67
           C32.5 64.5 33 61 31.5 57.5 Z"
        fill="#824A44"
        stroke="#6E3E39"
        strokeWidth="0.5"
      />
      {/* ساق‌های آویزان + کفش‌ها */}
      <path d="M12.5 65 C11.9 72.5 11.5 82 11.7 91.5" stroke="#3A3440" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d="M18.5 65.5 C18.2 73 18 83 18.2 92.5" stroke="#312B38" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d="M9.1 90 C7.5 93 8.9 95.5 12.3 95.8 L14.3 95.8 L14.3 90.5 Z" fill="#4A2E24" />
      <path d="M15.7 91 C14.3 93.8 15.8 96.2 19.1 96.4 L21 96.4 L21 91.5 Z" fill="#3E2620" />
      {/* چین دامن */}
      <path d="M17.5 58 C18.5 60.5 19 63 18.5 65.5 M23.5 57 C24.5 60 25 62.5 24.5 65.5" stroke="rgba(70,25,25,0.4)" strokeWidth="1" fill="none" />
    </svg>
  );
}

/** خودروی کلاسیک ایرانی (پیکان‌مانند) — تناسبات واقعی: کاپوت بلند، شیشه‌های
 *  مجزای عقب/جلو با ستون B، رکِ صاف، سپرهای کروم، چراغ‌های گرد؛ رین‌های چرخان
 *  (viewBox عریض‌تر از بدنه تا مخروط نور تا لبهٔ راست ادامه یابد) */
function ClassicCar({ width = 285 }: { width?: number }) {
  return (
    <svg viewBox="0 0 300 104" style={{ width }} className="shrink-0" aria-hidden focusable="false">
      <defs>
        <linearGradient id="hk-car-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F4EEDE" />
          <stop offset="0.55" stopColor="#E9E1CD" />
          <stop offset="1" stopColor="#C8BFA8" />
        </linearGradient>
        <linearGradient id="hk-car-glass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#54677D" />
          <stop offset="1" stopColor="#38485C" />
        </linearGradient>
        <radialGradient id="hk-car-head" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#FFF6D8" />
          <stop offset="0.35" stopColor="#FFE9A8" />
          <stop offset="1" stopColor="rgba(255,214,120,0)" />
        </radialGradient>
        <linearGradient id="hk-car-beam" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="rgba(255,232,150,0.55)" />
          <stop offset="1" stopColor="rgba(255,232,150,0)" />
        </linearGradient>
        <radialGradient id="hk-car-tail" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#FF7A66" />
          <stop offset="1" stopColor="rgba(226,72,63,0)" />
        </radialGradient>
      </defs>

      {/* نور جلو — مخروط روی آسفالت (در جهت حرکت) */}
      <g className="hk-ob-beam">
        <path d="M252 42 L300 26 L300 68 L252 58 Z" fill="url(#hk-car-beam)" />
        <path d="M252 47 L300 41 L300 49 L252 53 Z" fill="url(#hk-car-beam)" opacity="0.8" />
      </g>

      {/* بازتاب نرم روی آسفالت */}
      <ellipse cx="140" cy="98" rx="112" ry="4.5" fill="rgba(240,230,205,0.10)" />

      {/* بدنهٔ سدان کلاسیک — سقف صاف، شیشه‌های رک، کاپوت بلند */}
      <path
        d="M20 76
           L18 62
           C18 57 20 53 26 52
           L54 49
           C58 48.5 60.5 47 62.5 44
           L66 44
           C68 26 74 16.5 84 14.5
           L106 13
           C112 12.6 117 14.5 121 20
           L129 34
           C131 36.5 134 38 138 38.4
           L222 42
           C230 42.4 238 45 244 50
           L252 57
           L254 64
           L250 70
           L246 76
           L232 76
           A20 20 0 0 0 192 76
           L82 76
           A20 20 0 0 0 42 76
           Z"
        fill="url(#hk-car-body)"
        stroke="#A79E85"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />

      {/* شیشهٔ عقب (پشت ستون C) و شیشهٔ جلو/شبک حاضر (پشت ستون B) */}
      <path d="M70 41.5 C72 27 76.5 19 84 17.2 L89 17.8 L92 41.5 Z" fill="url(#hk-car-glass)" stroke="#98A5B4" strokeWidth="1.2" />
      <path d="M97 41.5 L100.5 17.6 L111 17 C115.5 17.4 118.6 22 122.5 30 L126.5 41.5 Z" fill="url(#hk-car-glass)" stroke="#98A5B4" strokeWidth="1.2" />
      {/* بازتاب مورب شیشه‌ها */}
      <path d="M77 20 L72.5 39 M106 18.5 L99.5 40.5" stroke="rgba(255,255,255,0.28)" strokeWidth="2.2" strokeLinecap="round" />

      {/* خط کرومِ کمربندی */}
      <path d="M26 53.5 C90 47.5 160 46.5 226 49.5" stroke="#D7DEE7" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M28 56 C92 50.5 158 49.5 222 52.5" stroke="#B9B2A0" strokeWidth="1" fill="none" strokeLinecap="round" />

      {/* درز درها + دستگیره + آینه */}
      <path d="M138 38.6 C137.6 46 137.8 58 138.5 70" stroke="#C4BBA3" strokeWidth="1.2" fill="none" />
      <path d="M96 41.8 C95.6 48 95.8 60 96.4 70" stroke="#C4BBA3" strokeWidth="1" fill="none" opacity="0.8" />
      <rect x="146" y="47" width="8" height="2.6" rx="1.3" fill="#8D846F" />
      <path d="M131 36 L125 32.5 L123 35.5 L128 38 Z" fill="#D7DEE7" stroke="#8D846F" strokeWidth="0.8" />

      {/* جلوپنجرهٔ کروم + چراغ گرد جلو (روشن) */}
      <path d="M244 50 C247 52 250 55 252 58 L252 63 L246 63 C244.5 60 244 55 244 50 Z" fill="#D7DEE7" stroke="#8D846F" strokeWidth="0.8" />
      <path d="M245.5 55 L250.5 55 M245 58 L251 58" stroke="#77808C" strokeWidth="1" />
      <circle cx="239" cy="51" r="10" fill="url(#hk-car-head)" />
      <circle cx="239" cy="51" r="4.8" fill="#FFF3C4" stroke="#D9B96A" strokeWidth="1" />

      {/* چراغ عقب (قرمز روشن) */}
      <circle cx="20" cy="57" r="7.5" fill="url(#hk-car-tail)" />
      <rect x="17.5" y="54" width="5.5" height="5.5" rx="1.2" fill="#E2483F" />

      {/* سپرهای کروم جلو و عقب */}
      <path d="M8 62 C5 62 3.5 64 4 66.5 C4.5 68.5 6.5 69.5 9 69.5 L22 69.5 L22 62 Z" fill="#D7DEE7" stroke="#8D846F" strokeWidth="0.9" />
      <path d="M250 60 L262 60 C265 60 266.5 62 266 64.5 C265.5 66.5 263.5 67.5 261 67.5 L250 67.5 Z" fill="#D7DEE7" stroke="#8D846F" strokeWidth="0.9" />

      {/* چرخ‌ها — تایر سفیدلبه (whitewall) + رین‌های چرخان */}
      <g>
        <circle cx="62" cy="78" r="16.5" fill="#20242B" stroke="#141920" strokeWidth="2" />
        <circle cx="62" cy="78" r="11.8" fill="none" stroke="#E8E4D6" strokeWidth="2.6" />
        <g className="hk-ob-wheel">
          <circle cx="62" cy="78" r="7.6" fill="#C9CFD8" />
          <path d="M62 71.5 L62 84.5 M55.5 78 L68.5 78 M57.6 73.6 L66.4 82.4 M57.6 82.4 L66.4 73.6" stroke="#6E7783" strokeWidth="1.6" />
          <circle cx="62" cy="78" r="2.7" fill="#8D95A1" />
        </g>
      </g>
      <g>
        <circle cx="212" cy="78" r="16.5" fill="#20242B" stroke="#141920" strokeWidth="2" />
        <circle cx="212" cy="78" r="11.8" fill="none" stroke="#E8E4D6" strokeWidth="2.6" />
        <g className="hk-ob-wheel">
          <circle cx="212" cy="78" r="7.6" fill="#C9CFD8" />
          <path d="M212 71.5 L212 84.5 M205.5 78 L218.5 78 M207.6 73.6 L216.4 82.4 M207.6 82.4 L216.4 73.6" stroke="#6E7783" strokeWidth="1.6" />
          <circle cx="212" cy="78" r="2.7" fill="#8D95A1" />
        </g>
      </g>
    </svg>
  );
}

/** یک کپی از مناظر (عرض دقیق ۶۴۰px — ۳ کپی = حلقهٔ بی‌نهایت بی‌پرش)
 *  چیدمان افقی: سرو کوچک ۸ | چراغ ۶۶ | گرافیتی اسپری ۸۴-۳۰۰ | تبلیغ اسپری ۳۰۶-۳۹۸
 *  (⭐ v3.9.6 — معرفی برنامه هم اسپری شد، هم‌زبان با شعار) | گروه نیمکت ۳۹۶-۵۱۴
 *  (دو دختر کنار هم روی نیمکت با موهای باز + گربه روی زمین کنار نیمکت) */
function SceneryCopy() {
  return (
    <div dir="ltr" className="relative h-full w-[640px] shrink-0" aria-hidden>
      {/* آسمان‌سازهٔ دور — باند ۲۰px دقیقاً بالای دیوار */}
      <div className="absolute inset-x-0 bottom-[88px] h-[20px] overflow-hidden">
        <svg viewBox="0 0 640 20" width={640} height={20} className="absolute bottom-0 left-0" preserveAspectRatio="none">
          <g fill="#2E3A4A">
            <rect x="10" y="6" width="70" height="14" rx="1.5" />
            <rect x="26" y="0" width="10" height="8" />
            <rect x="90" y="9" width="86" height="11" rx="1.5" />
            <rect x="130" y="2" width="8" height="9" />
            <path d="M196 20 L196 5 L206 0 L216 5 L216 20 Z" />
            <rect x="228" y="4" width="60" height="16" rx="1.5" />
            <circle cx="258" cy="1" r="3.5" />
            <rect x="300" y="7" width="96" height="13" rx="1.5" />
            <rect x="322" y="1" width="9" height="8" />
            <path d="M358 0 L358 7 M358 0 L363 4 M358 0 L353 4" stroke="#2E3A4A" strokeWidth="1.6" />
            <rect x="410" y="3" width="64" height="17" rx="1.5" />
            <rect x="432" y="0" width="8" height="6" />
            <rect x="486" y="6" width="66" height="14" rx="1.5" />
            <circle cx="512" cy="2" r="3" />
            <rect x="556" y="5" width="70" height="15" rx="1.5" />
            <rect x="575" y="0" width="9" height="7" />
            <path d="M636 20 L636 8 M636 8 L632 4 M636 8 L640 4" stroke="#2E3A4A" strokeWidth="1.4" />
          </g>
        </svg>
      </div>

      {/* دیوار آجری (ارتفاع ۸۸px) + شعار اسپری‌شدهٔ دیواری «زن زندگی آزادی» */}
      <div className="hk-ob-wall absolute inset-x-0 bottom-0 h-[88px]" />
      <WallGraffiti />

      {/* ⭐ v3.9.6 — تبلیغ اسپری‌شدهٔ برنامه روی دیوار — بلافاصله کنار شعار
          (شعار ۸۴-۳۰۰ + تبلیغ اسپری ۳۰۶-۳۹۸ = با هم در یک قاب دیده می‌شوند) */}
      <WallGraffitiAd />

      {/* چراغ خیابانی — روی لبهٔ پیاده‌رو */}
      <div className="absolute bottom-0 left-[66px]"><StreetLamp h={88} /></div>

      {/* درخت سرو — ستونی، ایستاده روی پیاده‌رو */}
      <div className="absolute bottom-0 left-[8px]"><CedarTree height={118} /></div>

      {/* نیمکت پارک + دو دختر کنار هم با موهای باز + گربهٔ نشسته روی زمین
          ترتیب عمق: سرو پشتی → نیمکت → دخترها → گربه روی زمین
          (⭐ v3.9.5: گروه به ۳۹۶ شیفت شد تا تبلیغ کنار شعار آزاد بماند) */}
      <div className="absolute bottom-0 left-[396px]">
        <div className="absolute bottom-0 left-[104px]"><CedarTree height={132} /></div>
        <div className="absolute bottom-0 left-[6px]"><ParkBench width={150} /></div>
        <div className="absolute bottom-0 left-[8px]"><BenchGirlReader height={104} /></div>
        <div className="absolute bottom-0 left-[52px]"><BenchGirlFriend height={100} /></div>
        <div className="absolute bottom-0 left-[158px]"><StreetCat width={60} /></div>
      </div>
    </div>
  );
}

/** صحنهٔ کامل اسلاید ۱ — جادهٔ واقعی در گرگ‌ومیش */
function WelcomeArt() {
  return (
    <div
      dir="ltr"
      className="relative mx-auto mt-1 w-full max-w-[352px] overflow-hidden rounded-[26px] border border-border/70 shadow-xl"
      style={{ aspectRatio: "352/300", background: "linear-gradient(180deg, #33455E 0%, #46586F 46%, #6E6A6A 74%, #93705A 100%)" }}
      aria-hidden
    >
      {/* خورشیدِ گرگ‌ومیش + هاله — کمی پشت خط افق (بالای دیوار) */}
      <div
        className="absolute left-[56%] top-[46px] size-[64px] -translate-x-1/2 rounded-full"
        style={{ background: "radial-gradient(circle, rgba(255,224,160,0.9) 0%, rgba(255,196,120,0.38) 45%, rgba(255,190,110,0) 70%)" }}
      />
      {/* ستاره‌ها */}
      {[
        { l: 30, t: 22, s: 2.5, d: "0s" },
        { l: 122, t: 12, s: 2, d: "1.1s" },
        { l: 214, t: 30, s: 2.5, d: "2.2s" },
        { l: 296, t: 16, s: 2, d: "0.6s" },
      ].map((st, i) => (
        <span
          key={i}
          className="hk-ob-star absolute rounded-full bg-[#EAEFF5]"
          style={{ left: st.l, top: st.t, width: st.s, height: st.s, animationDelay: st.d }}
        />
      ))}

      {/* مناظر متحرک — دیوار، درخت‌ها، نیمکت، دخترها، گربه
          (درگاه از y44 تا y210 — کف همهٔ اجزا روی پیاده‌رو) */}
      <div className="absolute inset-x-0 bottom-[90px] top-[44px] overflow-hidden">
        <div className="hk-ob-scenery-track flex h-full w-max">
          <SceneryCopy />
          <SceneryCopy />
          <SceneryCopy />
        </div>
      </div>

      {/* پیاده‌رو (y210-224) */}
      <div className="absolute inset-x-0 bottom-[76px] h-[14px] bg-[#4B545F]">
        <div className="absolute inset-x-0 top-0 h-[2px] bg-[#5C6672]" />
        <div className="hk-ob-kerb absolute inset-x-0 bottom-0 h-[3px] bg-[#3E4650]" />
      </div>

      {/* جادهٔ آسفالت (y224-300) + خط‌چین متحرک */}
      <div className="absolute inset-x-0 bottom-0 h-[76px] bg-[#2A313B]">
        <div className="absolute inset-x-0 top-0 h-[2.5px] bg-[#39424E]" />
        <div className="absolute inset-x-0 bottom-[6px] h-[3px] bg-[#232932]" />
      {/* خط‌چین وسط جاده — حرکت پیوسته (دورهٔ ۶۴px؛ عرض صریح تا دیده شود) */}
        <div className="absolute inset-x-0 top-[28px] h-[5px] overflow-hidden">
          <div className="hk-ob-road-line h-full" style={{ width: "calc(100% + 64px)", background: "repeating-linear-gradient(90deg, rgba(245,165,36,0.95) 0 32px, rgba(38,45,55,0) 32px 64px)" }} />
        </div>
      </div>

      {/* خودروی کلاسیک — پایین، روی جاده، چراغ‌ها روشن */}
      <div className="hk-ob-car absolute bottom-[8px] left-1/2 z-20 -translate-x-[38%]">
        <ClassicCar width={285} />
      </div>
    </div>
  );
}

/** نمایش متحرک سوایپ — سه صفحهٔ کوچک که به چپ/راست می‌لغزند */
function SwipeHintArt() {
  return (
    <div dir="ltr" className="relative mx-auto mt-2 flex h-20 w-52 items-center" aria-hidden>
      <div className="hk-onboard-side absolute right-0 top-1/2 flex h-14 w-20 -translate-y-1/2 flex-col gap-1 rounded-xl border border-primary/30 bg-muted p-2">
        <span className="h-1.5 w-8 rounded bg-primary/25" />
        <span className="h-1.5 w-12 rounded bg-muted-foreground/20" />
        <span className="h-1.5 w-10 rounded bg-muted-foreground/15" />
      </div>
      <div className="hk-onboard-main absolute top-1/2 flex h-16 w-24 -translate-y-1/2 flex-col gap-1.5 rounded-2xl border border-primary/45 bg-card p-2.5 shadow-lg">
        <span className="h-2 w-10 rounded bg-primary/30" />
        <span className="h-1.5 w-16 rounded bg-muted-foreground/20" />
        <span className="h-1.5 w-14 rounded bg-muted-foreground/15" />
        <span className="h-1.5 w-16 rounded bg-muted-foreground/10" />
      </div>
      <div className="hk-onboard-side-l absolute left-0 top-1/2 flex h-14 w-20 -translate-y-1/2 flex-col gap-1 rounded-xl border border-primary/30 bg-muted p-2">
        <span className="h-1.5 w-8 rounded bg-primary/25" />
        <span className="h-1.5 w-12 rounded bg-muted-foreground/20" />
        <span className="h-1.5 w-10 rounded bg-muted-foreground/15" />
      </div>
      <div className="hk-onboard-finger absolute top-1/2 size-7 -translate-y-1/2 rounded-full border-[3px] border-primary/70 bg-primary/15" />
    </div>
  );
}

/* ═══════════════════════════ اسلایدها ═══════════════════════════ */

interface Slide {
  icon: React.ElementType;
  title: string;
  body: React.ReactNode;
  cta?: { label: string; action: "add-vehicle" };
}

const SLIDES: Slide[] = [
  {
    icon: Car,
    title: "به همراه خودرو خوش آمدید",
    body: (
      <>
        سوابق سرویس، سوخت، کیلومتر و یادآورها را ثبت کنید — همه‌چیز آفلاین روی همین گوشی
        ذخیره می‌شود.
      </>
    ),
  },
  {
    icon: MoveHorizontal,
    title: "جابه‌جایی بین صفحه‌ها با سوایپ",
    body: (
      <>
        انگشت خود را به چپ یا راست بکشید — صفحه همراه انگشتتان حرکت می‌کند و صفحهٔ کناری
        جای آن می‌آید. پایین صفحه هم دکمه‌های گزارشات، سوابق، یادآورها و تنظیمات هست.
      </>
    ),
  },
  {
    icon: CloudUpload,
    title: "اطلاعات همیشه در امان",
    body: (
      <>
        از «تنظیمات ← پشتیبان‌گیری و بازیابی» با همان حساب گوگل، روی سرور ابری رایگان
        ذخیره کنید تا با تعویض گوشی یا حذفِ ناخواسته، همه‌چیز قابل بازگشت باشد.
      </>
    ),
  },
  {
    icon: Car,
    title: "نخستین خودرو را اضافه کنید",
    body: <>با ثبت خودرو، دفترچهٔ سرویس آن باز می‌شود — بدون خودرو هم می‌توانید آزادانه تور بزنید.</>,
    cta: { label: "افزودن نخستین خودرو", action: "add-vehicle" },
  },
];

export function OnboardingOverlay({
  open,
  onClose,
  onAddVehicle,
}: {
  open: boolean;
  onClose: () => void;
  onAddVehicle: () => void;
}) {
  const [step, setStep] = React.useState(0);
  const [mounted, setMounted] = React.useState(false);
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setStep(0);
      setMounted(true);
      requestAnimationFrame(() => setVisible(true));
      return;
    }
    setVisible(false);
    const t = window.setTimeout(() => setMounted(false), 220);
    return () => window.clearTimeout(t);
  }, [open]);

  if (!mounted) return null;

  const slide = SLIDES[Math.min(step, SLIDES.length - 1)];
  const Icon = slide.icon;
  const isLast = step === SLIDES.length - 1;

  const finish = (addAction?: boolean) => {
    markOnboarded();
    onClose();
    if (addAction) onAddVehicle();
  };

  return (
    <div
      dir="rtl"
      role="dialog"
      aria-modal="true"
      aria-label="آموزش اولیهٔ برنامه"
      className={cn(
        "fixed inset-0 z-[110] flex flex-col bg-background/97 backdrop-blur-none transition-opacity duration-200",
        visible ? "opacity-100" : "opacity-0"
      )}
    >
      <div className="mx-auto flex h-dvh w-full max-w-md flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(1.25rem,env(safe-area-inset-top))]">
        {/* رد کردن — گوشهٔ بالا (سمت چپ در RTL) */}
        <div className="flex shrink-0 justify-end">
          <button
            type="button"
            onClick={() => finish()}
            className="flex h-9 items-center gap-1 rounded-full bg-muted px-4 text-[13px] font-bold text-muted-foreground transition-all active:scale-95"
          >
            رد کردن
            <ChevronLeft className="size-4" />
          </button>
        </div>

        {/* محتوای اسلاید */}
        <div className="flex min-h-0 flex-1 flex-col items-center justify-center text-center">
          {step === 0 ? (
            <WelcomeArt />
          ) : (
            <span className="flex size-24 items-center justify-center rounded-full bg-primary/10">
              <span className="flex size-16 items-center justify-center rounded-full bg-primary/15">
                {step === 2 ? <KeyRound className="size-9 text-primary" strokeWidth={1.9} /> : <Icon className="size-9 text-primary" strokeWidth={1.9} />}
              </span>
            </span>
          )}

          <h2 className="mt-6 text-[21px] font-extrabold leading-8 text-foreground">{slide.title}</h2>
          <p className="mt-3 max-w-[300px] text-[14px] leading-8 text-muted-foreground">{slide.body}</p>

          {step === 1 && <SwipeHintArt />}

          {slide.cta && (
            <button
              type="button"
              onClick={() => finish(true)}
              className="mt-6 flex h-12 w-full max-w-xs items-center justify-center gap-2 rounded-xl bg-primary text-[15.5px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-transform active:scale-[.97]"
            >
              <Car className="size-5" strokeWidth={2.2} />
              {slide.cta.label}
            </button>
          )}
        </div>

        {/* نقطه‌ها + دکمهٔ بعدی/شروع */}
        <div className="flex shrink-0 flex-col items-center gap-4">
          <div className="flex items-center gap-2">
            {SLIDES.map((_, i) => (
              <span
                key={i}
                className={cn(
                  "h-2 rounded-full transition-all",
                  i === step ? "w-6 bg-primary" : "w-2 bg-muted-foreground/25"
                )}
              />
            ))}
          </div>

          <div className="flex w-full max-w-xs flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                if (isLast) finish();
                else setStep(step + 1);
              }}
              className="flex h-12 w-full items-center justify-center rounded-xl bg-primary text-[15.5px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-transform active:scale-[.97]"
            >
              {isLast ? "شروع استفاده" : "بعدی"}
            </button>
            {!isLast && step > 0 && (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="flex h-10 w-full items-center justify-center rounded-xl bg-muted text-[13.5px] font-bold text-muted-foreground transition-all active:scale-[.98]"
              >
                قبلی
              </button>
            )}
          </div>
          <p className="pb-1 text-[11px] text-muted-foreground">اسلاید {fa(step + 1)} از {fa(SLIDES.length)}</p>
        </div>
      </div>
    </div>
  );
}
