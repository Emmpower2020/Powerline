"use client";

/**
 * محافظ خروج — دکمهٔ برگشت (اندروید) یک‌بار برنامه را نمی‌بندد:
 *  • اگر پنجره/شیت بازی است → برگشت همان را می‌بندد
 *  • بار اول → پیام «برای خروج دوبار بزنید»
 *  • بار دوم (در کمتر از ۲.۵ ثانیه) → خروج از برنامه
 * در APK اندروید متد native exitApp صدا زده می‌شود؛ در وب window.close.
 */

import * as React from "react";
import { useToast } from "@/hooks/use-toast";

/** خروج واقعی از برنامه — پل اندروید یا بستن پنجره */
export function exitApp() {
  const w = window as unknown as {
    AndroidApi?: { exitApp?: () => void };
    AndroidBridge?: { exitApp?: () => void };
    close?: () => void;
  };
  try {
    if (typeof w.AndroidApi?.exitApp === "function") {
      w.AndroidApi.exitApp();
      return;
    }
    if (typeof w.AndroidBridge?.exitApp === "function") {
      w.AndroidBridge.exitApp();
      return;
    }
    w.close?.();
  } catch {
    /* ignore */
  }
}

/** شیت/پنجرهٔ مودال بازی هست؟ */
function hasOpenDialog(): boolean {
  return Boolean(document.querySelector('[role="dialog"][aria-modal="true"]'));
}

export function ExitGuard() {
  const { toast } = useToast();
  const lastBackRef = React.useRef(0);

  React.useEffect(() => {
    // یک ورودی تاریخچه نگه می‌داریم تا «برگشت» اول مصرف شود
    if (!window.history.state?.hkGuard) {
      window.history.pushState({ hkGuard: true }, "", window.location.href);
    }

    const rePush = () => {
      try {
        window.history.pushState({ hkGuard: true }, "", window.location.href);
      } catch {
        /* ignore */
      }
    };

    const onPop = () => {
      // ۱) پنجرهٔ بازی → بستن آن به‌جای خروج
      if (hasOpenDialog()) {
        window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" }));
        rePush();
        return;
      }
      // ۲) برگشت دوم در فاصلهٔ کوتاه → خروج
      const now = Date.now();
      if (now - lastBackRef.current < 2500) {
        exitApp();
        return;
      }
      // ۳) برگشت اول → هشدار
      lastBackRef.current = now;
      toast({
        title: "خروج از برنامه",
        description: "برای خروج، دوباره دکمهٔ برگشت را بزنید",
      });
      rePush();
    };

    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
    };
  }, [toast]);

  return null;
}
