"use client";

/**
 * دیالوگ تأیید درون‌برنامه‌ای — جایگزین window.confirm
 * در WebView اندروید confirm() بومی کار نمی‌کند؛ این دیالوگ همیشه مطمئن است.
 *
 * پیاده‌سازی با پورتال ساده (بدون Radix):
 *  - z-[120] — بالاتر از همهٔ لایه‌ها (تنظیمات z-70، شیت‌ها z-80، توست z-100)
 *    تا دیالوگ هرگز پشت شیت/پنجره گم نشود (باگ «هنگ کردن» هنگام حذف).
 *  - بدون قفل pointer-events روی body — حتی اگر چیزی روی آن بیفتد،
 *    برنامه منجمد نمی‌شود؛ بک‌دراپ خودش کلیک‌های بیرون را می‌گیرد.
 * استفاده: const ok = await confirmDialog({ message: "..." });
 */

import * as React from "react";
import { createPortal } from "react-dom";
import { TriangleAlert } from "lucide-react";
import { cn } from "@/lib/utils";

export type ConfirmOptions = {
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
};

type Slot = { options: ConfirmOptions; resolve: (v: boolean) => void };

let push: ((o: ConfirmOptions) => Promise<boolean>) | null = null;

/** تأیید درون‌برنامه‌ای — اگر Provider نصب نبود، confirm بومی (وب) */
export function confirmDialog(options: ConfirmOptions): Promise<boolean> {
  if (push) return push(options);
  if (typeof window !== "undefined" && typeof window.confirm === "function") {
    return Promise.resolve(window.confirm(options.message));
  }
  return Promise.resolve(false);
}

export function ConfirmDialogProvider() {
  const [current, setCurrent] = React.useState<Slot | null>(null);
  const queue = React.useRef<Slot[]>([]);

  const drain = React.useCallback(() => {
    setCurrent((cur) => {
      if (cur) return cur;
      const next = queue.current.shift();
      return next ?? null;
    });
  }, []);

  React.useEffect(() => {
    push = (options: ConfirmOptions) =>
      new Promise<boolean>((resolve) => {
        queue.current.push({ options, resolve });
        drain();
      });
    return () => {
      push = null;
    };
  }, [drain]);

  const settle = React.useCallback((v: boolean) => {
    setCurrent((cur) => {
      if (cur) {
        cur.resolve(v);
        const next = queue.current.shift();
        return next ?? null;
      }
      return null;
    });
  }, []);

  const o = current?.options;

  // Esc = انصراف
  React.useEffect(() => {
    if (!current) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") settle(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current, settle]);

  // قفل اسکرول حین باز بودن
  React.useEffect(() => {
    if (!current) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [current]);

  if (!o || typeof document === "undefined") return null;

  return createPortal(
    <div
      dir="rtl"
      className="fixed inset-0 z-[120] flex items-center justify-center p-6"
      role="alertdialog"
      aria-modal="true"
      aria-label={o.title ?? (o.destructive ? "حذف" : "تأیید")}
    >
      {/* بک‌دراپ — کلیک = انصراف */}
      <div className="absolute inset-0 bg-black/55" onClick={() => settle(false)} />

      {/* پنل دیالوگ */}
      <div className="relative w-full max-w-sm rounded-2xl border border-border bg-background p-5 text-right shadow-2xl">
        <div className="flex items-start gap-3">
          <span
            className={cn(
              "flex size-11 shrink-0 items-center justify-center rounded-xl",
              o.destructive || o.title?.includes("حذف")
                ? "bg-red-500/10 text-red-600 dark:text-red-400"
                : "bg-primary/10 text-primary"
            )}
          >
            <TriangleAlert className="size-5.5" strokeWidth={2.1} />
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="text-[17px] font-extrabold leading-7 text-foreground">
              {o.title ?? (o.destructive ? "حذف" : "تأیید")}
            </h2>
            <p className="mt-1.5 text-[14px] leading-7 text-muted-foreground">
              {o.message}
            </p>
          </div>
        </div>

        <div className="mt-5 flex gap-2">
          <button
            type="button"
            autoFocus
            onClick={() => settle(true)}
            className={cn(
              "flex h-12 flex-1 items-center justify-center rounded-xl text-[15px] font-bold transition-all active:scale-95",
              o.destructive || o.title?.includes("حذف")
                ? "bg-red-600 text-white shadow-lg shadow-red-600/25"
                : "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
            )}
          >
            {o.confirmLabel ?? (o.destructive ? "بله، حذف شود" : "تأیید")}
          </button>
          <button
            type="button"
            onClick={() => settle(false)}
            className="flex h-12 flex-1 items-center justify-center rounded-xl border border-input bg-card text-[15px] font-bold text-foreground transition-all active:scale-95"
          >
            {o.cancelLabel ?? "انصراف"}
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
