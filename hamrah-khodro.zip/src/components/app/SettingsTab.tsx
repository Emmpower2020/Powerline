"use client";

/**
 * تب تنظیمات — منوی مرتب با زیرمنوها:
 * ۱. خودروهای من  ۲. مدیریت برند و مدل  ۳. انواع سرویس  ۴. تم  ۵. پشتیبان‌گیری و بازیابی
 * ۶. تنظیمات نوتیفیکیشن  ۷. خروج
 * هر زیرمنو در پنجرهٔ تمام‌صفحهٔ جدید (بدون نوار پایین) باز می‌شود.
 * ⭐ v3.9.0: همهٔ منوهای پشتیبان (حساب ابری/پشتیبان‌گیری/بازیابی) در یک زیرمنوی
 *  «پشتیبان‌گیری و بازیابی» ادغام شدند (درخواست کاربر) — داخل آن سه تب: سرور ابری
 *  (Firebase — هر ایمیلی)، Google Drive و فایل پشتیبان.
 */

import * as React from "react";
import {
  BellRing,
  Building2,
  Car,
  DatabaseBackup,
  Info,
  Loader2,
  LogOut,
  Palette,
  Wrench,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";
import {
  APP_NAME,
  APP_VERSION,
  type BrandItem,
  type RecordItem,
  type ReminderItem,
  type ServiceTypeItem,
  type VehicleItem,
} from "@/lib/types";
import { getStoredTheme, getThemeDef } from "@/lib/theme";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import { exitApp } from "./ExitGuard";
import { BottomSheet } from "./BottomSheet";
import { PageHeader } from "./shared";
import { SubmitButton } from "./fields";
import { VehiclesWindow } from "./settings/VehiclesWindow";
import { BrandsWindow } from "./settings/BrandsWindow";
import { ServiceTypesWindow } from "./settings/ServiceTypesWindow";
import { ThemeWindow } from "./settings/ThemeWindow";
import { BackupWindow } from "./settings/BackupWindow";
import { NotificationsWindow } from "./settings/NotificationsWindow";

export type SettingsWindowKey = null | "vehicles" | "brands" | "types" | "theme" | "backup" | "notifications";

interface SettingsTabProps {
  vehicles: VehicleItem[];
  records: RecordItem[];
  reminders: ReminderItem[];
  currentKmByVehicle: Map<string, number>;
  brands: BrandItem[];
  serviceTypes: ServiceTypeItem[];
  activeVehicleId: string | null;
  onSetActive: (id: string) => void;
  onAddVehicle: () => void;
  onEditVehicle: (v: VehicleItem) => void;
  onDeleteVehicle: () => void;
  onRefresh: () => void;
  /** باز شدن خودکار یک پنجره (مثلاً از لینک «خودرویی ثبت نشده») */
  autoOpen?: SettingsWindowKey;
  onClearAutoOpen?: () => void;
}

/** ردیف منوی استاندارد تنظیمات */
function MenuRow({
  icon: Icon,
  title,
  desc,
  onClick,
  highlight,
  busy,
  trailing,
}: {
  icon: React.ElementType;
  title: string;
  desc: string;
  onClick: () => void;
  highlight?: boolean;
  busy?: boolean;
  trailing?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy}
      className={cn(
        "flex w-full items-center gap-3.5 rounded-2xl border p-4 text-right shadow-sm transition-all active:scale-[.98] disabled:opacity-50",
        highlight
          ? "border-primary/45 bg-primary/8 hover:border-primary/60"
          : "border-border/80 bg-card hover:border-primary/40"
      )}
    >
      <span
        className={cn(
          "flex size-11 shrink-0 items-center justify-center rounded-xl",
          highlight ? "bg-primary/15" : "bg-primary/10"
        )}
      >
        {busy ? (
          <Loader2 className="size-5 animate-spin text-primary" />
        ) : (
          <Icon className="size-5 text-primary" strokeWidth={2} />
        )}
      </span>
      <span className="flex min-w-0 flex-1 flex-col">
        <span className="flex items-center gap-2 text-[15px] font-bold text-foreground">{title}</span>
        <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">{desc}</span>
      </span>
      {trailing}
    </button>
  );
}

export function SettingsTab({
  vehicles,
  records,
  reminders,
  currentKmByVehicle,
  brands,
  serviceTypes,
  activeVehicleId,
  onSetActive,
  onAddVehicle,
  onEditVehicle,
  onDeleteVehicle,
  onRefresh,
  autoOpen,
  onClearAutoOpen,
}: SettingsTabProps) {
  const { toast } = useToast();
  const [win, setWin] = React.useState<SettingsWindowKey>(null);
  const [exitOpen, setExitOpen] = React.useState(false);
  const [theme, setTheme] = React.useState<string>("paper");

  React.useEffect(() => {
    setTheme(getStoredTheme());
  }, []);

  // باز شدن خودکار پنجره (لینک از تب‌های دیگر)
  React.useEffect(() => {
    if (autoOpen) {
      setWin(autoOpen);
      onClearAutoOpen?.();
    }
  }, [autoOpen, onClearAutoOpen]);

  const activeThemeDef = getThemeDef(theme);

  return (
    <div>
      {/* ─── سربرگ مشترک — عنوان + تاریخ امروز ─── */}
      <PageHeader
        title="تنظیمات"
        badge={`${fa(vehicles.length)} خودرو`}
      />

      <div className="px-4 pb-32">
        {/* ─────────── مدیریت ─────────── */}
        <section className="mb-6">
          <div className="flex flex-col gap-2.5">
            <MenuRow
              icon={Car}
              title="خودروهای من"
              desc={`${fa(vehicles.length)} خودرو — افزودن، ویرایش، حذف و انتخاب فعال`}
              onClick={() => setWin("vehicles")}
            />
            <MenuRow
              icon={Building2}
              title="مدیریت برند و مدل"
              desc={`${fa(brands.length)} برند — افزودن برند و مدل دلخواه`}
              onClick={() => setWin("brands")}
            />
            <MenuRow
              icon={Wrench}
              title="انواع سرویس"
              desc={`${fa(serviceTypes.length)} نوع — خدماتی/تعویض قطعه + سرویس‌های مکمل`}
              onClick={() => setWin("types")}
            />
            <MenuRow
              icon={Palette}
              title="تم برنامه"
              desc="۹ تم پیش‌فرض + تم شخصی — ویرایش رنگ، حذف و ساخت"
              onClick={() => setWin("theme")}
              trailing={
                <span className="flex shrink-0 items-center gap-1.5">
                  <span
                    className="size-4 rounded-full ring-1 ring-border"
                    style={{ background: activeThemeDef.preview.primary }}
                  />
                  <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
                    {activeThemeDef.name}
                  </span>
                </span>
              }
            />
          </div>
        </section>

        {/* ─────────── پشتیبان‌گیری و اطلاع‌رسانی ─────────── */}
        <section className="mb-6">
          <div className="flex flex-col gap-2.5">
            {/* ⭐ v3.9.0: همهٔ منوهای پشتیبان در یک زیرمنو (درخواست کاربر) */}
            <MenuRow
              icon={DatabaseBackup}
              title="پشتیبان‌گیری و بازیابی"
              desc={`سرور ابری (هر ایمیلی) • Google Drive • فایل — ${fa(records.length)} رکورد و ${fa(reminders.length)} یادآور`}
              onClick={() => setWin("backup")}
            />
            <MenuRow
              icon={BellRing}
              title="تنظیمات نوتیفیکیشن"
              desc="چند روز یا چند کیلومتر قبل از سررسید اطلاع بدهد"
              onClick={() => setWin("notifications")}
            />
          </div>
        </section>

        {/* ─────────── خروج ─────────── */}
        <section className="mb-6">
          <div className="flex flex-col gap-2.5">
            <MenuRow
              icon={LogOut}
              title="خروج از برنامه"
              desc="بستن کامل همراه خودرو"
              onClick={() => setExitOpen(true)}
            />
          </div>
        </section>

        {/* ─────────── درباره ─────────── */}
        <section>
          <div className="rounded-2xl border border-border/80 bg-card p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10">
                <Car className="size-5 text-primary" strokeWidth={2} />
              </span>
              <div>
                <div className="text-[15px] font-bold text-foreground">{APP_NAME}</div>
                <div className="mt-0.5 text-[12px] text-muted-foreground">
                  مدیریت سرویس، سوخت، یادآور و کارکرد خودرو
                </div>
              </div>
            </div>
            <p className="mt-3 text-[12.5px] leading-6 text-muted-foreground">
              داده‌ها روی حافظهٔ همین دستگاه ذخیره می‌شوند و بدون اینترنت هم در دسترس‌اند. برای
              انتقال به دستگاه دیگر یا اطمینان بیشتر، از «پشتیبان‌گیری» استفاده کنید.
            </p>
            <div className="mt-3 border-t border-border/70 pt-3 text-center text-[12px] font-bold text-muted-foreground">
              نسخه {APP_VERSION}
            </div>
          </div>
        </section>
      </div>

      {/* ─────────── پنجره‌های تمام‌صفحه ─────────── */}
      <VehiclesWindow
        open={win === "vehicles"}
        onClose={() => setWin(null)}
        vehicles={vehicles}
        records={records}
        reminders={reminders}
        currentKmByVehicle={currentKmByVehicle}
        activeVehicleId={activeVehicleId}
        onSetActive={onSetActive}
        onAdd={onAddVehicle}
        onEdit={onEditVehicle}
        onDeleted={onDeleteVehicle}
      />

      <BrandsWindow
        open={win === "brands"}
        onClose={() => setWin(null)}
        brands={brands}
        onRefresh={onRefresh}
      />

      <ServiceTypesWindow
        open={win === "types"}
        onClose={() => setWin(null)}
        serviceTypes={serviceTypes}
        onRefresh={onRefresh}
      />

      <ThemeWindow
        open={win === "theme"}
        onClose={() => setWin(null)}
        onThemeChange={setTheme}
      />

      <BackupWindow open={win === "backup"} onClose={() => setWin(null)} onRestored={onRefresh} />

      <NotificationsWindow open={win === "notifications"} onClose={() => setWin(null)} />

      {/* ─────────── شیت تأیید خروج ─────────── */}
      <BottomSheet
        open={exitOpen}
        onClose={() => setExitOpen(false)}
        title="خروج از برنامه"
        subtitle="همراه خودرو بسته می‌شود"
      >
        <p className="mb-4 text-[14px] leading-7 text-muted-foreground">
          آیا می‌خواهید از برنامه خارج شوید؟ داده‌های شما ذخیره شده و با اجرای بعدی در دسترس است.
        </p>
        <div className="flex flex-col gap-2 pb-2">
          <button
            type="button"
            onClick={() => {
              setExitOpen(false);
              exitApp();
            }}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-destructive text-[16px] font-bold text-white shadow-lg transition-all active:scale-[.98]"
          >
            <LogOut className="size-5" />
            خروج
          </button>
          <SubmitButton onClick={() => setExitOpen(false)} className="bg-muted text-foreground shadow-none">
            انصراف
          </SubmitButton>
        </div>
      </BottomSheet>
    </div>
  );
}
