"use client";

/**
 * اجزای مشترک — سربرگ صفحه (نوار رنگی بالای همهٔ تب‌ها و زیرمنوها)، پلاک نمایشی،
 * آیکون/رنگ رکوردها، وضعیت یادآورها و حالت بدون خودرو
 */

import * as React from "react";
import { ChevronRight, Fuel, Gauge, Wrench, CheckCircle2, AlarmClock, Bell, Clock, StickyNote, Car, Plus, Settings2, Pencil, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  daysUntilISO,
  fa,
  faNum,
  isoToJalali,
  formatJalaliMonth,
  todayJalali,
} from "@/lib/persian";
import type { RecordItem, RecordType, ReminderItem, VehicleItem } from "@/lib/types";

/* --------------------------- سربرگ صفحه --------------------------- */

/** نام روز هفته از Date انگلیسی */
export function weekdayName(d: Date): string {
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  return names[d.getDay()];
}

/**
 * سربرگ صفحه — نوار رنگی مشترک همهٔ تب‌ها (شبیه سوابق):
 * ⭐ v3.8.6: نوار «چسبان» است — با اسکرول بالا/پایین سر جایش می‌ماند و کارت‌ها از زیرش
 * رد می‌شوند؛ خط تاریخ بزرگ‌تر و خواناتر شد.
 * ⭐ v3.8.7: دکمهٔ بازگشت (در زیرمنوها) «سمت راست، قبل از عنوان» — هم‌الگو با
 * سربرگ پنجره‌های تنظیمات؛ تب‌های اصلی بدون دکمهٔ بازگشت، عنوان راست‌ترین است.
 * ⭐ v3.8.9: عنوان واقعاً به «گوشهٔ بالا سمت راست» می‌چسبد — قبلاً justify-end در RTL
 *  محتوا را به چپِ جعبه می‌راند (عنوان «سوابق» وسط صفحه می‌افتاد؛ درخواست کاربر:
 *  مثل گزارشات به گوشهٔ راست برود). با justify-start (در RTL = راست) + پایانِ طبیعی
 *  جعبهٔ عنوان در لبه، عنوان و برچسب همیشه در گوشهٔ بالا-راست همهٔ تب‌ها هستند.
 */
export function PageHeader({
  title,
  subtitle,
  badge,
  action,
  back,
}: {
  title: string;
  /** خط زیر عنوان — پیش‌فرض «امروز …»؛ در زیرمنوها زیرعنوان توضیحی */
  subtitle?: string;
  /** چیپ کوچک کنار عنوان (مثل تعداد یادآور فعال) */
  badge?: string;
  /** دکمهٔ سمت چپ (مثل اشتراک‌گذاری در سوابق) */
  action?: React.ReactNode;
  /** دکمهٔ بازگشت — ⭐ v3.8.7: سمت راست، قبل از عنوان (هم‌الگو با زیرمنوهای تنظیمات) */
  back?: { onClick: () => void; label?: string };
}) {
  const todayJ = todayJalali();
  const dateLine = (
    <>
      <span className="font-bold text-primary-foreground/85">{weekdayName(new Date())}</span>
      <span className="text-primary-foreground/45">•</span>
      <span className="font-extrabold tabular-nums">
        {fa(todayJ.jd)} {formatJalaliMonth(todayJ.jy, todayJ.jm)}
      </span>
    </>
  );
  return (
    <header className="sticky top-0 z-30 overflow-hidden rounded-b-[28px] bg-primary px-4 pb-3.5 pt-[max(1.25rem,env(safe-area-inset-top))] text-primary-foreground shadow-lg shadow-primary/25">
      <div className="pointer-events-none absolute -left-10 -top-12 size-36 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -left-2 -bottom-16 size-28 rounded-full bg-white/8" />
      <div className="pointer-events-none absolute -right-14 -top-8 size-32 rounded-full bg-white/6" />
      {/* عنوان همیشه سمت راست؛ دکمهٔ بازگشت (اگر باشد) راست‌تر از آن؛ اکشن سمت چپ */}
      <div className="relative flex items-center gap-3">
        {back && (
          <button
            type="button"
            onClick={back.onClick}
            aria-label={back.label ?? "بازگشت"}
            className="flex size-10 shrink-0 items-center justify-center rounded-full bg-white/18 backdrop-blur transition-all active:scale-95"
          >
            <ChevronRight className="size-6" strokeWidth={2.4} />
          </button>
        )}
        <div className="min-w-0 shrink-0 text-right">
          <h1 className="flex items-center justify-start gap-2 text-[25px] font-extrabold leading-8 tracking-tight">
            {title}
            {badge && (
              <span className="rounded-full bg-white/18 px-2.5 py-1 text-[12px] font-bold leading-none backdrop-blur">
                {badge}
              </span>
            )}
          </h1>
          <p className="mt-1 flex items-center justify-start gap-1.5 truncate text-[14px] font-bold leading-5 text-primary-foreground/95">
            {subtitle ?? dateLine}
          </p>
        </div>
        <div className="min-w-0 flex-1" />
        {action ?? <div className="shrink-0" />}
      </div>
    </header>
  );
}

/* --------------------------- پلاک نمایشی --------------------------- */

/** تجزیهٔ رشتهٔ پلاک ذخیره‌شده به ۴ بخش — «۱۲ ب ۳۴۵ ایران ۶۷» */
export function parsePlateParts(plate: string | null | undefined) {
  if (!plate) return null;
  const en = (s: string) =>
    s.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
  const m = en(plate).match(/^\s*(\d{1,2})\s+(\S{1,2})\s+(\d{1,3})\s+(?:ایران)?\s*(\d{1,2})\s*$/);
  if (!m) return null;
  return { two: m[1], letter: m[2], three: m[3], code: m[4] };
}

/**
 * پلاک نمایشی ایرانی — چیدمان واقعی چپ→راست:
 * [دورقمی] [حرف] [سه‌رقمی] [ایران + کد استان] — مثل پلاک واقعی خیابان.
 * (در VehiclesWindow و هرجای نمایش پلاک استفاده می‌شود)
 */
export function PlateView({ plate, size = "md" }: { plate: string | null | undefined; size?: "sm" | "md" }) {
  const parts = parsePlateParts(plate);
  if (!parts) return null;
  const { two, letter, three, code } = parts;
  const letterFa = letter === "ا" ? "الف" : letter;
  const nums = (s: string) => fa(s);
  if (size === "sm") {
    return (
      <span
        dir="ltr"
        className="inline-flex items-center gap-1.5 rounded-md border-2 border-neutral-700/80 bg-white px-2 py-0.5 align-middle shadow-sm"
      >
        <span className="text-[13px] font-black tabular-nums text-neutral-900">{nums(two)}</span>
        <span className="text-[13px] font-black text-neutral-900">{letterFa}</span>
        <span className="text-[13px] font-black tabular-nums text-neutral-900">{nums(three)}</span>
        <span className="mr-0.5 rounded-sm bg-[#20337a] px-1.5 py-0.5 text-[9px] font-bold leading-tight text-white">
          ایران {nums(code)}
        </span>
      </span>
    );
  }
  return (
    <div
      dir="ltr"
      className="inline-flex items-stretch overflow-hidden rounded-xl border-[2.5px] border-neutral-800 bg-white shadow-md"
      aria-label={`پلاک ${nums(two)} ${letterFa} ${nums(three)} ایران ${nums(code)}`}
    >
      <div className="flex items-center gap-2 px-3 py-1.5">
        <span className="w-8 text-center text-[18px] font-black tabular-nums text-neutral-900">{nums(two)}</span>
        <span className="text-[18px] font-black text-neutral-900">{letterFa}</span>
        <span className="w-12 text-center text-[18px] font-black tabular-nums text-neutral-900">{nums(three)}</span>
      </div>
      <div className="flex flex-col items-center justify-center gap-0.5 bg-[#20337a] px-2.5 py-1">
        <span className="text-[10px] font-bold leading-none text-white">ایران</span>
        <span className="text-[14px] font-black leading-tight tabular-nums text-white">{nums(code)}</span>
      </div>
    </div>
  );
}

/* --------------------------- رکوردها --------------------------- */

export const TYPE_META: Record<
  RecordType,
  { label: string; icon: React.ElementType; color: string; bg: string; text: string }
> = {
  SERVICE: {
    label: "سرویس",
    icon: Wrench,
    color: "#0E9F8E",
    bg: "bg-teal-500/12 dark:bg-teal-400/15",
    text: "text-teal-700 dark:text-teal-300",
  },
  FUEL: {
    label: "سوخت",
    icon: Fuel,
    color: "#F59E0B",
    bg: "bg-amber-500/12 dark:bg-amber-400/15",
    text: "text-amber-700 dark:text-amber-300",
  },
  ODOMETER: {
    label: "کیلومتر",
    icon: Gauge,
    color: "#8B5CF6",
    bg: "bg-violet-500/12 dark:bg-violet-400/15",
    text: "text-violet-700 dark:text-violet-300",
  },
  NOTE: {
    label: "یادداشت",
    icon: StickyNote,
    color: "#EC4899",
    bg: "bg-pink-500/12 dark:bg-pink-400/15",
    text: "text-pink-700 dark:text-pink-300",
  },
};

export function TypeBadge({ type, className }: { type: RecordType; className?: string }) {
  const meta = TYPE_META[type];
  const Icon = meta.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[12px] font-bold",
        meta.bg,
        meta.text,
        className
      )}
    >
      <Icon className="size-3.5" />
      {meta.label}
    </span>
  );
}

/* --------------------------- یادآورها --------------------------- */

export type ReminderStatus = "done" | "overdue" | "soon" | "ok";

export interface ReminderStatusInfo {
  status: ReminderStatus;
  label: string;
  color: string;
  bg: string;
  borderColor: string;
  icon: React.ElementType;
}

/** آستانهٔ «نزدیک» — از تنظیمات نوتیفیکیشن قابل تنظیم است */
export interface ReminderThresholds {
  /** چند روز قبل از سررسید = نزدیک (پیش‌فرض ۷) */
  soonDays?: number;
  /** چند کیلومتر قبل از سررسید = نزدیک (پیش‌فرض ۵۰۰) */
  soonKm?: number;
}

const OVERDUE_STYLE = {
  color: "text-red-700 dark:text-red-300",
  bg: "bg-red-500/10 dark:bg-red-400/15",
  borderColor: "border-red-500/35 dark:border-red-400/40",
  icon: AlarmClock,
};
const SOON_STYLE = {
  color: "text-amber-700 dark:text-amber-300",
  bg: "bg-amber-500/10 dark:bg-amber-400/15",
  borderColor: "border-amber-500/35 dark:border-amber-400/40",
  icon: Clock,
};
const OK_STYLE = {
  color: "text-teal-700 dark:text-teal-300",
  bg: "bg-teal-500/10 dark:bg-teal-400/15",
  borderColor: "border-teal-500/30 dark:border-teal-400/35",
  icon: Bell,
};

/**
 * محاسبه وضعیت یادآور بر اساس تاریخ/کارکرد — نوع «هر دو» (BOTH) هر دو شرط را با هم می‌سنجد:
 * وضعیت نهایی بدترینِ دو شرط است و برچسب هر دو نمایش داده می‌شود (مثلاً «۳ روز و ۲۰۰ کیلومتر مانده»).
 */
export function computeReminderStatus(
  r: ReminderItem,
  currentKm: number,
  thresholds?: ReminderThresholds
): ReminderStatusInfo {
  if (r.done) {
    return {
      status: "done",
      label: "انجام شد",
      color: "text-emerald-700 dark:text-emerald-300",
      bg: "bg-emerald-500/10 dark:bg-emerald-400/15",
      borderColor: "border-emerald-500/30 dark:border-emerald-400/35",
      icon: CheckCircle2,
    };
  }

  const soonDays = thresholds?.soonDays ?? 7;
  const soonKm = thresholds?.soonKm ?? 500;

  // سنجش تاریخ — یادآورهای «تاریخ» و «هر دو»
  let datePart: { level: 0 | 1 | 2; text: string } | null = null; // 0=فعال 1=نزدیک 2=گذشته
  if (r.dueDate) {
    const days = daysUntilISO(r.dueDate);
    if (days < 0) datePart = { level: 2, text: `${fa(-days)} روز گذشته` };
    else if (days === 0) datePart = { level: 1, text: "امروز!" };
    else if (days <= soonDays) datePart = { level: 1, text: `${fa(days)} روز مانده` };
    else datePart = { level: 0, text: `${fa(days)} روز مانده` };
  }

  // سنجش کیلومتر — یادآورهای «کیلومتر» و «هر دو»
  let kmPart: { level: 0 | 1 | 2; text: string } | null = null;
  if (r.dueKm !== null && r.dueKm > 0) {
    const left = r.dueKm - currentKm;
    if (left < 0) kmPart = { level: 2, text: `${faNum(-left)} کیلومتر گذشته` };
    else if (left <= soonKm) kmPart = { level: 1, text: `${faNum(left)} کیلومتر مانده` };
    else kmPart = { level: 0, text: `${faNum(left)} کیلومتر مانده` };
  }

  if (!datePart && !kmPart) {
    return {
      status: "ok",
      label: "بدون زمان",
      color: "text-muted-foreground",
      bg: "bg-muted",
      borderColor: "border-border",
      icon: Bell,
    };
  }

  // بدترین وضعیت ملاک رنگ/آیکون است؛ برچسب همهٔ اجزاء با هم
  const parts = [datePart, kmPart].filter(Boolean) as { level: 0 | 1 | 2; text: string }[];
  const worst = Math.max(...parts.map((p) => p.level)) as 0 | 1 | 2;
  const label = parts.map((p) => p.text).join(" و ");
  const style = worst === 2 ? OVERDUE_STYLE : worst === 1 ? SOON_STYLE : OK_STYLE;

  return {
    status: worst === 2 ? "overdue" : worst === 1 ? "soon" : "ok",
    label,
    ...style,
  };
}

/* --------------------------- کارت رکورد --------------------------- */

/**
 * کارت رکورد — بدنهٔ اصلی فقط نمایشی (با زدن کارت چیزی باز نمی‌شود؛
 * ورود به ویرایش فقط با دکمهٔ «ویرایش» در نوار اکشن) + دکمه‌های
 * «ویرایش» و «حذف» که همیشه دیده می‌شوند.
 */
export function RecordCard({
  record,
  vehicle,
  onEdit,
  onDelete,
  busy = false,
}: {
  record: RecordItem;
  vehicle?: VehicleItem;
  onEdit: () => void;
  onDelete: () => void;
  busy?: boolean;
}) {
  const meta = TYPE_META[record.type];
  const Icon = meta.icon;
  const j = isoToJalali(record.date);

  const titleLine =
    record.type === "SERVICE"
      ? record.title || "سرویس"
      : record.type === "FUEL"
        ? record.fullTank
          ? "سوخت‌گیری (باک کامل)"
          : "سوخت‌گیری (نیم‌بند)"
        : record.type === "NOTE"
          ? record.noteTitle || "یادداشت"
          : "ثبت کیلومتر";

  return (
    <div
      className={cn(
        "flex w-full flex-col rounded-2xl border border-border/80 bg-card text-right shadow-sm transition-all hover:border-primary/40 hover:shadow-md",
        busy && "opacity-60"
      )}
    >
      {/* بدنهٔ اصلی — فقط نمایش؛ ویرایش تنها با دکمهٔ «ویرایش» */}
      <div className="flex w-full items-stretch gap-3 rounded-t-2xl p-3.5 pb-2.5">
        {/* آیکون */}
        <span
          className={cn("flex size-12 shrink-0 items-center justify-center rounded-xl", meta.bg)}
          style={{ color: meta.color }}
        >
          <Icon className="size-6" strokeWidth={2} />
        </span>

        {/* بدنه */}
        <span className="flex min-w-0 flex-1 flex-col items-start gap-1.5">
          <span className="flex w-full items-center justify-between gap-2">
            <span className="truncate text-[16px] font-bold text-foreground">{titleLine}</span>
          </span>

          <span className="flex w-full flex-wrap items-center gap-x-2 gap-y-1 text-[13px] text-muted-foreground">
            <span>
              {fa(j.jd)} {formatJalaliMonth(j.jy, j.jm)}
            </span>
            {record.mileage !== null && (
              <>
                <span className="text-border">•</span>
                <span className="tabular-nums">{faNum(record.mileage)} کیلومتر</span>
              </>
            )}
            {vehicle && (
              <>
                <span className="text-border">•</span>
                <span className="truncate">{vehicle.name}</span>
              </>
            )}
          </span>

          <span className="flex w-full flex-wrap items-center gap-1.5">
            {record.type === "FUEL" && record.liters !== null && (
              <span className="rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[12px] font-bold text-amber-700 tabular-nums">
                {faNum(record.liters, 1)} لیتر
                {record.pricePerLiter ? ` — ${faNum(record.pricePerLiter)} تومان/لیتر` : ""}
                {record.consumption !== null ? ` • مصرف ${faNum(record.consumption, 1)}` : ""}
              </span>
            )}
            {record.type === "FUEL" && record.station && (
              <span className="max-w-full truncate rounded-full bg-muted px-2.5 py-0.5 text-[12px] font-medium text-muted-foreground">
                {record.station}
              </span>
            )}
            {record.type === "SERVICE" && record.provider && (
              <span className="max-w-full truncate rounded-full bg-muted px-2.5 py-0.5 text-[12px] font-medium text-muted-foreground">
                {record.provider}
              </span>
            )}
            {record.type === "SERVICE" && (record.complementary?.length ?? 0) > 0 && (
              <span className="max-w-full truncate rounded-full bg-teal-500/10 px-2.5 py-0.5 text-[12px] font-medium text-teal-700 dark:text-teal-300">
                {record.complementary.map((c) => c.name).join(" + ")}
              </span>
            )}
            {record.type === "SERVICE" &&
              (record.complementary?.length ?? 0) === 0 &&
              (record.hasOilFilter || record.hasAirFilter) && (
                <span className="rounded-full bg-teal-500/10 px-2.5 py-0.5 text-[12px] font-medium text-teal-700 dark:text-teal-300">
                  {record.hasOilFilter && "فیلتر روغن"}
                  {record.hasOilFilter && record.hasAirFilter && " + "}
                  {record.hasAirFilter && "فیلتر هوا"}
                </span>
              )}
            {record.type === "NOTE" && record.noteBody && (
              <span className="max-w-full truncate rounded-full bg-muted px-2.5 py-0.5 text-[12px] text-muted-foreground">
                {record.noteBody}
              </span>
            )}
          </span>
        </span>

        {/* هزینه */}
        {record.cost !== null && record.cost > 0 && (
          <span className="flex shrink-0 flex-col items-end justify-center">
            <span className="whitespace-nowrap text-[15px] font-extrabold tabular-nums text-primary">
              {faNum(record.cost)}
            </span>
            <span className="text-[11px] text-muted-foreground">تومان</span>
          </span>
        )}
      </div>

      {/* اکشن‌ها — همیشه قابل مشاهده */}
      <div className="flex items-center gap-2 border-t border-border/60 px-3.5 py-2">
        <button
          type="button"
          disabled={busy}
          onClick={onEdit}
          className={cn(
            "flex h-9 flex-1 items-center justify-center gap-1.5 rounded-xl bg-primary/12 text-[13px] font-bold text-primary transition-all active:scale-95 disabled:opacity-50"
          )}
        >
          <Pencil className="size-4" />
          ویرایش
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={onDelete}
          aria-label={`حذف ${titleLine}`}
          className="flex h-9 items-center justify-center gap-1.5 rounded-xl bg-red-500/10 px-3.5 text-[13px] font-bold text-red-600 transition-all active:scale-95 disabled:opacity-50 dark:text-red-400"
        >
          <Trash2 className="size-4" />
          حذف
        </button>
      </div>
    </div>
  );
}

/* ------------------------ حالت بدون خودرو ------------------------ */

/**
 * وقتی هنوز هیچ خودرویی ثبت نشده — راهنمای افزودن خودرو از فرم یا تنظیمات
 * برنامه همچنان با تب‌ها بالا می‌ماند؛ این کارت داخل هر تب نمایش داده می‌شود.
 */
export function EmptyVehicles({
  title = "هنوز خودرویی ثبت نشده",
  desc = "برای شروع، خودروی خود را اضافه کنید. می‌توانید مستقیم اینجا اضافه کنید یا از بخش «خودروهای من» در تنظیمات.",
  onAddVehicle,
  onGoSettings,
}: {
  title?: string;
  desc?: string;
  onAddVehicle: () => void;
  onGoSettings: () => void;
}) {
  return (
    <div className="mx-4 mt-3 flex flex-col items-center rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-6 text-center">
      <span className="flex size-20 items-center justify-center rounded-full bg-primary/10">
        <span className="flex size-14 items-center justify-center rounded-full bg-primary/15">
          <Car className="size-7 text-primary" strokeWidth={1.9} />
        </span>
      </span>
      <h3 className="mt-4 text-[18px] font-extrabold text-foreground">{title}</h3>
      <p className="mt-2 max-w-[310px] text-[14px] leading-7 text-muted-foreground">{desc}</p>

      <button
        type="button"
        onClick={onAddVehicle}
        className="mt-5 flex h-12 w-full max-w-xs items-center justify-center gap-2 rounded-xl bg-primary text-[16px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-transform active:scale-[.97]"
      >
        <Plus className="size-5" strokeWidth={2.4} />
        افزودن خودرو
      </button>

      <button
        type="button"
        onClick={onGoSettings}
        className="mt-3 flex items-center gap-1.5 text-[13.5px] font-bold text-primary active:opacity-70"
      >
        <Settings2 className="size-4" />
        رفتن به «خودروهای من» در تنظیمات
      </button>
    </div>
  );
}
