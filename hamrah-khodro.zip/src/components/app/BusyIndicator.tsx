"use client";

/**
 * نشانگر انتظار سراسری (v3.8.5) — نمایندهٔ src/lib/busy.ts روی صفحه:
 *
 *  - pill:    کپسول شناور بالای صفحه («در حال همگام‌سازی با Google Drive…») —
 *             کاربر می‌تواند کارش را ادامه دهد، فقط می‌بیند که کار در پس‌زمینه انجام است.
 *  - overlay: پردهٔ انتظار تمام‌صفحه با کارت مرکزی («در حال بازیابی اطلاعات…») —
 *             برای عملیاتی که باید تا پایانش صبر کند و نباید چیزی لمس شود.
 *
 * نکتهٔ حیاتی: انیمیشن‌ها همه CSS و از جنس transform/opacity هستند تا روی رشتهٔ
 * کامپوزیتور اجرا شوند — یعنی حتی وقتی رشتهٔ JS صبرِ فراخوانی همگامِ پل جاواست،
 * اسپینر همچنان می‌چرخد و «حالت انتظار زنده» دیده می‌شود.
 * ⭐ v3.8.9: backdrop-blur حذف شد — روی WebView برخی گوشی‌های اندروید، پس از حذفِ
 *  لایهٔ backdrop-filter رندر صفحه تیره/خراب می‌ماند (دقیقاً «صفحه تاریک می‌شود»).
 *  جایگزین: پس‌زمینهٔ نیمه‌شفاف ساده (bg-background/85) — بدون هیچ فیلتری.
 *  انیمیشن خروج هم درست شد (قبلاً با null شدن busy بلافاصله حذف می‌شد بدون fade).
 */
import * as React from "react";
import { Cloud, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { subscribeBusy, type BusyState } from "@/lib/busy";

export function BusyIndicator() {
  const [busy, setBusy] = React.useState<BusyState | null>(null);
  /* آخرین مشخصات دیده‌شده — برای نقاشی فریم‌های انیمیشن خروج (~۲۴۰ms) */
  const [shown, setShown] = React.useState<BusyState | null>(null);

  React.useEffect(
    () =>
      subscribeBusy((b) => {
        setBusy(b);
        if (b) setShown(b);
      }),
    []
  );

  /* عنصر تا پایان انیمیشن خروج (~۲۴۰ms) در DOM می‌ماند تا محو‌شدن نرم باشد */
  const [mounted, setMounted] = React.useState(false);
  const [visible, setVisible] = React.useState(false);
  React.useEffect(() => {
    if (busy) {
      setMounted(true);
      setVisible(true);
      return;
    }
    setVisible(false);
    const t = window.setTimeout(() => {
      setMounted(false);
      setShown(null);
    }, 240);
    return () => window.clearTimeout(t);
  }, [busy]);

  if (!mounted || !shown) return null;
  const overlay = shown.mode === "overlay";

  return (
    <div dir="rtl" aria-live={overlay ? "assertive" : "polite"}>
      {/* ─── حالت کپسول (غیرمسدودکننده) — ⭐ v3.8.6: بالای نوار پایین، زیر نوار چسبانِ بالا
           (قبلاً بالای صفحه بود و روی عنوانِ چسبان می‌افتاد) ─── */}
      {!overlay && (
        <div
          role="status"
          className={cn(
            "pointer-events-none fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom)+6rem)] z-[95] flex justify-center px-4",
            "transition-all duration-200 ease-out",
            visible ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0"
          )}
        >
          <div className="flex max-w-full items-center gap-2.5 rounded-full border border-primary/25 bg-card/95 py-2 pe-5 ps-2 shadow-xl shadow-black/10">
            <span className="relative flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/12">
              <Loader2 className="size-4.5 animate-spin text-primary" strokeWidth={2.4} />
            </span>
            <span className="flex min-w-0 flex-col">
              <span className="truncate text-[13px] font-bold leading-5 text-foreground">
                {shown.title}
              </span>
              {shown.detail && (
                <span className="truncate text-[10.5px] leading-4 text-muted-foreground">
                  {shown.detail}
                </span>
              )}
            </span>
          </div>
        </div>
      )}

      {/* ─── حالت پردهٔ انتظار (مسدودکننده) — تمام‌صفحه ───
          ⭐ v3.8.9: بدون backdrop-blur — روی WebView اندروید لایهٔ فیلتر پس از حذف،
          صفحه را تیره نگه می‌داشت؛ پس‌زمینهٔ نیمه‌شفاف ساده و مطمئن */}
      {overlay && (
        <div
          role="status"
          className={cn(
            "fixed inset-0 z-[95] flex items-center justify-center bg-background/85 p-6",
            "transition-opacity duration-200",
            visible ? "opacity-100" : "opacity-0"
          )}
        >
          <div
            className={cn(
              "flex w-full max-w-[300px] flex-col items-center rounded-3xl border border-border/60 bg-card p-7 text-center shadow-2xl",
              "transition-transform duration-200 ease-out",
              visible ? "scale-100" : "scale-90"
            )}
          >
            {/* نشانگر دوحلقه‌ای چرخان حول آیکن ابر */}
            <span className="relative flex size-20 items-center justify-center">
              <span className="absolute inset-0 rounded-full border-[3px] border-primary/12" />
              <span className="absolute inset-0 animate-spin rounded-full border-[3px] border-transparent border-t-primary" />
              <span className="absolute inset-2 animate-spin rounded-full border-[3px] border-transparent border-t-primary/40 [animation-direction:reverse] [animation-duration:1.7s]" />
              <Cloud className="size-8 text-primary" strokeWidth={1.9} />
            </span>
            <p className="mt-4 text-[16px] font-extrabold text-foreground">{shown.title}</p>
            {shown.detail && (
              <p className="mt-1.5 text-[12.5px] leading-6 text-muted-foreground">{shown.detail}</p>
            )}
            {/* نوار پیشرفت موج‌دار — انیمیشن transform (کامپوزیتور) */}
            <span className="mt-4 block h-1.5 w-40 overflow-hidden rounded-full bg-muted">
              <span className="hk-busy-shimmer block h-full w-full rounded-full" />
            </span>
            <p className="mt-3 flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground">
              <Loader2 className="size-3 animate-spin" />
              لطفاً منتظر بمانید…
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
