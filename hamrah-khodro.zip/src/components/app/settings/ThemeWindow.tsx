"use client";

/**
 * پنجرهٔ «تم برنامه» — ۹ تم پیش‌فرض (اختصاصی + ۲ روشن + ۲ متوسط + ۲ میانه + ۲ تیره)
 * + تم‌های شخصی. هر تم قابل ویرایش (انتخاب رنگ از طیف روشن→تیره + روشن/تیره + نام)
 * و حذف است؛ «اختصاصی» فقط ویرایش می‌شود. بازگردانی همهٔ پیش‌فرض‌ها هم هست.
 */

import * as React from "react";
import {
  Check,
  Contrast,
  Droplets,
  FileText,
  Flower2,
  LayoutTemplate,
  Moon,
  PaintBucket,
  Palette,
  Pencil,
  Plus,
  RotateCcw,
  Square,
  Star,
  Sun,
  Sunrise,
  Trash2,
  Trees,
  Waves,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  addCustomTheme,
  applyTheme,
  COLOR_FAMILIES,
  familyShade,
  getCustomThemes,
  getHiddenThemes,
  getStoredTheme,
  getThemeOverrides,
  hexToHsl,
  isSectionsDark,
  previewFromBase,
  previewFromSections,
  resolveThemeDefs,
  resetThemeCustomizations,
  saveCustomThemes,
  saveThemeOverrides,
  setHiddenThemes,
  SHADE_STEPS,
  THEME_GROUP_LABELS,
  type BuiltinThemeId,
  type ResolvedThemeDef,
  type ThemeGroup,
} from "@/lib/theme";
import { fa } from "@/lib/persian";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import { BottomSheet } from "../BottomSheet";
import { SubmitButton, TextInput } from "../fields";
import { useToast } from "@/hooks/use-toast";
import { SettingsWindow } from "./SettingsWindow";

const THEME_ICONS: Record<BuiltinThemeId, React.ElementType> = {
  paper: FileText,
  emerald: Sun,
  rosewater: Flower2,
  turquoise: Droplets,
  saffron: Sunrise,
  deepteal: Waves,
  graphite: Contrast,
  midnight: Moon,
  forest: Trees,
};

const GROUP_ORDER: ThemeGroup[] = ["special", "light", "medium", "mid", "dark", "mine"];

/* ------------------------------ کارت تم ------------------------------ */

function ThemeCard({
  def,
  active,
  onPick,
  onEdit,
  onDelete,
}: {
  def: ResolvedThemeDef;
  active: boolean;
  onPick: () => void;
  onEdit: () => void;
  onDelete: (() => void) | null;
}) {
  const Icon = def.isCustom ? Palette : (THEME_ICONS[def.id as BuiltinThemeId] ?? Star);
  const p = def.preview;
  return (
    <div
      className={cn(
        "flex flex-col overflow-hidden rounded-2xl border-2 text-right transition-all",
        active ? "border-primary shadow-lg shadow-primary/15" : "border-border/80 hover:border-primary/40"
      )}
    >
      {/* پیش‌نمایش — لمس = انتخاب */}
      <button
        type="button"
        onClick={onPick}
        aria-pressed={active}
        aria-label={`انتخاب تم ${def.name}`}
        className="relative p-3 active:scale-[.97] transition-transform"
        style={{ background: p.bg }}
      >
        <div
          className="flex h-16 items-center gap-2 rounded-xl px-3"
          style={{ background: p.card, border: `1px solid ${p.line}` }}
        >
          <span
            className="flex size-9 shrink-0 items-center justify-center rounded-lg"
            style={{ background: p.primary }}
          >
            <Icon className="size-5" style={{ color: p.primaryFg }} strokeWidth={2.2} />
          </span>
          <span className="flex min-w-0 flex-1 flex-col gap-1.5">
            <span className="h-2 w-3/4 rounded-full" style={{ background: p.text, opacity: 0.85 }} />
            <span className="h-2 w-1/2 rounded-full" style={{ background: p.sub, opacity: 0.7 }} />
          </span>
          <span className="h-6 w-10 shrink-0 rounded-md" style={{ background: p.primary, opacity: 0.9 }} />
        </div>
        {active && (
          <span
            className="absolute left-4 top-4 flex size-6 items-center justify-center rounded-full shadow-md"
            style={{ background: p.primary }}
          >
            <Check className="size-4" style={{ color: p.primaryFg }} strokeWidth={3} />
          </span>
        )}
        {def.edited && (
          <span className="absolute right-4 top-4 rounded-full bg-primary/85 px-2 py-0.5 text-[10px] font-bold text-white">
            ویرایش‌شده
          </span>
        )}
      </button>

      {/* نام + دکمه‌های ویرایش/حذف */}
      <div className="flex items-center gap-1.5 bg-card p-2.5 pl-2">
        <span
          className={cn(
            "flex size-6 shrink-0 items-center justify-center rounded-full text-[12px] font-extrabold tabular-nums",
            active ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          )}
        >
          {typeof def.no === "number" ? fa(def.no) : def.no}
        </span>
        <Icon className="size-4 shrink-0 text-primary" />
        <span className={cn("min-w-0 flex-1 truncate text-[14px] font-bold", active ? "text-primary" : "text-foreground")}>
          {def.name}
        </span>
        <button
          type="button"
          onClick={onEdit}
          aria-label={`ویرایش تم ${def.name}`}
          className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-all active:scale-90"
        >
          <Pencil className="size-3.5" />
        </button>
        {onDelete && (
          <button
            type="button"
            onClick={onDelete}
            aria-label={`حذف تم ${def.name}`}
            className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-red-500/10 text-red-600 transition-all active:scale-90 dark:text-red-400"
          >
            <Trash2 className="size-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}

/* ------------------------------ ویرایشگر تم ------------------------------ */

/** هدف ویرایش */
interface EditTarget {
  type: "new" | "custom" | "builtin";
  id: string;
}

/** نزدیک‌ترین خانوادهٔ رنگ و گام طیف برای یک رنگ پایه */
function nearestFamily(baseColor: string): { family: number; shade: number } {
  const { h, s, l } = hexToHsl(baseColor);
  let family = 0;
  let best = Infinity;
  COLOR_FAMILIES.forEach((f, i) => {
    // فاصلهٔ زاویه‌ای روی چرخ رنگ
    let dh = Math.abs(f.h - h);
    if (dh > 180) dh = 360 - dh;
    const score = dh + Math.abs(f.s - s) * 0.6;
    if (score < best) {
      best = score;
      family = i;
    }
  });
  let shade = 1;
  let bestL = Infinity;
  SHADE_STEPS.forEach((st, i) => {
    const d = Math.abs(st - l);
    if (d < bestL) {
      bestL = d;
      shade = i;
    }
  });
  return { family, shade };
}

/** انتخابگر رنگ یک بخش تم — خانوادهٔ رنگ + شدت (گام طیف) */
function SectionPicker({
  icon: Icon,
  label,
  desc,
  family,
  shade,
  onFamily,
  onShade,
}: {
  icon: React.ElementType;
  label: string;
  desc: string;
  family: number;
  shade: number;
  onFamily: (i: number) => void;
  onShade: (i: number) => void;
}) {
  const color = familyShade(COLOR_FAMILIES[family], shade);
  return (
    <section className="mb-3 rounded-2xl border border-border/80 bg-card p-3.5">
      <div className="mb-2.5 flex items-center gap-2.5">
        <span
          className="flex size-9 shrink-0 items-center justify-center rounded-xl"
          style={{ background: color }}
        >
          <Icon className="size-4.5 text-white drop-shadow" strokeWidth={2.3} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[13.5px] font-bold text-foreground">{label}</p>
          <p className="mt-0.5 text-[11px] leading-4 text-muted-foreground">{desc}</p>
        </div>
        <span
          className="size-7 shrink-0 rounded-lg ring-1 ring-border"
          style={{ background: color }}
          aria-hidden
        />
      </div>
      {/* خانوادهٔ رنگ */}
      <div className="grid grid-cols-6 gap-1.5">
        {COLOR_FAMILIES.map((f, i) => {
          const light = familyShade(f, 1);
          const mid = familyShade(f, 5);
          const deep = familyShade(f, 9);
          const selected = family === i;
          return (
            <button
              key={f.name}
              type="button"
              onClick={() => onFamily(i)}
              aria-label={f.name}
              title={f.name}
              className={cn(
                "flex aspect-square items-center justify-center rounded-full transition-all active:scale-90",
                selected && "ring-2 ring-primary ring-offset-2 ring-offset-card"
              )}
              style={{ background: `linear-gradient(135deg, ${light} 0%, ${mid} 50%, ${deep} 100%)` }}
            >
              {selected && <Check className="size-4 text-white drop-shadow" strokeWidth={3} />}
            </button>
          );
        })}
      </div>
      {/* شدت — روشن ← تیره */}
      <div className="mt-2 flex gap-1.5 overflow-x-auto rounded-xl border border-input bg-background p-1.5" style={{ scrollbarWidth: "thin" }}>
        {SHADE_STEPS.map((_, i) => {
          const c = familyShade(COLOR_FAMILIES[family], i);
          const selected = shade === i;
          return (
            <button
              key={i}
              type="button"
              onClick={() => onShade(i)}
              aria-label={`شدت ${fa(i + 1)}`}
              className={cn(
                "h-8 flex-1 min-w-8 shrink-0 rounded-lg transition-all active:scale-90",
                selected && "ring-2 ring-primary ring-offset-1 ring-offset-background"
              )}
              style={{ background: c }}
            >
              {selected && <Check className="mx-auto size-3.5 text-white drop-shadow" strokeWidth={3} />}
            </button>
          );
        })}
      </div>
      <p className="mt-1.5 px-1 text-[10.5px] text-muted-foreground">
        شدت: روشن ← تیره (گام {fa(shade + 1)} از {fa(SHADE_STEPS.length)})
      </p>
    </section>
  );
}

function ThemeEditor({
  target,
  onClose,
  onSaved,
}: {
  target: EditTarget;
  onClose: () => void;
  onSaved: (id: string) => void;
}) {
  const { toast } = useToast();
  const [name, setName] = React.useState("");
  const [headerSel, setHeaderSel] = React.useState({ family: 5, shade: 7 });
  const [bgSel, setBgSel] = React.useState({ family: 11, shade: 1 });
  const [cardSel, setCardSel] = React.useState({ family: 11, shade: 0 });

  React.useEffect(() => {
    // مقدار اولیهٔ هر بخش از رنگ مؤثر همان بخش در تم هدف
    let headerColor: string | null = null;
    let bgColor: string | null = null;
    let cardColor: string | null = null;
    let initialName = "";
    if (target.type === "new") {
      initialName = "تم من";
    } else if (target.type === "custom") {
      const c = getCustomThemes().find((t) => t.id === target.id);
      if (c) {
        initialName = c.name;
        if (c.sections) {
          headerColor = c.sections.header;
          bgColor = c.sections.background;
          cardColor = c.sections.card;
        } else {
          const p = previewFromBase(c.baseColor, c.dark);
          headerColor = p.primary;
          bgColor = p.bg;
          cardColor = p.card;
        }
      }
    } else {
      const ov = getThemeOverrides()[target.id as BuiltinThemeId];
      if (ov) {
        initialName = ov.name ?? "";
        if (ov.sections) {
          headerColor = ov.sections.header;
          bgColor = ov.sections.background;
          cardColor = ov.sections.card;
        } else {
          const p = previewFromBase(ov.baseColor, ov.dark);
          headerColor = p.primary;
          bgColor = p.bg;
          cardColor = p.card;
        }
      } else {
        const def = resolveThemeDefs().find((d) => d.id === target.id);
        if (def) {
          headerColor = def.preview.primary;
          bgColor = def.preview.bg;
          cardColor = def.preview.card;
        }
      }
    }
    if (headerColor) setHeaderSel(nearestFamily(headerColor));
    if (bgColor) setBgSel(nearestFamily(bgColor));
    if (cardColor) setCardSel(nearestFamily(cardColor));
    setName(initialName);
  }, [target]);

  const sections = {
    header: familyShade(COLOR_FAMILIES[headerSel.family], headerSel.shade),
    background: familyShade(COLOR_FAMILIES[bgSel.family], bgSel.shade),
    card: familyShade(COLOR_FAMILIES[cardSel.family], cardSel.shade),
  };
  const preview = previewFromSections(sections);

  const save = () => {
    const trimmed = name.trim() || "تم شخصی";
    const dark = isSectionsDark(sections);
    if (target.type === "new") {
      const t = addCustomTheme({ name: trimmed, baseColor: sections.header, dark, sections });
      applyTheme(t.id);
      toast({ title: "تم ساخته شد ✓", description: trimmed });
      onSaved(t.id);
    } else if (target.type === "custom") {
      const list = getCustomThemes().map((t) =>
        t.id === target.id ? { ...t, name: trimmed, baseColor: sections.header, dark, sections } : t
      );
      saveCustomThemes(list);
      applyTheme(target.id);
      toast({ title: "تم ویرایش شد ✓", description: trimmed });
      onSaved(target.id);
    } else {
      const overrides = getThemeOverrides();
      overrides[target.id as BuiltinThemeId] = { name: trimmed, baseColor: sections.header, dark, sections };
      saveThemeOverrides(overrides);
      applyTheme(target.id);
      toast({ title: "تم ویرایش شد ✓", description: trimmed });
      onSaved(target.id);
    }
    onClose();
  };

  return (
    <BottomSheet
      open={true}
      onClose={onClose}
      title={target.type === "new" ? "ساخت تم جدید" : "ویرایش تم"}
      subtitle="رنگ و شدت هر بخش را جدا تنظیم کنید"
      footer={
        <SubmitButton onClick={save}>
          <Check className="size-5" />
          {target.type === "new" ? "ساخت تم" : "ذخیرهٔ تغییرات"}
        </SubmitButton>
      }
    >
      {/* نام تم */}
      <div className="mb-3">
        <p className="mb-1.5 px-1 text-[12.5px] font-bold text-foreground">نام تم</p>
        <TextInput
          dir="rtl"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="مثلاً تم تابستان"
        />
      </div>

      {/* سه بخش تم — رنگ و شدت جداگانه */}
      <SectionPicker
        icon={LayoutTemplate}
        label="رنگ سربرگ"
        desc="نوار بالای صفحات، دکمه‌های اصلی و اکسنت‌ها"
        family={headerSel.family}
        shade={headerSel.shade}
        onFamily={(i) => setHeaderSel((s) => ({ ...s, family: i }))}
        onShade={(i) => setHeaderSel((s) => ({ ...s, shade: i }))}
      />
      <SectionPicker
        icon={PaintBucket}
        label="رنگ پس‌زمینه"
        desc="پس‌زمینهٔ صفحه‌ها — روشن یا تیره بودن تم از همین‌جا تشخیص داده می‌شود"
        family={bgSel.family}
        shade={bgSel.shade}
        onFamily={(i) => setBgSel((s) => ({ ...s, family: i }))}
        onShade={(i) => setBgSel((s) => ({ ...s, shade: i }))}
      />
      <SectionPicker
        icon={Square}
        label="رنگ کادرها"
        desc="کارت‌ها، کادرهای فرم و پنجره‌ها"
        family={cardSel.family}
        shade={cardSel.shade}
        onFamily={(i) => setCardSel((s) => ({ ...s, family: i }))}
        onShade={(i) => setCardSel((s) => ({ ...s, shade: i }))}
      />

      {/* پیش‌نمایش زنده — ماکت کوچک صفحه */}
      <div className="overflow-hidden rounded-2xl border border-border">
        {/* سربرگ ماکت */}
        <div
          className="relative flex items-center justify-between px-3.5 py-3"
          style={{ background: sections.header }}
        >
          <span
            className="rounded-full px-3 py-1 text-[10.5px] font-bold"
            style={{ background: "rgba(255,255,255,.2)", color: preview.primaryFg }}
          >
            دکمه
          </span>
          <span className="min-w-0 flex-1 pr-2 text-right">
            <span className="block truncate text-[14px] font-extrabold" style={{ color: preview.primaryFg }}>
              {name.trim() || "نام تم"}
            </span>
            <span className="mt-0.5 block text-[10.5px]" style={{ color: preview.primaryFg, opacity: 0.85 }}>
              پیش‌نمایش سربرگ
            </span>
          </span>
        </div>
        {/* پس‌زمینه + کارت ماکت */}
        <div className="p-3" style={{ background: sections.background }}>
          <div
            className="flex items-center gap-3 rounded-xl p-3"
            style={{ background: sections.card, border: `1px solid ${preview.line}` }}
          >
            <span
              className="flex size-10 shrink-0 items-center justify-center rounded-xl"
              style={{ background: sections.header }}
            >
              <Palette className="size-5" style={{ color: preview.primaryFg }} strokeWidth={2.2} />
            </span>
            <span className="flex min-w-0 flex-1 flex-col gap-1.5">
              <span className="text-[13.5px] font-bold" style={{ color: preview.text }}>
                کارت نمونه
              </span>
              <span className="h-2 w-2/3 rounded-full" style={{ background: preview.sub, opacity: 0.8 }} />
            </span>
          </div>
          <p className="mt-2 px-1 text-[10.5px]" style={{ color: preview.sub }}>
            {isSectionsDark(sections) ? "تم تیره — رنگ پس‌زمینه تیره است" : "تم روشن — رنگ پس‌زمینه روشن است"}
          </p>
        </div>
      </div>
    </BottomSheet>
  );
}

/* ------------------------------ پنجرهٔ اصلی ------------------------------ */

export function ThemeWindow({
  open,
  onClose,
  onThemeChange,
}: {
  open: boolean;
  onClose: () => void;
  onThemeChange?: (id: string) => void;
}) {
  const [theme, setTheme] = React.useState<string>("paper");
  const [editing, setEditing] = React.useState<EditTarget | null>(null);
  const [rev, setRev] = React.useState(0);

  React.useEffect(() => {
    if (open) setTheme(getStoredTheme());
  }, [open]);

  const defs = React.useMemo(() => (open ? resolveThemeDefs() : []), [open, rev]);

  const pick = (id: string) => {
    applyTheme(id);
    setTheme(id);
    onThemeChange?.(id);
  };

  /** حذف تم — پیش‌فرض‌ها مخفی می‌شوند؛ شخصی‌ها کامل حذف */
  const remove = async (def: ResolvedThemeDef) => {
    const ok = await confirmDialog({
      title: "حذف تم",
      message: `تم «${def.name}» حذف شود؟`,
    });
    if (!ok) return;
    if (def.isCustom) {
      saveCustomThemes(getCustomThemes().filter((t) => t.id !== def.id));
    } else {
      setHiddenThemes([...getHiddenThemes(), def.id as BuiltinThemeId]);
      const overrides = getThemeOverrides();
      delete overrides[def.id as BuiltinThemeId];
      saveThemeOverrides(overrides);
    }
    if (theme === def.id) {
      applyTheme("paper");
      setTheme("paper");
      onThemeChange?.("paper");
    }
    setRev((v) => v + 1);
  };

  /** بازگردانی همهٔ پیش‌فرض‌ها */
  const restoreDefaults = async () => {
    const ok = await confirmDialog({
      title: "بازگردانی پیش‌فرض‌ها",
      message: "همهٔ تم‌های پیش‌فرضِ حذف‌شده و ویرایش‌های آن‌ها بازگردانی می‌شوند. تم‌های شخصی حذف نمی‌شوند.",
      confirmLabel: "بازگردانی",
    });
    if (!ok) return;
    resetThemeCustomizations();
    // اعمال دوبارهٔ تم فعال بدون ویرایش — متغیرهای پویای قبلی پاک شود
    const current = getStoredTheme();
    applyTheme(current);
    setTheme(current);
    onThemeChange?.(current);
    setRev((v) => v + 1);
  };

  return (
    <SettingsWindow open={open} onClose={onClose} title="تم برنامه" subtitle="انتخاب، ویرایش رنگ و ساخت تم شخصی">
      {GROUP_ORDER.map((group) => {
        const groupThemes = defs.filter((t) => t.group === group);
        if (groupThemes.length === 0) return null;
        return (
          <section key={group} className="mb-5">
            <h3 className="mb-2.5 flex items-center gap-2 px-1 text-[13.5px] font-bold text-foreground">
              {THEME_GROUP_LABELS[group]}
              <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
                {fa(groupThemes.length)} تم
              </span>
              {group === "special" && (
                <span className="text-[11px] font-medium text-muted-foreground">(قابل ویرایش — غیرقابل حذف)</span>
              )}
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {groupThemes.map((t) => (
                <ThemeCard
                  key={t.id}
                  def={t}
                  active={theme === t.id}
                  onPick={() => pick(t.id)}
                  onEdit={() => setEditing({ type: t.isCustom ? "custom" : "builtin", id: t.id })}
                  onDelete={t.deletable ? () => remove(t) : null}
                />
              ))}

              {/* دکمهٔ ساخت تم جدید — در بخش «تم‌های من» */}
              {group === "mine" && (
                <button
                  type="button"
                  onClick={() => setEditing({ type: "new", id: "" })}
                  className="flex min-h-[120px] flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 text-primary transition-all active:scale-[.97]"
                >
                  <span className="flex size-11 items-center justify-center rounded-full bg-primary/12">
                    <Plus className="size-6" strokeWidth={2.4} />
                  </span>
                  <span className="text-[14px] font-bold">ساخت تم جدید</span>
                  <span className="px-3 text-center text-[11px] leading-4 text-muted-foreground">
                    رنگ و شدت جداگانهٔ سربرگ، پس‌زمینه و کادر
                  </span>
                </button>
              )}
            </div>
          </section>
        );
      })}

      {/* اگر هیچ تم شخصی‌ای نیست، دکمهٔ ساخت جداگانه */}
      {defs.every((d) => d.group !== "mine") && (
        <button
          type="button"
          onClick={() => setEditing({ type: "new", id: "" })}
          className="mb-4 flex min-h-[104px] w-full flex-col items-center justify-center gap-1.5 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 text-primary transition-all active:scale-[.98]"
        >
          <span className="flex size-10 items-center justify-center rounded-full bg-primary/12">
            <Plus className="size-5.5" strokeWidth={2.4} />
          </span>
          <span className="text-[14.5px] font-bold">ساخت تم جدید با رنگ دلخواه</span>
          <span className="text-[11.5px] text-muted-foreground">رنگ جداگانه برای سربرگ، پس‌زمینه و کادرها</span>
        </button>
      )}

      <div className="flex items-center justify-between gap-2 pb-1">
        <p className="flex-1 text-center text-[12px] leading-6 text-muted-foreground">
          انتخاب شما ذخیره می‌شود؛ تم‌ها را می‌توانید ویرایش یا حذف کنید.
        </p>
        <button
          type="button"
          onClick={restoreDefaults}
          className="flex shrink-0 items-center gap-1.5 rounded-xl bg-muted px-3 py-2 text-[12px] font-bold text-muted-foreground transition-all active:scale-95"
        >
          <RotateCcw className="size-3.5" />
          بازگردانی پیش‌فرض‌ها
        </button>
      </div>

      {/* ویرایشگر تم */}
      {editing && (
        <ThemeEditor
          target={editing}
          onClose={() => setEditing(null)}
          onSaved={(id) => {
            setTheme(id);
            onThemeChange?.(id);
            setRev((v) => v + 1);
          }}
        />
      )}
    </SettingsWindow>
  );
}
