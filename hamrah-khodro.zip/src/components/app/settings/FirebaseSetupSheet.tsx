"use client";

/**
 * شیت «راه‌اندازی گام‌به‌گام سرور ابری» (v3.9.5) — فایربیس از ابتدا، مرحله‌به‌مرحله.
 *
 * ⭐ چرا این شیت؟ خطای «ورود به سرور پشتیبان انجام نشد» تقریباً همیشه یکی از
 *    ۴ تنظیمِ کنسول گوگل است — این شیت همان‌ها را با «بررسی وضعیت» خودکار نشان می‌دهد:
 *      ۱) اینترنت و دسترسی به گوگل            → probe خودکار (fbProbeAsync «network»)
 *      ۲) Identity Toolkit API (ورود)          → probe خودکار («identity»)
 *      ۳) Cloud Firestore API (داده)           → probe خودکار («firestore»)
 *      ۴) ساخت دیتابیس Firestore + قوانین      → راهنمای کنسول (+ بعد از اتصال، تست واقعی سند)
 *    و در پایان: اتصال با حساب گوگل (که خودش تست کامل انتها-به-انتهاست).
 *
 * نکتهٔ مهم برای کاربر: مراحل Gradle/SDK که ویزارد کنسول فایربیس نشان می‌دهد برای این
 * برنامه لازم نیست — ارتباط مستقیم REST است؛ فقط همین ۴ تنظیم مهم است.
 */
import * as React from "react";
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleDashed,
  Copy,
  Database,
  ExternalLink,
  Globe,
  KeyRound,
  Loader2,
  Server,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { BottomSheet } from "../BottomSheet";
import {
  firebaseConsoleUrl,
  firebaseRulesUrl,
  firestoreApiEnableUrl,
  getFirebaseConfig,
  identityApiEnableUrl,
} from "@/lib/firebase-config";
import {
  downloadFirebaseSnapshot,
  firebaseProbe,
  getFirebaseAccount,
  hasFbBridge,
  type FbProbeResult,
} from "@/lib/firebase-sync";
import { openExternalUrl } from "@/lib/cloud-sync";
import { useToast } from "@/hooks/use-toast";

/** باز کردن لینک در مرورگر گوشی (لایهٔ جاوا) — در وب آزمایشی */
function openLink(url: string): void {
  void openExternalUrl(url);
}

const RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write:
        if request.auth != null
        && request.auth.uid == uid;
    }
  }
}`;

type StepState = "unknown" | "checking" | "ok" | "warn";

interface StepDef {
  key: "network" | "identity" | "firestore" | "database" | "rules";
  icon: React.ElementType;
  title: string;
  hint: string;
}

const STEPS: StepDef[] = [
  { key: "network", icon: Globe, title: "اینترنت و دسترسی به گوگل", hint: "اتصال گوشی به سرورهای گوگل" },
  { key: "identity", icon: KeyRound, title: "Identity Toolkit API (ورود)", hint: "سرویس ورود با حساب گوگل" },
  { key: "firestore", icon: Server, title: "Cloud Firestore API (داده)", hint: "سرویس ذخیرهٔ اطلاعات" },
  { key: "database", icon: Database, title: "ساخت دیتابیس Firestore", hint: "ظرف نگهداری داده‌ها در سرور" },
  { key: "rules", icon: ShieldCheck, title: "قوانین امنیتی Firestore", hint: "هر کاربر فقط دادهٔ خودش" },
];

export function FirebaseSetupSheet({
  open,
  onClose,
  onStartConnect,
}: {
  open: boolean;
  onClose: () => void;
  onStartConnect: () => void;
}) {
  const { toast } = useToast();
  const cfg = getFirebaseConfig();
  const [states, setStates] = React.useState<Record<string, StepState>>({});
  const [messages, setMessages] = React.useState<Record<string, string>>({});
  const [details, setDetails] = React.useState<Record<string, string>>({});
  const [urls, setUrls] = React.useState<Record<string, string>>({});
  const [expanded, setExpanded] = React.useState<string | null>(null);
  const [checking, setChecking] = React.useState(false);
  const [checkedOnce, setCheckedOnce] = React.useState(false);
  const [everChecked, setEverChecked] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setExpanded(null);
    }
  }, [open]);

  const applyProbe = (r: FbProbeResult) => {
    const st: StepState =
      r.state === "ok" ? "ok" : r.state === "disabled" || r.state === "network" || r.state === "no_database" ? "warn" : "unknown";
    setStates((s) => ({ ...s, [r.kind]: st }));
    setMessages((m) => ({ ...m, [r.kind]: r.message }));
    const det = r.detail;
    if (det) setDetails((d) => ({ ...d, [r.kind]: det }));
    const link = r.url;
    if (link) setUrls((u) => ({ ...u, [r.kind]: link }));
  };

  /* ─── بررسی وضعیت: probes ۱-۳ خودکار + اگر متصل هستیم تست واقعی سند ─── */
  const runChecks = async () => {
    if (checking) return;
    setChecking(true);
    setCheckedOnce(true);
    setEverChecked(true);
    try {
      const acc = hasFbBridge() ? getFirebaseAccount() : { connected: false };

      // ۱) اینترنت
      setStates((s) => ({ ...s, network: "checking" }));
      applyProbe(await firebaseProbe("network"));

      // ۲) Identity Toolkit
      setStates((s) => ({ ...s, identity: "checking" }));
      applyProbe(await firebaseProbe("identity"));

      // ۳) Firestore API — ⭐ v3.9.6: endpoint اسناد؛ در «وب» نتیجهٔ آن دربارهٔ وجود دیتابیس هم حکم می‌کند
      setStates((s) => ({ ...s, firestore: "checking" }));
      const fp = await firebaseProbe("firestore");
      applyProbe(fp);
      if (fp.state === "no_database") {
        // خودِ سرویس جواب داده (404 از Firestore) → API فعال است؛ دیتابیس نیست → گام ۴ هشدار
        setStates((s) => ({ ...s, firestore: "ok" }));
        setMessages((m) => ({ ...m, firestore: "Cloud Firestore API فعال است ✓ — اما دیتابیس هنوز ساخته نشده (گام ۴ را ببینید)" }));
        setStates((s) => ({ ...s, database: "warn" }));
        setMessages((m) => ({ ...m, database: fp.message }));
        setUrls((u) => ({ ...u, database: fp.url ?? firebaseConsoleUrl(cfg.projectId) }));
      } else if (!hasFbBridge() && fp.state === "ok") {
        // در وب: پاسخ endpoint اسناد یعنی دیتابیس موجود است — قوانین بعد از اتصال دقیق چک می‌شوند
        setStates((s) => ({ ...s, database: "ok" }));
        setMessages((m) => ({ ...m, database: "دیتابیس Firestore موجود است ✓ (قوانین بعد از اتصال دقیق چک می‌شوند)" }));
      }

      // ۴+۵) دیتابیس و قوانین — فقط با نشست واقعی قابل‌تست است؛
      //      «سند نیست» یعنی قوانین درست اجازهٔ خواندن می‌دهند ✓
      if (acc.connected) {
        setStates((s) => ({ ...s, database: "checking", rules: "checking" }));
        const doc = await downloadFirebaseSnapshot();
        const docErr = doc.error;
        if (docErr) {
          const help = docErr.help;
          if (help === "database" || docErr.code === "no_database") {
            setStates((s) => ({ ...s, database: "warn" }));
            setMessages((m) => ({ ...m, database: "دیتابیس Firestore هنوز ساخته نشده — با دکمهٔ «ساخت دیتابیس» در کنسول Create database را بزنید." }));
            setUrls((u) => ({ ...u, database: firebaseConsoleUrl(cfg.projectId) }));
            setStates((s) => ({ ...s, rules: "unknown" }));
          } else if (help === "rules") {
            setStates((s) => ({ ...s, database: "ok", rules: "warn" }));
            setMessages((m) => ({
              ...m,
              database: "دیتابیس موجود است ✓",
              rules: "قوانین امنیتی اجازهٔ خواندن/نوشتن سند را نمی‌دهند — قطعه‌کد پیشنهادی را در تب Rules جای‌گذاری و Publish کنید.",
            }));
            setUrls((u) => ({ ...u, rules: firebaseRulesUrl(cfg.projectId) }));
          } else {
            setStates((s) => ({ ...s, database: "warn", rules: "unknown" }));
            setMessages((m) => ({ ...m, database: docErr.message }));
          }
        } else {
          // خواندن سند موفق بود (خالی یا پر) → دیتابیس و قوانینともاً درست‌اند
          setStates((s) => ({ ...s, database: "ok", rules: "ok" }));
          setMessages((m) => ({
            ...m,
            database: doc.missing ? "دیتابیس موجود است ✓ (هنوز پشتیبانی در آن ذخیره نشده)" : "دیتابیس موجود است ✓",
            rules: "قوانین امنیتی درست کار می‌کنند ✓",
          }));
        }
      } else {
        // ⭐ v3.9.6 — اگر بررسی پیش از ورود، وضعیت دیتابیس را تعیین کرده، همان می‌ماند
        const preDbKnown = fp.state === "no_database" || (!hasFbBridge() && fp.state === "ok");
        if (!preDbKnown) {
          setStates((s) => ({ ...s, database: "unknown", rules: "unknown" }));
          setMessages((m) => ({
            ...m,
            database: "بررسی خودکار بعد از اتصال انجام می‌شود — طبق راهنمای این گام در کنسول بسازید.",
            rules: "بررسی خودکار بعد از اتصال انجام می‌شود — قطعه‌کد پیشنهادی را جای‌گذاری کنید.",
          }));
        } else {
          setStates((s) => ({ ...s, rules: "unknown" }));
          setMessages((m) => ({ ...m, rules: "بررسی خودکار بعد از اتصال انجام می‌شود — قطعه‌کد پیشنهادی را جای‌گذاری کنید." }));
        }
      }
    } finally {
      setChecking(false);
    }
  };

  const copyRules = async () => {
    let ok = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(RULES_SNIPPET);
        ok = true;
      }
    } catch {
      /* ادامه */
    }
    if (!ok) {
      try {
        const ta = document.createElement("textarea");
        ta.value = RULES_SNIPPET;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        ok = document.execCommand("copy");
        document.body.removeChild(ta);
      } catch {
        ok = false;
      }
    }
    toast({
      title: ok ? "کپی شد ✓" : "کپی نشد",
      description: ok ? "در تب Rules کنسول جای‌گذاری و Publish کنید" : "متن را دستی انتخاب و کپی کنید",
    });
  };

  const stateIcon = (st: StepState | undefined) => {
    if (st === "checking") return <Loader2 className="size-4.5 shrink-0 animate-spin text-primary" />;
    if (st === "ok") return <CheckCircle2 className="size-4.5 shrink-0 text-emerald-600 dark:text-emerald-400" />;
    if (st === "warn") return <AlertTriangle className="size-4.5 shrink-0 text-amber-600 dark:text-amber-400" />;
    return <CircleDashed className="size-4.5 shrink-0 text-muted-foreground/60" />;
  };

  return (
    <BottomSheet
      open={open}
      onClose={() => {
        if (!checking) onClose();
      }}
      title="راه‌اندازی گام‌به‌گام سرور ابری"
      subtitle={`پروژهٔ گوگل: ${cfg.projectId} — فقط یک‌بار لازم است`}
    >
      <div className="pb-2">
        {/* توضیح ابتدای کار */}
        <div className="mb-3 rounded-2xl border border-primary/30 bg-primary/6 p-3.5">
          <p className="text-[12.5px] leading-7 text-foreground">
            سرور پشتیبان از سرویس‌های رایگان گوگل (Firebase) استفاده می‌کند. اگر «ورود به سرور پشتیبان
            انجام نشد»، یکی از تنظیم‌های زیر در کنسول گوگل ناقص است — با «بررسی وضعیت» دقیقاً
            می‌بینید کدام‌یک.
          </p>
          <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-6 text-muted-foreground">
            <Wrench className="mt-1 size-3.5 shrink-0 text-primary/80" />
            نکته: مراحل Gradle/SDK که ویزارد کنسول فایربیس نشان می‌دهد برای این برنامه لازم نیست —
            ارتباط برنامه مستقیم و بدون SDK است.
          </p>
        </div>

        {/* دکمهٔ بررسی وضعیت */}
        <button
          type="button"
          onClick={() => void runChecks()}
          disabled={checking}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[14px] font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-all active:scale-[.98] disabled:opacity-60"
        >
          {checking ? <Loader2 className="size-4.5 animate-spin" /> : <Check className="size-4.5" />}
          {checking ? "در حال بررسی…" : everChecked ? "بررسی دوبارهٔ وضعیت" : "بررسی وضعیت (توصیه می‌شود)"}
        </button>
        {checking && (
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            چند ثانیه صبر کنید — وضعیت هر مرحله با پاسخ واقعی سرور گوگل چک می‌شود…
          </p>
        )}

        {/* گام‌ها */}
        <div className="mt-3 flex flex-col gap-2">
          {STEPS.map((step, i) => {
            const st = states[step.key];
            const isOpen = expanded === step.key;
            const Icon = step.icon;
            return (
              <div
                key={step.key}
                className={cn(
                  "overflow-hidden rounded-2xl border transition-colors",
                  st === "warn" ? "border-amber-500/40 bg-amber-500/8" : "border-border/80 bg-card"
                )}
              >
                {/* ردیف گام */}
                <button
                  type="button"
                  onClick={() => setExpanded(isOpen ? null : step.key)}
                  className="flex w-full items-center gap-2.5 p-3 text-right"
                  aria-expanded={isOpen}
                >
                  {stateIcon(st)}
                  <span className="flex min-w-0 flex-1 flex-col">
                    <span className="text-[13px] font-bold text-foreground">
                      {i + 1}. {step.title}
                    </span>
                    <span className="mt-0.5 truncate text-[11px] text-muted-foreground">{step.hint}</span>
                  </span>
                  <ChevronDown className={cn("size-4 shrink-0 text-muted-foreground transition-transform", isOpen && "rotate-180")} />
                </button>

                {/* پیام وضعیت */}
                {messages[step.key] && (
                  <p
                    className={cn(
                      "border-t border-border/60 px-3 py-2 text-[11.5px] leading-6",
                      st === "ok" ? "text-emerald-700 dark:text-emerald-400" : st === "warn" ? "text-amber-700 dark:text-amber-400" : "text-muted-foreground"
                    )}
                  >
                    {messages[step.key]}
                  </p>
                )}

                {/* جزئیات گام */}
                {isOpen && (
                  <div className="border-t border-border/60 p-3">
                    {step.key === "network" && (
                      <div className="text-[12px] leading-7 text-muted-foreground">
                        اگر این مرحله قرمز است: اینترنت گوشی را بررسی کنید (محدودیت/فیلترینگ/قطعی) و دوباره
                        «بررسی وضعیت» را بزنید. سایر مراحل بدون اینترنت قابل‌ارزیابی نیستند.
                      </div>
                    )}
                    {step.key === "identity" && (
                      <div className="flex flex-col gap-2.5">
                        <ol className="list-inside list-decimal space-y-1 text-[12px] leading-6 text-muted-foreground">
                          <li>دکمهٔ زیر را بزنید — صفحهٔ فعال‌سازی در مرورگر باز می‌شود.</li>
                          <li>اگر دکمهٔ «Enable» دیدید، بزنید و چند لحظه صبر کنید.</li>
                          <li>به برنامه برگردید و «بررسی دوبارهٔ وضعیت» را بزنید.</li>
                        </ol>
                        <button
                          type="button"
                          onClick={() => openLink(urls.identity ?? identityApiEnableUrl(cfg.projectId))}
                          className="flex h-10 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[12.5px] font-bold text-primary transition-all active:scale-[.98]"
                        >
                          <ExternalLink className="size-4" />
                          فعال‌سازی Identity Toolkit API
                        </button>
                      </div>
                    )}
                    {step.key === "firestore" && (
                      <div className="flex flex-col gap-2.5">
                        <ol className="list-inside list-decimal space-y-1 text-[12px] leading-6 text-muted-foreground">
                          <li>دکمهٔ زیر را بزنید — صفحهٔ فعال‌سازی در مرورگر باز می‌شود.</li>
                          <li>اگر دکمهٔ «Enable» دیدید، بزنید و چند لحظه صبر کنید.</li>
                          <li>به برنامه برگردید و «بررسی دوبارهٔ وضعیت» را بزنید.</li>
                        </ol>
                        <button
                          type="button"
                          onClick={() => openLink(urls.firestore ?? firestoreApiEnableUrl(cfg.projectId))}
                          className="flex h-10 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[12.5px] font-bold text-primary transition-all active:scale-[.98]"
                        >
                          <ExternalLink className="size-4" />
                          فعال‌سازی Cloud Firestore API
                        </button>
                      </div>
                    )}
                    {step.key === "database" && (
                      <div className="flex flex-col gap-2.5">
                        <ol className="list-inside list-decimal space-y-1 text-[12px] leading-6 text-muted-foreground">
                          <li>دکمهٔ زیر را بزنید — کنسول Firebase باز می‌شود.</li>
                          <li>از منوی «Build» گزینهٔ «Firestore Database» را انتخاب کنید.</li>
                          <li>«Create database» را بزنید — منطقهٔ دلخواه (مثلاً us-central1) — حالت شروع «Start in test mode».</li>
                          <li>برای بررسی، «بررسی دوبارهٔ وضعیت» را بزنید (بعد از اتصال دقیق چک می‌شود).</li>
                        </ol>
                        <button
                          type="button"
                          onClick={() => openLink(urls.database ?? firebaseConsoleUrl(cfg.projectId))}
                          className="flex h-10 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[12.5px] font-bold text-primary transition-all active:scale-[.98]"
                        >
                          <Database className="size-4" />
                          باز کردن کنسول Firestore
                        </button>
                      </div>
                    )}
                    {step.key === "rules" && (
                      <div className="flex flex-col gap-2.5">
                        <ol className="list-inside list-decimal space-y-1 text-[12px] leading-6 text-muted-foreground">
                          <li>در کنسول Firebase ← Firestore Database ← تب «Rules».</li>
                          <li>قطعه‌کد زیر را کپی و جای‌گذاری کنید، بعد «Publish».</li>
                        </ol>
                        <div className="rounded-xl border border-border/80 bg-muted/50 p-2.5">
                          <div className="mb-1.5 flex items-center justify-between">
                            <p className="text-[10.5px] font-bold text-muted-foreground">قوانین پیشنهادی برنامه:</p>
                            <button
                              type="button"
                              onClick={() => void copyRules()}
                              className="flex items-center gap-1 rounded-lg bg-muted px-2 py-1 text-[10.5px] font-bold text-muted-foreground transition-all active:scale-95"
                            >
                              <Copy className="size-3" />
                              کپی
                            </button>
                          </div>
                          <pre dir="ltr" className="max-h-36 overflow-y-auto rounded-lg bg-muted/60 p-2 text-left text-[10px] leading-5 text-foreground/90">
                            {RULES_SNIPPET}
                          </pre>
                        </div>
                        <button
                          type="button"
                          onClick={() => openLink(firebaseRulesUrl(cfg.projectId))}
                          className="flex h-10 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[12.5px] font-bold text-primary transition-all active:scale-[.98]"
                        >
                          <ExternalLink className="size-4" />
                          باز کردن تب Rules
                        </button>
                      </div>
                    )}
                    {details[step.key] && (
                      <details className="mt-1.5">
                        <summary className="cursor-pointer text-[10.5px] font-bold text-muted-foreground">جزئیات فنی</summary>
                        <pre dir="ltr" className="mt-1 max-h-24 overflow-y-auto rounded-lg bg-muted/60 p-2 text-left text-[9.5px] leading-4 text-muted-foreground">
                          {details[step.key]}
                        </pre>
                      </details>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* گام پایانی — اتصال */}
        <div className="mt-3 rounded-2xl border border-primary/35 bg-primary/6 p-3.5">
          <p className="flex items-center gap-2 text-[13.5px] font-extrabold text-foreground">
            <KeyRound className="size-4.5 text-primary" />
            ۶. اتصال با حساب گوگل
          </p>
          <p className="mt-1.5 text-[11.5px] leading-6 text-muted-foreground">
            {checkedOnce
              ? "اگر همهٔ مراحل سبزند، فقط دکمهٔ زیر را بزنید — صفحهٔ ورود گوگل باز می‌شود (قابل لغو)."
              : "بعد از مراحل بالا، با دکمهٔ زیر وارد شوید — صفحهٔ ورود گوگل باز می‌شود (قابل لغو)."}
          </p>
          <button
            type="button"
            onClick={() => {
              onClose();
              onStartConnect();
            }}
            className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[14px] font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-all active:scale-[.98]"
          >
            <KeyRound className="size-4.5" />
            اتصال با حساب گوگل
          </button>
        </div>

        <p className="mt-3 px-1 text-center text-[10.5px] leading-6 text-muted-foreground">
          این تنظیم‌ها فقط یک‌بار لازم است — بعد از اتصال موفق، همگام‌سازی خودکار انجام می‌شود.
        </p>
      </div>
    </BottomSheet>
  );
}
