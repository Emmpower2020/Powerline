"use client";

/**
 * پنجرهٔ تمام‌صفحهٔ تنظیمات — زیرمنوها در پنجرهٔ جدید باز می‌شوند
 * بدون نوار ناوبری پایین و دکمهٔ افزودن؛ سربرگ رنگی (شبیه سوابق) با دکمهٔ بازگشت.
 * ⭐ v3.8.9: پنجره با createPortal به body منتقل می‌شود + اسکرول بدنه قفل می‌شود.
 *  چرا؟ پنل‌های تب داخل کاروسل (track با will-change:transform) قرار دارند و ترکِ
 *  transform‌شده «بلوک‌محتوی» عناصر position:fixed می‌شود — یعنی fixed inset-0 به‌جای
 *  viewport به جعبهٔ ترکِ (به‌بلندای کل محتوای تب!) می‌چسبید: زیرمنوها جای غلط، شیت‌ها
 *  زیر صفحه نامرئی و فقط بک‌دراپ سیاه دیده می‌شد («صفحهٔ تاریک») و با اسکرولِ آزادِ
 *  پس‌زمینه همه‌چیز می‌پرید. با پورتال به body، پوزیشن همیشه نسبت به viewport است.
 */

import * as React from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

export interface SettingsWindowProps {
  open: boolean;
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export function SettingsWindow({
  open,
  title,
  subtitle,
  onClose,
  children,
  footer,
}: SettingsWindowProps) {
  // ⭐ v3.8.9: پورتال فقط بعد از مونت کلاینت (پرهیز از ناسازگاری هیدریشن/SSG)
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    setMounted(true);
  }, []);

  // بستن با Esc
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  // ⭐ v3.8.9: قفل اسکرول بدنه حین باز بودن — پس‌زمینه نه اسکرول می‌شود نه می‌پرد
  React.useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <div
          dir="rtl"
          className="fixed inset-0 z-[70] bg-[var(--app-shell)]"
          role="dialog"
          aria-modal="true"
          aria-label={title}
        >
          <motion.div
            className="mx-auto flex h-dvh max-w-md flex-col bg-background shadow-2xl"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 340 }}
          >
            {/* ─── سربرگ رنگی — ⭐ v3.8.7: دکمهٔ بازگشت «سمت راست، قبل از عنوان» (درخواست کاربر) ─── */}
            <header className="relative shrink-0 overflow-hidden rounded-b-[28px] bg-primary px-4 pb-3.5 pt-[max(1.25rem,env(safe-area-inset-top))] text-primary-foreground shadow-lg shadow-primary/25">
              <div className="pointer-events-none absolute -left-10 -top-12 size-36 rounded-full bg-white/10" />
              <div className="pointer-events-none absolute -left-2 -bottom-16 size-28 rounded-full bg-white/8" />
              <div className="pointer-events-none absolute -right-14 -top-8 size-32 rounded-full bg-white/6" />
              <div className="relative flex items-center gap-3">
                {/* دکمهٔ بازگشت — راست‌ترین؛ عنوان بعد از آن (سمت راستِ متن سربرگ) */}
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="بازگشت به تنظیمات"
                  className="flex size-10 shrink-0 items-center justify-center rounded-full bg-white/18 backdrop-blur transition-all active:scale-95"
                >
                  <ChevronRight className="size-6" strokeWidth={2.4} />
                </button>
                <div className="min-w-0 shrink-0 text-right">
                  <h2 className="truncate text-[21px] font-extrabold leading-7 tracking-tight">{title}</h2>
                  {subtitle && (
                    <p className="mt-1 truncate text-[13px] font-bold text-primary-foreground/95">
                      {subtitle}
                    </p>
                  )}
                </div>
                <div className="min-w-0 flex-1" />
              </div>
            </header>

            {/* محتوای اسکرول‌شونده */}
            <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-[max(2rem,env(safe-area-inset-bottom))] pt-4">
              {children}
            </div>

            {/* فوتر ثابت (اختیاری) */}
            {footer && (
              <div className="shrink-0 border-t border-border bg-background px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
