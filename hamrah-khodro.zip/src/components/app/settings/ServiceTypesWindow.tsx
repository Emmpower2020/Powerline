"use client";

/**
 * پنجرهٔ «انواع سرویس» — مدیریت انواع سرویس در پنجرهٔ تمام‌صفحه
 * هر نوع: خدماتی (فقط یک قیمت) یا تعویض قطعه (قیمت قطعه + دستمزد)
 * + سرویس‌های مکمل (فقط نام — قیمت هر مکمل هنگام ثبت/ویرایش سرویس وارد می‌شود)
 */

import * as React from "react";
import { Cog, Loader2, Pencil, Plus, Save, Trash2, Wrench, X, Info, ListPlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";
import {
  SERVICE_KIND_LABELS,
  type ServiceKind,
  type ServiceTypeItem,
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import { SettingsWindow } from "./SettingsWindow";
import { BottomSheet } from "../BottomSheet";
import { SubmitButton, TextInput } from "../fields";

interface ServiceTypesWindowProps {
  open: boolean;
  onClose: () => void;
  serviceTypes: ServiceTypeItem[];
  onRefresh: () => void;
}

/* ---------------- ویرایشگر یک نوع سرویس ---------------- */

function TypeEditorSheet({
  type,
  onClose,
  onSaved,
}: {
  type: ServiceTypeItem | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [label, setLabel] = React.useState("");
  const [kind, setKind] = React.useState<ServiceKind>("SERVICE");
  const [items, setItems] = React.useState<string[]>([]);
  const [busy, setBusy] = React.useState(false);
  const [deleting, setDeleting] = React.useState(false);

  React.useEffect(() => {
    if (type) {
      setLabel(type.label);
      setKind(type.kind ?? "SERVICE");
      setItems([...(type.complementary ?? [])]);
    }
  }, [type]);

  if (!type) return null;

  const setItem = (i: number, v: string) => {
    setItems((prev) => prev.map((it, idx) => (idx === i ? v : it)));
  };
  const removeItem = (i: number) => setItems((prev) => prev.filter((_, idx) => idx !== i));
  const addItem = () => setItems((prev) => [...prev, ""]);

  const save = async () => {
    if (!label.trim()) {
      toast({ title: "خطا", description: "نام نوع سرویس را وارد کنید", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/service-types/${type.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          label: label.trim(),
          kind,
          complementary: items.map((it) => it.trim()).filter(Boolean),
        }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => null);
        throw new Error(d?.error ?? "خطا");
      }
      toast({ title: "ذخیره شد ✓", description: label.trim() });
      onSaved();
      onClose();
    } catch (e) {
      toast({
        title: "خطا",
        description: e instanceof Error ? e.message : "ذخیره نشد",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    const ok = await confirmDialog({
      title: "حذف نوع سرویس",
      message: `نوع سرویس «${type.label}» حذف شود؟`,
      confirmLabel: "حذف",
    });
    if (!ok) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/service-types/${type.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "حذف شد", description: type.label });
      onSaved();
      onClose();
    } catch {
      toast({ title: "خطا", description: "حذف نشد", variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <BottomSheet
      open={type !== null}
      onClose={onClose}
      title="ویرایش نوع سرویس"
      subtitle={type.isDefault ? "نوع پیش‌فرض برنامه" : "نوع شخصی"}
      maxHeight="max-h-[92dvh]"
      footer={
        <div className="flex gap-2">
          <button
            type="button"
            onClick={remove}
            disabled={deleting}
            aria-label="حذف نوع سرویس"
            className="flex h-12 w-14 shrink-0 items-center justify-center rounded-xl border border-red-200 bg-red-50 text-red-600 transition-colors active:scale-95 disabled:opacity-50 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400"
          >
            {deleting ? <Loader2 className="size-5 animate-spin" /> : <Trash2 className="size-5" />}
          </button>
          <SubmitButton onClick={save} disabled={busy} className="flex-1">
            {busy ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5" />}
            ذخیره تغییرات
          </SubmitButton>
        </div>
      }
    >
      {/* نام */}
      <div className="mb-4">
        <label className="mb-1.5 block text-[14px] font-semibold text-foreground">نام نوع سرویس</label>
        <TextInput dir="rtl" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="مثلاً تعویض روغن موتور" />
      </div>

      {/* نوع: خدماتی / تعویض قطعه */}
      <div className="mb-4">
        <label className="mb-1.5 block text-[14px] font-semibold text-foreground">نوع سرویس</label>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setKind("SERVICE")}
            aria-pressed={kind === "SERVICE"}
            className={cn(
              "flex flex-col items-center gap-1 rounded-2xl border-2 p-3 text-center transition-all active:scale-[.97]",
              kind === "SERVICE"
                ? "border-primary bg-primary/8"
                : "border-border/80 bg-card hover:border-primary/40"
            )}
          >
            <Cog className={cn("size-7", kind === "SERVICE" ? "text-primary" : "text-muted-foreground")} />
            <span className={cn("text-[14.5px] font-bold", kind === "SERVICE" ? "text-primary" : "text-foreground")}>
              خدماتی
            </span>
            <span className="text-[11px] leading-4 text-muted-foreground">فقط یک قیمت کل</span>
          </button>
          <button
            type="button"
            onClick={() => setKind("PART")}
            aria-pressed={kind === "PART"}
            className={cn(
              "flex flex-col items-center gap-1 rounded-2xl border-2 p-3 text-center transition-all active:scale-[.97]",
              kind === "PART" ? "border-primary bg-primary/8" : "border-border/80 bg-card hover:border-primary/40"
            )}
          >
            <Wrench className={cn("size-7", kind === "PART" ? "text-primary" : "text-muted-foreground")} />
            <span className={cn("text-[14.5px] font-bold", kind === "PART" ? "text-primary" : "text-foreground")}>
              تعویض قطعه
            </span>
            <span className="text-[11px] leading-4 text-muted-foreground">قیمت قطعه + دستمزد جدا</span>
          </button>
        </div>
      </div>

      {/* سرویس‌های مکمل — فقط نام، قیمت هنگام ثبت سرویس */}
      <div className="mb-2">
        <label className="mb-1.5 flex items-center gap-1.5 text-[14px] font-semibold text-foreground">
          <ListPlus className="size-4 text-primary" />
          سرویس‌های مکمل
          <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
            {fa(items.filter((it) => it.trim()).length)} مورد
          </span>
        </label>
        <p className="mb-2.5 text-[12px] leading-5 text-muted-foreground">
          این موارد در فرم ثبت سرویس — بعد از سرویس اصلی — همراه فیلد قیمت جداگانه نمایش داده می‌شوند و
          در جمع کل لحاظ می‌شوند. مثلاً برای تعویض روغن: فیلتر روغن، فیلتر هوا و تنظیم باد.
        </p>

        <div className="flex flex-col gap-2">
          {items.map((it, i) => (
            <div
              key={i}
              className="flex items-center gap-2 rounded-xl border border-input bg-background p-2"
            >
              <TextInput
                dir="rtl"
                value={it}
                onChange={(e) => setItem(i, e.target.value)}
                placeholder="نام مکمل — مثلاً فیلتر روغن"
                className="h-10 flex-1 text-[14px]"
              />
              <button
                type="button"
                onClick={() => removeItem(i)}
                aria-label={`حذف ${it || "مورد"}`}
                className="flex size-10 shrink-0 items-center justify-center rounded-xl text-red-500 active:bg-red-500/10"
              >
                <X className="size-4.5" />
              </button>
            </div>
          ))}

          <button
            type="button"
            onClick={addItem}
            className="flex h-11 w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-primary/40 bg-primary/5 text-[13.5px] font-bold text-primary transition-colors active:bg-primary/10"
          >
            <Plus className="size-4" />
            افزودن سرویس مکمل
          </button>
        </div>

        {kind === "SERVICE" && items.length > 0 && (
          <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-500/10 px-3.5 py-2.5 text-[12px] leading-5 text-amber-700 dark:text-amber-300">
            <Info className="mt-0.5 size-4 shrink-0" />
            سرویس‌های مکمل برای هر دو نوع «خدماتی» و «تعویض قطعه» در فرم ثبت سرویس نمایش داده می‌شوند.
          </div>
        )}
      </div>
    </BottomSheet>
  );
}

/* ---------------- پنجرهٔ اصلی ---------------- */

export function ServiceTypesWindow({ open, onClose, serviceTypes, onRefresh }: ServiceTypesWindowProps) {
  const { toast } = useToast();
  const [newType, setNewType] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [editing, setEditing] = React.useState<ServiceTypeItem | null>(null);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  /** حذف نوع سرویس — برای انواع شخصی و پیش‌فرض (سرویس‌های پیش‌فرض هم قابل حذف‌اند) */
  const removeType = async (t: ServiceTypeItem) => {
    const msg = t.isDefault
      ? `«${t.label}» یک سرویس پیش‌فرض است — حذف شود؟ (دیگر به‌صورت خودکار برنمی‌گردد)`
      : `نوع سرویس «${t.label}» حذف شود؟`;
    const ok = await confirmDialog({ title: "حذف نوع سرویس", message: msg, confirmLabel: "حذف" });
    if (!ok) return;
    setDeletingId(t.id);
    try {
      const res = await fetch(`/api/service-types/${t.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "حذف شد", description: t.label });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "حذف نشد", variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  const addType = async () => {
    if (!newType.trim()) return;
    setBusy(true);
    try {
      const res = await fetch("/api/service-types", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ label: newType.trim() }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => null);
        throw new Error(d?.error ?? "خطا");
      }
      toast({ title: "نوع سرویس اضافه شد ✓", description: newType.trim() });
      setNewType("");
      onRefresh();
    } catch (e) {
      toast({
        title: "خطا",
        description: e instanceof Error ? e.message : "ثبت نشد",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <SettingsWindow
      open={open}
      onClose={onClose}
      title="انواع سرویس"
      subtitle={`${fa(serviceTypes.length)} نوع — نوع هزینه و سرویس‌های مکمل`}
    >
      {/* افزودن نوع جدید */}
      <div className="mb-4 flex gap-2">
        <TextInput
          dir="rtl"
          value={newType}
          onChange={(e) => setNewType(e.target.value)}
          placeholder="نام نوع سرویس جدید..."
          className="flex-1"
        />
        <button
          type="button"
          onClick={addType}
          disabled={busy || !newType.trim()}
          className="flex h-12 w-14 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all active:scale-95 disabled:opacity-50"
          aria-label="افزودن نوع سرویس"
        >
          {busy ? <Loader2 className="size-5 animate-spin" /> : <Plus className="size-5" />}
        </button>
      </div>

      <p className="mb-3 text-[12px] leading-5 text-muted-foreground">
        با دکمهٔ ویرایش، «خدماتی یا تعویض قطعه» و سرویس‌های مکمل هر نوع را مشخص کنید. قیمت مکمل‌ها
        هنگام ثبت سرویس وارد می‌شود. انواع پیش‌فرض هم قابل حذف‌اند و پس از حذف، دوباره ساخته نمی‌شوند.
      </p>

      <div className="pb-2">
        {serviceTypes.map((t) => (
          <div
            key={t.id}
            className="mb-1.5 flex w-full items-center gap-1.5 rounded-xl bg-card px-2.5 py-2 text-right shadow-sm"
          >
            <div className="flex min-w-0 flex-1 items-center gap-3 rounded-lg px-1.5 py-1.5">
              <span
                className={cn(
                  "flex size-10 shrink-0 items-center justify-center rounded-xl",
                  (t.kind ?? "SERVICE") === "PART" ? "bg-primary/12" : "bg-teal-500/10"
                )}
              >
                {(t.kind ?? "SERVICE") === "PART" ? (
                  <Wrench className="size-5 text-primary" />
                ) : (
                  <Cog className="size-5 text-teal-600 dark:text-teal-300" />
                )}
              </span>
              <span className="flex min-w-0 flex-1 flex-col items-start">
                <span className="flex items-center gap-2">
                  <span className="truncate text-[16px] font-medium text-foreground">{t.label}</span>
                  {!t.isDefault && (
                    <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
                      شخصی
                    </span>
                  )}
                </span>
                <span className="mt-1 flex flex-wrap items-center gap-1.5">
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[11px] font-bold",
                      (t.kind ?? "SERVICE") === "PART"
                        ? "bg-primary/10 text-primary"
                        : "bg-teal-500/10 text-teal-700 dark:text-teal-300"
                    )}
                  >
                    {SERVICE_KIND_LABELS[t.kind ?? "SERVICE"]}
                  </span>
                  {t.complementary?.length ? (
                    <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                      {fa(t.complementary.length)} مکمل
                    </span>
                  ) : null}
                </span>
              </span>
            </div>
            {/* ویرایش + حذف — کنار هم */}
            <div className="flex shrink-0 items-center gap-0.5">
              <button
                type="button"
                onClick={() => setEditing(t)}
                aria-label={`ویرایش ${t.label}`}
                className="flex size-10 items-center justify-center rounded-xl text-muted-foreground/80 transition-colors active:bg-muted"
              >
                <Pencil className="size-4.5" />
              </button>
              <button
                type="button"
                onClick={() => removeType(t)}
                disabled={deletingId === t.id}
                aria-label={`حذف ${t.label}`}
                className="flex size-10 items-center justify-center rounded-xl text-red-500 transition-colors active:bg-red-500/10 disabled:opacity-50"
              >
                {deletingId === t.id ? (
                  <Loader2 className="size-4.5 animate-spin" />
                ) : (
                  <Trash2 className="size-4.5" />
                )}
              </button>
            </div>
          </div>
        ))}
        {serviceTypes.length === 0 && (
          <p className="py-8 text-center text-[15px] text-muted-foreground">نوع سرویسی یافت نشد</p>
        )}
      </div>

      <TypeEditorSheet
        type={editing}
        onClose={() => setEditing(null)}
        onSaved={onRefresh}
      />
    </SettingsWindow>
  );
}
