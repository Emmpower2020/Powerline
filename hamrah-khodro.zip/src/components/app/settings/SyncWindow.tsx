"use client";

/**
 * پنجرهٔ «حساب ابری» — اتصال واقعی به Google Drive با یک دکمه.
 * ⭐ v3.9.0: محتوا به DriveSyncSection تبدیل شد تا داخل «پشتیبان‌گیری و بازیابی»
 *  (BackupWindow) به‌عنوان یک تب جاسازی شود؛ SyncWindow فقط پوشش مستقل قدیمی است.
 * ⭐ v3.8.6: بازطراحی ساده برای کاربر عادی (درخواست کاربر):
 *  - خطاها «یک‌خطی» نمایش داده می‌شوند + دکمهٔ تلاش دوباره در همان خط
 *  - حالت متصل: یک کارت حساب + یک خط وضعیت + یک خط شمارش + کلید خودکار + دو دکمه
 *  - کارت‌های بزرگ راهنما حذف شدند؛ راهنمای گام‌به‌گام فقط با لینک کوچک «راهنما» باز می‌شود
 * منطق زیرین دست‌نخورده ماند (همهٔ رفتارهای v3.8.3–v3.8.5):
 *  - تبدیل کد/تأیید دسترسی واقعی Drive (probe) + نگه‌داشتن توکن سالم در خطاهای پروژه
 *  - محافظ «ابر جلوتر است» + بازیابی خودکار + تاریخچهٔ نسخه‌های گوگل
 *  - تلاش خودکار بعد از بازگشت از فعال‌سازی Drive API در مرورگر
 */
import * as React from "react";
import {
  AlertTriangle,
  Check,
  ChevronLeft,
  Cloud,
  CloudDownload,
  CloudOff,
  CloudUpload,
  ExternalLink,
  Globe,
  History,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Unlink,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";
import { withBusy } from "@/lib/busy";
import { SettingsWindow } from "./SettingsWindow";
import { BottomSheet } from "../BottomSheet";
import { SubmitButton } from "../fields";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import {
  type CloudSnapshot,
  type CloudErrorInfo,
  cancelBrowserAuth,
  cleanupLegacyKeys,
  cloudBridge,
  disconnectCloud,
  driveApiEnableUrl,
  exchangeCode,
  findCloudFile,
  findRecoverableSnapshot,
  downloadCloudSnapshot,
  getAutoSync,
  getCloudAccount,
  getSyncMeta,
  mapDriveError,
  mergeSnapshots,
  openExternalUrl,
  pollBrowserAuth,
  queueAutoSync,
  resetAutoSyncState,
  restoreFromSnapshot,
  runSyncNow,
  accountMissingBackupScope,
  scopeErrorInfo,
  setAutoSync,
  snapshotCounts,
  snapshotIsEmpty,
  startBrowserAuth,
  buildLocalSnapshot,
} from "@/lib/cloud-sync";

/** لوگوی سادهٔ گوگل (G چندرنگ) */
function GoogleLogo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
    </svg>
  );
}

function timeLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  const time = `${fa(d.getHours())}:${fa(String(d.getMinutes()).padStart(2, "0"))}`;
  return `${names[d.getDay()]} ${time}`;
}

/* ───────────────────── خط خطای یک‌خطی (درخواست کاربر v3.8.6) ───────────────────── */

/** یک خط قرمز: ⚠ پیام + دکمهٔ کوچک تلاش دوباره (+ دکمهٔ راهنمای مخصوص همان خطا) */
function ErrorLine({
  error,
  onRetry,
  retrying,
  onHelp,
  helpLabel,
  onGuide,
}: {
  error: CloudErrorInfo;
  onRetry?: () => void;
  retrying?: boolean;
  /** اکشن مخصوص همان خطا — مثل فعال‌سازی Drive API یا اتصال مجدد */
  onHelp?: () => void;
  helpLabel?: string;
  /** راهنمای گام‌به‌گام (شیت) */
  onGuide?: () => void;
}) {
  return (
    <div className="mb-3 flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/8 px-3 py-2">
      <AlertTriangle className="size-4 shrink-0 text-red-600 dark:text-red-400" />
      <p className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-foreground" title={error.message}>
        {error.message}
      </p>
      {onHelp && (
        <button
          type="button"
          onClick={onHelp}
          className="flex h-8 shrink-0 items-center gap-1 rounded-lg bg-red-600/10 px-2.5 text-[12px] font-bold text-red-700 transition-all active:scale-95 dark:text-red-400"
        >
          {helpLabel}
        </button>
      )}
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          disabled={retrying}
          aria-label="تلاش دوباره"
          className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-red-600/10 text-red-700 transition-all active:scale-95 disabled:opacity-50 dark:text-red-400"
        >
          {retrying ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
        </button>
      )}
      {onGuide && (
        <button
          type="button"
          onClick={onGuide}
          aria-label="راهنمای گام‌به‌گام"
          className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-all active:scale-95"
        >
          <ExternalLink className="size-4" />
        </button>
      )}
    </div>
  );
}

/** سوییچ سادهٔ «همگام‌سازی خودکار» */
function AutoSyncRow({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="mb-3 flex w-full items-center justify-between rounded-2xl border border-border/80 bg-card px-4 py-3 text-right transition-all active:scale-[.98]"
    >
      <span className="flex min-w-0 flex-col">
        <span className="text-[14px] font-bold text-foreground">همگام‌سازی خودکار</span>
        <span className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
          با هر تغییر، نسخهٔ جدید در Google Drive ذخیره می‌شود
        </span>
      </span>
      <span
        className={cn(
          "relative ml-3 flex h-7 w-12 shrink-0 items-center rounded-full transition-colors",
          checked ? "bg-primary" : "bg-muted"
        )}
      >
        <span
          className={cn(
            "absolute right-1 size-5.5 rounded-full bg-white shadow transition-transform duration-150",
            checked ? "-translate-x-[18px]" : "translate-x-0"
          )}
        />
      </span>
    </button>
  );
}

interface RestoreChoiceState {
  cloud: CloudSnapshot;
  cloudModified?: string;
  local: CloudSnapshot;
  /** v3.8.4: محتوای فعلی فایل ابری خالی بوده و این داده از نسخهٔ قبلیِ تاریخچهٔ گوگل گرفته شده است */
  recoveredFrom?: string;
}

/** پوشش مستقل (پنجرهٔ تمام‌صفحه) — برای استفادهٔ مستقیم در صورت لزوم */
export function SyncWindow({ open, onClose, onRestored }: { open: boolean; onClose: () => void; onRestored?: () => void }) {
  return (
    <SettingsWindow open={open} onClose={onClose} title="حساب ابری" subtitle="همگام‌سازی با Google Drive">
      {open && <DriveSyncSection onRestored={onRestored} />}
    </SettingsWindow>
  );
}

/** بخش همگام‌سازی Google Drive — قابل‌جاسازی داخل BackupWindow (v3.9.0) */
export function DriveSyncSection({ onRestored }: { onRestored?: () => void }) {
  const { toast } = useToast();
  const [supported] = React.useState(() => cloudBridge() !== null);
  const [account, setAccount] = React.useState({ connected: false, email: "" });
  const [meta, setMeta] = React.useState(getSyncMeta());
  const [auto, setAuto] = React.useState(true);

  // جریان اتصال (یک دکمه — بدون تنظیمات)
  const [flow, setFlow] = React.useState<"idle" | "browser" | "exchanging">("idle");
  const [flowError, setFlowError] = React.useState<CloudErrorInfo | null>(null);
  const [connectError, setConnectError] = React.useState<CloudErrorInfo | null>(null);

  // عملیات‌ها
  const [syncing, setSyncing] = React.useState(false);
  const [syncError, setSyncError] = React.useState<CloudErrorInfo | null>(null);
  const [disconnecting, setDisconnecting] = React.useState(false);
  const [restoring, setRestoring] = React.useState(false);
  const [restoreChoice, setRestoreChoice] = React.useState<RestoreChoiceState | null>(null);
  const [restoreBusy, setRestoreBusy] = React.useState<"" | "merge" | "cloud" | "fresh">("");

  // شیت راهنمای کنسول گوگل — موضوع‌دار (فقط با لینک کوچک باز می‌شود)
  const [helpTopic, setHelpTopic] = React.useState<"scheme" | "driveapi" | "publish" | null>(null);
  // جزییات آخرین خطای api_disabled برای ساخت لینک فعال‌سازی مستقیم
  const [apiDetail, setApiDetail] = React.useState<string | undefined>();

  const refreshState = React.useCallback(() => {
    const acc = getCloudAccount();
    setAccount({ connected: acc.connected, email: acc.email ?? "" });
    setMeta(getSyncMeta());
    setAuto(getAutoSync());
  }, []);

  React.useEffect(() => {
    // مونت = باز (بخش جاسازی‌شده در BackupWindow فقط وقتی تب فعال است رندر می‌شود)
    resetAutoSyncState();
    cleanupLegacyKeys();
    setFlow("idle");
    setFlowError(null);
    setConnectError(null);
    setSyncError(null);
    setRestoreChoice(null);
    setHelpTopic(null);
    refreshState();
  }, [refreshState]);

  /* ─── تأیید نهایی اتصال: توکن باید واقعاً به Drive دسترسی داشته باشد ───
   *  ⭐ v3.8.7: ناهمگام — برنامه هنگام گفت‌وگو با گوگل زنده می‌ماند */
  const verifyDriveAccess = async () => {
    const acc = getCloudAccount();
    if (!acc.connected) {
      setFlowError({ code: "verify", message: "دسترسی به Google Drive تأیید نشد" });
      setFlow("idle");
      return false;
    }
    // توکنِ تازه بدون drive.appdata (مجوز ناقص گوگل) — مستقیم راهنمای اتصال مجدد
    if (accountMissingBackupScope()) {
      void disconnectCloud();
      setAccount({ connected: false, email: "" });
      setFlowError(scopeErrorInfo(acc.scope));
      setFlow("idle");
      return false;
    }
    const probe = await withBusy(
      { mode: "pill", title: "در حال تأیید دسترسی به Google Drive…", detail: "بررسی توکن و پروژهٔ گوگل" },
      () => findCloudFile()
    );
    // ok فقط یعنی «درخواست به سرور رسید» — خطای HTTP گوگل هم همین‌جا بررسی می‌شود
    if (!probe.resp.ok || probe.resp.status !== 200) {
      const info = mapDriveError(probe.resp);
      if (info.code === "api_disabled" && info.detail) setApiDetail(info.detail);
      if (info.code === "scope_insufficient" || info.code === "disconnected") {
        void disconnectCloud();
        setAccount({ connected: false, email: "" });
        setFlowError(info);
      } else {
        // خطای سمت پروژهٔ گوگل (api_disabled / rate_limited / شبکه) — توکن سالم نگه می‌داریم
        setSyncError(info);
        refreshState();
      }
      setFlow("idle");
      return false;
    }
    return true;
  };

  /* ─── پولینگ جریان اتصال (بازگشت از مرورگر) ─── */
  React.useEffect(() => {
    if (flow !== "browser") return;
    let cancelled = false;
    const iv = setInterval(async () => {
      if (cancelled) return;
      const p = pollBrowserAuth();
      if (p.state === "done") {
        clearInterval(iv);
        setFlow("exchanging");
        try {
          // نشانگر سراسری — حتی اگر کاربر از پنجره بیرون رفته باشد دیده می‌شود
          const r = await withBusy(
            { mode: "pill", title: "در حال تکمیل اتصال امن…", detail: "تبدیل کد مجوز به توکن در لایهٔ جاوا" },
            () => exchangeCode()
          );
          if (!r.ok || !r.email) {
            setFlowError(r.error ?? { code: "unknown", message: "اتصال انجام نشد" });
            setFlow("idle");
            return;
          }
          if (await verifyDriveAccess()) {
            setFlow("idle");
            refreshState();
            toast({ title: "به حساب گوگل وصل شد ✓", description: r.email });
            // اولین سینک بلافاصله بعد از اتصال؛ اگر نصب تازه است و ابر پشتیبانِ پرتری
            // دارد، آپلود ممنوع است و دیالوگ بازیابی خودکار باز می‌شود (v3.8.4)
            try {
              const s = await withBusy(
                { mode: "pill", title: "در حال همگام‌سازی اولیه با Google Drive…", detail: "بررسی و ذخیرهٔ نسخهٔ پشتیبان" },
                () => runSyncNow()
              );
              if (s.ok) {
                setMeta(getSyncMeta());
              } else if (s.needsRestore && s.cloudSnapshot) {
                setMeta(getSyncMeta());
                const local = buildLocalSnapshot();
                if (local) {
                  setRestoreChoice({ cloud: s.cloudSnapshot, cloudModified: s.cloudModified, local });
                  toast({
                    title: "پشتیبان قبلی شما در Google Drive پیدا شد ✓",
                    description: "اطلاعات قبلی آمادهٔ بازگردانی است — روش بازیابی را انتخاب کنید",
                  });
                }
              }
            } catch {
              /* بی‌صدا */
            }
          } else if (getCloudAccount().connected) {
            toast({
              title: "اتصال گوگل ثبت شد",
              description: "برای شروع پشتیبان‌گیری، Drive API را فعال کنید",
            });
          }
        } catch {
          setFlow("idle");
          setFlowError({ code: "unknown", message: "اتصال انجام نشد — دوباره تلاش کنید" });
        }
      } else if (p.state === "error") {
        clearInterval(iv);
        setFlow("idle");
        setFlowError({
          code: p.error ?? "unknown",
          message:
            p.error === "access_denied"
              ? "دسترسی در صفحهٔ گوگل رد شد"
              : "ورود در مرورگر کامل نشد — دوباره تلاش کنید",
        });
      } else if (p.state === "timeout") {
        clearInterval(iv);
        setFlow("idle");
        setFlowError({
          code: "timeout",
          message: "زمان انتظار تمام شد — دوباره تلاش کنید",
        });
      }
    }, 1200);
    return () => {
      cancelled = true;
      clearInterval(iv);
    };
  }, [flow, refreshState, toast]);

  /* ─── اتصال: فقط یک دکمه — مرورگر سیستم با صفحهٔ رسمی گوگل ─── */
  const connect = () => {
    setFlowError(null);
    setConnectError(null);
    const r = startBrowserAuth();
    if (!r.ok) {
      setConnectError(r.error ?? { code: "unknown", message: "شروع اتصال ناموفق بود" });
      return;
    }
    setFlow("browser");
    toast({
      title: "صفحهٔ ورود گوگل باز شد",
      description: "حساب را انتخاب و مجوز را تأیید کنید — بعد از آن خودکار به برنامه برمی‌گردید",
    });
  };

  const cancelFlow = () => {
    if (flow === "browser") cancelBrowserAuth();
    setFlow("idle");
    setFlowError(null);
  };

  /* ─── همگام‌سازی دستی ─── */
  const syncNow = async () => {
    setSyncing(true);
    setSyncError(null);
    try {
      const r = await withBusy(
        { mode: "pill", title: "در حال همگام‌سازی با Google Drive…", detail: "ذخیرهٔ آخرین اطلاعات در ابر" },
        () => runSyncNow()
      );
      if (r.ok) {
        toast({
          title: r.unchanged ? "همگام‌سازی انجام شد ✓" : "در Google Drive ذخیره شد ✓",
          description: r.unchanged ? "اطلاعات تغییری نکرده بود" : "آخرین اطلاعات در ابر ذخیره شد",
        });
      } else if (r.needsRestore && r.cloudSnapshot) {
        // ابر جلوتر است — به‌جای آپلودِ مخرب، دیالوگ بازیابی باز می‌شود
        const local = buildLocalSnapshot();
        if (local) {
          setRestoreChoice({ cloud: r.cloudSnapshot, cloudModified: r.cloudModified, local });
          toast({
            title: "پشتیبانِ پرتری در Google Drive موجود است",
            description: "اول بازیابی/ادغام را کامل کنید",
          });
        }
      } else {
        setSyncError(r.error ?? { code: "unknown", message: "همگام‌سازی ناموفق بود" });
      }
    } finally {
      setSyncing(false);
      setMeta(getSyncMeta());
    }
  };

  /* ─── بازگشت به برنامه بعد از فعال‌سازی Drive API در مرورگر → تلاش خودکار دوباره ─── */
  const apiDisabledAt = React.useRef(0);
  const syncNowRef = React.useRef(syncNow);
  syncNowRef.current = syncNow;
  React.useEffect(() => {
    apiDisabledAt.current = syncError?.code === "api_disabled" ? Date.now() : 0;
  }, [syncError]);
  React.useEffect(() => {
    if (!supported) return;
    const onVisible = () => {
      if (document.visibilityState !== "visible") return;
      const at = apiDisabledAt.current;
      if (!at || Date.now() - at < 10_000) return;
      apiDisabledAt.current = 0;
      void syncNowRef.current();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [supported]);

  /* ─── قطع اتصال واقعی ─── */
  const disconnect = async () => {
    const ok = await confirmDialog({
      title: "قطع اتصال حساب گوگل",
      message: "اتصال به Google Drive قطع می‌شود. داده‌های محلی دست‌نخورده می‌ماند. ادامه؟",
    });
    if (!ok) return;
    setDisconnecting(true);
    try {
      const r = await withBusy(
        { mode: "pill", title: "در حال قطع اتصال…" },
        () => disconnectCloud()
      );
      if (r.ok) {
        refreshState();
        toast({ title: "اتصال قطع شد", description: r.revoked ? "دسترسی برنامه در گوگل هم باطل شد" : "اتصال محلی قطع شد" });
      } else {
        toast({ title: "خطا", description: r.error?.message ?? "قطع اتصال انجام نشد", variant: "destructive" });
      }
    } finally {
      setDisconnecting(false);
    }
  };

  /* ─── بازیابی از ابر ─── */
  const openRestore = async () => {
    setRestoring(true);
    setSyncError(null);
    try {
      const r = await withBusy(
        { mode: "pill", title: "در حال دریافت نسخهٔ پشتیبان از ابر…", detail: "خواندن فایل پشتیبان از Google Drive" },
        () => downloadCloudSnapshot()
      );
      if (!r.snapshot) {
        if (r.resp.error === "invalid_backup") {
          setSyncError({ code: "invalid_backup", message: "فایل ابری معتبر نیست — احتمالاً نسخهٔ قدیمی است" });
          return;
        }
        const st = typeof r.resp.status === "number" ? r.resp.status : 0;
        if ((r.resp.ok && st < 400) || st === 404) {
          toast({ title: "ابر خالی است", description: "هنوز فایل پشتیبانی ذخیره نشده — اول همگام‌سازی کنید" });
          return;
        }
        setSyncError(mapDriveError(r.resp));
        return;
      }
      const local = buildLocalSnapshot();
      if (!local) {
        setSyncError({ code: "local", message: "خواندن دادهٔ محلی ناموفق بود" });
        return;
      }
      // نسخهٔ فعلی ابر خالی است — تاریخچهٔ نسخه‌های گوگل برای نسخهٔ قبلیِ دارای داده جستجو می‌شود
      if (snapshotIsEmpty(r.snapshot) && r.file) {
        // ⭐ v3.8.7: جستجوی نسخه‌ها ناهمگام شد + کپسول انتظار خودش (قبلاً بی‌نشانگر و قفل‌کننده بود)
        const rec = await withBusy(
          { mode: "pill", title: "در حال جستجوی نسخه‌های قبلی…", detail: "بررسی تاریخچهٔ Google Drive" },
          () => findRecoverableSnapshot(r.file!)
        );
        if (rec.snapshot) {
          const when = rec.revision?.modifiedTime ?? r.file.modifiedTime;
          setRestoreChoice({ cloud: rec.snapshot, cloudModified: when, local, recoveredFrom: when });
          toast({
            title: "نسخهٔ قبلی پشتیبان پیدا شد ✓",
            description: "اطلاعات از تاریخچهٔ Google Drive بازیابی می‌شود",
          });
          return;
        }
        toast({
          title: "ابر خالی است",
          description: "نسخه‌های قبلی هم خالی‌اند — اول همگام‌سازی کنید",
        });
        return;
      }
      setRestoreChoice({ cloud: r.snapshot, cloudModified: r.file?.modifiedTime, local });
    } finally {
      setRestoring(false);
    }
  };

  /** پشتیبان خودکار قبل از جایگزینی — همیشه دادهٔ محلی قابل بازگشت است */
  const safetyBackup = (): void => {
    try {
      const androidApi = (globalThis as unknown as { AndroidApi?: { saveBackup?: () => string } }).AndroidApi;
      if (typeof androidApi?.saveBackup === "function") androidApi.saveBackup();
    } catch {
      /* best-effort */
    }
  };

  const doRestore = async (mode: "merge" | "cloud") => {
    if (!restoreChoice) return;
    setRestoreBusy(mode);
    try {
      const json =
        mode === "cloud"
          ? JSON.stringify(restoreChoice.cloud)
          : JSON.stringify(mergeSnapshots(restoreChoice.local, restoreChoice.cloud));
      // پردهٔ انتظار تمام‌صفحه — بازیابی داده مهم است و کاربر باید صبر کند
      const r = await withBusy(
        {
          mode: "overlay",
          title: mode === "cloud" ? "در حال بازیابی اطلاعات از ابر…" : "در حال ادغام محلی + ابری…",
          detail: "قبل از جایگزینی، از داده‌های فعلی این گوشی پشتیبان تهیه می‌شود",
        },
        () => {
          safetyBackup();
          return restoreFromSnapshot(json);
        }
      );
      if (r.ok) {
        setRestoreChoice(null);
        toast({
          title: "بازیابی از ابر انجام شد ✓",
          description: "از داده‌های قبلی هم پشتیبان در پوشهٔ Download تهیه شد",
        });
        onRestored?.();
        queueAutoSync();
      } else {
        toast({ title: "خطا", description: r.error ?? "بازیابی انجام نشد", variant: "destructive" });
      }
    } finally {
      setRestoreBusy("");
    }
  };

  /* ─── «شروع تازه» — جایگزینی صریح ابر با دادهٔ همین گوشی ─── */
  const startFresh = async () => {
    if (!restoreChoice) return;
    setRestoreBusy("fresh");
    try {
      setRestoreChoice(null);
      const r = await withBusy(
        {
          mode: "overlay",
          title: "در حال جایگزینی نسخهٔ ابری…",
          detail: "ابر با دادهٔ همین گوشی به‌روزرسانی می‌شود",
        },
        () => runSyncNow({ forceOverwrite: true })
      );
      if (r.ok) {
        setMeta(getSyncMeta());
        toast({
          title: "ابر با دادهٔ همین گوشی جایگزین شد ✓",
          description: "از این به بعد همگام‌سازی عادی ادامه می‌یابد",
        });
      } else {
        setSyncError(r.error ?? { code: "unknown", message: "شروع تازه انجام نشد" });
      }
    } finally {
      setRestoreBusy("");
    }
  };

  /* ─── قطع و اتصال مجدد با مجوز تازه — برای خطاهای «مجوز ناکافی» ─── */
  const reconnectNow = async () => {
    setDisconnecting(true);
    try {
      // ⭐ v3.8.7: قطع اتصال ناهمگام — بدون قفل‌کردن برنامه
      await withBusy({ mode: "pill", title: "در حال قطع اتصال قبلی…" }, () => disconnectCloud());
      setSyncError(null);
      setFlowError(null);
      setConnectError(null);
      refreshState();
      const r = startBrowserAuth();
      if (r.ok) {
        setFlow("browser");
        toast({
          title: "صفحهٔ مجوز گوگل باز شد",
          description: "حساب را انتخاب و روی «اجازه دادن» بزنید",
        });
      } else {
        toast({
          title: "اتصال قبلی قطع شد",
          description: "حالا دکمهٔ «به Google Drive وصل شوید» را بزنید",
        });
      }
    } finally {
      setDisconnecting(false);
    }
  };

  /* ─── رندر خط یک‌خطی با اکشن‌های مخصوص همان خطا ─── */
  const renderErrorLine = (
    err: CloudErrorInfo | null,
    opts?: { retry?: () => void; retrying?: boolean }
  ) => {
    if (!err) return null;
    // اکشن مخصوص: فقط برای خطاهایی که یک دکمهٔ مشخص دارند
    let onHelp: (() => void) | undefined;
    let helpLabel: string | undefined;
    if (err.help === "enable_drive_api") {
      onHelp = () => {
        if (err.detail) setApiDetail(err.detail);
        openExternalUrl(driveApiEnableUrl(err.detail ?? apiDetail));
      };
      helpLabel = "فعال‌سازی";
    } else if (err.help === "reconnect") {
      onHelp = () => void reconnectNow();
      helpLabel = "اتصال مجدد";
    } else if (err.help === "storage") {
      onHelp = () => openExternalUrl("https://one.google.com/storage");
      helpLabel = "مدیریت فضا";
    }
    // راهنمای گام‌به‌گام — آیکون کوچک «؟» برای همان خطا
    const onGuide =
      err.help === "enable_drive_api"
        ? () => {
            if (err.detail) setApiDetail(err.detail);
            setHelpTopic("driveapi");
          }
        : err.help === "reconnect" || err.help === "scheme"
          ? () => setHelpTopic("scheme")
          : err.help === "publish"
            ? () => setHelpTopic("publish")
            : undefined;
    return (
      <ErrorLine
        error={err}
        onRetry={opts?.retry}
        retrying={opts?.retrying}
        onHelp={onHelp}
        helpLabel={helpLabel}
        onGuide={onGuide}
      />
    );
  };

  /* ─── شمارش‌های نمایش ─── */
  const counts = meta?.counts ?? null;
  const cloudCounts = restoreChoice ? snapshotCounts(restoreChoice.cloud) : null;
  const localCounts = restoreChoice ? snapshotCounts(restoreChoice.local) : null;
  const cloudAhead =
    cloudCounts && localCounts
      ? cloudCounts.vehicles > localCounts.vehicles ||
        cloudCounts.totalRecords > localCounts.totalRecords ||
        cloudCounts.reminders > localCounts.reminders
      : false;

  return (
    <>
      {/* ─── نسخهٔ وب: صادقانه — اتصال واقعی فقط در APK ─── */}
      {!supported && (
        <div className="flex flex-col items-center rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-6 text-center">
          <span className="flex size-16 items-center justify-center rounded-full bg-primary/10">
            <Globe className="size-8 text-primary" strokeWidth={1.9} />
          </span>
          <h3 className="mt-4 text-[17px] font-extrabold text-foreground">اتصال گوگل در نسخهٔ اندروید</h3>
          <p className="mt-2 max-w-[320px] text-[13.5px] leading-7 text-muted-foreground">
            ورود امن به گوگل و ذخیره در Google Drive فقط در نسخهٔ نصبی اندروید (APK) فعال است.
          </p>
          <div className="mt-3 flex items-center gap-1.5 text-[12px] text-muted-foreground">
            <Smartphone className="size-3.5" />
            APK جدید را از بخش «درباره» نصب کنید
          </div>
        </div>
      )}

      {/* ─── هنوز وصل نشده — ساده و تمیز ─── */}
      {supported && !account.connected && flow === "idle" && (
        <>
          {renderErrorLine(connectError, { retry: connect })}
          {renderErrorLine(flowError, { retry: connect })}

          <div className="flex flex-col items-center rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-6 text-center">
            <span className="flex size-18 items-center justify-center rounded-full bg-primary/10">
              <CloudOff className="size-8 text-primary" strokeWidth={1.9} />
            </span>
            <h3 className="mt-3.5 text-[17px] font-extrabold text-foreground">پشتیبان‌گیری خودکار در ابر</h3>
            <p className="mt-1.5 max-w-[300px] text-[13px] leading-6 text-muted-foreground">
              اطلاعات خودروها و سوابق به‌صورت خودکار در Google Drive شما ذخیره می‌شود.
            </p>

            <button
              type="button"
              onClick={connect}
              className="mt-5 flex h-12 w-full max-w-xs items-center justify-center gap-2.5 rounded-xl bg-primary text-[16px] font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-transform active:scale-[.97]"
            >
              <GoogleLogo className="size-5.5" />
              به Google Drive وصل شوید
            </button>

            <p className="mt-3 flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
              <ShieldCheck className="size-3.5 text-primary" />
              ورود از صفحهٔ رسمی گوگل — رمز شما دیده نمی‌شود
            </p>

            <button
              type="button"
              onClick={() => setHelpTopic("publish")}
              className="mt-3 flex items-center gap-1 text-[11.5px] font-bold text-muted-foreground/80 transition-all active:opacity-70"
            >
              اتصال ایمیل‌های دیگر به برنامه
              <ChevronLeft className="size-3.5" />
            </button>
          </div>
        </>
      )}

      {/* ─── در حال اتصال: منتظر تأیید در مرورگر ─── */}
      {supported && flow === "browser" && (
        <div className="flex flex-col items-center rounded-2xl border border-primary/40 bg-primary/5 p-6 text-center">
          <span className="flex size-18 items-center justify-center rounded-full bg-primary/10">
            <GoogleLogo className="size-8" />
          </span>
          <h3 className="mt-3.5 text-[16px] font-extrabold text-foreground">منتظر تأیید شما در گوگل…</h3>
          <p className="mt-1.5 max-w-[300px] text-[12.5px] leading-6 text-muted-foreground">
            در مرورگر حساب را انتخاب و اجازهٔ دسترسی را تأیید کنید — بعد از آن خودکار برمی‌گردید.
          </p>
          <div className="mt-3 flex items-center gap-2 text-[12.5px] font-bold text-primary">
            <Loader2 className="size-4 animate-spin" />
            در حال بررسی…
          </div>
          <button
            type="button"
            onClick={cancelFlow}
            className="mt-4 flex h-11 w-full max-w-[220px] items-center justify-center rounded-xl bg-muted text-[14.5px] font-bold text-foreground transition-all active:scale-[.98]"
          >
            لغو
          </button>
        </div>
      )}

      {/* ─── در حال اتصال: تبادل توکن ─── */}
      {supported && flow === "exchanging" && (
        <div className="flex flex-col items-center rounded-2xl border border-primary/40 bg-primary/5 p-8 text-center">
          <Loader2 className="size-10 animate-spin text-primary" />
          <p className="mt-4 text-[15px] font-bold text-foreground">در حال تکمیل اتصال امن…</p>
          <p className="mt-1 text-[12.5px] text-muted-foreground">در حال تأیید دسترسی با سرور گوگل</p>
        </div>
      )}

      {/* ─── حساب متصل — ساده و یک‌خطی (بازطراحی v3.8.6) ─── */}
      {supported && account.connected && flow === "idle" && (
        <>
          {/* کارت حساب — یک ردیف */}
          <div className="mb-3 flex items-center gap-3 rounded-2xl border border-primary/40 bg-primary/8 p-3.5">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/15">
              <Cloud className="size-5.5 text-primary" strokeWidth={2} />
            </span>
            <div className="min-w-0 flex-1">
              <p dir="ltr" className="truncate text-right text-[14.5px] font-bold text-foreground">
                {account.email}
              </p>
              <p className="flex items-center gap-1 text-[11.5px] font-medium text-muted-foreground">
                <Check className="size-3 text-emerald-600 dark:text-emerald-400" />
                متصل به Google Drive
              </p>
            </div>
            <button
              type="button"
              onClick={disconnect}
              disabled={disconnecting}
              aria-label="قطع اتصال"
              className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-red-500/10 text-red-600 transition-all active:scale-95 disabled:opacity-50 dark:text-red-400"
            >
              {disconnecting ? <Loader2 className="size-4.5 animate-spin" /> : <Unlink className="size-4.5" />}
            </button>
          </div>

          {/* خط خطای سینک (اگر باشد) — یک‌خطی + تلاش دوباره؛ جایگزین خط وضعیت می‌شود
              تا همان پیام دو بار تکرار نشود (سادگی = درخواست کاربر) */}
          {syncError && renderErrorLine(syncError, { retry: syncNow, retrying: syncing })}

          {/* وضعیت — یک خط (وقتی خطای فعال نداریم) */}
          {!syncError && (meta?.status === "cloud_ahead" ? (
            <div className="mb-3 flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/8 px-3 py-2">
              <CloudDownload className="size-4 shrink-0 text-amber-600 dark:text-amber-400" />
              <p className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-foreground">
                {counts
                  ? `پشتیبان قبلی (${fa(counts.vehicles)} خودرو، ${fa(counts.totalRecords)} رکورد) منتظر بازیابی است`
                  : "پشتیبان قبلی در ابر منتظر بازیابی است"}
              </p>
              <button
                type="button"
                onClick={openRestore}
                disabled={restoring}
                className="flex h-8 shrink-0 items-center gap-1 rounded-lg bg-amber-600/10 px-2.5 text-[12px] font-bold text-amber-700 transition-all active:scale-95 disabled:opacity-50 dark:text-amber-400"
              >
                بازیابی
              </button>
            </div>
          ) : meta ? (
            <div
              className={cn(
                "mb-3 flex items-center gap-2 rounded-xl border px-3 py-2",
                meta.status === "failed"
                  ? "border-red-500/30 bg-red-500/8"
                  : "border-border/80 bg-card"
              )}
            >
              {meta.status === "failed" ? (
                <AlertTriangle className="size-4 shrink-0 text-red-600 dark:text-red-400" />
              ) : (
                <CloudUpload className="size-4 shrink-0 text-primary" />
              )}
              <p className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-foreground">
                {meta.status === "ok"
                  ? `آخرین همگام‌سازی: ${timeLabel(meta.at)}${meta.unchanged ? " — بدون تغییر" : ""}`
                  : `آخرین همگام‌سازی ناموفق: ${meta.error ?? ""}`}
              </p>
              {meta.status === "ok" && counts && (
                <span className="shrink-0 rounded-full bg-muted px-2 py-0.5 text-[10.5px] font-bold tabular-nums text-muted-foreground">
                  {fa(counts.totalRecords)} رکورد
                </span>
              )}
            </div>
          ) : (
            <div className="mb-3 flex items-center gap-2 rounded-xl border border-border/80 bg-card px-3 py-2">
              <CloudUpload className="size-4 shrink-0 text-muted-foreground" />
              <p className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-muted-foreground">
                هنوز همگام‌سازی انجام نشده
              </p>
            </div>
          ))}

          {/* شمارش در ابر — یک خط جمع‌وجور */}
          {counts && meta?.status === "ok" && (
            <p className="mb-3 px-1 text-[11.5px] text-muted-foreground">
              در ابر: {fa(counts.vehicles)} خودرو • {fa(counts.services)} سرویس • {fa(counts.fuels)} سوخت‌گیری •{" "}
              {fa(counts.reminders)} یادآور
            </p>
          )}

          {/* سینک خودکار */}
          <AutoSyncRow
            checked={auto}
            onChange={(v) => {
              setAutoSync(v);
              setAuto(v);
              if (v) queueAutoSync();
            }}
          />

          {/* دکمه‌ها */}
          <div className="mb-2 flex flex-col gap-2.5">
            <SubmitButton onClick={syncNow} disabled={syncing}>
              {syncing ? <Loader2 className="size-5 animate-spin" /> : <RefreshCw className="size-5" />}
              {syncing ? "در حال همگام‌سازی…" : "همگام‌سازی الان"}
            </SubmitButton>
            <button
              type="button"
              onClick={openRestore}
              disabled={restoring}
              className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[15px] font-bold text-primary transition-all active:scale-[.98] disabled:opacity-50"
            >
              {restoring ? <Loader2 className="size-5 animate-spin" /> : <CloudDownload className="size-5" />}
              بازیابی از ابر
            </button>
          </div>
        </>
      )}

      {/* ─── شیت انتخاب روش بازیابی ─── */}
      <BottomSheet
        open={restoreChoice !== null}
        onClose={() => {
          if (!restoreBusy) setRestoreChoice(null);
        }}
        title="بازیابی از Google Drive"
        subtitle="قبل از جایگزینی، از داده‌های فعلی پشتیبان تهیه می‌شود"
      >
        {restoreChoice && cloudCounts && localCounts && (
          <>
            {/* بازیابی از تاریخچهٔ نسخه‌های گوگل (نسخهٔ فعلی ابر خالی بوده) */}
            {restoreChoice.recoveredFrom && (
              <div className="mb-4 flex items-start gap-2.5 rounded-2xl border border-amber-500/40 bg-amber-500/8 p-3.5">
                <History className="mt-0.5 size-5 shrink-0 text-amber-600 dark:text-amber-400" />
                <p className="text-[12px] leading-6 text-muted-foreground">
                  نسخهٔ فعلی فایل ابری خالی بود — این اطلاعات از نسخهٔ قبلیِ تاریخچهٔ Google Drive
                  {restoreChoice.recoveredFrom
                    ? ` (${new Date(restoreChoice.recoveredFrom).toLocaleString("fa-IR")})`
                    : ""}{" "}
                  بازیابی می‌شود.
                </p>
              </div>
            )}

            {/* مقایسه */}
            <div className="mb-4 grid grid-cols-2 gap-2.5">
              <div className="rounded-2xl border border-border/80 bg-card p-3.5">
                <p className="text-[12px] font-bold text-muted-foreground">این گوشی</p>
                <p className="mt-1.5 text-[13px] font-extrabold tabular-nums text-foreground">
                  {fa(localCounts.vehicles)} خودرو • {fa(localCounts.totalRecords)} رکورد
                </p>
              </div>
              <div className="rounded-2xl border border-primary/40 bg-primary/8 p-3.5">
                <p className="text-[12px] font-bold text-primary">Google Drive</p>
                <p className="mt-1.5 text-[13px] font-extrabold tabular-nums text-foreground">
                  {fa(cloudCounts.vehicles)} خودرو • {fa(cloudCounts.totalRecords)} رکورد
                </p>
                {restoreChoice.cloudModified && (
                  <p className="mt-1 text-[10.5px] text-muted-foreground">
                    {new Date(restoreChoice.cloudModified).toLocaleString("fa-IR")}
                  </p>
                )}
              </div>
            </div>

            <div className="mb-3 flex items-center justify-center gap-1.5 text-[11.5px] text-muted-foreground">
              <ShieldCheck className="size-3.5 text-emerald-600 dark:text-emerald-400" />
              قبل از هر تغییری از داده‌های فعلی پشتیبان خودکار گرفته می‌شود
            </div>

            <div className="flex flex-col gap-2.5 pb-2">
              <SubmitButton onClick={() => doRestore("merge")} disabled={restoreBusy !== ""}>
                {restoreBusy === "merge" ? <Loader2 className="size-5 animate-spin" /> : <Check className="size-5" />}
                ادغام محلی + ابری (پیشنهادی)
              </SubmitButton>
              <button
                type="button"
                onClick={() => doRestore("cloud")}
                disabled={restoreBusy !== ""}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/8 text-[15px] font-bold text-red-700 transition-all active:scale-[.98] disabled:opacity-50 dark:text-red-400"
              >
                {restoreBusy === "cloud" ? <Loader2 className="size-5 animate-spin" /> : <CloudDownload />}
                جایگزینی کامل با نسخهٔ ابری
              </button>
              <button
                type="button"
                onClick={() => setRestoreChoice(null)}
                disabled={restoreBusy !== ""}
                className="flex h-11 w-full items-center justify-center rounded-xl bg-muted text-[14.5px] font-bold text-foreground transition-all active:scale-[.98] disabled:opacity-50"
              >
                انصراف
              </button>

              {/* فقط وقتی ابر پرتر از گوشی است — جایگزینی صریح ابر با دادهٔ همین گوشی */}
              {cloudAhead && (
                <>
                  <button
                    type="button"
                    onClick={startFresh}
                    disabled={restoreBusy !== ""}
                    className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-red-500/30 bg-red-500/5 text-[13.5px] font-bold text-red-600 transition-all active:scale-[.98] disabled:opacity-50 dark:text-red-400"
                  >
                    {restoreBusy === "fresh" ? (
                      <Loader2 className="size-4.5 animate-spin" />
                    ) : (
                      <CloudOff className="size-4.5" />
                    )}
                    شروع تازه — ابر با دادهٔ همین گوشی جایگزین شود
                  </button>
                </>
              )}
            </div>
          </>
        )}
      </BottomSheet>

      {/* ─── شیت راهنمای گوگل — فقط با لینک کوچک باز می‌شود ─── */}
      <BottomSheet
        open={helpTopic !== null}
        onClose={() => setHelpTopic(null)}
        title={
          helpTopic === "driveapi"
            ? "فعال‌سازی Google Drive API"
            : helpTopic === "publish"
              ? "دسترسی همهٔ ایمیل‌های گوگل"
              : "فعال‌سازی ورود گوگل"
        }
      >
        {helpTopic === "scheme" && (
          <ol className="mb-4 flex flex-col gap-3">
            {[
              {
                n: 1,
                t: "در console.cloud.google.com پروژهٔ «همراه خودرو» را باز کنید",
                d: "بخش APIs & Services ← Credentials",
              },
              {
                n: 2,
                t: "کلاینت اندروید برنامه را باز کنید",
                d: "روی OAuth client نوع Android کلیک کنید",
              },
              {
                n: 3,
                t: "«Enable custom URI scheme» را روشن کنید",
                d: "در Advanced settings کلاینت + Save",
              },
              {
                n: 4,
                t: "به برنامه برگردید و دوباره وصل شوید",
                d: "این‌بار صفحهٔ ورود گوگل کامل باز می‌شود",
              },
            ].map((s) => (
              <li key={s.n} className="flex gap-3 rounded-2xl border border-border/80 bg-card p-3.5">
                <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/12 text-[13px] font-extrabold text-primary">
                  {fa(s.n)}
                </span>
                <div className="min-w-0">
                  <p className="text-[13.5px] font-bold text-foreground">{s.t}</p>
                  <p className="mt-1 text-[12.5px] leading-6 text-muted-foreground">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
        )}

        {helpTopic === "driveapi" && (
          <>
            <ol className="mb-4 flex flex-col gap-3">
              {[
                { n: 1, t: "باز کردن صفحهٔ فعال‌سازی", d: "دکمهٔ زیر — صفحهٔ رسمی گوگل با پروژهٔ برنامه" },
                { n: 2, t: "روی «Enable» بزنید", d: "رایگان و فوری فعال می‌شود" },
                { n: 3, t: "به برنامه برگردید", d: "همگام‌سازی خودکار دوباره انجام می‌شود" },
              ].map((s) => (
                <li key={s.n} className="flex gap-3 rounded-2xl border border-border/80 bg-card p-3.5">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/12 text-[13px] font-extrabold text-primary">
                    {fa(s.n)}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-bold text-foreground">{s.t}</p>
                    <p className="mt-1 text-[12.5px] leading-6 text-muted-foreground">{s.d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mb-3 flex flex-col gap-2.5">
              <SubmitButton onClick={() => openExternalUrl(driveApiEnableUrl(apiDetail))}>
                <ExternalLink className="size-5" />
                باز کردن صفحهٔ فعال‌سازی Drive API
              </SubmitButton>
            </div>
          </>
        )}

        {helpTopic === "publish" && (
          <>
            <p className="mb-3 px-1 text-[13px] leading-7 text-foreground">
              الان فقط ایمیل‌های ثبت‌شده در پروژهٔ گوگل می‌توانند وصل شوند. برای «همهٔ ایمیل‌ها»:
            </p>
            <ol className="mb-4 flex flex-col gap-3">
              {[
                {
                  n: 1,
                  t: "افزودن ایمیل‌ها به‌عنوان Test User (ساده‌تر)",
                  d: "در کنسول: OAuth consent screen ← Audience ← + Add users (تا ۱۰۰ ایمیل)",
                },
                {
                  n: 2,
                  t: "یا انتشار کامل: دکمهٔ PUBLISH APP",
                  d: "همان صفحهٔ Audience — بعد از انتشار، اولین ورود هر ایمیل هشدار «تأییدنشده» می‌دهد: Advanced ← Go to (unsafe) — طبیعی است",
                },
              ].map((s) => (
                <li key={s.n} className="flex gap-3 rounded-2xl border border-border/80 bg-card p-3.5">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/12 text-[13px] font-extrabold text-primary">
                    {fa(s.n)}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-bold text-foreground">{s.t}</p>
                    <p className="mt-1 text-[12.5px] leading-6 text-muted-foreground">{s.d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mb-3 flex flex-col gap-2.5">
              <SubmitButton onClick={() => openExternalUrl("https://console.cloud.google.com/auth/audience")}>
                <ExternalLink className="size-5" />
                باز کردن صفحهٔ Audience در کنسول
              </SubmitButton>
            </div>
          </>
        )}

        <div className="pb-2">
          <SubmitButton onClick={() => setHelpTopic(null)}>متوجه شدم</SubmitButton>
        </div>
      </BottomSheet>
    </>
  );
}
