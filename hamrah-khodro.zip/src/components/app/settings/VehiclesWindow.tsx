"use client";

/**
 * پنجرهٔ «خودروهای من» — مدیریت کامل خودروها در پنجرهٔ تمام‌صفحه
 * افزودن / ویرایش / حذف / انتخاب خودروی فعال
 */

import * as React from "react";
import { Car, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa, faNum } from "@/lib/persian";
import {
  CAR_STATUS_LABELS,
  FUEL_TYPE_LABELS,
  TRANSMISSION_LABELS,
  type RecordItem,
  type ReminderItem,
  type VehicleItem,
} from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import { PlateView } from "../shared";
import { SettingsWindow } from "./SettingsWindow";

interface VehiclesWindowProps {
  open: boolean;
  onClose: () => void;
  vehicles: VehicleItem[];
  records: RecordItem[];
  reminders: ReminderItem[];
  currentKmByVehicle: Map<string, number>;
  activeVehicleId: string | null;
  onSetActive: (id: string) => void;
  onAdd: () => void;
  onEdit: (v: VehicleItem) => void;
  onDeleted: () => void;
}

export function VehiclesWindow({
  open,
  onClose,
  vehicles,
  records,
  reminders,
  currentKmByVehicle,
  activeVehicleId,
  onSetActive,
  onAdd,
  onEdit,
  onDeleted,
}: VehiclesWindowProps) {
  const { toast } = useToast();
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  const removeVehicle = async (v: VehicleItem) => {
    const recCount = records.filter((r) => r.vehicleId === v.id).length;
    const ok = await confirmDialog({
      title: "حذف خودرو",
      message: `خودرو «${v.name}» با ${fa(recCount)} رکورد و یادآورهایش حذف شود؟`,
      confirmLabel: "حذف خودرو",
    });
    if (!ok) return;
    setDeletingId(v.id);
    try {
      const res = await fetch(`/api/vehicles/${v.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      toast({ title: "حذف شد", description: `خودرو «${v.name}» حذف شد` });
      onDeleted();
    } catch {
      toast({ title: "خطا", description: "حذف انجام نشد", variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <SettingsWindow
      open={open}
      onClose={onClose}
      title="خودروهای من"
      subtitle={`${fa(vehicles.length)} خودرو — انتخاب، ویرایش و مدیریت`}
    >
      <div className="flex flex-col gap-3">
        {vehicles.map((v) => {
          const km = currentKmByVehicle.get(v.id) ?? v.mileage;
          const recCount = records.filter((r) => r.vehicleId === v.id).length;
          const remCount = reminders.filter((r) => r.vehicleId === v.id && !r.done).length;
          const isActive = v.id === activeVehicleId;
          return (
            <div
              key={v.id}
              className={cn(
                "rounded-2xl border bg-card p-4 shadow-sm transition-colors",
                isActive ? "border-primary/45 ring-1 ring-primary/20" : "border-border/80"
              )}
            >
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onSetActive(v.id)}
                  aria-label={`انتخاب ${v.name} به‌عنوان خودروی فعال`}
                  className={cn(
                    "flex size-14 shrink-0 items-center justify-center overflow-hidden rounded-xl transition-colors",
                    v.imageData
                      ? isActive
                        ? "ring-2 ring-primary ring-offset-2 ring-offset-card"
                        : "border border-border/80"
                      : isActive
                        ? "bg-primary text-primary-foreground"
                        : "bg-primary/10 text-primary"
                  )}
                >
                  {v.imageData ? (
                    <img
                      src={v.imageData}
                      alt={`عکس ${v.name}`}
                      className="size-14 object-cover"
                    />
                  ) : (
                    <Car className="size-6" strokeWidth={2} />
                  )}
                </button>
                <div className="min-w-0 flex-1">
                  <h3 className="flex items-center gap-2 truncate text-[16px] font-bold text-foreground">
                    <span className="truncate">{v.name}</span>
                    {isActive && (
                      <span className="shrink-0 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
                        فعال
                      </span>
                    )}
                  </h3>
                  <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12.5px] text-muted-foreground">
                    {v.plate && <PlateView plate={v.plate} size="sm" />}
                    {v.year && <span>• {fa(v.year)}</span>}
                    {v.status !== "ACTIVE" && (
                      <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[11px] font-bold text-amber-700 dark:text-amber-300">
                        {CAR_STATUS_LABELS[v.status]}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-2 flex flex-wrap gap-1.5 text-[11.5px]">
                <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                  {FUEL_TYPE_LABELS[v.fuelType]}
                </span>
                <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                  {TRANSMISSION_LABELS[v.transmission]}
                </span>
                {v.color && (
                  <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">{v.color}</span>
                )}
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-muted/50 p-2.5 text-center">
                <div>
                  <div className="text-[13px] font-extrabold tabular-nums text-foreground">{faNum(km)}</div>
                  <div className="mt-0.5 text-[10.5px] text-muted-foreground">کیلومتر</div>
                </div>
                <div className="border-x border-border/60">
                  <div className="text-[13px] font-extrabold text-foreground">{fa(recCount)}</div>
                  <div className="mt-0.5 text-[10.5px] text-muted-foreground">رکورد</div>
                </div>
                <div>
                  <div className="text-[13px] font-extrabold text-foreground">{fa(remCount)}</div>
                  <div className="mt-0.5 text-[10.5px] text-muted-foreground">یادآور فعال</div>
                </div>
              </div>

              <div className="mt-3 flex gap-2">
                {!isActive && (
                  <button
                    type="button"
                    onClick={() => onSetActive(v.id)}
                    className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-primary/10 text-[14px] font-bold text-primary transition-all active:scale-95"
                  >
                    انتخاب به‌عنوان فعال
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onEdit(v)}
                  className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-muted text-[14px] font-bold text-foreground transition-all active:scale-95"
                >
                  <Pencil className="size-4" />
                  ویرایش
                </button>
                <button
                  type="button"
                  disabled={deletingId === v.id}
                  onClick={() => removeVehicle(v)}
                  aria-label={`حذف ${v.name}`}
                  className="flex size-10 items-center justify-center rounded-xl bg-red-500/10 text-red-600 transition-all active:scale-95 disabled:opacity-50"
                >
                  {deletingId === v.id ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <Trash2 className="size-4" />
                  )}
                </button>
              </div>
            </div>
          );
        })}

        {vehicles.length === 0 && (
          <div className="flex flex-col items-center rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-8 text-center">
            <Car className="size-10 text-primary" strokeWidth={1.8} />
            <p className="mt-3 text-[15px] font-bold text-foreground">هنوز خودرویی ثبت نشده</p>
            <p className="mt-1 text-[13px] leading-6 text-muted-foreground">
              اولین خودروی خود را اضافه کنید تا سوابق سرویس و سوختش را ثبت کنید.
            </p>
          </div>
        )}

        {/* افزودن خودرو */}
        <button
          type="button"
          onClick={onAdd}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-primary/40 bg-primary/5 text-[15px] font-bold text-primary transition-colors active:bg-primary/10"
        >
          <Plus className="size-5" />
          {vehicles.length === 0 ? "افزودن اولین خودرو" : "افزودن خودرو جدید"}
        </button>
      </div>
    </SettingsWindow>
  );
}
