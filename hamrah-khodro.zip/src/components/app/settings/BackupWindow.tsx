"use client";

/**
 * پنجرهٔ «پشتیبان‌گیری و بازیابی» (v3.9.3) — همهٔ منوهای پشتیبان در یک زیرمنو:
 *  ۱) تب «سرور ابری»  — Firebase با «حساب گوگل» (OAuth در مرورگر سیستم از طریق
 *     CloudBridge جاوا؛ بدون ایمیل/رمز جدا) + Firestore — REST خالص.
 *     ⭐ v3.9.3: کارت‌های خطای هوشمند با دکمهٔ مستقیم کنسول گوگل:
 *     فعال‌سازی Identity Toolkit / Firestore API، ساخت دیتابیس، قوانین امنیتی،
 *     تیک Custom URI Scheme — + چک‌لیست ۳ مرحله‌ای راه‌اندازی در همان کارت.
 *  ۲) تب «Google Drive» — همان DriveSyncSection نسخه‌های قبل.
 *  ۳) تب «فایل پشتیبان» — ذخیره در پوشهٔ Download گوشی + بازیابی از فایل.
 *
 * منطق‌های امنیتی مشترک حفظ شده: پیام موفقیت فقط با پاسخ واقعی سرور؛ پشتیبان خودکار
 * محلی قبل از هر جایگزینی؛ خطا هرگز دادهٔ محلی را دست نمی‌زند؛ ادغام بدون تکرار.
 */

import * as React from "react";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Cloud,
  CloudDownload,
  CloudUpload,
  Copy,
  Database,
  Download,
  ExternalLink,
  KeyRound,
  ListChecks,
  Loader2,
  LogOut,
  RefreshCw,
  Server,
  ShieldCheck,
  Upload,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { fa } from "@/lib/persian";
import { withBusy } from "@/lib/busy";
import { SettingsWindow } from "./SettingsWindow";
import { BottomSheet } from "../BottomSheet";
import { SubmitButton } from "../fields";
import { DriveSyncSection } from "./SyncWindow";
import { FirebaseSetupSheet } from "./FirebaseSetupSheet";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import {
  firebaseConsoleUrl,
  firestoreApiEnableUrl,
  getFirebaseConfig,
  identityApiEnableUrl,
  oauthClientsUrl,
} from "@/lib/firebase-config";
import {
  applyFirebaseSnapshot,
  buildLocalSnapshotPublic,
  downloadFirebaseSnapshot,
  firebaseConnectCancel,
  firebaseConnectComplete,
  firebaseConnectPoll,
  firebaseConnectStart,
  firebaseDisconnect,
  getFbAutoSync,
  getFbSyncMeta,
  getFirebaseAccount,
  hasFbBridge,
  mergeWithLocal,
  queueFirebaseAutoSync,
  resetFirebaseSyncState,
  runFirebaseSyncNow,
  setFbAutoSync,
  type CloudSnapshotAlias,
  type FbErrorInfo,
} from "@/lib/firebase-sync";
import { openExternalUrl, snapshotCounts, snapshotIsEmpty } from "@/lib/cloud-sync";

type BackupTab = "server" | "drive" | "file";

const TABS: { key: BackupTab; label: string; icon: React.ElementType }[] = [
  { key: "server", label: "سرور ابری", icon: Server },
  { key: "drive", label: "Google Drive", icon: Cloud },
  { key: "file", label: "فایل پشتیبان", icon: Database },
];

function timeLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  const time = `${fa(d.getHours())}:${fa(String(d.getMinutes()).padStart(2, "0"))}`;
  return `${names[d.getDay()]} ${time}`;
}

/** باز کردن لینک در مرورگر گوشی (لایهٔ جاوا) — در وب آزمایشی */
function openLink(url: string): void {
  void openExternalUrl(url);
}

async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* ادامه */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

const RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write:
        if request.auth != null
        && request.auth.uid == uid;
    }
  }
}`;

/* ─────────────── کارت خطای هوشمند — دکمهٔ اقدام + چک‌لیست راه‌اندازی ─────────────── */

function SetupChecklist({ highlight }: { highlight?: FbErrorInfo["help"] }) {
  const cfg = getFirebaseConfig();
  const steps: { key: NonNullable<FbErrorInfo["help"]>; title: string; url: string }[] = [
    { key: "identity-api", title: "فعال‌سازی Identity Toolkit API (ورود)", url: identityApiEnableUrl(cfg.projectId) },
    { key: "firestore-api", title: "فعال‌سازی Cloud Firestore API (داده)", url: firestoreApiEnableUrl(cfg.projectId) },
    { key: "database", title: "ساخت دیتابیس Firestore + قوانین", url: firebaseConsoleUrl(cfg.projectId) },
  ];
  return (
    <div className="mt-3 rounded-xl border border-border/80 bg-muted/50 p-2.5">
      <p className="mb-2 text-[11px] font-bold text-muted-foreground">
        چک‌لیست راه‌اندازی پروژهٔ گوگل (همه را یک‌بار انجام دهید):
      </p>
      <div className="flex flex-col gap-1.5">
        {steps.map((s) => (
          <button
            key={s.key}
            type="button"
            onClick={() => openLink(s.url)}
            className={cn(
              "flex items-center gap-2 rounded-lg px-2.5 py-2 text-right text-[12px] font-bold transition-all active:scale-[.98]",
              highlight === s.key
                ? "bg-primary/15 text-primary"
                : "bg-card text-foreground/80 hover:bg-card"
            )}
          >
            <ExternalLink className="size-3.5 shrink-0" />
            <span className="min-w-0 flex-1">{s.title}</span>
            {highlight === s.key && (
              <span className="shrink-0 rounded-full bg-primary px-1.5 py-0.5 text-[9.5px] font-extrabold text-primary-foreground">
                لازم
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

function FbErrorCard({
  error,
  onRetry,
  retrying,
  onSetup,
}: {
  error: FbErrorInfo;
  onRetry: () => void;
  retrying?: boolean;
  /** v3.9.5 — باز کردن شیت راه‌اندازی گام‌به‌گام */
  onSetup?: () => void;
}) {
  const { toast } = useToast();
  const [showDetail, setShowDetail] = React.useState(false);
  const isSetup = error.help === "identity-api" || error.help === "firestore-api" || error.help === "database" || error.help === "rules";

  return (
    <div className="mb-3 rounded-2xl border border-amber-500/40 bg-amber-500/8 p-3.5">
      <div className="flex items-start gap-2.5">
        <AlertTriangle className="mt-0.5 size-5 shrink-0 text-amber-600 dark:text-amber-400" />
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-bold leading-6 text-foreground">{error.message}</p>

          {/* دکمهٔ اقدام اصلی — بسته به نوع خطا */}
          {error.help === "identity-api" && (
            <SubmitButton
              onClick={() => openLink(error.url ?? identityApiEnableUrl(getFirebaseConfig().projectId))}
              className="mt-3"
            >
              <ExternalLink className="size-5" />
              فعال‌سازی Identity Toolkit API
            </SubmitButton>
          )}
          {error.help === "firestore-api" && (
            <SubmitButton
              onClick={() => openLink(error.url ?? firestoreApiEnableUrl(getFirebaseConfig().projectId))}
              className="mt-3"
            >
              <ExternalLink className="size-5" />
              فعال‌سازی Cloud Firestore API
            </SubmitButton>
          )}
          {error.help === "database" && (
            <SubmitButton onClick={() => openLink(error.url ?? firebaseConsoleUrl(getFirebaseConfig().projectId))} className="mt-3">
              <Database className="size-5" />
              ساخت دیتابیس (Firebase)
            </SubmitButton>
          )}
          {error.help === "rules" && (
            <>
              <SubmitButton onClick={() => openLink(error.url ?? firebaseConsoleUrl(getFirebaseConfig().projectId))} className="mt-3">
                <ExternalLink className="size-5" />
                باز کردن قوانین Firestore
              </SubmitButton>
              <div className="mt-2.5 rounded-xl border border-border/80 bg-card p-2.5">
                <div className="mb-1.5 flex items-center justify-between">
                  <p className="text-[11px] font-bold text-muted-foreground">قوانین پیشنهادی — در تب Rules جای‌گذاری و Publish کنید:</p>
                  <button
                    type="button"
                    onClick={async () => {
                      const ok = await copyText(RULES_SNIPPET);
                      toast({
                        title: ok ? "کپی شد ✓" : "کپی نشد",
                        description: ok ? "در تب Rules کنسول جای‌گذاری کنید" : "متن را دستی انتخاب و کپی کنید",
                      });
                    }}
                    className="flex items-center gap-1 rounded-lg bg-muted px-2 py-1 text-[10.5px] font-bold text-muted-foreground transition-all active:scale-95"
                  >
                    <Copy className="size-3" />
                    کپی
                  </button>
                </div>
                <pre dir="ltr" className="max-h-40 overflow-y-auto rounded-lg bg-muted/60 p-2 text-left text-[10px] leading-5 text-foreground/90">
                  {RULES_SNIPPET}
                </pre>
              </div>
            </>
          )}
          {error.help === "uri-scheme" && (
            <SubmitButton onClick={() => openLink(error.url ?? oauthClientsUrl(getFirebaseConfig().projectId))} className="mt-3">
              <ExternalLink className="size-5" />
              کلاینت‌های OAuth پروژه
            </SubmitButton>
          )}

          {/* چک‌لیست کامل راه‌اندازی — کنار خطاهای سمت پروژه */}
          {isSetup && <SetupChecklist highlight={error.help} />}

          {/* تلاش دوباره */}
          <button
            type="button"
            onClick={onRetry}
            disabled={retrying}
            className="mt-2.5 flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-card text-[13.5px] font-bold text-foreground transition-all active:scale-[.98] disabled:opacity-50"
          >
            {retrying ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
            تلاش دوباره
          </button>

          {/* ⭐ v3.9.5 — ورود به راه‌اندازی گام‌به‌گام (فایربیس از ابتدا) */}
          {onSetup && (
            <button
              type="button"
              onClick={onSetup}
              className="mt-1.5 flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[13px] font-bold text-primary transition-all active:scale-[.98]"
            >
              <ListChecks className="size-4" />
              راه‌اندازی گام‌به‌گام از ابتدا
            </button>
          )}

          {/* جزئیات خام خطا — برای عیب‌یابی */}
          {error.detail && (
            <div className="mt-2">
              <button
                type="button"
                onClick={() => setShowDetail(!showDetail)}
                className="flex items-center gap-1 text-[11px] font-bold text-muted-foreground transition-all active:scale-95"
              >
                <ChevronDown className={cn("size-3.5 transition-transform", showDetail && "rotate-180")} />
                جزئیات فنی خطا
              </button>
              {showDetail && (
                <pre dir="ltr" className="mt-1.5 max-h-32 overflow-y-auto rounded-lg bg-muted/60 p-2 text-left text-[10px] leading-5 text-muted-foreground">
                  {error.detail}
                </pre>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/** سوییچ «همگام‌سازی خودکار» (سرور) */
function AutoSyncRow({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="mb-3 flex w-full items-center justify-between rounded-2xl border border-border/80 bg-card px-4 py-3 text-right transition-all active:scale-[.98]"
    >
      <span className="flex min-w-0 flex-col">
        <span className="text-[14px] font-bold text-foreground">همگام‌سازی خودکار</span>
        <span className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
          با هر تغییر، نسخهٔ جدید در سرور ذخیره می‌شود
        </span>
      </span>
      <span
        className={cn(
          "relative ml-3 flex h-7 w-12 shrink-0 items-center rounded-full transition-colors",
          checked ? "bg-primary" : "bg-muted"
        )}
      >
        <span
          className={cn(
            "absolute right-1 size-5.5 rounded-full bg-white shadow transition-transform duration-150",
            checked ? "-translate-x-[18px]" : "translate-x-0"
          )}
        />
      </span>
    </button>
  );
}

/* ───────────────────────── تب سرور ابری (Firebase + حساب گوگل) ───────────────────────── */

function ServerPanel({ onRestored }: { onRestored?: () => void }) {
  const { toast } = useToast();
  const cfg = getFirebaseConfig();
  const [account, setAccount] = React.useState<{ connected: boolean; email?: string }>({ connected: false, email: "" });
  const [meta, setMeta] = React.useState(getFbSyncMeta());
  const [auto, setAuto] = React.useState(true);

  // جریان اتصال: idle → browser (مرورگر گوگل باز است) → exchanging (تبدیل کد)
  const [flow, setFlow] = React.useState<"idle" | "browser" | "exchanging">("idle");
  const [connectError, setConnectError] = React.useState<FbErrorInfo | null>(null);

  // ⭐ v3.9.5 — شیت راه‌اندازی گام‌به‌گام + پرچم لغو حین تبدیل کد
  const [setupOpen, setSetupOpen] = React.useState(false);
  const cancelRef = React.useRef(false);

  // عملیات‌ها
  const [syncing, setSyncing] = React.useState(false);
  const [syncError, setSyncError] = React.useState<FbErrorInfo | null>(null);
  const [restoring, setRestoring] = React.useState(false);
  const [restoreChoice, setRestoreChoice] = React.useState<{ cloud: CloudSnapshotAlias; local: CloudSnapshotAlias } | null>(null);
  const [restoreBusy, setRestoreBusy] = React.useState<"" | "merge" | "cloud">("");

  const refreshState = React.useCallback(() => {
    setAccount(getFirebaseAccount());
    setMeta(getFbSyncMeta());
    setAuto(getFbAutoSync());
  }, []);

  React.useEffect(() => {
    resetFirebaseSyncState();
    refreshState();
  }, [refreshState]);

  /* ─── اتصال با گوگل ─── */
  const connect = async () => {
    setConnectError(null);
    setSyncError(null);
    cancelRef.current = false;
    if (!hasFbBridge()) {
      setConnectError({ code: "no_bridge", message: "اتصال ابری فقط در نسخهٔ اندروید برنامه فعال است" });
      return;
    }
    const r = await firebaseConnectStart();
    if (!r.ok) {
      setConnectError(r.error ?? { code: "unknown", message: "شروع اتصال ناموفق بود" });
      return;
    }
    setFlow("browser");
    toast({
      title: "صفحهٔ ورود گوگل باز شد",
      description: "حساب را انتخاب و مجوز را تأیید کنید — بعد از آن خودکار به برنامه برمی‌گردید",
    });
  };

  /* ─── پولینگ جریان اتصال (بازگشت از مرورگر) ─── */
  React.useEffect(() => {
    if (flow !== "browser") return;
    let cancelled = false;
    const iv = setInterval(async () => {
      if (cancelled) return;
      const p = firebaseConnectPoll();
      if (p.state === "done") {
        clearInterval(iv);
        setFlow("exchanging");
        cancelRef.current = false;
        try {
          const r = await withBusy(
            { mode: "pill", title: "در حال تکمیل اتصال امن…", detail: "ورود با حساب گوگل به سرور پشتیبان" },
            () => firebaseConnectComplete()
          );
          // ⭐ v3.9.5 — کاربر حین تبدیل لغو کرد: نشست را بی‌صدا پاک کن و برگرد
          if (cancelRef.current) {
            void firebaseDisconnect();
            setFlow("idle");
            refreshState();
            return;
          }
          if (!r.ok || (!r.email && !r.uid)) {
            // v3.9.4: ایمیل اختیاری است — ملاک موفقیت، uid نشست است
            setConnectError(r.error ?? { code: "unknown", message: "ورود به سرور پشتیبان انجام نشد — دوباره تلاش کنید" });
            setFlow("idle");
            return;
          }
          refreshState();
          toast({ title: "به حساب گوگل وصل شد ✓", description: r.email || "حساب گوگل شما" });
          // اولین سینک بلافاصله — خطای راه‌اندازی پروژه اینجا با کارت دقیق نشان داده می‌شود
          try {
            const s = await withBusy(
              { mode: "pill", title: "در حال همگام‌سازی اولیه…" },
              () => runFirebaseSyncNow()
            );
            setMeta(getFbSyncMeta());
            if (s.ok) {
              setFlow("idle");
              toast({ title: "در سرور پشتیبان ذخیره شد ✓", description: "از این به بعد خودکار ذخیره می‌شود" });
            } else if (s.needsRestore && s.cloudSnapshot) {
              setFlow("idle");
              const local = await buildLocalSnapshotPublic();
              if (local) {
                setRestoreChoice({ cloud: s.cloudSnapshot, local });
                toast({ title: "پشتیبان قبلی در سرور پیدا شد ✓", description: "روش بازیابی را انتخاب کنید" });
              }
            } else if (s.error) {
              setFlow("idle");
              setConnectError(s.error);
            }
          } catch {
            setFlow("idle");
          }
        } catch {
          setFlow("idle");
          setConnectError({ code: "unknown", message: "ورود به سرور پشتیبان انجام نشد — دوباره تلاش کنید" });
        }
      } else if (p.state === "error") {
        clearInterval(iv);
        setFlow("idle");
        setConnectError({
          code: p.error ?? "unknown",
          message: p.error === "access_denied" ? "دسترسی در صفحهٔ گوگل رد شد" : "ورود در مرورگر کامل نشد — دوباره تلاش کنید",
        });
      } else if (p.state === "timeout") {
        clearInterval(iv);
        setFlow("idle");
        setConnectError({ code: "timeout", message: "زمان انتظار تمام شد — دوباره تلاش کنید" });
      }
    }, 1200);
    return () => {
      cancelled = true;
      clearInterval(iv);
    };
  }, [flow, refreshState, toast]);

  /* ⭐ v3.9.5 — لغو اتصال: در حالت مرورگر جریان را می‌بندد؛ در حالت تبدیل، نتیجه را بی‌صدا دور می‌اندازد */
  const cancelFlow = () => {
    if (flow === "browser") {
      firebaseConnectCancel();
      setFlow("idle");
      setConnectError(null);
      toast({ title: "اتصال لغو شد" });
      return;
    }
    if (flow === "exchanging") {
      cancelRef.current = true;
      setFlow("idle");
      setConnectError(null);
      toast({ title: "اتصال لغو شد", description: "اگر ورود در پس‌زمینه کامل شده باشد، قطع می‌شود" });
    }
  };

  /** تلاش دوبارهٔ کارت اتصال — از مرحلهٔ سینک شروع می‌شود (نشست ممکن است سالم باشد) */
  const retryConnect = async () => {
    setConnectError(null);
    refreshState();
    if (getFirebaseAccount().connected) {
      // نشست سالم — فقط سینک را دوباره امتحان کن
      setSyncing(true);
      try {
        const r = await withBusy(
          { mode: "pill", title: "در حال همگام‌سازی با سرور پشتیبان…", detail: "ذخیرهٔ آخرین اطلاعات" },
          () => runFirebaseSyncNow()
        );
        if (r.ok) {
          toast({ title: "در سرور پشتیبان ذخیره شد ✓", description: "اتصال برقرار شد" });
        } else if (r.needsRestore && r.cloudSnapshot) {
          const local = await buildLocalSnapshotPublic();
          if (local) setRestoreChoice({ cloud: r.cloudSnapshot, local });
        } else if (r.error) {
          setConnectError(r.error);
        }
      } finally {
        setSyncing(false);
        setMeta(getFbSyncMeta());
      }
      return;
    }
    await connect();
  };

  const logout = async () => {
    const ok = await confirmDialog({
      title: "خروج از حساب پشتیبان",
      message: "اتصال به سرور قطع می‌شود. داده‌های محلی و نسخهٔ سرور دست‌نخورده می‌مانند. ادامه؟",
    });
    if (!ok) return;
    await withBusy({ mode: "pill", title: "در حال قطع اتصال…" }, () => firebaseDisconnect());
    resetFirebaseSyncState();
    refreshState();
    toast({ title: "از حساب پشتیبان خارج شدید" });
  };

  /* ─── همگام‌سازی دستی ─── */
  const syncNow = async () => {
    setSyncing(true);
    setSyncError(null);
    try {
      const r = await withBusy(
        { mode: "pill", title: "در حال همگام‌سازی با سرور پشتیبان…", detail: "ذخیرهٔ آخرین اطلاعات" },
        () => runFirebaseSyncNow()
      );
      if (r.ok) {
        setConnectError(null);
        toast({
          title: r.unchanged ? "همگام‌سازی انجام شد ✓" : "در سرور پشتیبان ذخیره شد ✓",
          description: r.unchanged ? "اطلاعات تغییری نکرده بود" : undefined,
        });
      } else if (r.needsRestore && r.cloudSnapshot) {
        const local = await buildLocalSnapshotPublic();
        if (local) {
          setRestoreChoice({ cloud: r.cloudSnapshot, local });
          toast({ title: "پشتیبانِ پرتری در سرور موجود است", description: "اول بازیابی/ادغام را کامل کنید" });
        }
      } else {
        setSyncError(r.error ?? { code: "unknown", message: "همگام‌سازی ناموفق بود" });
      }
    } finally {
      setSyncing(false);
      setMeta(getFbSyncMeta());
    }
  };

  /* ─── بازیابی از سرور ─── */
  const openRestore = async () => {
    setRestoring(true);
    setSyncError(null);
    try {
      const r = await withBusy(
        { mode: "pill", title: "در حال دریافت نسخهٔ پشتیبان از سرور…" },
        () => downloadFirebaseSnapshot()
      );
      if (r.error) {
        setSyncError(r.error);
        return;
      }
      if (r.missing || !r.snapshot || snapshotIsEmpty(r.snapshot)) {
        toast({ title: "سرور خالی است", description: "هنوز پشتیبانی ذخیره نشده — اول همگام‌سازی کنید" });
        return;
      }
      const local = await buildLocalSnapshotPublic();
      if (!local) {
        setSyncError({ code: "local", message: "خواندن دادهٔ محلی ناموفق بود" });
        return;
      }
      setRestoreChoice({ cloud: r.snapshot, local });
    } finally {
      setRestoring(false);
    }
  };

  const safetyBackup = (): void => {
    try {
      const androidApi = (globalThis as unknown as { AndroidApi?: { saveBackup?: () => string } }).AndroidApi;
      if (typeof androidApi?.saveBackup === "function") androidApi.saveBackup();
    } catch {
      /* best-effort */
    }
  };

  const doRestore = async (m: "merge" | "cloud") => {
    if (!restoreChoice) return;
    setRestoreBusy(m);
    try {
      const json =
        m === "cloud"
          ? JSON.stringify(restoreChoice.cloud)
          : JSON.stringify(mergeWithLocal(restoreChoice.local, restoreChoice.cloud));
      const r = await withBusy(
        {
          mode: "overlay",
          title: m === "cloud" ? "در حال بازیابی اطلاعات از سرور…" : "در حال ادغام محلی + سرور…",
          detail: "قبل از جایگزینی، از داده‌های فعلی این گوشی پشتیبان تهیه می‌شود",
        },
        () => {
          safetyBackup();
          return applyFirebaseSnapshot(json);
        }
      );
      if (r.ok) {
        setRestoreChoice(null);
        toast({
          title: "بازیابی از سرور انجام شد ✓",
          description: "از داده‌های قبلی هم در پوشهٔ Download پشتیبان تهیه شد",
        });
        onRestored?.();
        queueFirebaseAutoSync();
      } else {
        toast({ title: "خطا", description: r.error ?? "بازیابی انجام نشد", variant: "destructive" });
      }
    } finally {
      setRestoreBusy("");
    }
  };

  const counts = meta?.counts ?? null;

  /* ─── حالت ۱: وارد نشده — کارت اتصال با حساب گوگل ─── */
  if (!account.connected) {
    return (
      <>
        {connectError && (
          <FbErrorCard error={connectError} onRetry={() => void retryConnect()} retrying={syncing} onSetup={() => setSetupOpen(true)} />
        )}

        <div className="rounded-2xl border border-primary/35 bg-primary/6 p-5 text-center">
          <span className="mx-auto flex size-16 items-center justify-center rounded-full bg-primary/12">
            <Server className="size-8 text-primary" strokeWidth={1.9} />
          </span>
          <h3 className="mt-3.5 text-[17px] font-extrabold text-foreground">سرور پشتیبان (با حساب گوگل)</h3>
          <p className="mt-2 max-w-[320px] text-[13px] leading-7 text-muted-foreground">
            اطلاعات خودرو، سوابق و یادآورها روی سرور ابریِ رایگان گوگل (Firebase) ذخیره می‌شود —
            ورود با همان حساب گوگل گوشی؛ بدون ایمیل و رمز جداگانه، بدون محدودیت تعداد دستگاه.
          </p>

          {flow === "idle" && (
            <div className="mt-4 flex flex-col gap-2">
              <SubmitButton onClick={() => void connect()}>
                <KeyRound className="size-5" />
                اتصال با حساب گوگل
              </SubmitButton>
              {/* ⭐ v3.9.5 — ورود به راه‌اندازی گام‌به‌گام (فایربیس از ابتدا) */}
              <button
                type="button"
                onClick={() => setSetupOpen(true)}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[13.5px] font-bold text-primary transition-all active:scale-[.98]"
              >
                <ListChecks className="size-4.5" />
                راه‌اندازی گام‌به‌گام سرور
              </button>
            </div>
          )}

          {flow === "browser" && (
            <div className="mt-4 flex flex-col items-center gap-2.5">
              <div className="flex items-center gap-2 rounded-xl border border-primary/30 bg-card px-4 py-2.5">
                <Loader2 className="size-4 animate-spin text-primary" />
                <p className="text-[12.5px] font-bold text-foreground">
                  صفحهٔ ورود گوگل باز شد — بعد از تأیید، خودکار ادامه می‌یابد…
                </p>
              </div>
              {/* ⭐ v3.9.5 — دکمهٔ لغو اتصال (درخواست کاربر) */}
              <button
                type="button"
                onClick={cancelFlow}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/8 text-[13.5px] font-bold text-red-700 transition-all active:scale-[.98] dark:text-red-400"
              >
                <X className="size-4.5" />
                لغو اتصال
              </button>
            </div>
          )}

          {flow === "exchanging" && (
            <div className="mt-4 flex flex-col items-center gap-2.5">
              <div className="flex items-center gap-2 rounded-xl border border-primary/30 bg-card px-4 py-2.5">
                <Loader2 className="size-4 animate-spin text-primary" />
                <p className="text-[12.5px] font-bold text-foreground">در حال تکمیل اتصال امن…</p>
              </div>
              {/* ⭐ v3.9.5 — لغو حتی در میانهٔ تبدیل کد */}
              <button
                type="button"
                onClick={cancelFlow}
                className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/8 text-[12.5px] font-bold text-red-700 transition-all active:scale-[.98] dark:text-red-400"
              >
                <X className="size-4" />
                لغو اتصال
              </button>
            </div>
          )}

          <p className="mt-3.5 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
            <ShieldCheck className="size-3.5 text-primary" />
            پروژه: {cfg.projectId} — راهنمای راه‌اندازی: docs/firebase-setup.md
          </p>
        </div>

        {/* ⭐ v3.9.5 — شیت راه‌اندازی گام‌به‌گام (فایربیس از ابتدا) */}
        <FirebaseSetupSheet
          open={setupOpen}
          onClose={() => setSetupOpen(false)}
          onStartConnect={() => void connect()}
        />
      </>
    );
  }

  /* ─── حالت ۲: وارد شده — وضعیت + عملیات ─── */
  return (
    <>
      {/* ⭐ خطای سینک اولیه بعد از اتصال (مثل فعال‌نبودن API) — در حالت متصل هم دیده شود */}
      {connectError && !syncError && (
        <FbErrorCard error={connectError} onRetry={() => void retryConnect()} retrying={syncing} onSetup={() => setSetupOpen(true)} />
      )}
      {syncError && <FbErrorCard error={syncError} onRetry={() => void syncNow()} retrying={syncing} onSetup={() => setSetupOpen(true)} />}

      {/* کارت حساب */}
      <div className="mb-3 flex items-center gap-3 rounded-2xl border border-primary/40 bg-primary/8 p-3.5">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/15">
          <Server className="size-5.5 text-primary" strokeWidth={2} />
        </span>
        <div className="min-w-0 flex-1">
          <p dir="ltr" className="truncate text-right text-[14.5px] font-bold text-foreground">
            {account.email}
          </p>
          <p className="flex items-center gap-1 text-[11.5px] font-medium text-muted-foreground">
            <Check className="size-3 text-emerald-600 dark:text-emerald-400" />
            متصل به سرور پشتیبان ({cfg.projectId})
          </p>
        </div>
        <button
          type="button"
          onClick={logout}
          aria-label="خروج از حساب"
          className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-red-500/10 text-red-600 transition-all active:scale-95 dark:text-red-400"
        >
          <LogOut className="size-4.5" />
        </button>
      </div>

      {/* خط وضعیت */}
      {meta ? (
        <div
          className={cn(
            "mb-3 flex items-center gap-2 rounded-xl border px-3 py-2",
            meta.status === "failed" ? "border-red-500/30 bg-red-500/8" : "border-border/80 bg-card"
          )}
        >
          {meta.status === "failed" ? (
            <AlertTriangle className="size-4 shrink-0 text-red-600 dark:text-red-400" />
          ) : (
            <CloudUpload className="size-4 shrink-0 text-primary" />
          )}
          <p className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-foreground">
            {meta.status === "ok"
              ? `آخرین همگام‌سازی: ${timeLabel(meta.at)}`
              : `آخرین همگام‌سازی ناموفق: ${meta.error ?? ""}`}
          </p>
          {meta.status === "ok" && counts && (
            <span className="shrink-0 rounded-full bg-muted px-2 py-0.5 text-[10.5px] font-bold tabular-nums text-muted-foreground">
              {fa(counts.totalRecords)} رکورد
            </span>
          )}
        </div>
      ) : (
        <div className="mb-3 flex items-center gap-2 rounded-xl border border-border/80 bg-card px-3 py-2">
          <CloudUpload className="size-4 shrink-0 text-muted-foreground" />
          <p className="min-w-0 flex-1 text-[12.5px] font-bold text-muted-foreground">هنوز همگام‌سازی انجام نشده</p>
        </div>
      )}

      {counts && meta?.status === "ok" && (
        <p className="mb-3 px-1 text-[11.5px] text-muted-foreground">
          در سرور: {fa(counts.vehicles)} خودرو • {fa(counts.totalRecords)} رکورد • {fa(counts.reminders)} یادآور
        </p>
      )}

      <AutoSyncRow
        checked={auto}
        onChange={(v) => {
          setFbAutoSync(v);
          setAuto(v);
          if (v) queueFirebaseAutoSync();
        }}
      />

      <div className="mb-2 flex flex-col gap-2.5">
        <SubmitButton onClick={syncNow} disabled={syncing}>
          {syncing ? <Loader2 className="size-5 animate-spin" /> : <RefreshCw className="size-5" />}
          {syncing ? "در حال همگام‌سازی…" : "همگام‌سازی الان"}
        </SubmitButton>
        <button
          type="button"
          onClick={openRestore}
          disabled={restoring}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/8 text-[15px] font-bold text-primary transition-all active:scale-[.98] disabled:opacity-50"
        >
          {restoring ? <Loader2 className="size-5 animate-spin" /> : <CloudDownload className="size-5" />}
          بازیابی از سرور
        </button>
      </div>

      {/* ⭐ v3.9.5 — بررسی وضعیت سرور/راه‌اندازی گام‌به‌گام — در حالت متصل هم در دسترس */}
      <button
        type="button"
        onClick={() => setSetupOpen(true)}
        className="mb-3 flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-muted text-[12.5px] font-bold text-muted-foreground transition-all active:scale-[.98]"
      >
        <ListChecks className="size-4" />
        راه‌اندازی گام‌به‌گام و بررسی وضعیت سرور
      </button>

      {/* شیت انتخاب روش بازیابی — همان الگوی Drive */}
      <BottomSheet
        open={restoreChoice !== null}
        onClose={() => {
          if (!restoreBusy) setRestoreChoice(null);
        }}
        title="بازیابی از سرور پشتیبان"
        subtitle="قبل از جایگزینی، از داده‌های فعلی پشتیبان تهیه می‌شود"
      >
        {restoreChoice && (() => {
          const cloudCounts = snapshotCounts(restoreChoice.cloud);
          const localCounts = snapshotCounts(restoreChoice.local);
          return (
            <>
              <div className="mb-4 grid grid-cols-2 gap-2.5">
                <div className="rounded-2xl border border-border/80 bg-card p-3.5">
                  <p className="text-[12px] font-bold text-muted-foreground">این گوشی</p>
                  <p className="mt-1.5 text-[13px] font-extrabold tabular-nums text-foreground">
                    {fa(localCounts.vehicles)} خودرو • {fa(localCounts.totalRecords)} رکورد
                  </p>
                </div>
                <div className="rounded-2xl border border-primary/40 bg-primary/8 p-3.5">
                  <p className="text-[12px] font-bold text-primary">سرور پشتیبان</p>
                  <p className="mt-1.5 text-[13px] font-extrabold tabular-nums text-foreground">
                    {fa(cloudCounts.vehicles)} خودرو • {fa(cloudCounts.totalRecords)} رکورد
                  </p>
                </div>
              </div>
              <div className="mb-3 flex items-center justify-center gap-1.5 text-[11.5px] text-muted-foreground">
                <ShieldCheck className="size-3.5 text-emerald-600 dark:text-emerald-400" />
                قبل از هر تغییری از داده‌های فعلی پشتیبان خودکار گرفته می‌شود
              </div>
              <div className="flex flex-col gap-2.5 pb-2">
                <SubmitButton onClick={() => doRestore("merge")} disabled={restoreBusy !== ""}>
                  {restoreBusy === "merge" ? <Loader2 className="size-5 animate-spin" /> : <Check className="size-5" />}
                  ادغام محلی + سرور (پیشنهادی)
                </SubmitButton>
                <button
                  type="button"
                  onClick={() => doRestore("cloud")}
                  disabled={restoreBusy !== ""}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/8 text-[15px] font-bold text-red-700 transition-all active:scale-[.98] disabled:opacity-50 dark:text-red-400"
                >
                  {restoreBusy === "cloud" ? <Loader2 className="size-5 animate-spin" /> : <CloudDownload />}
                  جایگزینی کامل با نسخهٔ سرور
                </button>
                <button
                  type="button"
                  onClick={() => setRestoreChoice(null)}
                  disabled={restoreBusy !== ""}
                  className="flex h-11 w-full items-center justify-center rounded-xl bg-muted text-[14.5px] font-bold text-foreground transition-all active:scale-[.98] disabled:opacity-50"
                >
                  انصراف
                </button>
              </div>
            </>
          );
        })()}
      </BottomSheet>

      {/* ⭐ v3.9.5 — شیت راه‌اندازی گام‌به‌گام (فایربیس از ابتدا) — از کارت‌های خطا */}
      <FirebaseSetupSheet
        open={setupOpen}
        onClose={() => setSetupOpen(false)}
        onStartConnect={() => void connect()}
      />
    </>
  );
}

/* ───────────────────────── تب فایل پشتیبان ───────────────────────── */

function FilePanel() {
  const { toast } = useToast();
  const [exporting, setExporting] = React.useState(false);
  const [restoring, setRestoring] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement | null>(null);

  const androidApi = (globalThis as unknown as {
    AndroidApi?: {
      saveBackup?: () => string;
      pickRestoreFile?: () => void;
    };
  }).AndroidApi;

  const exportData = async () => {
    setExporting(true);
    try {
      const saveBackupFn = androidApi?.saveBackup;
      if (typeof saveBackupFn === "function") {
        const txt = await withBusy(
          {
            mode: "overlay",
            title: "در حال تهیهٔ پشتیبان…",
            detail: "ذخیرهٔ فایل پشتیبان در پوشهٔ Download گوشی",
          },
          () => saveBackupFn()
        );
        try {
          const parsed = JSON.parse(txt) as { status: number; body: { path?: string; error?: string } };
          if (parsed.status >= 200 && parsed.status < 300) {
            toast({
              title: "پشتیبان گرفته شد ✓",
              description: parsed.body?.path
                ? `ذخیره در پوشهٔ Download گوشی: ${parsed.body.path}`
                : "فایل پشتیبان در پوشهٔ Download گوشی ذخیره شد",
            });
          } else {
            toast({ title: "خطا", description: parsed.body?.error ?? "پشتیبان‌گیری انجام نشد", variant: "destructive" });
          }
        } catch {
          toast({ title: "خطا", description: "پاسخ پل نامعتبر بود", variant: "destructive" });
        }
        return;
      }
      const res = await withBusy(
        { mode: "pill", title: "در حال تهیهٔ فایل پشتیبان…", detail: "دریافت و دانلود فایل JSON" },
        () => fetch("/api/backup")
      );
      if (!res.ok) throw new Error();
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const stamp = new Date().toISOString().slice(0, 10);
      a.download = `hamrah-khodro-backup-${stamp}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: "خروجی گرفته شد ✓", description: "فایل پشتیبان JSON دانلود شد" });
    } catch {
      toast({ title: "خطا", description: "خروجی گرفته نشد", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  const restoreData = async (file: File) => {
    setRestoring(true);
    try {
      const text = await file.text();
      const ok = await confirmDialog({
        title: "بازیابی پشتیبان",
        message: "داده‌های فعلی با محتوای فایل پشتیبان جایگزین می‌شود. ادامه؟",
        confirmLabel: "بازیابی",
        destructive: false,
      });
      if (!ok) return;
      const res = await fetch("/api/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: text,
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "خطا");
      toast({ title: "بازیابی شد ✓", description: "داده‌ها از پشتیبان بازگردانی شد" });
    } catch (e) {
      toast({
        title: "خطا",
        description: e instanceof Error ? e.message : "بازیابی انجام نشد",
        variant: "destructive",
      });
    } finally {
      setRestoring(false);
    }
  };

  return (
    <>
      <div className="flex flex-col gap-2.5">
        <button
          type="button"
          onClick={exportData}
          disabled={exporting}
          className="flex w-full items-center gap-3.5 rounded-2xl border border-border/80 bg-card p-4 text-right shadow-sm transition-all active:scale-[.98] disabled:opacity-50"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10">
            {exporting ? <Loader2 className="size-5 animate-spin text-primary" /> : <Download className="size-5 text-primary" strokeWidth={2} />}
          </span>
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="text-[15px] font-bold text-foreground">پشتیبان‌گیری در فایل</span>
            <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">
              ذخیرهٔ همهٔ داده‌ها در یک فایل JSON — در APK: پوشهٔ Download گوشی
            </span>
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            if (typeof androidApi?.pickRestoreFile === "function") {
              androidApi.pickRestoreFile();
              return;
            }
            fileRef.current?.click();
          }}
          disabled={restoring}
          className="flex w-full items-center gap-3.5 rounded-2xl border border-border/80 bg-card p-4 text-right shadow-sm transition-all active:scale-[.98] disabled:opacity-50"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10">
            {restoring ? <Loader2 className="size-5 animate-spin text-primary" /> : <Upload className="size-5 text-primary" strokeWidth={2} />}
          </span>
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="text-[15px] font-bold text-foreground">بازیابی از فایل</span>
            <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">
              بازگرداندن داده‌ها از فایل پشتیبان قبلی — در APK: انتخاب فایل از گوشی
            </span>
          </span>
        </button>

        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (file) void restoreData(file);
          }}
        />
      </div>

      <p className="mt-4 px-1 text-[11.5px] leading-6 text-muted-foreground">
        داده‌ها به‌صورت پیش‌فرض روی حافظهٔ همین دستگاه ذخیره می‌شوند و بدون اینترنت هم در دسترس‌اند؛
        فایل پشتیبان برای انتقال به دستگاه دیگر یا اطمینان بیشتر است.
      </p>
    </>
  );
}

/* ───────────────────────── پنجرهٔ اصلی ───────────────────────── */

export function BackupWindow({ open, onClose, onRestored }: { open: boolean; onClose: () => void; onRestored?: () => void }) {
  const [tab, setTab] = React.useState<BackupTab>("server");

  React.useEffect(() => {
    if (open) setTab("server");
  }, [open]);

  return (
    <SettingsWindow open={open} onClose={onClose} title="پشتیبان‌گیری و بازیابی" subtitle="سرور ابری، Google Drive و فایل">
      {/* انتخاب روش — سه تب */}
      <div className="mb-4 grid grid-cols-3 gap-1 rounded-2xl bg-muted p-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              aria-current={active ? "true" : undefined}
              className={cn(
                "flex h-10 items-center justify-center gap-1.5 rounded-xl text-[12.5px] font-bold transition-all",
                active ? "bg-card text-foreground shadow" : "text-muted-foreground"
              )}
            >
              <Icon className="size-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === "server" && <ServerPanel onRestored={onRestored} />}
      {tab === "drive" && <DriveSyncSection onRestored={onRestored} />}
      {tab === "file" && <FilePanel />}
    </SettingsWindow>
  );
}
