"use client";

/**
 * زیرمنوی «تنظیمات نوتیفیکیشن» — جدا از بقیهٔ تنظیمات:
 *  - فعال/غیرفعال‌سازی نوتیفیکیشن یادآورها
 *  - چند روز قبل از سررسید (تاریخ) اطلاع بدهد
 *  - چند کیلومتر قبل از سررسید (کارکرد) اطلاع بدهد
 *  - تکرار اطلاع روزانه برای عقب‌افتاده‌ها
 *  - مجوز نوتیفیکیشن سیستم + نوتیفیکیشن تست
 */

import * as React from "react";
import { Bell, BellOff, BellRing, Check, Gauge, CalendarDays, Loader2, Repeat, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { fa, faNum } from "@/lib/persian";
import {
  DEFAULT_NOTIFY_SETTINGS,
  loadNotifySettings,
  notificationPermission,
  requestNotificationPermission,
  saveNotifySettings,
  showNotification,
  type NotificationSettings,
} from "@/lib/notifications";
import { SettingsWindow } from "./SettingsWindow";
import { useToast } from "@/hooks/use-toast";

const DAY_OPTIONS = [1, 2, 3, 5, 7, 14, 30];
const KM_OPTIONS = [100, 200, 500, 1000, 2000];

function OptionChips({
  options,
  value,
  onChange,
  unit,
  format,
}: {
  options: number[];
  value: number;
  onChange: (v: number) => void;
  unit: string;
  format?: (n: number) => string;
}) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1" style={{ scrollbarWidth: "thin" }}>
      {options.map((o) => (
        <button
          key={o}
          type="button"
          onClick={() => onChange(o)}
          className={cn(
            "shrink-0 rounded-full px-4 py-2 text-[13px] font-bold tabular-nums transition-colors active:scale-95",
            value === o
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground active:bg-primary/15"
          )}
        >
          {format ? format(o) : faNum(o)} {unit}
        </button>
      ))}
    </div>
  );
}

export function NotificationsWindow({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const [settings, setSettings] = React.useState<NotificationSettings>(DEFAULT_NOTIFY_SETTINGS);
  const [permission, setPermission] = React.useState<NotificationPermission | "unsupported">("default");
  const [requesting, setRequesting] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setSettings(loadNotifySettings());
      setPermission(notificationPermission());
    }
  }, [open]);

  const update = (patch: Partial<NotificationSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveNotifySettings(next);
  };

  const requestPermission = async () => {
    setRequesting(true);
    try {
      const p = await requestNotificationPermission();
      setPermission(p);
      if (p === "granted") {
        toast({ title: "مجوز نوتیفیکیشن داده شد ✓", description: "اطلاع‌رسانی یادآورها فعال شد" });
      } else if (p === "denied") {
        toast({
          title: "مجوز رد شد",
          description: "از تنظیمات گوشی/مرورگر، اعلان برنامه را فعال کنید",
          variant: "destructive",
        });
      }
    } finally {
      setRequesting(false);
    }
  };

  const testNotification = () => {
    const ok = showNotification("🔔 نوتیفیکیشن همراه خودرو", "یادآورهای نزدیک این‌طوری اطلاع داده می‌شوند");
    if (!ok) {
      toast({
        title: "نوتیفیکیشن نمایش داده نشد",
        description: "ابتدا مجوز اعلان را فعال کنید",
        variant: "destructive",
      });
    } else {
      toast({ title: "نوتیفیکیشن تست ارسال شد ✓" });
    }
  };

  return (
    <SettingsWindow
      open={open}
      onClose={onClose}
      title="تنظیمات نوتیفیکیشن"
      subtitle="اطلاع‌رسانی یادآورهای نزدیک روی گوشی"
    >
      {/* روشن/خاموش کلی */}
      <button
        type="button"
        onClick={() => update({ enabled: !settings.enabled })}
        className={cn(
          "mb-4 flex w-full items-center gap-3.5 rounded-2xl border-2 p-4 text-right transition-all active:scale-[.98]",
          settings.enabled ? "border-primary/45 bg-primary/8" : "border-border bg-card"
        )}
      >
        <span
          className={cn(
            "flex size-12 shrink-0 items-center justify-center rounded-xl",
            settings.enabled ? "bg-primary/15" : "bg-muted"
          )}
        >
          {settings.enabled ? (
            <BellRing className="size-6 text-primary" strokeWidth={2} />
          ) : (
            <BellOff className="size-6 text-muted-foreground" strokeWidth={2} />
          )}
        </span>
        <span className="flex min-w-0 flex-1 flex-col">
          <span className="text-[15px] font-bold text-foreground">
            نوتیفیکیشن یادآورها {settings.enabled ? "روشن" : "خاموش"}
          </span>
          <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">
            یادآورهایی که تاریخ یا کیلومترشان نزدیک است روی گوشی اطلاع داده می‌شوند
          </span>
        </span>
        <span
          className={cn(
            "relative h-7 w-12 shrink-0 rounded-full transition-colors",
            settings.enabled ? "bg-primary" : "bg-muted"
          )}
          aria-hidden
        >
          <span
            className={cn(
              "absolute top-1 size-5 rounded-full bg-white shadow transition-all",
              settings.enabled ? "right-1" : "right-6"
            )}
          />
        </span>
      </button>

      {/* چند روز قبل از سررسید */}
      <section className={cn("mb-4 rounded-2xl border border-border/80 bg-card p-4", !settings.enabled && "opacity-50")}>
        <h3 className="mb-1 flex items-center gap-2 text-[14px] font-bold text-foreground">
          <CalendarDays className="size-4.5 text-primary" />
          چند روز قبل از سررسید اطلاع بدهد؟
        </h3>
        <p className="mb-3 text-[12px] leading-5 text-muted-foreground">
          یادآورهای تاریخ‌دار از این تعداد روز قبل، «نزدیک» حساب و اطلاع داده می‌شوند (همین بازه در صفحهٔ
          اصلی و تب یادآورها هم نمایش داده می‌شود).
        </p>
        <OptionChips
          options={DAY_OPTIONS}
          value={settings.daysBefore}
          onChange={(v) => update({ daysBefore: v })}
          unit="روز قبل"
          format={(n) => fa(n)}
        />
      </section>

      {/* چند کیلومتر قبل از سررسید */}
      <section className={cn("mb-4 rounded-2xl border border-border/80 bg-card p-4", !settings.enabled && "opacity-50")}>
        <h3 className="mb-1 flex items-center gap-2 text-[14px] font-bold text-foreground">
          <Gauge className="size-4.5 text-primary" />
          چند کیلومتر قبل از سررسید اطلاع بدهد؟
        </h3>
        <p className="mb-3 text-[12px] leading-5 text-muted-foreground">
          برای یادآورهای کیلومتری — وقتی کارکرد خودرو به هدف این مقدار نزدیک شود اطلاع داده می‌شود.
        </p>
        <OptionChips
          options={KM_OPTIONS}
          value={settings.kmBefore}
          onChange={(v) => update({ kmBefore: v })}
          unit="کیلومتر قبل"
        />
      </section>

      {/* تکرار اطلاع عقب‌افتاده‌ها */}
      <button
        type="button"
        onClick={() => update({ renotifyOverdue: !settings.renotifyOverdue })}
        disabled={!settings.enabled}
        className={cn(
          "mb-4 flex w-full items-center gap-3 rounded-2xl border border-border/80 bg-card p-4 text-right transition-all active:scale-[.98] disabled:opacity-50",
          settings.renotifyOverdue && settings.enabled && "border-primary/40 bg-primary/5"
        )}
      >
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
          <Repeat className="size-5 text-primary" />
        </span>
        <span className="flex min-w-0 flex-1 flex-col">
          <span className="text-[14px] font-bold text-foreground">تکرار اطلاع روزانهٔ عقب‌افتاده‌ها</span>
          <span className="mt-0.5 text-[12px] leading-5 text-muted-foreground">
            یادآورهای گذشته هر روز یک بار دوباره اطلاع می‌دهند تا انجام شوند
          </span>
        </span>
        <span
          className={cn(
            "flex size-6 shrink-0 items-center justify-center rounded-full border-2",
            settings.renotifyOverdue && settings.enabled
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-transparent"
          )}
        >
          <Check className="size-3.5" strokeWidth={3} />
        </span>
      </button>

      {/* مجوز سیستم */}
      <section className="mb-4 rounded-2xl border border-border/80 bg-card p-4">
        <h3 className="mb-1 flex items-center gap-2 text-[14px] font-bold text-foreground">
          <Volume2 className="size-4.5 text-primary" />
          مجوز اعلان سیستم
        </h3>
        <p className="mb-3 text-[12px] leading-5 text-muted-foreground">
          {permission === "granted"
            ? "مجوز اعلان فعال است ✓ — نوتیفیکیشن‌ها روی گوشی نمایش داده می‌شوند."
            : permission === "denied"
              ? "مجوز رد شده — از تنظیمات گوشی/مرورگر، اعلان برنامه را فعال کنید."
              : permission === "unsupported"
                ? "این محیط از نوتیفیکیشن سیستم پشتیبانی نمی‌کند — اطلاع‌رسانی درون‌برنامه‌ای فعال است."
                : "برای نمایش نوتیفیکیشن روی گوشی، مجوز اعلان را فعال کنید."}
        </p>
        <div className="flex gap-2">
          {permission !== "granted" && (
            <button
              type="button"
              onClick={requestPermission}
              disabled={requesting || permission === "unsupported"}
              className="flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-primary text-[14px] font-bold text-primary-foreground transition-all active:scale-95 disabled:opacity-50"
            >
              {requesting ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />}
              فعال‌سازی مجوز اعلان
            </button>
          )}
          <button
            type="button"
            onClick={testNotification}
            className="flex h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-input bg-background text-[14px] font-bold text-foreground transition-all active:scale-95"
          >
            <BellRing className="size-4" />
            نوتیفیکیشن تست
          </button>
        </div>
      </section>

      <p className="pb-2 text-center text-[11.5px] leading-6 text-muted-foreground">
        هنگام باز بودن برنامه، هر چند دقیقه یک بار یادآورها بررسی می‌شوند؛ بنر «یادآورهای نزدیک» هم
        همیشه بالای صفحهٔ اصلی دیده می‌شود.
      </p>
    </SettingsWindow>
  );
}
