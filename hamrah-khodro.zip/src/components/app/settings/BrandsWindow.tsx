"use client";

/**
 * پنجرهٔ «مدیریت برند و مدل» — افزودن، ویرایش نام و حذف برند/مدل در پنجرهٔ تمام‌صفحه
 * با باز شدن هر برند، لیست مدل‌ها حداکثر به ارتفاع ~۷ ردیف محدود می‌شود و خودش قابل اسکرول است.
 */

import * as React from "react";
import { Building2, Check, ChevronDown, Loader2, Pencil, Plus, Trash2, X } from "lucide-react";
import { faNum } from "@/lib/persian";
import type { BrandItem } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { confirmDialog } from "@/components/app/ConfirmDialog";
import { SettingsWindow } from "./SettingsWindow";
import { TextInput } from "../fields";

interface BrandsWindowProps {
  open: boolean;
  onClose: () => void;
  brands: BrandItem[];
  onRefresh: () => void;
}

/** ارتفاع ~۷ ردیف مدل — بعدش اسکرول */
const MODELS_MAX_H = "max-h-[322px]";

export function BrandsWindow({ open, onClose, brands, onRefresh }: BrandsWindowProps) {
  const { toast } = useToast();
  const [expanded, setExpanded] = React.useState<string | null>(null);
  const [newBrand, setNewBrand] = React.useState("");
  const [newModel, setNewModel] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  // ویرایش درجا
  const [editBrandId, setEditBrandId] = React.useState<string | null>(null);
  const [editBrandName, setEditBrandName] = React.useState("");
  const [editModelBrand, setEditModelBrand] = React.useState<string | null>(null);
  const [editModelOld, setEditModelOld] = React.useState("");
  const [editModelNew, setEditModelNew] = React.useState("");

  const addBrand = async () => {
    if (!newBrand.trim()) return;
    setBusy(true);
    try {
      const res = await fetch("/api/brands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newBrand.trim(), models: [] }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => null);
        throw new Error(d?.error ?? "خطا");
      }
      toast({ title: "برند اضافه شد ✓", description: newBrand.trim() });
      setNewBrand("");
      onRefresh();
    } catch (e) {
      toast({
        title: "خطا",
        description: e instanceof Error ? e.message : "ثبت نشد",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  const addModel = async (brand: BrandItem, name: string) => {
    if (!name.trim()) return;
    if (brand.models.includes(name.trim())) {
      toast({ title: "این مدل موجود است", description: name.trim() });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/brands/${brand.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ models: [...brand.models, name.trim()] }),
      });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "مدل اضافه شد ✓", description: `${brand.name} — ${name.trim()}` });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "ثبت نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  /** ویرایش نام برند */
  const renameBrand = async (brand: BrandItem) => {
    const name = editBrandName.trim();
    if (!name || name === brand.name) {
      setEditBrandId(null);
      return;
    }
    if (brands.some((b) => b.id !== brand.id && b.name === name)) {
      toast({ title: "برندی با این نام موجود است", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/brands/${brand.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "نام برند ویرایش شد ✓", description: name });
      setEditBrandId(null);
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "ویرایش نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  /** ویرایش نام مدل */
  const renameModel = async (brand: BrandItem, oldName: string) => {
    const name = editModelNew.trim();
    if (!name || name === oldName) {
      setEditModelBrand(null);
      return;
    }
    if (brand.models.includes(name)) {
      toast({ title: "این مدل موجود است", description: name, variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/brands/${brand.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ models: brand.models.map((m) => (m === oldName ? name : m)) }),
      });
      if (!res.ok) throw new Error("خطا");
      toast({ title: "مدل ویرایش شد ✓", description: `${brand.name} — ${name}` });
      setEditModelBrand(null);
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "ویرایش نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const removeModel = async (brand: BrandItem, model: string) => {
    const ok = await confirmDialog({
      title: "حذف مدل",
      message: `مدل «${model}» حذف شود؟`,
      confirmLabel: "حذف",
    });
    if (!ok) return;
    try {
      await fetch(`/api/brands/${brand.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ models: brand.models.filter((m) => m !== model) }),
      });
      toast({ title: "مدل حذف شد", description: model });
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "حذف نشد", variant: "destructive" });
    }
  };

  const removeBrand = async (brand: BrandItem) => {
    const ok = await confirmDialog({
      title: "حذف برند",
      message: `برند «${brand.name}» و همه مدل‌هایش حذف شود؟`,
      confirmLabel: "حذف",
    });
    if (!ok) return;
    try {
      await fetch(`/api/brands/${brand.id}`, { method: "DELETE" });
      toast({ title: "برند حذف شد", description: brand.name });
      if (expanded === brand.id) setExpanded(null);
      onRefresh();
    } catch {
      toast({ title: "خطا", description: "حذف نشد", variant: "destructive" });
    }
  };

  return (
    <SettingsWindow
      open={open}
      onClose={onClose}
      title="مدیریت برند و مدل"
      subtitle={`${faNum(brands.length)} برند — افزودن، ویرایش و حذف`}
    >
      {/* افزودن برند */}
      <div className="mb-4 flex gap-2">
        <TextInput
          dir="rtl"
          value={newBrand}
          onChange={(e) => setNewBrand(e.target.value)}
          placeholder="نام برند جدید..."
          className="flex-1"
        />
        <button
          type="button"
          onClick={addBrand}
          disabled={busy || !newBrand.trim()}
          className="flex h-12 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground transition-all active:scale-95 disabled:opacity-50"
          aria-label="افزودن برند"
        >
          {busy ? <Loader2 className="size-5 animate-spin" /> : <Plus className="size-5" />}
        </button>
      </div>

      <div className="pb-2">
        {brands.map((b) => {
          const isOpen = expanded === b.id;
          const editingBrand = editBrandId === b.id;
          return (
            <div key={b.id} className="mb-1.5 overflow-hidden rounded-2xl border border-input">
              {/* ردیف برند — فونت درشت */}
              {editingBrand ? (
                <div className="flex items-center gap-2 bg-card px-3.5 py-2">
                  <TextInput
                    dir="rtl"
                    value={editBrandName}
                    autoFocus
                    onChange={(e) => setEditBrandName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") renameBrand(b);
                      if (e.key === "Escape") setEditBrandId(null);
                    }}
                    className="flex-1"
                    aria-label="نام جدید برند"
                  />
                  <button
                    type="button"
                    onClick={() => renameBrand(b)}
                    disabled={busy}
                    aria-label="ذخیره نام برند"
                    className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-50"
                  >
                    {busy ? <Loader2 className="size-5 animate-spin" /> : <Check className="size-5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditBrandId(null)}
                    aria-label="لغو"
                    className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-muted text-muted-foreground"
                  >
                    <X className="size-5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center bg-card">
                  <button
                    type="button"
                    onClick={() => setExpanded(isOpen ? null : b.id)}
                    className="flex h-[56px] min-w-0 flex-1 items-center gap-2.5 px-3.5 text-right active:bg-muted/60"
                    aria-expanded={isOpen}
                  >
                    <span className="flex size-9 items-center justify-center rounded-xl bg-primary/10">
                      <Building2 className="size-4.5 text-primary" />
                    </span>
                    <span className="truncate text-[17px] font-bold text-foreground">{b.name}</span>
                    <span className="text-[12px] font-medium text-muted-foreground">
                      {faNum(b.models.length)} مدل
                    </span>
                  </button>
                  {/* ویرایش برند */}
                  <button
                    type="button"
                    onClick={() => {
                      setEditBrandId(b.id);
                      setEditBrandName(b.name);
                    }}
                    aria-label={`ویرایش برند ${b.name}`}
                    className="flex size-11 shrink-0 items-center justify-center rounded-xl text-muted-foreground active:bg-muted"
                  >
                    <Pencil className="size-4.5" />
                  </button>
                  {/* حذف برند */}
                  <button
                    type="button"
                    onClick={() => removeBrand(b)}
                    aria-label={`حذف برند ${b.name}`}
                    className="flex size-11 shrink-0 items-center justify-center rounded-xl text-red-500 active:bg-red-500/10"
                  >
                    <Trash2 className="size-4.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setExpanded(isOpen ? null : b.id)}
                    aria-label="باز/بسته کردن مدل‌ها"
                    className="flex size-11 shrink-0 items-center justify-center rounded-xl text-muted-foreground active:bg-muted"
                  >
                    <ChevronDown
                      className={
                        "size-5 transition-transform " + (isOpen ? "rotate-180" : "")
                      }
                    />
                  </button>
                </div>
              )}

              {isOpen && (
                <div className="border-t border-border/60 bg-muted/30">
                  {/* لیست مدل‌ها — حداکثر ~۷ ردیف، بعد اسکرول */}
                  <div className={`${MODELS_MAX_H} overflow-y-auto overscroll-contain`}>
                    {b.models.map((m) =>
                      editModelBrand === b.id && editModelOld === m ? (
                        <div key={m} className="flex items-center gap-2 px-3 py-1.5">
                          <TextInput
                            dir="rtl"
                            value={editModelNew}
                            autoFocus
                            onChange={(e) => setEditModelNew(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") renameModel(b, m);
                              if (e.key === "Escape") setEditModelBrand(null);
                            }}
                            className="h-10 flex-1 text-[14px]"
                            aria-label="نام جدید مدل"
                          />
                          <button
                            type="button"
                            onClick={() => renameModel(b, m)}
                            disabled={busy}
                            aria-label="ذخیره مدل"
                            className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-50"
                          >
                            {busy ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditModelBrand(null)}
                            aria-label="لغو"
                            className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-muted text-muted-foreground"
                          >
                            <X className="size-4" />
                          </button>
                        </div>
                      ) : (
                        <div
                          key={m}
                          className="flex h-[46px] items-center justify-between pl-3 pr-4"
                        >
                          <span className="truncate text-[15px] font-medium text-foreground">{m}</span>
                          <span className="flex shrink-0 items-center gap-0.5">
                            <button
                              type="button"
                              onClick={() => {
                                setEditModelBrand(b.id);
                                setEditModelOld(m);
                                setEditModelNew(m);
                              }}
                              aria-label={`ویرایش مدل ${m}`}
                              className="flex size-9 items-center justify-center rounded-xl text-muted-foreground active:bg-muted"
                            >
                              <Pencil className="size-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => removeModel(b, m)}
                              aria-label={`حذف مدل ${m}`}
                              className="flex size-9 items-center justify-center rounded-xl text-red-500 active:bg-red-500/10"
                            >
                              <X className="size-4" />
                            </button>
                          </span>
                        </div>
                      )
                    )}
                    {b.models.length === 0 && (
                      <p className="px-4 py-2 text-[12.5px] text-muted-foreground">مدلی ثبت نشده</p>
                    )}
                  </div>

                  {/* افزودن مدل */}
                  <div className="flex gap-1.5 border-t border-border/50 p-2">
                    <TextInput
                      dir="rtl"
                      value={newModel}
                      onChange={(e) => setNewModel(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") addModel(b, newModel).then(() => setNewModel(""));
                      }}
                      placeholder="مدل جدید..."
                      className="h-10 flex-1 text-[14px]"
                    />
                    <button
                      type="button"
                      onClick={() => addModel(b, newModel).then(() => setNewModel(""))}
                      disabled={busy || !newModel.trim()}
                      className="flex h-10 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary disabled:opacity-50"
                      aria-label="افزودن مدل"
                    >
                      {busy ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {brands.length === 0 && (
          <p className="py-8 text-center text-[15px] text-muted-foreground">برندی یافت نشد</p>
        )}
      </div>
    </SettingsWindow>
  );
}
