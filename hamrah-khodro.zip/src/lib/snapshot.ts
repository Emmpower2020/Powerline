/**
 * اسنپ‌شات دادهٔ «همراه خودرو» — ابزارهای مشترکِ همهٔ مسیرهای پشتیبان (v3.9.1).
 * (جدا شده از cloud-sync.ts قدیمی — Drive حذف شد؛ این ماژول بین سینک ابری و فایل مشترک است)
 */

export interface CloudSnapshot {
  app?: string;
  version?: string;
  exportedAt?: string;
  exportedAtTehran?: string;
  vehicles: Record<string, unknown>[];
  records: Record<string, unknown>[];
  reminders: Record<string, unknown>[];
  brands?: Record<string, unknown>[];
  serviceTypes?: Record<string, unknown>[];
  [k: string]: unknown;
}

export interface CloudSyncCounts {
  vehicles: number;
  totalRecords: number;
  services: number;
  fuels: number;
  odometers: number;
  notes: number;
  reminders: number;
  brands: number;
  serviceTypes: number;
  totalCost: number;
}

/** شمارش برای نمایش «اطلاعات ذخیره‌شده» */
export function snapshotCounts(s: CloudSnapshot | null | undefined): CloudSyncCounts {
  const records = s?.records ?? [];
  let cost = 0;
  for (const r of records) {
    const c = r.cost;
    if (typeof c === "number") cost += c;
  }
  const cnt = (t: string) => records.filter((r) => r.type === t).length;
  return {
    vehicles: s?.vehicles?.length ?? 0,
    totalRecords: records.length,
    services: cnt("SERVICE"),
    fuels: cnt("FUEL"),
    odometers: cnt("ODOMETER"),
    notes: cnt("NOTE"),
    reminders: s?.reminders?.length ?? 0,
    brands: s?.brands?.length ?? 0,
    serviceTypes: s?.serviceTypes?.length ?? 0,
    totalCost: cost,
  };
}

/** آیا اسنپ‌شات هیچ داده‌ای ندارد؟ (نصب تازه — چیزی برای آپلود نیست) */
export function snapshotIsEmpty(s: CloudSnapshot | null | undefined): boolean {
  if (!s) return true;
  return (
    (Array.isArray(s.vehicles) ? s.vehicles.length : 0) === 0 &&
    (Array.isArray(s.records) ? s.records.length : 0) === 0 &&
    (Array.isArray(s.reminders) ? s.reminders.length : 0) === 0
  );
}

/** هش سبک برای تشخیص «بی‌تغییر» (جلوگیری از آپلود بی‌مورد) */
export function hashString(s: string): string {
  let h1 = 0xdeadbeef ^ s.length;
  let h2 = 0x41c6ce57 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    const ch = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16) + (h1 >>> 0).toString(16) + ":" + s.length;
}

/* ───────────────────────────── خواندن/نوشتن دادهٔ محلی ───────────────────────────── */

type AndroidDataApi = { api: (m: string, u: string, b: string) => string };

function androidDataApi(): AndroidDataApi | null {
  try {
    const api = (globalThis as unknown as { AndroidApi?: { api?: unknown } }).AndroidApi;
    if (api && typeof api.api === "function") return api as AndroidDataApi;
  } catch {
    /* ignore */
  }
  return null;
}

/** خواندن دادهٔ کامل محلی — در APK از پل جاوا (همان خروجی پشتیبان)، در وب fetch */
export async function buildLocalSnapshot(): Promise<CloudSnapshot | null> {
  const api = androidDataApi();
  if (api) {
    try {
      const raw = api.api("GET", "/api/backup", "");
      const parsed = JSON.parse(raw) as { status: number; body: CloudSnapshot };
      if (parsed.status === 200 && parsed.body) return parsed.body;
      return null;
    } catch {
      return null;
    }
  }
  try {
    const res = await fetch("/api/backup");
    if (!res.ok) return null;
    return (await res.json()) as CloudSnapshot;
  } catch {
    return null;
  }
}

/** اعمال اسنپ‌شات روی دادهٔ محلی (همان مسیر بازیابی پشتیبان) */
export async function restoreSnapshot(json: string): Promise<{ ok: boolean; error?: string }> {
  const api = androidDataApi();
  if (api) {
    try {
      const raw = api.api("POST", "/api/restore", json);
      const parsed = JSON.parse(raw) as { status: number; body: { ok?: boolean; error?: string } };
      if (parsed.status >= 200 && parsed.status < 300 && parsed.body?.ok !== false) return { ok: true };
      return { ok: false, error: parsed.body?.error ?? `خطای بازیابی (${parsed.status})` };
    } catch {
      return { ok: false, error: "بازیابی انجام نشد" };
    }
  }
  try {
    const res = await fetch("/api/restore", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: json,
    });
    if (!res.ok) {
      const d = (await res.json().catch(() => null)) as { error?: string } | null;
      return { ok: false, error: d?.error ?? "بازیابی انجام نشد" };
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "بازیابی انجام نشد" };
  }
}

/* ───────────────────────────── ادغام (merge) ───────────────────────────── */

function ts(v: unknown): number {
  if (typeof v === "string") {
    const t = Date.parse(v);
    if (!Number.isNaN(t)) return t;
  }
  return 0;
}

function newer(a: Record<string, unknown>, b: Record<string, unknown>): Record<string, unknown> {
  const au = ts(a.updatedAt) || ts(a.createdAt);
  const bu = ts(b.updatedAt) || ts(b.createdAt);
  return au >= bu ? a : b;
}

/** ادغام بدون تکرار: کلید شناسه + نسخهٔ جدیدتر ملاک است */
export function mergeSnapshots(local: CloudSnapshot, cloud: CloudSnapshot): CloudSnapshot {
  const mergeById = (
    a: Record<string, unknown>[],
    b: Record<string, unknown>[]
  ): Record<string, unknown>[] => {
    const m = new Map<string, Record<string, unknown>>();
    for (const x of a) if (typeof x.id === "string") m.set(x.id, x);
    for (const x of b) {
      if (typeof x.id !== "string") continue;
      const cur = m.get(x.id);
      m.set(x.id, cur ? newer(cur, x) : x);
    }
    return Array.from(m.values());
  };

  const vehicles = mergeById(local.vehicles ?? [], cloud.vehicles ?? []);
  const vehicleIds = new Set(vehicles.map((v) => String(v.id)));
  const records = mergeById(local.records ?? [], cloud.records ?? []).filter((r) =>
    vehicleIds.has(String(r.vehicleId))
  );
  const reminders = mergeById(local.reminders ?? [], cloud.reminders ?? []).filter((r) =>
    vehicleIds.has(String(r.vehicleId))
  );

  // برندها: کلید نام — اجتماع مدل‌ها
  const brands: Record<string, unknown>[] = [];
  const brandByName = new Map<string, Record<string, unknown>>();
  for (const b of [...(local.brands ?? []), ...(cloud.brands ?? [])]) {
    const name = typeof b.name === "string" ? b.name : "";
    if (!name) continue;
    const cur = brandByName.get(name);
    if (!cur) {
      brandByName.set(name, { ...b });
      continue;
    }
    const models = new Set(
      [...(Array.isArray(cur.models) ? cur.models : []), ...(Array.isArray(b.models) ? b.models : [])].filter(
        (m): m is string => typeof m === "string"
      )
    );
    brandByName.set(name, { ...cur, models: Array.from(models) });
  }
  brands.push(...Array.from(brandByName.values()));

  // انواع سرویس: کلید value — نسخهٔ محلی + موارد فقط-ابری
  const serviceTypes: Record<string, unknown>[] = [...(local.serviceTypes ?? [])];
  const values = new Set(
    serviceTypes.map((t) => String(t.value ?? t.label)).filter((v) => v && v !== "undefined")
  );
  for (const t of cloud.serviceTypes ?? []) {
    const key = String(t.value ?? t.label);
    if (key && key !== "undefined" && !values.has(key)) {
      values.add(key);
      serviceTypes.push(t);
    }
  }

  return {
    app: "همراه خودرو",
    version: "cloud-merge",
    exportedAt: new Date().toISOString(),
    vehicles,
    records,
    reminders,
    brands,
    serviceTypes,
  };
}
