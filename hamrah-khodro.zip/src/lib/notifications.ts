/**
 * زیرساخت نوتیفیکیشن یادآورها — سمت کلاینت:
 *  - تنظیمات: چند روز قبل از سررسید / چند کیلومتر قبل (زیرمنوی «تنظیمات نوتیفیکیشن»)
 *  - بررسی دوره‌ای یادآورهای نزدیک (حتی وقتی برنامه در پس‌زمینه باز است) و ارسال
 *    نوتیفیکیشن سیستم (Notification API) + فهرست برای بنر درون‌برنامه‌ای
 *  - جلوگیری از تکرار: هر یادآور تا وقتی «کلید وضعیتش» (هدف + وضعیت) عوض نشود یک بار اطلاع می‌دهد
 */

import type { ReminderItem } from "@/lib/types";
import { computeReminderStatus, type ReminderThresholds } from "@/components/app/shared";

export interface NotificationSettings {
  enabled: boolean;
  /** چند روز قبل از سررسید اطلاع بدهد */
  daysBefore: number;
  /** چند کیلومتر قبل از سررسید اطلاع بدهد */
  kmBefore: number;
  /** تکرار اطلاع روزانه برای یادآورهای عقب‌افتاده */
  renotifyOverdue: boolean;
}

const SETTINGS_KEY = "hamrah-khodro-notify-settings";
const NOTIFIED_KEY = "hamrah-khodro-notified";
/** جدا از توست درون‌برنامه‌ای — کدام یادآورها با نوتیفیکیشن سیستم اطلاع شده‌اند */
const SYS_NOTIFIED_KEY = "hamrah-khodro-notified-sys";

export const DEFAULT_NOTIFY_SETTINGS: NotificationSettings = {
  enabled: true,
  daysBefore: 7,
  kmBefore: 500,
  renotifyOverdue: true,
};

export function loadNotifySettings(): NotificationSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<NotificationSettings>;
      return { ...DEFAULT_NOTIFY_SETTINGS, ...parsed };
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_NOTIFY_SETTINGS;
}

export function saveNotifySettings(s: NotificationSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

/** آستانهٔ «نزدیک» برای محاسبهٔ وضعیت یادآورها (نمایش در برنامه هم از همین استفاده می‌کند) */
export function thresholdsFromSettings(s: NotificationSettings): ReminderThresholds {
  return { soonDays: Math.max(1, s.daysBefore), soonKm: Math.max(10, s.kmBefore) };
}

/* ------------------------- وضعیت مجوز نوتیفیکیشن ------------------------- */

export function notificationPermission(): NotificationPermission | "unsupported" {
  if (typeof window === "undefined" || typeof Notification === "undefined") return "unsupported";
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission | "unsupported"> {
  if (notificationPermission() === "unsupported") return "unsupported";
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

/** نمایش نوتیفیکیشن سیستم — اگر مجوز داده شده باشد */
export function showNotification(title: string, body: string): boolean {
  try {
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return false;
    new Notification(title, { body, dir: "rtl", lang: "fa", tag: `hk-${title}-${body}` });
    return true;
  } catch {
    return false;
  }
}

/** آیا مجوز نوتیفیکیشن سیستم داده شده؟ (در APK از پل جاوا) */
export function notifPermissionGranted(): boolean {
  try {
    return typeof Notification !== "undefined" && Notification.permission === "granted";
  } catch {
    return false;
  }
}

/* --------------------------- بررسی یادآورهای نزدیک --------------------------- */

/** کلید وضعیت یادآور — تغییر هدف/وضعیت یعنی اطلاع دوباره */
function reminderKey(r: ReminderItem): string {
  return `${r.done ? "d" : "a"}|${r.dueDate ?? ""}|${r.dueKm ?? ""}`;
}

function loadNotified(): Record<string, string> {
  try {
    const raw = localStorage.getItem(NOTIFIED_KEY);
    if (raw) return JSON.parse(raw) as Record<string, string>;
  } catch {
    /* ignore */
  }
  return {};
}

function saveNotified(map: Record<string, string>) {
  try {
    localStorage.setItem(NOTIFIED_KEY, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

function loadSysNotified(): Record<string, string> {
  try {
    const raw = localStorage.getItem(SYS_NOTIFIED_KEY);
    if (raw) return JSON.parse(raw) as Record<string, string>;
  } catch {
    /* ignore */
  }
  return {};
}

function saveSysNotified(map: Record<string, string>) {
  try {
    localStorage.setItem(SYS_NOTIFIED_KEY, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

export interface NearbyReminder {
  reminder: ReminderItem;
  label: string;
  overdue: boolean;
}

/**
 * بررسی یادآورهای نزدیک — یادآورهایی که تاریخ یا کیلومترشان در بازهٔ تنظیم‌شده است
 * (شامل عقب‌افتاده‌ها). برای تازه‌وارد‌ها نوتیفیکیشن سیستم ارسال می‌کند و نتیجه را
 * برای بنر/توست درون‌برنامه‌ای برمی‌گرداند.
 */
export function checkAndNotify(
  reminders: ReminderItem[],
  currentKmByVehicle: Map<string, number>,
  vehicleNames: Map<string, string>,
  settings: NotificationSettings
): { fired: NearbyReminder[]; sysPosted: NearbyReminder[] } {
  if (!settings.enabled) return { fired: [], sysPosted: [] };
  const thresholds = thresholdsFromSettings(settings);

  const nearby: NearbyReminder[] = [];
  for (const r of reminders) {
    if (r.done) continue;
    const st = computeReminderStatus(r, currentKmByVehicle.get(r.vehicleId) ?? 0, thresholds);
    if (st.status === "overdue" || st.status === "soon") {
      nearby.push({ reminder: r, label: st.label, overdue: st.status === "overdue" });
    }
  }

  const notified = loadNotified();
  const sysNotified = loadSysNotified();
  const permGranted = notifPermissionGranted();
  const today = new Date().toISOString().slice(0, 10);
  const fired: NearbyReminder[] = [];
  const sysPosted: NearbyReminder[] = [];

  for (const n of nearby) {
    const key = reminderKey(n.reminder);
    const id = n.reminder.id;
    const vehicleName = vehicleNames.get(n.reminder.vehicleId) ?? "خودرو";
    const title = n.overdue ? `⏰ یادآور عقب‌افتاده: ${n.reminder.title}` : `🔔 یادآور نزدیک: ${n.reminder.title}`;
    const body = `${vehicleName} — ${n.label}`;

    // ۱) توست درون‌برنامه‌ای — با کلید وضعیت، بدون تکرار
    const prev = notified[id];
    const shouldFire =
      prev !== key ||
      (n.overdue && settings.renotifyOverdue && prev !== `${key}#${today}`);
    if (shouldFire) {
      notified[id] = n.overdue ? `${key}#${today}` : key;
      fired.push(n);
    }

    // ۲) نوتیفیکیشن سیستم — فقط با مجوز، با ردیابی جدا؛
    //    اگر بعداً مجوز داده شد، همین بررسی دوباره اطلاع‌های سیستم را می‌فرستد
    if (permGranted && sysNotified[id] !== key) {
      sysNotified[id] = key;
      sysPosted.push(n);
      showNotification(title, body);
    }
  }

  // پاک‌سازی یادآورهای حذف‌شده/انجام‌شده
  const activeIds = new Set(reminders.map((r) => r.id));
  for (const id of Object.keys(notified)) {
    if (!activeIds.has(id)) delete notified[id];
  }
  for (const id of Object.keys(sysNotified)) {
    if (!activeIds.has(id)) delete sysNotified[id];
  }
  saveNotified(notified);
  saveSysNotified(sysNotified);

  return { fired, sysPosted };
}
