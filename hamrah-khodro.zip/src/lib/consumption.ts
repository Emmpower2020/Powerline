/** بازمحاسبه مصرف سوخت باک‌کامل به باک‌کامل — با احتساب سوخت‌گیری‌های نیم‌بند بینابین */
export async function recalcConsumption(vehicleId: string) {
  const { db } = await import("@/lib/db");
  const fuels = await db.record.findMany({
    where: { vehicleId, type: "FUEL" },
    orderBy: [{ date: "asc" }, { createdAt: "asc" }],
  });
  let prevFull: { mileage: number | null } | null = null;
  let litersSinceFull = 0;
  for (const f of fuels) {
    let consumption: number | null = null;
    litersSinceFull += f.liters ?? 0;
    if (f.fullTank && prevFull && f.mileage && prevFull.mileage && f.mileage > prevFull.mileage && litersSinceFull > 0) {
      const distance = f.mileage - prevFull.mileage;
      if (distance > 0) {
        const value = (litersSinceFull / distance) * 100;
        consumption = value > 0 && value < 60 ? Math.round(value * 10) / 10 : null;
      }
    }
    await db.record.update({ where: { id: f.id }, data: { consumption } });
    if (f.fullTank) {
      prevFull = { mileage: f.mileage };
      litersSinceFull = 0;
    }
  }
}
