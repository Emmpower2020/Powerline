/**
 * پیکربندی Firebase (v3.9.3) — سینک ابری فقط با «حساب گوگل».
 *
 * همهٔ پیکربندی در کد تعبیه شده است (درخواست کاربر) — پروژهٔ گوگل «hamrahprj»:
 *  - ورود: OAuth گوگل در مرورگر سیستم (Chrome Custom Tab) از طریق CloudBridge جاوا
 *  - توکن: id_token گوگل → Firebase Auth REST (signInWithIdp) → نشست فایربیس
 *  - داده: سند Firestore «hamrah_users/{uid}» با REST خالص
 *
 * مقادیر شناسه‌های عمومی‌اند و امنیت واقعی با Rules فایراستور اعمال می‌شود
 * (هر کاربر فقط سند خودش را می‌خواند/می‌نویسد — docs/firebase-setup.md).
 */

export interface FirebaseAppConfig {
  apiKey: string;
  authDomain?: string;
  projectId: string;
  appId?: string;
  /** کلاینت OAuth اندرویدِ همین پروژه — برای ورود گوگل در CloudBridge */
  androidClientId?: string;
}

/** ⭐ پیکربندی تعبیه‌شدهٔ پیش‌فرض — پروژهٔ hamrahprj (google-services.json) */
export const FIREBASE_DEFAULT_CONFIG: FirebaseAppConfig = {
  apiKey: "AIzaSyDitRMguD0DVjqiMxNCbVPuPS0s0D-7uZk",
  authDomain: "hamrahprj.firebaseapp.com",
  projectId: "hamrahprj",
  appId: "1:358616461933:android:22c19f99f5a704f78a0564",
  androidClientId: "358616461933-okqrjiuosruele895435ti2s2lpgvm46.apps.googleusercontent.com",
};

const K_CONFIG = "hamrah-khodro-fb-config";

/** پیکربندی فعال — همیشه مقدار دارد (پیش‌فرض تعبیه‌شده؛ localStorage فقط override) */
export function getFirebaseConfig(): FirebaseAppConfig {
  try {
    const raw = localStorage.getItem(K_CONFIG);
    if (raw) {
      const j = JSON.parse(raw) as FirebaseAppConfig;
      if (j && typeof j.apiKey === "string" && typeof j.projectId === "string" && j.apiKey && j.projectId) {
        return { ...FIREBASE_DEFAULT_CONFIG, ...j };
      }
    }
  } catch {
    /* ignore */
  }
  return FIREBASE_DEFAULT_CONFIG;
}

/** ذخیرهٔ پیکربندی جایگزین (فقط برای تست/پروژهٔ دیگر) */
export function saveFirebaseConfig(cfg: FirebaseAppConfig): void {
  localStorage.setItem(K_CONFIG, JSON.stringify({ apiKey: cfg.apiKey, projectId: cfg.projectId }));
}

export function clearFirebaseConfig(): void {
  try {
    localStorage.removeItem(K_CONFIG);
  } catch {
    /* ignore */
  }
}

/** پارس متن چسبانده‌شده (firebaseConfig یا google-services.json) */
export function parseFirebaseConfigText(text: string): FirebaseAppConfig | null {
  const t = text.trim();
  if (!t) return null;
  try {
    const j = JSON.parse(t) as Record<string, unknown>;
    const key = typeof j.apiKey === "string" ? j.apiKey : undefined;
    const pid = typeof j.projectId === "string" ? j.projectId : undefined;
    if (key && pid) return { apiKey: key, projectId: pid };
  } catch {
    /* ادامه با regex */
  }
  const key = /["']?apiKey["']?\s*[:=]\s*["']([A-Za-z0-9_\-]{20,})["']/.exec(t)?.[1];
  const pid = /["']?projectId["']?\s*[:=]\s*["']([a-z0-9\-]{4,})["']/.exec(t)?.[1];
  if (key && pid) return { apiKey: key, projectId: pid };
  return null;
}

/* ─────────── لینک‌های کنسول برای کارت‌های راهنمای فعال‌سازی ─────────── */

export function identityApiEnableUrl(projectId: string): string {
  return `https://console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=${projectId}`;
}

export function firestoreApiEnableUrl(projectId: string): string {
  return `https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=${projectId}`;
}

export function firebaseConsoleUrl(projectId: string): string {
  return `https://console.firebase.google.com/project/${projectId}/firestore`;
}

export function firebaseRulesUrl(projectId: string): string {
  return `https://console.firebase.google.com/project/${projectId}/firestore/rules`;
}

export function oauthClientsUrl(projectId: string): string {
  return `https://console.cloud.google.com/auth/clients?project=${projectId}`;
}
