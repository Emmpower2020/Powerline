/**
 * نشانگر انتظار سراسری (v3.8.5) — حین کارهای پس‌زمینه (همگام‌سازی / بازیابی از ابر)
 *
 * چرا این ماژول لازم است؟
 *  - فراخوانی‌های پل جاوا (AndroidCloud.driveRequest و…) «همگام» هستند؛ یعنی تا پایان
 *    عملیات، رشتهٔ JS قفل می‌شود و هیچ رندر React در میانهٔ کار ممکن نیست.
 *  - راه‌حل: نشانگر «قبل از شروعِ» عملیات رندر می‌شود (withBusy منتظر دو فریم نقاشی
 *    می‌ماند) و انیمیشن‌های CSS آن (transform/opacity) روی رشتهٔ کامپوزیتور اجرا
 *    می‌شوند — یعنی حتی وقتی JS مشغولِ گفت‌وگو با گوگل است، اسپینر می‌چرخد و کاربر
 *    می‌بیند که «کار در حال انجام است» و باید لحظه‌ای صبر کند.
 *
 * دو حالت نمایش:
 *  - pill    → کپسول شناور بالای صفحه (غیرمسدودکننده) — برای همگام‌سازی/دریافت
 *  - overlay → پردهٔ انتظار تمام‌صفحه با کارت مرکزی — برای بازیابی/جایگزینی داده
 *
 * استفاده:
 *    const r = await withBusy({ mode: "pill", title: "در حال همگام‌سازی…" }, () => runSyncNow());
 */

export type BusyMode = "pill" | "overlay";

export interface BusySpec {
  /** pill: کپسول شناور بالای صفحه — overlay: پردهٔ انتظار تمام‌صفحه (پیش‌فرض pill) */
  mode?: BusyMode;
  /** پیام اصلی — مثلاً «در حال همگام‌سازی با Google Drive…» */
  title: string;
  /** توضیح اختیاری زیر پیام اصلی */
  detail?: string;
}

export interface BusyState extends Required<Omit<BusySpec, "detail">> {
  detail?: string;
  /** شمارهٔ یکتای نشانگر — عملیات قدیمی با توکنش نمی‌تواند نشانگرِ جدیدتر را ببندد */
  token: number;
}

type Listener = (state: BusyState | null) => void;

let current: BusyState | null = null;
let seq = 0;
const listeners = new Set<Listener>();

/** اشتراک تغییرات — بلافاصله با وضعیت فعلی صدا زده می‌شود */
export function subscribeBusy(listener: Listener): () => void {
  listeners.add(listener);
  listener(current);
  return () => {
    listeners.delete(listener);
  };
}

export function getBusy(): BusyState | null {
  return current;
}

/** نمایش نشانگر — توکن را برگرداند تا در پایان، پنهان‌کردنِ امن انجام شود */
export function showBusy(spec: BusySpec): number {
  const token = ++seq;
  current = { mode: spec.mode ?? "pill", title: spec.title, detail: spec.detail, token };
  for (const l of listeners) l(current);
  return token;
}

/** پنهان‌کردن نشانگر — با توکنِ عملیات خودش؛ نشانگرِ جدیدتر را نمی‌بندد */
export function hideBusy(token?: number): void {
  if (token && current && current.token !== token) return;
  current = null;
  for (const l of listeners) l(null);
}

/* قلاب تست/شبیه‌ساز — برای E2E و بررسی بصری دستی (فقط مرورگر) */
if (typeof window !== "undefined") {
  (window as unknown as { __hkBusy?: { show: (s: BusySpec) => void; hide: () => void } }).__hkBusy = {
    show: (s) => {
      showBusy(s);
    },
    hide: () => {
      hideBusy();
    },
  };
}

/**
 * انتظار تا نقاشیِ قطعی نشانگر: دو فریم انیمیشن + مکث کوتاه.
 * بعد از این، فراخوانی همگام پل جاوا با خیال راحت اجرا می‌شود — نشانگر
 * حتماً روی صفحه است و انیمیشن CSS آن (روی کامپوزیتور) حتی حین قفل JS ادامه دارد.
 */
function nextPaint(): Promise<void> {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    try {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setTimeout(finish, 70);
        });
      });
    } catch {
      /* محیط بدون rAF */
    }
    // fallback قطعی — هر اتفاقی افتاد، عملیات بیش از این معطل نمی‌ماند
    setTimeout(finish, 900);
  });
}

/**
 * اجرای عملیات (همگام یا ناهمگام) همراه با نشانگر انتظار سراسری.
 *
 * ترتیب: نمایش نشانگر → انتظار برای نقاشی → اجرای عملیات → حفظ حداقلِ نمایشِ
 * «قشنگ» (که حالت انتظار برای کاربرِ سریع‌الپس هم قابل‌ادراک باشد) → پنهان‌سازی.
 * اگر عملیات خطا بدهد، نشانگر در finally حتماً پنهان می‌شود.
 * ⭐ v3.8.7: عملیات می‌تواند Promise برگرداند — با await واقعی، نشانگر تا «پایانِ"
 * کار زنده می‌ماند (قبلاً با برگرداندن Promise، finally بلافاصله اجرا می‌شد!).
 */
export async function withBusy<T>(
  spec: BusySpec,
  fn: () => T | Promise<T>,
  opts?: { minMs?: number }
): Promise<T> {
  const token = showBusy(spec);
  const t0 = Date.now();
  try {
    await nextPaint();
    return await fn();
  } finally {
    const min = opts?.minMs ?? (spec.mode === "overlay" ? 750 : 450);
    const elapsed = Date.now() - t0;
    if (elapsed < min) {
      await new Promise((r) => setTimeout(r, min - elapsed));
    }
    hideBusy(token);
  }
}
