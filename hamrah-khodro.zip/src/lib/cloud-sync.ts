/**
 * موتور همگام‌سازی ابری واقعی — Google Drive (App Data) از طریق پل جاوای CloudBridge
 *
 * اصول (نسخهٔ v3.8 — Client ID تعبیه‌شده):
 *  - اتصال فقط با احراز هویت واقعی OAuth 2.0 (PKCE + اسکیم اختصاصی برنامه) برقرار می‌شود؛
 *    هیچ حالت «وصل شد» جعلی وجود ندارد. کاربر فقط دکمهٔ «به Google Drive وصل شوید» را می‌زند و
 *    صفحهٔ رسمی انتخاب حساب گوگل در مرورگر گوشی باز می‌شود؛ مجوزها را همان‌جا تأیید می‌کند.
 *  - Client ID از src/lib/cloud-config.ts (توسط توسعه‌دهنده) — کاربر نهایی چیزی وارد نمی‌کند.
 *  - توکن‌ها فقط در لایهٔ جاوا (SharedPreferences خصوصی) نگه داشته می‌شوند و هرگز به JS نمی‌آیند.
 *  - همهٔ فراخوانی‌های گوگل (تبدیل کد، نوسازی توکن، Drive API) از جاوا با هدر Authorization انجام می‌شود.
 *  - داده‌ها در پوشهٔ اختصاصی برنامه (appDataFolder) در Drive کاربر ذخیره می‌شوند — نه در فایل‌های شخصی.
 *  - پیام موفقیت/«متصل» فقط بعد از پاسخ موفق واقعی گوگل (تبدیل توکن + فراخوانی Drive) نمایش داده می‌شود.
 *  - خطای سینک هرگز دادهٔ محلی را پاک نمی‌کند؛ قبل از جایگزینی، پشتیبان محلی تهیه می‌شود.
 *  - جریان نیمه‌تمام (بازگشت از مرورگر بعد از بسته‌شدن برنامه) در بوت بعدی خودکار ادامه می‌یابد.
 */

import { GOOGLE_CLIENT_ID } from "@/lib/cloud-config";
import { withBusy } from "@/lib/busy";

/* ───────────────────────────── پل جاوا (AndroidCloud) ───────────────────────────── */

export interface CloudBridgeResult {
  ok?: boolean;
  [k: string]: unknown;
}

export interface AndroidCloudBridge {
  /** شروع جریان اتصال: پیش‌بررسی + باز کردن صفحهٔ رسمی گوگل در مرورگر سیستم */
  startBrowserAuth(): string;
  /** وضعیت جریان اتصال: waiting | done | error | timeout | none */
  pollBrowserAuth(): string;
  /** لغو جریان اتصال */
  cancelBrowserAuth(): string;
  /** تبدیل کد مجوز به توکن (PKCE) + ذخیرهٔ امن در جاوا + ایمیل از id_token */
  exchangeCode(): string;
  /** حساب ذخیره‌شده در جاوا */
  getAccount(): string;
  /** فراخوانی Drive API با توکن جاوا (نوسازی خودکار + تلاش مجدد 401) */
  driveRequest(method: string, url: string, contentType: string, body: string): string;
  /** باز کردن یک URL گوگل در مرورگر سیستم */
  openUrl(url: string): string;
  /** قطع اتصال: ابطال توکن در گوگل + پاک‌کردن ذخیرهٔ محلی */
  disconnect(): string;
  /* ── ⭐ v3.8.7: پل ناهمگام — HTTP در نخ پس‌زمینهٔ جاوا؛ JS قفل نمی‌شود و برنامه زنده می‌ماند.
     نتیجه با evaluateJavascript به تابعِ globalِ به‌نامِ callback می‌رسد (آبجکت JSON). ── */
  driveRequestAsync?(method: string, url: string, contentType: string, body: string, callback: string): void;
  exchangeCodeAsync?(callback: string): void;
  disconnectAsync?(callback: string): void;
}

declare global {
  interface Window {
    AndroidCloud?: AndroidCloudBridge;
  }
}

/** آیا پل جاوای ابری وجود دارد؟ (فقط داخل APK) */
export function cloudBridge(): AndroidCloudBridge | null {
  try {
    const b = (globalThis as unknown as { AndroidCloud?: AndroidCloudBridge }).AndroidCloud;
    if (b && typeof b.getAccount === "function" && typeof b.driveRequest === "function") return b;
  } catch {
    /* ignore */
  }
  return null;
}

/* ───────────────────────────── تنظیمات و فراداده (localStorage) ───────────────────────────── */

const K_AUTO = "hamrah-khodro-cloud-auto";
const K_META = "hamrah-khodro-cloud-meta";
const K_LAST_HASH = "hamrah-khodro-cloud-last-hash";
/** ⭐ v3.8.7: کش شناسهٔ فایل ابری — آپلود/دانلود بدون «لیست» اضافی (سینک سریع‌تر) */
const K_FILE_ID = "hamrah-khodro-cloud-file-id";

export interface CloudSyncCounts {
  vehicles: number;
  totalRecords: number;
  services: number;
  fuels: number;
  odometers: number;
  notes: number;
  reminders: number;
  brands: number;
  serviceTypes: number;
  totalCost: number;
}

export interface CloudSyncMeta {
  at: string;
  status: "ok" | "failed" | "cloud_ahead";
  error?: string;
  counts?: CloudSyncCounts;
  cloudModified?: string;
  cloudSize?: number;
  unchanged?: boolean;
}

function lsGet(k: string): string | null {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
}
function lsSet(k: string, v: string) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* ignore */
  }
}
function lsDel(k: string) {
  try {
    localStorage.removeItem(k);
  } catch {
    /* ignore */
  }
}

export function getAutoSync(): boolean {
  return lsGet(K_AUTO) !== "0";
}

export function setAutoSync(on: boolean) {
  lsSet(K_AUTO, on ? "1" : "0");
}

export function getSyncMeta(): CloudSyncMeta | null {
  try {
    const raw = lsGet(K_META);
    if (!raw) return null;
    const m = JSON.parse(raw) as CloudSyncMeta;
    if (!m || !m.at) return null;
    return m;
  } catch {
    return null;
  }
}

function setSyncMeta(m: CloudSyncMeta) {
  lsSet(K_META, JSON.stringify(m));
}

/* ───────────────────────────── خطاها → پیام فارسی ───────────────────────────── */

/** نوع راهنمایی که UI می‌تواند برای هر خطا ارائه کند */
export type CloudErrorHelp =
  | "enable_drive_api"
  | "reconnect"
  | "storage"
  | "publish"
  | "scheme";

export interface CloudErrorInfo {
  code: string;
  message: string;
  /** متن فنی واقعی گوگل (انگلیسی) — برای شفافیت و عیب‌یابی دقیق */
  detail?: string;
  /** راهنمای متناسب با خطا (UI دکمه/شیت مناسب را نشان می‌دهد) */
  help?: CloudErrorHelp;
}

/** تبدیل خطای واقعی گوگل/شبکه به پیام فارسی قابل فهم */
export function mapCloudError(
  error: string | undefined,
  detail: string | undefined,
  status?: number
): CloudErrorInfo {
  const e = (error ?? "").trim();
  const d = (detail ?? "").trim();
  switch (e) {
    case "network":
      return {
        code: "network",
        message:
          "اتصال به سرور گوگل برقرار نشد — اینترنت گوشی را بررسی کنید و دوباره تلاش کنید",
      };
    case "no_browser":
      return { code: "no_browser", message: "مرورگری روی گوشی برای ورود به گوگل پیدا نشد" };
    case "custom_scheme_disabled":
      return {
        code: "custom_scheme_disabled",
        message:
          "یک تنظیم در Google Cloud باقی مانده: در کنسول، کلاینت اندروید برنامه را باز کنید و در «Advanced settings» گزینهٔ «Enable custom URI scheme» را روشن و ذخیره کنید (یک‌بار برای همیشه) — سپس دوباره تلاش کنید",
        help: "scheme",
      };
    case "invalid_client":
      return {
        code: "invalid_client",
        message:
          "شناسهٔ کلاینت گوگل برنامه معتبر نیست — کلاینت اندروید (Android) در Google Cloud با پکیج com.zai.hamrahkhodro و SHA-1 کلید امضا باید ساخته/به‌روز شده باشد",
        help: "scheme",
      };
    case "redirect_uri_mismatch":
      return {
        code: "redirect_uri_mismatch",
        message: "آدرس بازگشت (redirect) با کلاینت گوگل هم‌خوانی ندارد — گزینهٔ Custom URI scheme در کنسول فعال باشد",
        help: "scheme",
      };
    case "invalid_grant":
      if (/expired or revoked/i.test(d))
        return {
          code: "invalid_grant_expired",
          message:
            "دسترسی گوگل منقضی شد (اگر پروژه در حالت Testing باشد، گوگل اتصال را هر ۷ روز یک‌بار باطل می‌کند) — دوباره دکمهٔ اتصال را بزنید؛ برای دائمی‌شدن، پروژه را در کنسول Publish کنید",
          detail: d,
          help: "publish",
        };
      return d.includes("code")
        ? {
            code: "invalid_grant",
            message: "کد ورود منقضی یا یک‌بار مصرف است — دوباره تلاش کنید",
            detail: d,
          }
        : {
            code: "invalid_grant",
            message: "دسترسی گوگل منقضی یا لغو شده — دوباره به حساب وصل شوید",
            detail: d,
            help: "reconnect",
          };
    case "access_denied":
      return {
        code: "access_denied",
        message:
          "دسترسی در صفحهٔ گوگل رد شد — اگر هشدار «برنامهٔ تأییدنشده» دیدید، روی Advanced و سپس Go to (unsafe) بزنید و ادامه دهید (برنامهٔ خودتان است)؛ بعد مجوز را تأیید کنید",
        help: "publish",
      };
    case "org_internal":
      return {
        code: "org_internal",
        message: "این حساب گوگل اجازهٔ استفاده از این کلاینت را ندارد — آن را Test User کنید",
        help: "publish",
      };
    case "expired_token":
      return { code: "expired_token", message: "کد اتصال منقضی شد — دوباره تلاش کنید" };
    case "unauthorized_client":
      return {
        code: "unauthorized_client",
        message: "این نوع کلاینت گوگل برای این روش اتصال مجاز نیست — نوع کلاینت را در Google Cloud بررسی کنید",
        help: "scheme",
      };
    case "unsupported_grant_type":
    case "invalid_request":
      return {
        code: e,
        message: "درخواست به گوگل نامعتبر بود — دوباره تلاش کنید",
        detail: d,
      };
    case "disconnected":
      return {
        code: "disconnected",
        message:
          "دسترسی گوگل قطع شده — دوباره به حساب وصل شوید (در حالت Testing گوگل اتصال را هر ۷ روز باطل می‌کند؛ برای دائمی‌شدن پروژه را Publish کنید)",
        help: "reconnect",
      };
    case "quota":
      return {
        code: "storage_full",
        message:
          "فضای Google Drive حساب شما پر شده است — از one.google.com/storage فضای خالی کنید و دوباره تلاش کنید",
        help: "storage",
      };
    case "http":
      if (status === 403)
        return { code: "http", message: "گوگل اجازهٔ این عملیات را نداد (403) — دوباره تلاش کنید" };
      if (status === 404)
        return { code: "http", message: "فایل پشتیبان در ابر پیدا نشد — اول همگام‌سازی کنید" };
      if (status === 429)
        return { code: "http", message: "درخواست‌های زیاد به گوگل — کمی صبر کنید و دوباره تلاش کنید" };
      return {
        code: "http",
        message: `خطای سرور گوگل (${status ?? "?"}) — بعداً دوباره تلاش کنید`,
      };
    default: {
      const fallback = d || e || (status ? `کد ${status}` : "خطای نامشخص");
      return { code: e || "unknown", message: `اتصال/همگام‌سازی ناموفق بود — ${fallback}`, detail: d || undefined };
    }
  }
}

/** خروجی پارس JSON خطای گوگل */
export interface ParsedGoogleError {
  /** reason واقعی گوگل مثل storageQuotaExceeded / insufficientPermissions */
  error?: string;
  /** پیام انگلیسی واقعی گوگل */
  errorDescription?: string;
  /** وضعیت REST مثل FAILED_PRECONDITION / PERMISSION_DENIED / RESOURCE_EXHAUSTED */
  gstatus?: string;
}

/**
 * اگر body خطای گوگل JSON است، «دلیل واقعی» گوگل را بیرون می‌کشد.
 * هر سه قالب گوگل را می‌شناسد:
 *  - OAuth:            { error: "invalid_grant", error_description: "…" }
 *  - قدیمی (errors[]): { error: { code: 403, message: "…", errors: [{ reason, message }] } }
 *  - جدید (status):    { error: { code: 403, message: "…", status: "FAILED_PRECONDITION", details: [{ reason }] } }
 */
export function parseGoogleError(body: unknown): ParsedGoogleError {
  if (typeof body === "string" && body.trim().startsWith("{")) {
    try {
      const j = JSON.parse(body) as Record<string, unknown>;
      if (typeof j.error === "string") {
        return { error: j.error, errorDescription: String(j.error_description ?? "") };
      }
      if (j.error && typeof j.error === "object") {
        const o = j.error as Record<string, unknown>;
        const errs = Array.isArray(o.errors) ? (o.errors as Record<string, unknown>[])[0] : undefined;
        const det = Array.isArray(o.details) ? (o.details as Record<string, unknown>[])[0] : undefined;
        const reason =
          (typeof errs?.reason === "string" && errs.reason) ||
          (typeof det?.reason === "string" && det.reason) ||
          (typeof o.reason === "string" && o.reason) ||
          (typeof o.status === "string" && o.status) ||
          "";
        const message = String(
          (typeof o.message === "string" && o.message) ||
            (typeof errs?.message === "string" && errs.message) ||
            ""
        );
        return {
          error: reason || (o.code !== undefined ? String(o.code) : ""),
          errorDescription: message,
          gstatus: typeof o.status === "string" ? o.status : "",
        };
      }
    } catch {
      /* ignore */
    }
  }
  return {};
}

/**
 * ⭐ نگاشت دقیق خطای Drive API — به‌جای حدس زدن، «دلیل واقعی گوگل» را می‌خواند:
 *  - Drive API غیرفعال است؟ (FAILED_PRECONDITION / accessNotConfigured)
 *  - مجوز/اسکوپ ناکافی؟ (insufficientPermissions / ACCESS_TOKEN_SCOPE_INSUFFICIENT)
 *  - فضای واقعی Drive پر است؟ (storageQuotaExceeded — فقط همین حالت «فضا پر است» است!)
 *  - محدودیت تعداد درخواست؟ (rateLimitExceeded / RESOURCE_EXHAUSTED)
 *  - یا پیام واقعی گوگل به‌عنوان جزییات فنی نمایش داده می‌شود.
 */
export function mapDriveError(resp: DriveResponse): CloudErrorInfo {
  if (resp.error === "network") return mapCloudError("network", "");
  if (resp.error === "no_bridge") return mapCloudError("unknown", "پل ابری فقط در نسخهٔ اندروید فعال است");
  if (resp.disconnected || resp.error === "disconnected") return mapCloudError("disconnected", "");

  const { error, errorDescription, gstatus } = parseGoogleError(resp.body);
  const reason = (error ?? "").trim();
  const msg = (errorDescription ?? "").trim();
  const st = (gstatus ?? "").trim();
  const all = `${reason} ${st} ${msg}`;
  const detail = msg || reason || undefined;

  // ۱) Drive API در پروژهٔ گوگل فعال نیست
  if (
    /accessNotConfigured|SERVICE_DISABLED|FAILED_PRECONDITION/i.test(all) ||
    /has not been used in project|is disabled\.?\s*Enable it/i.test(msg)
  ) {
    return {
      code: "api_disabled",
      message:
        "Google Drive API در پروژهٔ گوگل شما فعال نیست — دکمهٔ «فعال‌سازی Drive API» را بزنید، در صفحهٔ بازشده روی Enable کلیک کنید و به برنامه برگردید؛ همگام‌سازی خودکار دوباره انجام می‌شود. اگر به‌تازگی فعال کرده‌اید چند لحظه صبر کنید و «تلاش دوباره» را بزنید.",
      detail,
      help: "enable_drive_api",
    };
  }
  // ۲) مجوز/اسکوپ کافی نیست → قطع و اتصال مجدد (از v3.8.2 صفحهٔ تأیید گوگل اجباری می‌شود)
  if (/insufficientPermissions|ACCESS_TOKEN_SCOPE_INSUFFICIENT|insufficient authentication scopes|Insufficient Permission/i.test(all)) {
    return scopeErrorInfo(detail);
  }
  // ۳) فضای واقعی Drive پر است — فقط این حالت «فضا پر است» است
  if (/storageQuotaExceeded|storage quota|quota is exhausted/i.test(all)) {
    return {
      code: "storage_full",
      message:
        "گوگل می‌گوید فضای Drive این حساب پر شده است — از one.google.com/storage فضای خالی کنید و دوباره تلاش کنید (فایل پشتیبان این برنامه فقط چند کیلوبایت است)",
      detail,
      help: "storage",
    };
  }
  // ۴) محدودیت تعداد/سهمیهٔ درخواست‌ها (موقتی)
  if (
    /quotaExceeded|dailyLimitExceeded|userRateLimitExceeded|rateLimitExceeded|sharingRateLimitExceeded|RESOURCE_EXHAUSTED|rate limit|Too many requests/i.test(
      all
    ) ||
    resp.status === 429
  ) {
    return {
      code: "rate_limited",
      message:
        "تعداد درخواست‌ها به گوگل بیشتر از حد مجاز لحظه‌ای بوده — چند دقیقه صبر کنید و دوباره تلاش کنید",
      detail,
    };
  }
  // ۵) توکن نامعتبر (جاوا معمولاً خودش نوسازی می‌کند)
  if (resp.status === 401) {
    return { code: "disconnected", message: "دسترسی گوگل منقضی شده — دوباره به حساب وصل شوید", detail, help: "reconnect" };
  }
  // ۶) بقیه — پیام واقعی گوگل همراه پیام فارسی عمومی
  const info = mapCloudError(reason || (resp.status ? "http" : "unknown"), msg, resp.status);
  return { ...info, detail };
}

/**
 * خطای «مجوز پشتیبان‌گیری داده نشده» — توکن فعلی اسکوپ drive.appdata ندارد.
 * علت رایج: گوگل برای کلاینتی که قبلاً مجوز ناقص گرفته، بدون صفحهٔ تأیید توکن تکراری می‌دهد.
 * راه‌حل: قطع اتصال (ابطال توکن) + اتصال مجدد — از v3.8.2 صفحهٔ تأیید اجباری است و مجوز تازه می‌گیرد.
 */
export function scopeErrorInfo(detail?: string): CloudErrorInfo {
  return {
    code: "scope_insufficient",
    message:
      "مجوز پشتیبان‌گیری در Drive به برنامه داده نشده — «قطع و اتصال مجدد» را بزنید و در صفحهٔ تأیید گوگل حتماً «اجازه دادن» را انتخاب کنید",
    detail,
    help: "reconnect",
  };
}

/** آیا اسکوپِ توکنِ متصل، مجوز پشتیبان (drive.appdata) را ندارد؟ (v3.8.2+) */
export function accountMissingBackupScope(): boolean {
  const acc = getCloudAccount();
  if (!acc.connected || !acc.scope) return false;
  return !/drive\.appdata/.test(acc.scope);
}

/** استخراج لینک فعال‌سازی Drive API از پیام خطای گوگل (شمارهٔ پروژه) */
export function driveApiEnableUrl(detail?: string): string {
  const m = /project\/?(\d+)|project=(\d+)|project ([0-9]{6,})/i.exec(detail ?? "");
  const num = m?.[1] ?? m?.[2] ?? m?.[3];
  if (num) return `https://console.developers.google.com/apis/api/drive.googleapis.com/overview?project=${num}`;
  return "https://console.developers.google.com/apis/api/drive.googleapis.com/overview";
}

/* ───────────────────────────── جریان اتصال (مرورگر سیستم + اسکیم اختصاصی) ───────────────────────────── */

export type BrowserAuthState = "none" | "waiting" | "done" | "error" | "timeout";

export interface BrowserAuthPoll {
  state: BrowserAuthState;
  error?: string;
}

function jp<T>(raw: string): T {
  return JSON.parse(raw) as T;
}

/** شروع اتصال — Client ID تعبیه‌شده در پل جاوا است؛ کاربر فقط دکمه را می‌زند */
export function startBrowserAuth(): { ok: boolean; authUrl?: string; error?: CloudErrorInfo } {
  const bridge = cloudBridge();
  if (!bridge) return { ok: false, error: { code: "no_bridge", message: "پل ابری فقط در نسخهٔ اندروید فعال است" } };
  try {
    const r = jp<CloudBridgeResult>(bridge.startBrowserAuth());
    if (r.ok) return { ok: true, authUrl: String(r.authUrl ?? "") };
    const { error, errorDescription } = parseGoogleError(r.body);
    return {
      ok: false,
      error: mapCloudError(
        String(r.error ?? error),
        String(r.errorDescription ?? errorDescription ?? r.detail),
        typeof r.status === "number" ? r.status : undefined
      ),
    };
  } catch (e) {
    return { ok: false, error: mapCloudError("unknown", String(e)) };
  }
}

export function pollBrowserAuth(): BrowserAuthPoll {
  const bridge = cloudBridge();
  if (!bridge) return { state: "none" };
  try {
    return jp<BrowserAuthPoll>(bridge.pollBrowserAuth());
  } catch {
    return { state: "none" };
  }
}

export function cancelBrowserAuth(): void {
  const bridge = cloudBridge();
  try {
    bridge?.cancelBrowserAuth();
  } catch {
    /* ignore */
  }
}

/** تبدیل کد به توکن — فقط بعد از موفقیت، حساب متصل می‌شود
 *  ⭐ v3.8.7: ناهمگام — گفت‌وگو با سرور گوگل روی نخ پس‌زمینهٔ جاوا (برنامه زنده می‌ماند) */
export async function exchangeCode(): Promise<{ ok: boolean; email?: string; error?: CloudErrorInfo }> {
  const bridge = cloudBridge();
  if (!bridge) return { ok: false, error: { code: "no_bridge", message: "پل ابری فقط در نسخهٔ اندروید فعال است" } };
  const asyncFn = bridge.exchangeCodeAsync;
  if (typeof asyncFn === "function") {
    const r = await callBridgeAsync<CloudBridgeResult & { email?: string }>((cb) => {
      asyncFn.call(bridge, cb);
    });
    if (r) return parseExchangeResult(r);
    return { ok: false, error: mapCloudError("unknown", "تبدیل کد پاسخ نداد — دوباره تلاش کنید") };
  }
  try {
    const r = jp<CloudBridgeResult & { email?: string }>(bridge.exchangeCode());
    if (r) return parseExchangeResult(r);
    return { ok: false, error: mapCloudError("unknown", "پاسخ پل خوانده نشد") };
  } catch (e) {
    return { ok: false, error: mapCloudError("unknown", String(e)) };
  }
}

function parseExchangeResult(r: CloudBridgeResult & { email?: string }): {
  ok: boolean;
  email?: string;
  error?: CloudErrorInfo;
} {
  if (r.ok) return { ok: true, email: String(r.email ?? "") };
  const { error, errorDescription } = parseGoogleError(typeof r.body === "string" ? r.body : "");
  return {
    ok: false,
    error: mapCloudError(
      String(r.error ?? error),
      String((r.errorDescription as string) ?? errorDescription ?? r.detail),
      typeof r.status === "number" ? r.status : undefined
    ),
  };
}

/* ─── ادامهٔ خودکار جریان نیمه‌تمام (بازگشت از مرورگر بعد از بسته‌شدن برنامه) ─── */

let resumeTimer: ReturnType<typeof setInterval> | null = null;

/**
 * در بوت برنامه صدا زده می‌شود:
 *  - اگر کد مجوز از گوگل رسیده ولی هنوز تبدیل نشده → تبدیل و اتصال کامل می‌شود.
 *  - اگر کاربر وسط ورود بوده → در پس‌زمینه منتظر می‌ماند و خودکار کامل می‌کند.
 */
export function autoResumeAuthFlow(onConnected?: (email: string) => void): void {
  const bridge = cloudBridge();
  if (!bridge) return;
  try {
    const account = getCloudAccount();
    if (account.connected) return;
    const p = pollBrowserAuth();
    if (p.state === "done") {
      // ⭐ v3.8.5: نشانگر انتظار سراسری — کاربر می‌بیند اتصال در حال تکمیل است
      void withBusy(
        { mode: "pill", title: "در حال تکمیل اتصال به حساب گوگل…", detail: "تأیید دسترسی با سرور گوگل" },
        () => exchangeCode()
      ).then((r) => {
        if (r.ok && r.email) onConnected?.(r.email);
      });
      return;
    }
    if (p.state === "waiting") {
      if (resumeTimer) return;
      resumeTimer = setInterval(() => {
        try {
          const q = pollBrowserAuth();
          if (q.state === "done") {
            if (resumeTimer) clearInterval(resumeTimer);
            resumeTimer = null;
            void withBusy(
              { mode: "pill", title: "در حال تکمیل اتصال به حساب گوگل…", detail: "تأیید دسترسی با سرور گوگل" },
              () => exchangeCode()
            ).then((r) => {
              if (r.ok && r.email) onConnected?.(r.email);
            });
          } else if (q.state !== "waiting") {
            if (resumeTimer) clearInterval(resumeTimer);
            resumeTimer = null;
          }
        } catch {
          /* بی‌صدا */
        }
      }, 1500);
    }
    // error/timeout/none → کاری نیست (خطای نمایشی در پنجرهٔ ابری مدیریت می‌شود)
  } catch {
    /* ignore */
  }
}

/** برای تست شبیه‌ساز: توقف پولینگ پس‌زمینه */
export function stopAuthResume(): void {
  if (resumeTimer) clearInterval(resumeTimer);
  resumeTimer = null;
}

/* ───────────────────────────── حساب و Drive ───────────────────────────── */

/** باز کردن یک صفحهٔ گوگل در مرورگر سیستم — از پل جاوا (فقط دامنه‌های گوگل) */
export function openExternalUrl(url: string): boolean {
  const bridge = cloudBridge();
  if (bridge) {
    try {
      const r = jp<CloudBridgeResult>(bridge.openUrl(url));
      return r.ok === true;
    } catch {
      return false;
    }
  }
  try {
    window.open(url, "_blank", "noopener");
    return true;
  } catch {
    return false;
  }
}

export interface CloudAccount {
  connected: boolean;
  email?: string;
  expiresAt?: number;
  /** اسکوپ‌های واقعاً داده‌شده به توکن (v3.8.2+) — برای تشخیص مجوز ناقص */
  scope?: string;
}

export function getCloudAccount(): CloudAccount {
  const bridge = cloudBridge();
  if (!bridge) return { connected: false };
  try {
    return jp<CloudAccount>(bridge.getAccount());
  } catch {
    return { connected: false };
  }
}

export interface DriveResponse {
  ok: boolean;
  status: number;
  body: string;
  error?: string;
  disconnected?: boolean;
}

/* ──────────────── ⭐ v3.8.7: پل ناهمگام — کار ابر در پس‌زمینهٔ واقعی ──────────────── */

/** شمارهٔ توالی توابع callback سراسری (هر فراخوانی نام یکتا می‌گیرد) */
let asyncCbSeq = 0;

/** آیا پل ناهمگام (v3.8.7+) در این نصب موجود است؟ */
export function hasAsyncBridge(): boolean {
  const b = cloudBridge();
  return !!b && typeof b.driveRequestAsync === "function";
}

/**
 * اجرای یک متد ناهمگام پل جاوا و دریافت نتیجه به‌صورت Promise.
 * جاوا HTTP را در نخ پس‌زمینه انجام می‌دهد و با evaluateJavascript تابعِ
 * `window[name]` را با آبجکت JSON صدا می‌زند — رشتهٔ JS آزاد می‌ماند و
 * برنامه در تمام طول عملیات به لمس/اسکرول پاسخ می‌دهد.
 */
function callBridgeAsync<T>(
  invoke: (cbName: string) => void,
  timeoutMs = 45000
): Promise<T | null> {
  return new Promise((resolve) => {
    const name = `__hkCloudCb${(++asyncCbSeq).toString(36)}${Date.now().toString(36)}`;
    const w = globalThis as unknown as Record<string, unknown>;
    let settled = false;
    const finish = (raw: unknown) => {
      if (settled) return;
      settled = true;
      try {
        delete w[name];
      } catch {
        /* ignore */
      }
      clearTimeout(timer);
      resolve((raw ?? null) as T | null);
    };
    const timer = setTimeout(() => finish(null), timeoutMs);
    w[name] = finish;
    try {
      invoke(name);
    } catch {
      finish(null);
    }
  });
}

/** فراخوانی Drive API — توکن‌ها در جاوا هستند و از اینجا عبور نمی‌کنند */
export function driveRequest(
  method: string,
  url: string,
  body?: string,
  contentType?: string
): DriveResponse {
  const bridge = cloudBridge();
  if (!bridge) return { ok: false, status: 0, body: "", error: "no_bridge" };
  try {
    const r = jp<DriveResponse>(
      bridge.driveRequest(method, url, contentType ?? "application/json", body ?? "")
    );
    return r;
  } catch (e) {
    return { ok: false, status: 0, body: "", error: String(e) };
  }
}

/**
 * ⭐ v3.8.7: فراخوانی Drive API «بدون قفل‌کردن برنامه»:
 *  - در APK v3.8.7+ روی نخ پس‌زمینهٔ جاوا انجام می‌شود (پاسخ با callback)
 *  - در نصب‌های قدیمی‌تر/وب به همان مسیر همگام برمی‌گردد (با withBusy پوشش داده می‌شود)
 */
export async function driveRequestAsync(
  method: string,
  url: string,
  body?: string,
  contentType?: string
): Promise<DriveResponse> {
  const bridge = cloudBridge();
  const asyncFn = bridge?.driveRequestAsync;
  if (typeof asyncFn === "function") {
    const r = await callBridgeAsync<DriveResponse>((cb) => {
      asyncFn.call(
        bridge,
        method,
        url,
        contentType ?? "application/json",
        body ?? "",
        cb
      );
    });
    if (r && typeof r === "object" && typeof (r as DriveResponse).status === "number") {
      return r;
    }
    if (r && typeof r === "object") {
      // آبجکت JSON رسیده بدون فیلد status — ساختار مورد اعتماد نیست ولی پاسخ گوگل است
      return r as DriveResponse;
    }
    return { ok: false, status: 0, body: "", error: "async_timeout" };
  }
  return driveRequest(method, url, body, contentType);
}

export interface DisconnectResult {
  ok: boolean;
  revoked?: boolean;
  error?: CloudErrorInfo;
}

function parseDisconnectResult(r: CloudBridgeResult | null): DisconnectResult {
  if (r && r.ok) return { ok: true, revoked: r.revoked === true };
  const body = typeof r?.body === "string" ? r.body : "";
  const { error, errorDescription } = parseGoogleError(body);
  return {
    ok: false,
    error: mapCloudError(
      String(r?.error ?? error ?? "unknown"),
      String(r ? (errorDescription ?? ((r.errorDescription as string) ?? r.detail)) : "unknown")
    ),
  };
}

/** قطع اتصال واقعی: ابطال توکن در سرور گوگل + پاک‌کردن دادهٔ محلی — ⭐ v3.8.7 ناهمگام */
export async function disconnectCloud(): Promise<DisconnectResult> {
  const bridge = cloudBridge();
  if (!bridge) return { ok: false, error: { code: "no_bridge", message: "پل ابری فقط در نسخهٔ اندروید فعال است" } };
  const asyncFn = bridge.disconnectAsync;
  if (typeof asyncFn === "function") {
    const r = await callBridgeAsync<CloudBridgeResult>((cb) => {
      asyncFn.call(bridge, cb);
    });
    if (r) return parseDisconnectResult(r);
    return { ok: false, error: mapCloudError("unknown", "قطع اتصال پاسخ نداد — دوباره تلاش کنید") };
  }
  try {
    return parseDisconnectResult(jp<CloudBridgeResult>(bridge.disconnect()));
  } catch (e) {
    return { ok: false, error: mapCloudError("unknown", String(e)) };
  }
}

/* ───────────────────────────── اسنپ‌شات داده ───────────────────────────── */

export interface CloudSnapshot {
  app?: string;
  version?: string;
  exportedAt?: string;
  exportedAtTehran?: string;
  vehicles: Record<string, unknown>[];
  records: Record<string, unknown>[];
  reminders: Record<string, unknown>[];
  brands?: Record<string, unknown>[];
  serviceTypes?: Record<string, unknown>[];
  [k: string]: unknown;
}

export const CLOUD_FILE_NAME = "hamrah-khodro-backup.json";

/** خواندن دادهٔ کامل محلی — در APK از لایهٔ جاوا (همان خروجی پشتیبان) */
export function buildLocalSnapshot(): CloudSnapshot | null {
  try {
    const androidApi = (globalThis as unknown as { AndroidApi?: { api?: (m: string, u: string, b: string) => string } }).AndroidApi;
    if (typeof androidApi?.api !== "function") return null;
    const raw = androidApi.api("GET", "/api/backup", "");
    const parsed = JSON.parse(raw) as { status: number; body: CloudSnapshot };
    if (parsed.status !== 200 || !parsed.body) return null;
    return parsed.body;
  } catch {
    return null;
  }
}

/** اعمال اسنپ‌شات روی دادهٔ محلی (همان مسیر بازیابی پشتیبان) */
export function restoreFromSnapshot(json: string): { ok: boolean; error?: string } {
  try {
    const androidApi = (globalThis as unknown as { AndroidApi?: { api?: (m: string, u: string, b: string) => string } }).AndroidApi;
    if (typeof androidApi?.api !== "function") return { ok: false, error: "پل داده فقط در نسخهٔ اندروید فعال است" };
    const raw = androidApi.api("POST", "/api/restore", json);
    const parsed = JSON.parse(raw) as { status: number; body: { ok?: boolean; error?: string } };
    if (parsed.status >= 200 && parsed.status < 300 && parsed.body?.ok !== false) {
      return { ok: true };
    }
    return { ok: false, error: parsed.body?.error ?? `خطای بازیابی (${parsed.status})` };
  } catch {
    return { ok: false, error: "بازیابی انجام نشد" };
  }
}

/** شمارش برای نمایش «اطلاعات ذخیره‌شده» */
export function snapshotCounts(s: CloudSnapshot | null | undefined): CloudSyncCounts {
  const records = s?.records ?? [];
  let cost = 0;
  for (const r of records) {
    const c = r.cost;
    if (typeof c === "number") cost += c;
  }
  const cnt = (t: string) => records.filter((r) => r.type === t).length;
  return {
    vehicles: s?.vehicles?.length ?? 0,
    totalRecords: records.length,
    services: cnt("SERVICE"),
    fuels: cnt("FUEL"),
    odometers: cnt("ODOMETER"),
    notes: cnt("NOTE"),
    reminders: s?.reminders?.length ?? 0,
    brands: s?.brands?.length ?? 0,
    serviceTypes: s?.serviceTypes?.length ?? 0,
    totalCost: cost,
  };
}

/** هش سبک برای تشخیص «بی‌تغییر» (جلوگیری از آپلود بی‌مورد) */
export function hashString(s: string): string {
  let h1 = 0xdeadbeef ^ s.length;
  let h2 = 0x41c6ce57 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    const ch = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16) + (h1 >>> 0).toString(16) + ":" + s.length;
}

/* ───────────────────────────── عملیات Drive (آپلود/دانلود/لیست) ───────────────────────────── */

export interface CloudFileInfo {
  id: string;
  name: string;
  modifiedTime?: string;
  size?: number;
}

/** آیا اسنپ‌شات هیچ داده‌ای ندارد؟ (نصب تازه — چیزی برای آپلود نیست) */
export function snapshotIsEmpty(s: CloudSnapshot | null | undefined): boolean {
  if (!s) return true;
  return (
    (Array.isArray(s.vehicles) ? s.vehicles.length : 0) === 0 &&
    (Array.isArray(s.records) ? s.records.length : 0) === 0 &&
    (Array.isArray(s.reminders) ? s.reminders.length : 0) === 0
  );
}

/** فایل پشتیبان برنامه در appDataFolder را پیدا کن — ⭐ v3.8.7 ناهمگام */
export async function findCloudFile(): Promise<{ file?: CloudFileInfo; resp: DriveResponse }> {
  const resp = await driveRequestAsync(
    "GET",
    "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=50&fields=files(id,name,modifiedTime,size)"
  );
  if (!resp.ok || resp.status !== 200) return { resp };
  try {
    const j = JSON.parse(resp.body) as { files?: CloudFileInfo[] };
    const file = (j.files ?? []).find((f) => f.name === CLOUD_FILE_NAME);
    // ⭐ کش شناسهٔ فایل — آپلود/دانلود بعدی بدون «لیست» اضافی (سینک سریع‌تر)
    if (file?.id) lsSet(K_FILE_ID, file.id);
    else if ((j.files ?? []).length >= 0) lsDel(K_FILE_ID);
    return { file, resp };
  } catch {
    return { resp: { ...resp, ok: false, error: "parse" } };
  }
}

/** دانلود محتوای ابری — ⭐ v3.8.7 ناهمگام */
export async function downloadCloudSnapshot(): Promise<{
  snapshot?: CloudSnapshot;
  file?: CloudFileInfo;
  resp: DriveResponse;
}> {
  const { file, resp: listResp } = await findCloudFile();
  if (!file) return { resp: listResp };
  const resp = await driveRequestAsync("GET", `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`);
  if (!resp.ok || resp.status !== 200) return { file, resp };
  try {
    const snapshot = JSON.parse(resp.body) as CloudSnapshot;
    if (!Array.isArray(snapshot.vehicles) || !Array.isArray(snapshot.records)) {
      return { file, resp: { ...resp, ok: false, error: "invalid_backup" } };
    }
    return { snapshot, file, resp };
  } catch {
    return { file, resp: { ...resp, ok: false, error: "invalid_backup" } };
  }
}

/* ─── v3.8.4: تاریخچهٔ نسخه‌های فایل در Drive (revisions) ───
 * گوگل با هر به‌روزرسانی محتوا یک «نسخهٔ» جدید می‌سازد و نسخه‌های قبلی را نگه می‌دارد.
 * اگر نسخهٔ فعلی فایل ابری خالی/خراب شده باشد (مثلاً نصب مجدد با نسخهٔ قدیمی دادهٔ
 * خالی روی پشتیبان نوشته باشد)، اطلاعات از نسخه‌های قبلی قابل بازیابی است. */

export interface CloudRevisionInfo {
  id: string;
  modifiedTime?: string;
  size?: number;
}

/** فهرست نسخه‌های قبلی فایل در Drive — ⭐ v3.8.7 ناهمگام */
export async function listCloudRevisions(
  fileId: string
): Promise<{ revisions?: CloudRevisionInfo[]; resp: DriveResponse }> {
  const resp = await driveRequestAsync(
    "GET",
    `https://www.googleapis.com/drive/v3/files/${fileId}/revisions?pageSize=100&fields=revisions(id,modifiedTime,size)`
  );
  if (!resp.ok || resp.status !== 200) return { resp };
  try {
    const j = JSON.parse(resp.body) as { revisions?: CloudRevisionInfo[] };
    return { revisions: j.revisions ?? [], resp };
  } catch {
    return { resp: { ...resp, ok: false, error: "parse" } };
  }
}

/** دانلود محتوای یک نسخهٔ خاص از فایل — ⭐ v3.8.7 ناهمگام */
export async function downloadCloudRevision(
  fileId: string,
  revisionId: string
): Promise<{ snapshot?: CloudSnapshot; resp: DriveResponse }> {
  const resp = await driveRequestAsync(
    "GET",
    `https://www.googleapis.com/drive/v3/files/${fileId}/revisions/${revisionId}?alt=media`
  );
  if (!resp.ok || resp.status !== 200) return { resp };
  try {
    const snapshot = JSON.parse(resp.body) as CloudSnapshot;
    if (!Array.isArray(snapshot.vehicles) || !Array.isArray(snapshot.records)) {
      return { resp: { ...resp, ok: false, error: "invalid_backup" } };
    }
    return { snapshot, resp };
  } catch {
    return { resp: { ...resp, ok: false, error: "invalid_backup" } };
  }
}

/** جستجوی نسخهٔ قابل‌بازیابی — از جدیدترین به قدیمی‌ترین؛ اولین نسخهٔ دارای داده — ⭐ v3.8.7 ناهمگام */
export async function findRecoverableSnapshot(
  file: CloudFileInfo
): Promise<{ snapshot?: CloudSnapshot; revision?: CloudRevisionInfo; resp: DriveResponse }> {
  const { revisions, resp } = await listCloudRevisions(file.id);
  if (!revisions || revisions.length === 0) return { resp };
  const sorted = [...revisions].sort((a, b) => ts(b.modifiedTime ?? "") - ts(a.modifiedTime ?? ""));
  for (const rev of sorted) {
    const { snapshot } = await downloadCloudRevision(file.id, rev.id);
    if (!snapshot) continue;
    if (!snapshotIsEmpty(snapshot)) return { snapshot, revision: rev, resp };
  }
  return { resp };
}

/** آپلود/به‌روزرسانی اسنپ‌شات در appDataFolder — پیام موفقیت فقط با پاسخ 200 گوگل
 *  ⭐ v3.8.7: ناهمگام + کش شناسهٔ فایل (PATCH مستقیم بدون «لیست» — سینک سریع‌تر) */
export async function uploadCloudSnapshot(
  snapshotJson: string
): Promise<{ resp: DriveResponse; file?: CloudFileInfo }> {
  // مسیر سریع: شناسهٔ فایل از سینک قبلی کش شده → PATCH مستقیم (یک رفت‌وبرگشت)
  const cachedId = lsGet(K_FILE_ID);
  if (cachedId) {
    const resp = await driveRequestAsync(
      "PATCH",
      `https://www.googleapis.com/upload/drive/v3/files/${cachedId}?uploadType=media&fields=id,modifiedTime,size`,
      snapshotJson,
      "application/json"
    );
    if (resp.ok && (resp.status === 200 || resp.status === 201)) {
      return { resp, file: { id: cachedId, name: CLOUD_FILE_NAME } };
    }
    // ۴۰۴/۴۰۳ = فایل ابری حذف شده / حساب عوض شده → کش بی‌اعتبار، از مسیر لیست ادامه بده
    if (resp.status === 404 || resp.status === 403) lsDel(K_FILE_ID);
    else return { resp }; // خطای واقعی شبکه/گوگل — همان رفتار قبلی
  }
  // اگر فایل قبلاً هست → به‌روزرسانی محتوا (PATCH با uploadType=media)
  const { file, resp: listResp } = await findCloudFile();
  if (!file && !listResp.ok) return { resp: listResp };
  if (file) {
    const resp = await driveRequestAsync(
      "PATCH",
      `https://www.googleapis.com/upload/drive/v3/files/${file.id}?uploadType=media&fields=id,modifiedTime,size`,
      snapshotJson,
      "application/json"
    );
    return { resp, file };
  }
  // ساخت فایل جدید با فراداده (multipart/related)
  const boundary = "hk" + Date.now().toString(36) + "hk";
  const meta = JSON.stringify({ name: CLOUD_FILE_NAME, parents: ["appDataFolder"], mimeType: "application/json" });
  const body =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n` +
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${snapshotJson}\r\n` +
    `--${boundary}--`;
  const resp = await driveRequestAsync(
    "POST",
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,modifiedTime,size",
    body,
    `multipart/related; boundary=${boundary}`
  );
  if (resp.ok && (resp.status === 200 || resp.status === 201)) {
    try {
      const j = JSON.parse(resp.body) as { id?: string };
      if (j.id) lsSet(K_FILE_ID, j.id);
    } catch {
      /* ignore */
    }
  }
  return { resp };
}

/* ───────────────────────────── ادغام (merge) ───────────────────────────── */

function ts(v: unknown): number {
  if (typeof v === "string") {
    const t = Date.parse(v);
    if (!Number.isNaN(t)) return t;
  }
  return 0;
}

function newer(a: Record<string, unknown>, b: Record<string, unknown>): Record<string, unknown> {
  const au = ts(a.updatedAt) || ts(a.createdAt);
  const bu = ts(b.updatedAt) || ts(b.createdAt);
  return au >= bu ? a : b;
}

/** ادغام بدون تکرار: کلید شناسه + نسخهٔ جدیدتر ملاک است */
export function mergeSnapshots(local: CloudSnapshot, cloud: CloudSnapshot): CloudSnapshot {
  const mergeById = (
    a: Record<string, unknown>[],
    b: Record<string, unknown>[]
  ): Record<string, unknown>[] => {
    const m = new Map<string, Record<string, unknown>>();
    for (const x of a) if (typeof x.id === "string") m.set(x.id, x);
    for (const x of b) {
      if (typeof x.id !== "string") continue;
      const cur = m.get(x.id);
      m.set(x.id, cur ? newer(cur, x) : x);
    }
    return Array.from(m.values());
  };

  const vehicles = mergeById(local.vehicles ?? [], cloud.vehicles ?? []);
  const vehicleIds = new Set(vehicles.map((v) => String(v.id)));
  const records = mergeById(local.records ?? [], cloud.records ?? []).filter((r) =>
    vehicleIds.has(String(r.vehicleId))
  );
  const reminders = mergeById(local.reminders ?? [], cloud.reminders ?? []).filter((r) =>
    vehicleIds.has(String(r.vehicleId))
  );

  // برندها: کلید نام — اجتماع مدل‌ها
  const brands: Record<string, unknown>[] = [];
  const brandByName = new Map<string, Record<string, unknown>>();
  for (const b of [...(local.brands ?? []), ...(cloud.brands ?? [])]) {
    const name = typeof b.name === "string" ? b.name : "";
    if (!name) continue;
    const cur = brandByName.get(name);
    if (!cur) {
      brandByName.set(name, { ...b });
      continue;
    }
    const models = new Set(
      [...(Array.isArray(cur.models) ? cur.models : []), ...(Array.isArray(b.models) ? b.models : [])].filter(
        (m): m is string => typeof m === "string"
      )
    );
    brandByName.set(name, { ...cur, models: Array.from(models) });
  }
  brands.push(...Array.from(brandByName.values()));

  // انواع سرویس: کلید value — نسخهٔ محلی + موارد فقط-ابری
  const serviceTypes: Record<string, unknown>[] = [...(local.serviceTypes ?? [])];
  const values = new Set(
    serviceTypes.map((t) => String(t.value ?? t.label)).filter((v) => v && v !== "undefined")
  );
  for (const t of cloud.serviceTypes ?? []) {
    const key = String(t.value ?? t.label);
    if (key && key !== "undefined" && !values.has(key)) {
      values.add(key);
      serviceTypes.push(t);
    }
  }

  return {
    app: "همراه خودرو",
    version: "cloud-merge",
    exportedAt: new Date().toISOString(),
    vehicles,
    records,
    reminders,
    brands,
    serviceTypes,
  };
}

/* ───────────────────────────── سینک (دستی/خودکار) ───────────────────────────── */

export interface SyncResult {
  ok: boolean;
  unchanged?: boolean;
  /** ⭐ v3.8.4: ابر «جلوتر» از این گوشی است — آپلود انجام نشد؛ باید بازیابی/ادغام شود */
  needsRestore?: boolean;
  /** اسنپ‌شات ابری (برای دیالوگ بازیابی — فقط همراه needsRestore) */
  cloudSnapshot?: CloudSnapshot;
  counts?: CloudSyncCounts;
  cloudModified?: string;
  error?: CloudErrorInfo;
}

/** اجرای کامل همگام‌سازی دستی (آپلود). «متصل» فقط با پاسخ واقعی گوگل معتبر است.
 *  ⭐ v3.8.4 محافظ ابر: اگر این نصب هنوز همگام‌سازی موفق نداشته باشد (نصب تازه) و
 *  ابر داده‌های بیشتری از گوشی داشته باشد، آپلود «ممنوع» است — تا وقتی کاربر
 *  اطلاعات ابری را بازیابی/ادغام نکرده یا صریحاً «شروع تازه» را انتخاب نکرده باشد.
 *  (همان سناریوی «حذف و نصب مجدد → ابر خالی شد» را ریشه‌کن می‌کند.)
 *  ⭐ v3.8.7: ناهمگام — HTTP روی نخ پس‌زمینهٔ جاوا؛ برنامه هنگام همگام‌سازی زنده است.
 *  سینک‌های همزمان (خودکار + دستی) با زنجیرهٔ serialized پشت هم می‌روند (بدون PATCH دوگانه). */
let syncChain: Promise<unknown> = Promise.resolve();

export function runSyncNow(opts?: { forceOverwrite?: boolean }): Promise<SyncResult> {
  const p = syncChain.then(() => runSyncNowInner(opts), () => runSyncNowInner(opts));
  syncChain = p.then(
    () => undefined,
    () => undefined
  );
  return p;
}

async function runSyncNowInner(opts?: { forceOverwrite?: boolean }): Promise<SyncResult> {
  const bridge = cloudBridge();
  if (!bridge) {
    return { ok: false, error: { code: "no_bridge", message: "پل ابری فقط در نسخهٔ اندروید (APK) فعال است" } };
  }
  const account = getCloudAccount();
  if (!account.connected) {
    return { ok: false, error: { code: "disconnected", message: "ابتدا به حساب گوگل وصل شوید" } };
  }
  // ⭐ توکن قدیمی/ناقص بدون drive.appdata — بدون رفتن به شبکه، راهنمای دقیق داده می‌شود
  if (accountMissingBackupScope()) {
    const info = scopeErrorInfo(account.scope);
    setSyncMeta({ at: new Date().toISOString(), status: "failed", error: info.message });
    return { ok: false, error: info };
  }
  const snapshot = buildLocalSnapshot();
  if (!snapshot) {
    return { ok: false, error: { code: "local", message: "خواندن دادهٔ محلی ناموفق بود" } };
  }
  const json = JSON.stringify(snapshot);
  const hash = hashString(json);
  const lastHash = lsGet(K_LAST_HASH);
  const lastMeta = getSyncMeta();
  if (lastHash === hash && lastMeta?.status === "ok") {
    return { ok: true, unchanged: true, counts: lastMeta.counts, cloudModified: lastMeta.cloudModified };
  }

  // ─── ⭐ v3.8.4 محافظ «ابر جلوتر است» — فقط در نصبِ تازه (هنوز سینک موفق نداشته) ───
  if (!lastHash && !opts?.forceOverwrite) {
    const cloud = await downloadCloudSnapshot();
    const cloudErr =
      cloud.resp.error !== "invalid_backup" && (!cloud.resp.ok || cloud.resp.status !== 200);
    if (cloudErr) {
      // خطای واقعی گوگل/شبکه — ابر دست‌نخورده می‌ماند و خطای دقیق نمایش داده می‌شود
      const info = mapDriveError(cloud.resp);
      setSyncMeta({ at: new Date().toISOString(), status: "failed", error: info.message });
      return { ok: false, error: info };
    }
    if (cloud.snapshot && !snapshotIsEmpty(cloud.snapshot)) {
      const lc = snapshotCounts(snapshot);
      const cc = snapshotCounts(cloud.snapshot);
      const cloudAhead =
        cc.vehicles > lc.vehicles || cc.totalRecords > lc.totalRecords || cc.reminders > lc.reminders;
      if (cloudAhead) {
        const cloudModified = cloud.file?.modifiedTime;
        setSyncMeta({ at: new Date().toISOString(), status: "cloud_ahead", counts: cc, cloudModified });
        return {
          ok: false,
          needsRestore: true,
          cloudSnapshot: cloud.snapshot,
          counts: cc,
          cloudModified,
          error: {
            code: "cloud_ahead",
            message:
              "در Google Drive پشتیبانِ پرتری از این گوشی موجود است — برای برگرداندن اطلاعات قبلی، «بازیابی از ابر» را بزنید (اگر عمداً می‌خواهید ابر با همین گوشی شروع شود، در پنجرهٔ بازیابی «شروع تازه» را انتخاب کنید)",
          },
        };
      }
    }
  }

  const { resp, file } = await uploadCloudSnapshot(json);
  const good = resp.ok && (resp.status === 200 || resp.status === 201);
  if (!good) {
    // ⭐ دلیل واقعی گوگل پارس می‌شود (API غیرفعال / مجوز ناکافی / فضای واقعی پر / rate limit / …)
    const info = mapDriveError(resp);
    setSyncMeta({ at: new Date().toISOString(), status: "failed", error: info.message });
    return { ok: false, error: info };
  }
  const counts = snapshotCounts(snapshot);
  let cloudModified: string | undefined;
  try {
    const j = JSON.parse(resp.body) as { modifiedTime?: string };
    cloudModified = j.modifiedTime ?? file?.modifiedTime;
  } catch {
    cloudModified = file?.modifiedTime;
  }
  lsSet(K_LAST_HASH, hash);
  setSyncMeta({ at: new Date().toISOString(), status: "ok", counts, cloudModified });
  return { ok: true, counts, cloudModified };
}

/* ─── سینک خودکار پس از تغییر داده (debounce) — بی‌صدا و مقاوم به خطا ─── */

let autoTimer: ReturnType<typeof setTimeout> | null = null;
let lastFailureNotified = false;

/** با هر تغییر داده صدا زده می‌شود؛ اگر متصل+فعال بود بعد از چند ثانیه آپلود می‌کند */
export function queueAutoSync(): void {
  const bridge = cloudBridge();
  if (!bridge) return;
  if (!getAutoSync()) return;
  if (autoTimer) clearTimeout(autoTimer);
  autoTimer = setTimeout(() => {
    autoTimer = null;
    void (async () => {
      try {
        const account = getCloudAccount();
        if (!account.connected) return;
        // ⭐ v3.8.5: نشانگر انتظار سراسری (کپسول بالا) — کاربر می‌بیند همگام‌سازی
        // پس‌زمینه در حال انجام است؛ انیمیشن CSS روی کامپوزیتور، حتی حین قفلِ JS پل می‌چرخد
        const result = await withBusy(
          {
            mode: "pill",
            title: "در حال همگام‌سازی با Google Drive…",
            detail: "آخرین اطلاعات در ابر ذخیره می‌شود",
          },
          () => runSyncNow()
        );
        if (!result.ok && result.error) {
          // خطا در فراداده ذخیره می‌شود (نمایش در پنجرهٔ ابری)؛ توست فقط برای اولین خطا بعد از موفقیت
          if (!lastFailureNotified) {
            lastFailureNotified = true;
            window.dispatchEvent(
              new CustomEvent("hk-cloud-sync-failed", { detail: { message: result.error.message } })
            );
          }
        } else if (result.ok) {
          lastFailureNotified = false;
        }
      } catch {
        /* سینک پس‌زمینه — خطایش بی‌صدا */
      }
    })();
  }, 8000);
}

/** برای تست شبیه‌ساز: ریست state داخلی */
export function resetAutoSyncState(): void {
  if (autoTimer) clearTimeout(autoTimer);
  autoTimer = null;
  lastFailureNotified = false;
  // ⭐ v3.8.7: کش شناسهٔ فایل هم بی‌اعتبار می‌شود — سینک بعدی از «لیست» تازه شروع می‌کند
  lsDel(K_FILE_ID);
}

/** پاک‌سازی کلیدهای قدیمی Client ID از نسخه‌های قبل (مهاجرت v3.7 → v3.8) */
export function cleanupLegacyKeys(): void {
  try {
    lsDel("hamrah-khodro-cloud-clientid-browser");
    lsDel("hamrah-khodro-cloud-clientid-device");
  } catch {
    /* ignore */
  }
}
