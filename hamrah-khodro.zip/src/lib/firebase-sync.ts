/**
 * موتور همگام‌سازی ابری Firebase (v3.9.3) — فقط با «حساب گوگل».
 *
 * معماری:
 *  - ورود: OAuth گوگل در مرورگر سیستم (Chrome Custom Tab) توسط CloudBridge جاوا
 *          (fbStartAuthAsync/fbPollAuth/fbExchangeCodeAsync — PKCE، بدون Client Secret)
 *  - توکن: id_token گوگل → Firebase Auth REST (signInWithIdp) در لایهٔ جاوا
 *  - داده: سند Firestore «hamrah_users/{uid}» با fbRequestAsync (پروکسی REST جاوا)
 *
 *  ⭐ v3.9.3 — نگاشت خطای کامل فارسی با «دکمهٔ اقدام»:
 *  - فعال‌نبودن Identity Toolkit API (خطای ورود) → کارت فعال‌سازی با لینک مستقیم
 *  - فعال‌نبودن Cloud Firestore API → کارت فعال‌سازی با لینک مستقیم
 *  - دیتابیس ساخته‌نشده / قوانین امنیتی بسته → کارت راهنمای کنسول
 *  (هر دو خطای Rules و API-disabled همان 403 PERMISSION_DENIED اند — ترتیب شاخه‌ها حیاتی است)
 *
 * همان اصول نسخه‌های قبل:
 *  - پیام موفقیت فقط بعد از پاسخ واقعی سرور
 *  - خطا هرگز دادهٔ محلی را دست نمی‌زند؛ قبل از جایگزینی پشتیبان خودکار محلی
 *  - ادغام بدون تکرار (mergeSnapshots مشترک)
 *  - سینک خودکار debounce شده بعد از هر تغییر داده
 */

import { getFirebaseConfig, firestoreApiEnableUrl, identityApiEnableUrl, firebaseConsoleUrl } from "@/lib/firebase-config";
import { withBusy } from "@/lib/busy";
import { mergeSnapshots, snapshotCounts, snapshotIsEmpty, type CloudSnapshot } from "@/lib/cloud-sync";

/** نام جایگزین برای import تمیزتر از UI (BackupWindow) */
export type CloudSnapshotAlias = CloudSnapshot;

/* ───────────────────────────── خطاها (فارسی + دکمهٔ اقدام) ───────────────────────────── */

/** نوع راهنمایی که کارت خطا نشان می‌دهد */
export type FbErrorHelp = "identity-api" | "firestore-api" | "database" | "rules" | "uri-scheme";

export interface FbErrorInfo {
  code: string;
  message: string;
  /** متن خام خطای گوگل (برای نمایش جزئیات/تشخیص) */
  detail?: string;
  /** لینک actionable کنسول گوگل */
  url?: string;
  help?: FbErrorHelp;
}

const FB_DISABLED_PATTERN = /has not been used in project|or it is disabled|Enable it by visiting/i;

/** استخراج لینک فعال‌سازی از پیام خام گوگل */
function extractEnableUrl(raw: string): string | undefined {
  return /https:\/\/console\.developers\.google\.com\/[^\s"']+/i.exec(raw)?.[0];
}

/** کدام API غیرفعال است؟ (از لینک/متن پیام) */
function disabledApiKind(raw: string): "identitytoolkit" | "firestore" | "unknown" {
  if (/identitytoolkit/i.test(raw)) return "identitytoolkit";
  if (/firestore/i.test(raw)) return "firestore";
  return "unknown";
}

/**
 * نگاشت خطای REST گوگل (Firebase Auth یا Firestore) — v3.9.3
 * ⭐ ترتیب شاخه‌ها حیاتی است: «API غیرفعال» باید قبل از Rules بررسی شود
 *   (هر دو 403 PERMISSION_DENIED اند ولی پیام متفاوت دارند)
 */
export function mapFbRestError(status: number | undefined, rawBody: string): FbErrorInfo {
  const cfg = getFirebaseConfig();
  const all = `${rawBody ?? ""}`;

  // ۱) API غیرفعال (Identity Toolkit یا Firestore) — «Enable it by visiting …»
  if (FB_DISABLED_PATTERN.test(all)) {
    const kind = disabledApiKind(all);
    const extracted = extractEnableUrl(all);
    if (kind === "identitytoolkit") {
      return {
        code: "auth_api_disabled",
        message:
          "«Identity Toolkit API» در پروژهٔ گوگل فعال نیست — ورود به سرور پشتیبان ممکن نیست. با دکمهٔ زیر فعالش کنید و بعد «تلاش دوباره» را بزنید.",
        detail: rawBody,
        help: "identity-api",
        url: extracted ?? `https://console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=${cfg.projectId}`,
      };
    }
    return {
      code: "firestore_api_disabled",
      message:
        "«Cloud Firestore API» در پروژهٔ گوگل فعال نیست — ذخیرهٔ اطلاعات در سرور ممکن نیست. با دکمهٔ زیر فعالش کنید و بعد «تلاش دوباره» را بزنید.",
      detail: rawBody,
      help: "firestore-api",
      url: extracted ?? `https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=${cfg.projectId}`,
    };
  }

  // ۲) دیتابیس ساخته نشده (404 از Firestore — databases/(default))
  if ((status === 404 || !status) && /database[^\n]{0,80}(does not exist|not exist|unknown|not found)/i.test(all)) {
    return {
      code: "no_database",
      message:
        "دیتابیس Firestore هنوز ساخته نشده است — در کنسول Firebase با دکمهٔ زیر «Create database» را بزنید (منطقهٔ دلخواه، شروع در حالت test) و بعد «تلاش دوباره».",
      detail: rawBody,
      help: "database",
      url: `https://console.firebase.google.com/project/${cfg.projectId}/firestore`,
    };
  }

  // ۳) قوانین امنیتی دسترسی را بسته‌اند (403 PERMISSION_DENIED بعد از فعال‌بودن API)
  if (status === 403 || /PERMISSION_DENIED|Missing or insufficient permissions/i.test(all)) {
    return {
      code: "rules_denied",
      message:
        "قوانین امنیتی Firestore اجازهٔ خواندن/نوشتن سند را نمی‌دهند. در کنسول Firebase با دکمهٔ زیر، قوانینِ پیشنهادی برنامه را در تب Rules جای‌گذاری و Publish کنید و بعد «تلاش دوباره».",
      detail: rawBody,
      help: "rules",
      url: `https://console.firebase.google.com/project/${cfg.projectId}/firestore/rules`,
    };
  }

  // ۴) نشست منقضی
  if (status === 401) {
    return { code: "disconnected", message: "نشست حساب منقضی شده — دوباره وارد شوید" };
  }

  // ۵) محدودیت تعداد درخواست
  if (status === 429 || /RESOURCE_EXHAUSTED|rate.?limit/i.test(all)) {
    return { code: "rate_limited", message: "تعداد درخواست‌ها زیاد بوده — چند دقیقه بعد دوباره تلاش کنید" };
  }

  // ۶) سایر خطاهای HTTP
  if (status && status >= 400) {
    return {
      code: "http",
      message: `خطای سرور گوگل (${status}) — دوباره تلاش کنید`,
      detail: rawBody.slice(0, 400) || undefined,
    };
  }
  return { code: "unknown", message: "ارتباط با سرور پشتیبان ناموفق بود — دوباره تلاش کنید", detail: rawBody.slice(0, 400) || undefined };
}

/** نگاشت خطای مرحلهٔ ورود (نتیجهٔ fbExchangeCode / fbStartAuth) */
function mapFbAuthError(code: string, message?: string, status?: number): FbErrorInfo {
  const cfg = getFirebaseConfig();
  switch (code) {
    case "custom_scheme_disabled":
      return {
        code,
        message:
          "یک تنظیم در Google Cloud باقی مانده: کلاینت اندرویدِ برنامه را باز کنید و در «Advanced settings» گزینهٔ «Enable custom URI scheme» را روشن و ذخیره کنید (یک‌بار برای همیشه) — سپس دوباره تلاش کنید.",
        help: "uri-scheme",
        url: `https://console.cloud.google.com/auth/clients?project=${cfg.projectId}`,
      };
    case "redirect_uri_mismatch":
      return {
        code,
        message:
          "آدرس بازگشت (redirect) OAuth با کلاینت کلاینت اندروید نمی‌خواند — کلاینت باید برای بستهٔ com.zai.hamrahkhodro با همین امضا ساخته شده باشد.",
        help: "uri-scheme",
        url: `https://console.cloud.google.com/auth/clients?project=${cfg.projectId}`,
      };
    case "invalid_client":
      return {
        code,
        message: "کلاینت OAuth پروژه در دسترس نیست — تنظیمات Google Cloud را بررسی کنید.",
        help: "uri-scheme",
        url: `https://console.cloud.google.com/auth/clients?project=${cfg.projectId}`,
      };
    case "network":
      return { code, message: "اتصال به سرور گوگل برقرار نشد — اینترنت گوشی را بررسی و دوباره تلاش کنید" };
    case "busy":
      return { code, message: "یک جریان اتصال در حال اجراست — کمی صبر کنید" };
    case "denied":
      return { code, message: "دسترسی در صفحهٔ گوگل رد شد — دوباره تلاش کنید" };
    case "timeout":
      return { code, message: "زمان انتظار تمام شد — دوباره تلاش کنید" };
    case "no_code":
      return { code, message: "کد ورود دریافت نشد — دوباره تلاش کنید" };
    case "code_used":
      // ⭐ v3.9.4: کد oauth یک‌بارمصرف است — «تلاش دوباره» ورود تازهٔ مرورگر را باز می‌کند
      return {
        code,
        message: "کد ورود قبلی یک‌بارمصرف است — دوباره تلاش کنید تا صفحهٔ ورود گوگل از نو باز شود.",
      };
    case "auth_api_disabled":
      // ⭐ Identity Toolkit API غیرفعال — پیام خام گوگل لینک فعال‌سازی دارد
      return mapFbRestError(403, message ?? "");
    case "signin_failed":
    case "exchange_failed": {
      const info = mapFbRestError(status, message ?? "");
      if (info.code !== "unknown") return info;
      // invalid_grant خام گوگل = کد یک‌بارمصرف/منقضی (بعد از تلاش دوباره با همان کد)
      if (/invalid_grant/i.test(message ?? "")) {
        return {
          code: "code_used",
          message: "کد ورود قبلی یک‌بارمصرف است — دوباره تلاش کنید تا صفحهٔ ورود گوگل از نو باز شود.",
          detail: (message ?? "").slice(0, 400) || undefined,
        };
      }
      return {
        code,
        message: "ورود به سرور پشتیبان انجام نشد — دوباره تلاش کنید",
        detail: (message ?? "").slice(0, 400) || undefined,
      };
    }
    case "no_bridge":
      return { code, message: "اتصال ابری فقط در نسخهٔ اندروید برنامه فعال است" };
    default:
      return { code: code || "unknown", message: message || "ورود به سرور پشتیبان انجام نشد — دوباره تلاش کنید" };
  }
}

/* ───────────────────────────── پل جاوا (AndroidCloud — CloudBridge) ───────────────────────────── */

export interface FbCloudBridge {
  fbStartAuthAsync(callback: string): void;
  fbPollAuth(): string;
  fbCancelAuth(): string;
  fbExchangeCodeAsync(callback: string): void;
  fbGetAccount(): string;
  fbRequestAsync(method: string, url: string, contentType: string, body: string, callback: string): void;
  fbDisconnectAsync(callback: string): void;
  /** ⭐ v3.9.5 — بررسی وضعیت راه‌اندازی (network/identity/firestore) بدون نیاز به ورود */
  fbProbeAsync?(probe: string, callback: string): void;
  openUrl?(url: string): string;
}

function fbBridge(): FbCloudBridge | null {
  try {
    const b = (globalThis as unknown as { AndroidCloud?: FbCloudBridge }).AndroidCloud;
    if (b && typeof b.fbGetAccount === "function" && typeof b.fbRequestAsync === "function") return b;
  } catch {
    /* ignore */
  }
  return null;
}

/** آیا پل ابری فایربیس در این محیط فعال است؟ */
export function hasFbBridge(): boolean {
  return fbBridge() !== null;
}

function jp<T>(raw: string): T {
  return JSON.parse(raw) as T;
}

let asyncCbSeq = 0;

/** فراخوانی ناهمگام پل جاوا با timeout — نتیجه با evaluateJavascript برمی‌گردد */
function callFbAsync<T>(invoke: (cbName: string) => void, timeoutMs = 45000): Promise<T | null> {
  return new Promise((resolve) => {
    const name = `__hkFbCb${(++asyncCbSeq).toString(36)}${Date.now().toString(36)}`;
    const w = globalThis as unknown as Record<string, unknown>;
    let settled = false;
    const timer = window.setTimeout(() => finish(null), timeoutMs);
    const wrapped = (v: unknown) => {
      window.clearTimeout(timer);
      finish(v);
    };
    function finish(raw: unknown) {
      if (settled) return;
      settled = true;
      try {
        delete w[name];
      } catch {
        /* ignore */
      }
      try {
        resolve(raw as T);
      } catch {
        resolve(null);
      }
    }
    w[name] = wrapped;
    try {
      invoke(name);
    } catch {
      window.clearTimeout(timer);
      finish(null);
    }
  });
}

/* ───────────────────────────── ورود با گوگل ───────────────────────────── */

export interface FbAccount {
  connected: boolean;
  email?: string;
  uid?: string;
}

/** وضعیت حساب — از لایهٔ جاوا (نشست آنجا نگهداری می‌شود) */
export function getFirebaseAccount(): FbAccount {
  const bridge = fbBridge();
  if (!bridge) return { connected: false };
  try {
    const a = jp<{ connected?: boolean; email?: string; uid?: string }>(bridge.fbGetAccount());
    if (a && a.connected) return { connected: true, email: a.email, uid: a.uid };
  } catch {
    /* ignore */
  }
  return { connected: false };
}

export interface FbAuthPoll {
  state: "none" | "waiting" | "done" | "error" | "timeout";
  error?: string;
}

/** گام ۱ — شروع ورود: مرورگر سیستم با حساب گوگل باز می‌شود */
export async function firebaseConnectStart(): Promise<{ ok: boolean; authUrl?: string; error?: FbErrorInfo }> {
  const bridge = fbBridge();
  if (!bridge) return { ok: false, error: mapFbAuthError("no_bridge") };
  const r = await callFbAsync<{ ok?: boolean; authUrl?: string; error?: string; errorDescription?: string }>((cb) => {
    bridge.fbStartAuthAsync(cb);
  }, 30000);
  if (!r) return { ok: false, error: mapFbAuthError("network") };
  if (r.ok) return { ok: true, authUrl: String(r.authUrl ?? "") };
  return { ok: false, error: mapFbAuthError(String(r.error ?? "unknown"), String(r.errorDescription ?? "")) };
}

/** گام ۲ — پولینگ وضعیت جریان ورود (بازگشت از مرورگر) */
export function firebaseConnectPoll(): FbAuthPoll {
  const bridge = fbBridge();
  if (!bridge) return { state: "none" };
  try {
    return jp<FbAuthPoll>(bridge.fbPollAuth());
  } catch {
    return { state: "none" };
  }
}

/** لغو جریان ورود */
export function firebaseConnectCancel(): void {
  const bridge = fbBridge();
  try {
    bridge?.fbCancelAuth();
  } catch {
    /* ignore */
  }
}

/** گام ۳ — تبدیل کد به نشست فایربیس (id_token → signInWithIdp در لایهٔ جاوا) */
export async function firebaseConnectComplete(): Promise<{ ok: boolean; email?: string; uid?: string; error?: FbErrorInfo }> {
  const bridge = fbBridge();
  if (!bridge) return { ok: false, error: mapFbAuthError("no_bridge") };
  const r = await callFbAsync<{
    ok?: boolean;
    email?: string;
    uid?: string;
    error?: string;
    message?: string;
    status?: number;
  }>((cb) => {
    bridge.fbExchangeCodeAsync(cb);
  }, 45000);
  if (!r) return { ok: false, error: mapFbAuthError("network") };
  if (r.ok) return { ok: true, email: String(r.email ?? ""), uid: String(r.uid ?? "") };
  return { ok: false, error: mapFbAuthError(String(r.error ?? "unknown"), String(r.message ?? ""), r.status) };
}

/** خروج از حساب (نشست جاوا پاک می‌شود — دادهٔ سرور دست‌نخورده می‌ماند) */
export async function firebaseDisconnect(): Promise<boolean> {
  const bridge = fbBridge();
  if (!bridge) {
    return true;
  }
  const r = await callFbAsync<{ ok?: boolean }>((cb) => {
    bridge.fbDisconnectAsync(cb);
  }, 15000);
  return !r || !!r.ok;
}

/* ─────────── ادامهٔ خودکار جریان نیمه‌تمام (بازگشت از مرورگر بعد از بسته‌شدن برنامه) ─────────── */

let fbResumeTimer: ReturnType<typeof setInterval> | null = null;

/**
 * در بوت برنامه صدا زده می‌شود: اگر کد مجوز گوگل رسیده ولی هنوز تبدیل نشده →
 * تبدیل و اتصال کامل می‌شود.
 */
export function autoResumeFbAuthFlow(onConnected?: (email: string) => void): void {
  const bridge = fbBridge();
  if (!bridge) return;
  try {
    if (getFirebaseAccount().connected) return;
    const p = firebaseConnectPoll();
    if (p.state === "done") {
      void withBusy(
        { mode: "pill", title: "در حال تکمیل اتصال به حساب گوگل…", detail: "تأیید با سرور گوگل و فایربیس" },
        () => firebaseConnectComplete()
      ).then((r) => {
        if (r.ok && r.email) onConnected?.(r.email);
      });
      return;
    }
    if (p.state === "waiting") {
      if (fbResumeTimer) return;
      fbResumeTimer = setInterval(() => {
        try {
          const q = firebaseConnectPoll();
          if (q.state === "done") {
            if (fbResumeTimer) clearInterval(fbResumeTimer);
            fbResumeTimer = null;
            void withBusy(
              { mode: "pill", title: "در حال تکمیل اتصال به حساب گوگل…" },
              () => firebaseConnectComplete()
            ).then((r) => {
              if (r.ok && r.email) onConnected?.(r.email);
            });
          } else if (q.state === "error" || q.state === "timeout") {
            if (fbResumeTimer) clearInterval(fbResumeTimer);
            fbResumeTimer = null;
          }
        } catch {
          /* ignore */
        }
      }, 1200);
    }
  } catch {
    /* ignore */
  }
}

/* ───────────────────── v3.9.5: بررسی وضعیت راه‌اندازی (گام‌به‌گام) ───────────────────── */

export type FbProbeKind = "network" | "identity" | "firestore";

/** نتیجهٔ یک بررسی: ok = سرویس فعال/در دسترس | disabled = باید در کنسول فعال شود | no_database = دیتابیس Firestore ساخته نشده | network = اینترنت | unknown */
export interface FbProbeResult {
  kind: FbProbeKind;
  state: "ok" | "disabled" | "no_database" | "network" | "unknown";
  message: string;
  detail?: string;
  url?: string;
}

/** نگاشت پاسخ خام HTTP گوگل به نتیجهٔ بررسی — مشترک بین مسیر پل و وب */
function mapProbeStatus(kind: FbProbeKind, status: number, body: string): FbProbeResult {
  const cfg = getFirebaseConfig();
  const all = `${body ?? ""}`;
  // ۱) الگوی «API غیرفعال» — همان پیام استاندارد گوگل (لینک فعال‌سازی داخل پیام است)
  if (FB_DISABLED_PATTERN.test(all)) {
    if (kind === "identity") {
      return {
        kind,
        state: "disabled",
        message: "«Identity Toolkit API» در پروژهٔ گوگل فعال نیست — با دکمهٔ زیر فعالش کنید و دوباره «بررسی وضعیت» را بزنید.",
        detail: all.slice(0, 320),
        url: extractEnableUrl(all) ?? identityApiEnableUrl(cfg.projectId),
      };
    }
    return {
      kind,
      state: "disabled",
      message: "«Cloud Firestore API» در پروژهٔ گوگل فعال نیست — با دکمهٔ زیر فعالش کنید و دوباره «بررسی وضعیت» را بزنید.",
      detail: all.slice(0, 320),
      url: extractEnableUrl(all) ?? firestoreApiEnableUrl(cfg.projectId),
    };
  }
  // ۱.۵) ⭐ v3.9.6 — دیتابیس ساخته‌نشده: 404 از endpoint اسناد (بدون نیاز به ورود هم
  //      پاسخِ «database does not exist» می‌آید) → قبل از ورود هم دقیق مشخص است
  if (
    kind === "firestore" &&
    (status === 404 || /\bNOT_FOUND\b/.test(all)) &&
    /database[\s\S]{0,80}?(does not exist|not exist|unknown|not found)/i.test(all)
  ) {
    return {
      kind,
      state: "no_database",
      message:
        "دیتابیس Firestore هنوز ساخته نشده — با دکمهٔ زیر در کنسول Firebase «Create database» را بزنید (منطقهٔ دلخواه، شروع در حالت test) و دوباره «بررسی وضعیت» را بزنید.",
      detail: all.slice(0, 320),
      url: firebaseConsoleUrl(cfg.projectId),
    };
  }
  // ۲) پاسخ HTTP دریافت شد → سرویس فعال است (هر کد خطای معمولی یعنی API جواب می‌دهد)
  if (kind === "network") {
    return { kind, state: "ok", message: "اینترنت و دسترسی به سرورهای گوگل برقرار است ✓" };
  }
  if (kind === "identity") {
    return { kind, state: "ok", message: "Identity Toolkit API فعال است ✓ — ورود با گوگل کار می‌کند" };
  }
  return {
    kind,
    state: "ok",
    message: "Cloud Firestore API فعال است ✓ — دیتابیس موجود و آمادهٔ ذخیرهٔ داده",
    detail: `HTTP ${status}`,
  };
}

/** بررسی وضعیت — بدون نیاز به ورود؛ از طریق پل جاوا یا (در وب) fetch مستقیم */
export async function firebaseProbe(kind: FbProbeKind): Promise<FbProbeResult> {
  const cfg = getFirebaseConfig();
  const bridge = fbBridge();

  // ── مسیر ۱: پل جاوا (APK) — fbProbeAsync ──
  if (bridge && typeof bridge.fbProbeAsync === "function") {
    const r = await callFbAsync<{ ok?: boolean; status?: number; body?: string; error?: string }>((cb) => {
      bridge.fbProbeAsync!(kind, cb);
    }, 25000);
    if (!r) return { kind, state: "network", message: "اتصال به سرور گوگل برقرار نشد — اینترنت گوشی را بررسی کنید" };
    if (!r.ok) {
      if (r.error === "network") {
        return { kind, state: "network", message: "اتصال به سرور گوگل برقرار نشد — اینترنت گوشی را بررسی کنید" };
      }
      return { kind, state: "unknown", message: "بررسی انجام نشد — دوباره تلاش کنید", detail: String(r.error ?? "") };
    }
    return mapProbeStatus(kind, typeof r.status === "number" ? r.status : 0, String(r.body ?? ""));
  }

  // ── مسیر ۲: وب (پیش‌نمایش مرورگر) — fetch مستقیم به همان endpointها ──
  try {
    if (kind === "network") {
      await fetch("https://accounts.google.com/", { mode: "no-cors" });
      return { kind, state: "ok", message: "اینترنت و دسترسی به سرورهای گوگل برقرار است ✓" };
    }
    if (kind === "identity") {
      const res = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${cfg.apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: "probe@example.com", password: "0123456789", returnSecureToken: true }),
        }
      );
      const text = await res.text().catch(() => "");
      return mapProbeStatus(kind, res.status, text);
    }
    // ⭐ v3.9.6 — endpoint اسناد (به‌جای endpoint ادمین دیتابیس):
    //    دیتابیسِ نبود → 404 «database does not exist» (حتی بدون ورود)
    //    دیتابیسِ بود → 401/403 (قوانین محافظت می‌کنند) یا 200
    const res = await fetch(
      `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/hamrah_users?pageSize=1`
    );
    const text = await res.text().catch(() => "");
    return mapProbeStatus(kind, res.status, text);
  } catch {
    return {
      kind,
      state: kind === "network" ? "network" : "unknown",
      message:
        kind === "network"
          ? "اتصال به سرور گوگل برقرار نشد — اینترنت را بررسی کنید"
          : "بررسی از این مرورگر ممکن نشد — در نسخهٔ اندروید برنامه دقیق انجام می‌شود",
    };
  }
}

/* ───────────────────────────── اسنپ‌شات محلی ───────────────────────────── */

/** خواندن دادهٔ کامل محلی — پل جاوا (APK) یا fetch وب */
async function buildLocalSnapshot(): Promise<CloudSnapshot | null> {
  try {
    const androidApi = (
      globalThis as unknown as { AndroidApi?: { api?: (m: string, u: string, b: string) => string } }
    ).AndroidApi;
    if (typeof androidApi?.api === "function") {
      const raw = androidApi.api("GET", "/api/backup", "");
      const parsed = JSON.parse(raw) as { status: number; body: CloudSnapshot };
      if (parsed.status === 200 && parsed.body) return parsed.body;
      return null;
    }
    const res = await fetch("/api/backup");
    if (!res.ok) return null;
    return (await res.json()) as CloudSnapshot;
  } catch {
    return null;
  }
}

/** اعمال اسنپ‌شات روی دادهٔ محلی — همان مسیر بازیابی پشتیبان */
async function restoreSnapshot(json: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const androidApi = (
      globalThis as unknown as { AndroidApi?: { api?: (m: string, u: string, b: string) => string } }
    ).AndroidApi;
    if (typeof androidApi?.api === "function") {
      const raw = androidApi.api("POST", "/api/restore", json);
      const parsed = JSON.parse(raw) as { status: number; body: { ok?: boolean; error?: string } };
      if (parsed.status >= 200 && parsed.status < 300 && parsed.body?.ok !== false) return { ok: true };
      return { ok: false, error: parsed.body?.error ?? `خطای بازیابی (${parsed.status})` };
    }
    const res = await fetch("/api/restore", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: json,
    });
    if (!res.ok) {
      const d = (await res.json().catch(() => null)) as { error?: string } | null;
      return { ok: false, error: d?.error ?? "بازیابی انجام نشد" };
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "بازیابی انجام نشد" };
  }
}

/* ───────────────────────────── Firestore REST (از طریق پل جاوا) ───────────────────────────── */

function docUrl(uid: string): string {
  const cfg = getFirebaseConfig();
  return `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/hamrah_users/${uid}`;
}

interface FbRestResponse {
  ok: boolean;
  status?: number;
  body?: string;
  /** فقط خطاهای سطح انتقال (شبکه/نشست/پل) — خطای HTTP توسط فراخوان‌کننده نگاشت می‌شود */
  error?: FbErrorInfo;
}

/** درخواست REST با توکن نشست فایربیس — در لایهٔ جاوا (Bearer خودکار)
 *  پاسخ خام برمی‌گردد (status/body) تا 404 «سند وجود ندارد» از 404 «دیتابیس نیست» جدا شود */
async function fbRest(method: string, url: string, body?: string): Promise<FbRestResponse> {
  const bridge = fbBridge();
  if (!bridge) return { ok: false, error: mapFbAuthError("no_bridge") };
  const r = await callFbAsync<{ ok?: boolean; status?: number; body?: string; error?: string }>((cb) => {
    bridge.fbRequestAsync(method, url, "application/json", body ?? "", cb);
  }, 45000);
  if (!r) return { ok: false, error: mapFbAuthError("network") };
  if (r.error === "disconnected") return { ok: false, error: { code: "disconnected", message: "ابتدا به حساب پشتیبان وارد شوید" } };
  if (r.error === "network") return { ok: false, error: mapFbAuthError("network") };
  if (!r.ok && r.error) return { ok: false, error: mapFbAuthError(String(r.error)) };
  const status = typeof r.status === "number" ? r.status : 0;
  if (status >= 200 && status < 300) return { ok: true, status, body: String(r.body ?? "") };
  return { ok: false, status, body: String(r.body ?? "") };
}

/** نوشتن اسنپ‌شات در سند کاربر — فیلد data (رشتهٔ JSON) */
async function fbUpload(uid: string, snapshotJson: string): Promise<{ ok: boolean; error?: FbErrorInfo }> {
  const body = {
    fields: {
      data: { stringValue: snapshotJson },
      updatedAt: { timestampValue: new Date().toISOString() },
    },
  };
  const r = await fbRest("PATCH", docUrl(uid), JSON.stringify(body));
  if (r.ok) return { ok: true };
  return { ok: false, error: r.error ?? mapFbRestError(r.status, r.body ?? "") };
}

/** خواندن اسنپ‌شات از سند کاربر — missing یعنی هنوز پشتیبانی در سرور نیست */
async function fbDownload(uid: string): Promise<{
  snapshot?: CloudSnapshot;
  error?: FbErrorInfo;
  missing?: boolean;
}> {
  const r = await fbRest("GET", docUrl(uid));
  if (r.error) return { error: r.error };
  if (r.status === 404) {
    // ۴۰۴ دوتاست: «سند نیست» (طبیعی — پشتیبانی هنوز ساخته نشده) یا «دیتابیس نیست» (راهنمای کنسول)
    if (/database[\s\S]{0,120}(does not exist|not exist|unknown)/i.test(r.body ?? "")) {
      return { error: mapFbRestError(404, r.body ?? "") };
    }
    return { missing: true };
  }
  if (!r.ok) return { error: mapFbRestError(r.status, r.body ?? "") };
  try {
    const doc = JSON.parse(r.body ?? "") as { fields?: { data?: { stringValue?: string } } };
    const raw = doc.fields?.data?.stringValue;
    if (!raw) return { missing: true };
    const snap = JSON.parse(raw) as CloudSnapshot;
    if (!Array.isArray(snap.vehicles) || !Array.isArray(snap.records)) return { missing: true };
    return { snapshot: snap };
  } catch {
    return { error: { code: "invalid_backup", message: "نسخهٔ پشتیبان سرور معتبر نیست" } };
  }
}

/* ───────────────────────────── فرادادهٔ سینک ───────────────────────────── */

export interface FbSyncCounts {
  vehicles: number;
  totalRecords: number;
  reminders: number;
}

export interface FbSyncMeta {
  at: string;
  status: "ok" | "failed";
  counts?: FbSyncCounts;
  error?: string;
}

const K_META = "hamrah-khodro-fb-meta";
const K_AUTO = "hamrah-khodro-fb-auto";
const K_LAST_HASH = "hamrah-khodro-fb-lasthash";

export function getFbSyncMeta(): FbSyncMeta | null {
  try {
    const raw = localStorage.getItem(K_META);
    if (raw) return JSON.parse(raw) as FbSyncMeta;
  } catch {
    /* ignore */
  }
  return null;
}

function setFbSyncMeta(m: FbSyncMeta): void {
  try {
    localStorage.setItem(K_META, JSON.stringify(m));
  } catch {
    /* ignore */
  }
}

export function getFbAutoSync(): boolean {
  try {
    return localStorage.getItem(K_AUTO) !== "0";
  } catch {
    return true;
  }
}

export function setFbAutoSync(v: boolean): void {
  try {
    localStorage.setItem(K_AUTO, v ? "1" : "0");
  } catch {
    /* ignore */
  }
}

/* ───────────────────────────── سینک ───────────────────────────── */

export interface FbSyncResult {
  ok: boolean;
  unchanged?: boolean;
  needsRestore?: boolean;
  cloudSnapshot?: CloudSnapshot;
  counts?: FbSyncCounts;
  error?: FbErrorInfo;
}

let fbSyncChain: Promise<unknown> = Promise.resolve();

/** سینک دستی (آپلود) — زنجیرهٔ سریالی؛ سینک‌های همزمان پشت هم می‌روند */
export function runFirebaseSyncNow(opts?: { forceOverwrite?: boolean }): Promise<FbSyncResult> {
  const p = fbSyncChain.then(
    () => runFirebaseSyncInner(opts),
    () => runFirebaseSyncInner(opts)
  );
  fbSyncChain = p.then(
    () => undefined,
    () => undefined
  );
  return p;
}

async function runFirebaseSyncInner(opts?: { forceOverwrite?: boolean }): Promise<FbSyncResult> {
  const acc = getFirebaseAccount();
  if (!acc.connected || !acc.uid) {
    return { ok: false, error: { code: "disconnected", message: "ابتدا به حساب پشتیبان وارد شوید" } };
  }
  const snapshot = await buildLocalSnapshot();
  if (!snapshot) return { ok: false, error: { code: "local", message: "خواندن دادهٔ محلی ناموفق بود" } };

  const json = JSON.stringify(snapshot);
  // جلوگیری از آپلود بی‌مورد — هش سبک
  const lastHash = (() => {
    try {
      return localStorage.getItem(K_LAST_HASH);
    } catch {
      return null;
    }
  })();
  const hash = `${json.length}:${hashLight(json)}`;
  const meta = getFbSyncMeta();
  if (lastHash === hash && meta?.status === "ok" && !opts?.forceOverwrite) {
    return { ok: true, unchanged: true, counts: meta.counts };
  }

  // محافظ «سرور جلوتر است» — نصب تازه: قبل از بازنویسی، سرور خوانده می‌شود
  if (!lastHash && !opts?.forceOverwrite) {
    const cloud = await fbDownload(acc.uid);
    if (cloud.error) {
      setFbSyncMeta({ at: new Date().toISOString(), status: "failed", error: cloud.error.message });
      return { ok: false, error: cloud.error };
    }
    if (cloud.snapshot && !snapshotIsEmpty(cloud.snapshot)) {
      const lc = snapshotCounts(snapshot);
      const cc = snapshotCounts(cloud.snapshot);
      const cloudAhead =
        cc.vehicles > lc.vehicles || cc.totalRecords > lc.totalRecords || cc.reminders > lc.reminders;
      if (cloudAhead) {
        return {
          ok: false,
          needsRestore: true,
          cloudSnapshot: cloud.snapshot,
          counts: { vehicles: cc.vehicles, totalRecords: cc.totalRecords, reminders: cc.reminders },
          error: {
            code: "cloud_ahead",
            message: "در سرور پشتیبان پرتری از این گوشی هست — «بازیابی از سرور» را بزنید",
          },
        };
      }
    }
  }

  const up = await fbUpload(acc.uid, json);
  if (!up.ok) {
    setFbSyncMeta({ at: new Date().toISOString(), status: "failed", error: up.error?.message });
    return { ok: false, error: up.error };
  }
  try {
    localStorage.setItem(K_LAST_HASH, hash);
  } catch {
    /* ignore */
  }
  const counts = snapshotCounts(snapshot);
  setFbSyncMeta({
    at: new Date().toISOString(),
    status: "ok",
    counts: { vehicles: counts.vehicles, totalRecords: counts.totalRecords, reminders: counts.reminders },
  });
  return {
    ok: true,
    counts: {
      vehicles: counts.vehicles,
      totalRecords: counts.totalRecords,
      reminders: counts.reminders,
    },
  };
}

/** هش سبک (همان الگوی نسخهٔ Drive) */
function hashLight(s: string): string {
  let h1 = 0xdeadbeef ^ s.length;
  let h2 = 0x41c6ce57 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    const ch = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16) + (h1 >>> 0).toString(16);
}

/* ───────────────────────────── بازیابی ───────────────────────────── */

export async function downloadFirebaseSnapshot(): Promise<{
  snapshot?: CloudSnapshot;
  missing?: boolean;
  error?: FbErrorInfo;
}> {
  const acc = getFirebaseAccount();
  if (!acc.connected || !acc.uid) {
    return { error: { code: "disconnected", message: "ابتدا به حساب پشتیبان وارد شوید" } };
  }
  return fbDownload(acc.uid);
}

/** ادغام محلی + ابری — همان منطق مشترک نسخهٔ Drive */
export function mergeWithLocal(local: CloudSnapshot, cloud: CloudSnapshot): CloudSnapshot {
  return mergeSnapshots(local, cloud);
}

export async function applyFirebaseSnapshot(json: string): Promise<{ ok: boolean; error?: string }> {
  return restoreSnapshot(json);
}

export function buildLocalSnapshotPublic(): Promise<CloudSnapshot | null> {
  return buildLocalSnapshot();
}

/* ───────────────────────────── سینک خودکار ───────────────────────────── */

let fbAutoTimer: ReturnType<typeof setTimeout> | null = null;
let fbLastFailureNotified = false;

/** با هر تغییر داده صدا زده می‌شود؛ اگر حساب متصل و سینک خودکار روشن باشد آپلود می‌کند */
export function queueFirebaseAutoSync(): void {
  if (!fbBridge()) return;
  const acc = getFirebaseAccount();
  if (!acc.connected) return;
  if (!getFbAutoSync()) return;
  if (fbAutoTimer) clearTimeout(fbAutoTimer);
  fbAutoTimer = setTimeout(() => {
    fbAutoTimer = null;
    void (async () => {
      try {
        const result = await withBusy(
          { mode: "pill", title: "در حال همگام‌سازی با سرور پشتیبان…", detail: "آخرین اطلاعات ذخیره می‌شود" },
          () => runFirebaseSyncNow()
        );
        if (!result.ok && result.error) {
          if (!fbLastFailureNotified) {
            fbLastFailureNotified = true;
            window.dispatchEvent(
              new CustomEvent("hk-cloud-sync-failed", { detail: { message: result.error.message } })
            );
          }
        } else if (result.ok) {
          fbLastFailureNotified = false;
        }
      } catch {
        /* بی‌صدا */
      }
    })();
  }, 8000);
}

/** برای تست شبیه‌ساز: ریست وضعیت داخلی */
export function resetFirebaseSyncState(): void {
  if (fbAutoTimer) clearTimeout(fbAutoTimer);
  fbAutoTimer = null;
  fbLastFailureNotified = false;
  try {
    localStorage.removeItem(K_LAST_HASH);
  } catch {
    /* ignore */
  }
}
