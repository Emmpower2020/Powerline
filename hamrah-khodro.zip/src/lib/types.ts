/**
 * تایپ‌های اشتراکی سمت کلاینت + ثابت‌ها
 */

export type RecordType = "SERVICE" | "FUEL" | "ODOMETER" | "NOTE";
/** نوع یادآور: تاریخ | کیلومتر | هر دو (تاریخ + کیلومتر با هم) */
export type ReminderKind = "DATE" | "KM" | "BOTH";
export type ReminderRepeat = "NONE" | "MONTHLY" | "YEARLY" | "KM";
export type ReminderStatus = "ACTIVE" | "PENDING" | "DONE" | "OVERDUE";
export type CostMode = "TOTAL" | "SEPARATE";
export type FuelType = "GASOLINE" | "DIESEL" | "HYBRID" | "ELECTRIC" | "CNG";
export type Transmission = "MANUAL" | "AUTOMATIC";
export type CarStatus = "ACTIVE" | "IN_REPAIR" | "SOLD";
export type YearType = "JALALI" | "GREGORIAN";
/** نوع سرویس: خدماتی (فقط یک قیمت) یا تعویض قطعه (قطعه + دستمزد) */
export type ServiceKind = "SERVICE" | "PART";

export interface VehicleItem {
  id: string;
  name: string;
  brand: string;
  model: string;
  year: number | null;
  yearType: YearType;
  plate: string | null;
  vin: string | null;
  color: string | null;
  /** عکس خودرو (data URL — JPEG کوچک‌شده) */
  imageData?: string | null;
  fuelType: FuelType;
  transmission: Transmission;
  status: CarStatus;
  mileage: number;
  purchasePrice: number | null;
  purchaseDate: string | null;
  notes: string | null;
  isDefault: boolean;
  createdAt: string;
}

export interface RecordItem {
  id: string;
  type: RecordType;
  vehicleId: string;
  date: string; // ISO YYYY-MM-DD
  mileage: number | null;
  cost: number | null;
  // سرویس
  title: string | null;
  costMode: CostMode | null;
  partsCost: number | null;
  laborCost: number | null;
  hasOilFilter: boolean;
  oilFilterCost: number | null;
  hasAirFilter: boolean;
  airFilterCost: number | null;
  complementary: ComplementaryItem[]; // سرویس‌های مکمل انجام‌شده
  provider: string | null;
  description: string | null;
  nextDueDate: string | null;
  nextDueKm: number | null;
  // سوخت
  liters: number | null;
  pricePerLiter: number | null;
  fullTank: boolean;
  prevRegistered: boolean;
  consumption: number | null;
  station: string | null;
  // یادداشت
  noteTitle: string | null;
  noteBody: string | null;
  createdAt: string;
}

export interface ReminderItem {
  id: string;
  vehicleId: string;
  title: string;
  kind: ReminderKind;
  dueDate: string | null; // ISO YYYY-MM-DD
  dueKm: number | null;
  repeatKind: ReminderRepeat;
  repeatEveryKm: number | null;
  status: ReminderStatus;
  notes: string | null;
  linkedRecordId: string | null;
  done: boolean;
  doneAt: string | null;
  createdAt: string;
}

export interface BrandItem {
  id: string;
  name: string;
  models: string[];
  isCustom: boolean;
  createdAt: string;
}

/** آیتم سرویس مکمل روی رکورد سرویس — قیمت در فرم ثبت/ویرایش سرویس وارد می‌شود */
export interface ComplementaryItem {
  name: string;
  price: number | null;
}

export interface ServiceTypeItem {
  id: string;
  label: string;
  value: string;
  order: number;
  isDefault: boolean;
  separateCost: boolean;
  kind: ServiceKind; // SERVICE=خدماتی | PART=تعویض قطعه
  /** نام سرویس‌های مکمل تعریف‌شده برای این نوع — بدون قیمت (قیمت هنگام ثبت سرویس) */
  complementary: string[];
  createdAt: string;
}

export interface VehicleStats {
  vehicleId: string;
  currentKm: number;
  totalCost: number;
  monthCost: number;
  prevMonthCost: number;
  serviceCount: number;
  fuelCount: number;
  fuelTotalLiters: number;
  fuelTotalCost: number;
  avgConsumption: number | null; // لیتر بر ۱۰۰ کیلومتر
  lastServiceKm: number | null;
  monthlyCosts: { label: string; monthIndex: number; service: number; fuel: number }[];
  consumptionPoints: { label: string; value: number }[];
}

export interface StatsResponse {
  stats: VehicleStats[];
}

export const APP_VERSION = "v3.9.6";
export const APP_NAME = "مدیریت خودرو";

export const SERVICE_KIND_LABELS: Record<ServiceKind, string> = {
  SERVICE: "خدماتی",
  PART: "تعویض قطعه",
};

/** انواع سرویس پیش‌فرض — همراه نوع (خدماتی/تعویض قطعه) و سرویس‌های مکمل (فقط نام — قیمت در فرم ثبت سرویس) */
export const SERVICE_TYPE_DEFAULTS: {
  label: string;
  kind: ServiceKind;
  complementary?: string[];
}[] = [
  {
    label: "تعویض روغن موتور",
    kind: "SERVICE",
    complementary: ["فیلتر هوا", "فیلتر روغن"],
  },
  {
    label: "تعویض لنت ترمز",
    kind: "PART",
    complementary: ["تراشیدگی دیسک"],
  },
  {
    label: "تعویض تسمه تایم",
    kind: "PART",
    complementary: ["واترپمپ", "تسمه دینام"],
  },
  { label: "تعویض باتری", kind: "PART" },
  {
    label: "تعویض لاستیک",
    kind: "PART",
    complementary: ["چرخ‌لی و بالانس"],
  },
  {
    label: "تعویض روغن گیربکس",
    kind: "PART",
    complementary: ["فیلتر گیربکس"],
  },
  { label: "تعمیر موتور", kind: "SERVICE" },
  { label: "تعمیر گیربکس", kind: "SERVICE" },
  { label: "صافکاری و نقاشی", kind: "SERVICE" },
  {
    label: "تنظیم موتور",
    kind: "SERVICE",
    complementary: ["تعویض شمع‌ها", "تنظیم باد"],
  },
  { label: "برق خودرو", kind: "SERVICE" },
  { label: "معاینه فنی", kind: "SERVICE" },
  { label: "بیمه", kind: "SERVICE" },
  { label: "تمدید پلاک", kind: "SERVICE" },
  { label: "سایر", kind: "SERVICE" },
];

/** فهرست ساده نام‌ها — برای سازگاری با کدهای قبلی */
export const SERVICE_TYPES: readonly string[] = SERVICE_TYPE_DEFAULTS.map((t) => t.label);

export const RECORD_TYPE_LABELS: Record<RecordType, string> = {
  SERVICE: "سرویس",
  FUEL: "سوخت",
  ODOMETER: "کیلومتر",
  NOTE: "یادداشت",
};

export const FUEL_TYPE_LABELS: Record<FuelType, string> = {
  GASOLINE: "بنزینی",
  DIESEL: "دیزل",
  HYBRID: "هیبریدی",
  ELECTRIC: "برقی",
  CNG: "دوگانه",
};

export const TRANSMISSION_LABELS: Record<Transmission, string> = {
  MANUAL: "دستی",
  AUTOMATIC: "اتوماتیک",
};

export const CAR_STATUS_LABELS: Record<CarStatus, string> = {
  ACTIVE: "فعال",
  IN_REPAIR: "در تعمیر",
  SOLD: "فروخته",
};

export const REMINDER_REPEAT_LABELS: Record<ReminderRepeat, string> = {
  NONE: "بدون تکرار",
  MONTHLY: "ماهانه",
  YEARLY: "سالانه",
  KM: "هر N کیلومتر",
};

export const REMINDER_KIND_LABELS: Record<ReminderKind, string> = {
  DATE: "بر اساس تاریخ",
  KM: "بر اساس کارکرد",
  BOTH: "تاریخ و کیلومتر",
};

/** عنوان‌های پیشنهادی یادآور */
export const REMINDER_PRESETS = [
  "سرویس بعدی روغن",
  "معاینه فنی",
  "تمدید بیمه شخص ثالث",
  "تمدید بیمه بدنه",
  "تمدید پلاک",
  "تعویض لاستیک",
];

/** برندهای پیش‌فرض ایرانی و خارجی — شامل مدل‌های تولید/عرضهٔ ایران از حدود ۱۳۸۵ به بعد (ترتیب مدل‌ها: جدید → قدیمی) */
export const DEFAULT_BRANDS: { name: string; models: string[] }[] = [
  {
    name: "ایران خودرو",
    models: [
      // جدید
      "پژو ۵۰۸",
      "تارا اتوماتیک",
      "تارا دستی",
      "دنا رونین",
      "دنا پلاس توربو",
      "دنا پلاس",
      "دنا",
      "رانا",
      "هوشمند آریسان",
      "هوشمند",
      "سورن پلاس",
      "سورن ELX",
      "سمند سورن",
      "سمند ایسید",
      "سمند EF7",
      "سمند LX",
      "سمند",
      "پژو پارس ELX",
      "پژو پارس",
      "پژو ۲۰۷i اتوماتیک",
      "پژو ۲۰۷i دنده",
      "پژو ۲۰۶ تیپ ۶",
      "پژو ۲۰۶ تیپ ۵",
      "پژو ۲۰۶ تیپ ۲",
      "پژو ۲۰۶ صندوق",
      "ال۹۰ پلاس",
      "ال۹۰ (تندر ۹۰)",
      "پژو روآ",
      "پژو RD (رادیاتور جلو)",
      "پژو RD",
      "پژو ۴۰۵ GLX",
      "پژو ۴۰۵ SLX",
      "پژو ۴۰۵",
      "پیکان",
      "پیکان وانت",
    ],
  },
  {
    name: "سایپا",
    models: [
      "ریا",
      "اطلس",
      "سیبل",
      "شاهین اتوماتیک",
      "شاهین",
      "ساینا اتوماتیک",
      "ساینا",
      "کوییک اتوماتیک",
      "کوییک",
      "سایپا ۱۵۱",
      "تیبا S",
      "تیبا ۲",
      "تیبا صندوق",
      "پراید ۹۹",
      "پراید ۱۴۱",
      "پراید واگن",
      "پراید ۱۳۲",
      "پراید ۱۳۱",
      "پراید ۱۱۱",
    ],
  },
  { name: "بهمن موتور", models: ["دسترس", "شاهین", "کراس", "فیدلیتی", "ارمنیا"] },
  { name: "مدیران خودرو", models: ["کیا سراتو", "سراتو کاسپین", "ساینا", "کوییک"] },
  { name: "تویوتا", models: ["کرولا", "راو۴", "لندکروز", "پرادو", "پریوس", "کمری", "هایلوکس", "پاترول", "یاریس"] },
  { name: "هیوندای", models: ["النترا", "آوانته", "سوناتا", "توسن", "سانتافه", "اکسنت", "ورنا", "کوپه", "پورشه"] },
  { name: "کیا", models: ["سراتو", "سورنتو", "اسپورتیج", "اسپریج", "پیکانتو", "ریو", "کارنز", "فردشن"] },
  { name: "مزدا", models: ["مزدا ۲", "مزدا ۳", "مزدا ۶", "مزدا ۳۲۳"] },
  { name: "نیسان", models: ["ماکسیما", "تیانا", "قشقایی", "مگان", "پیکاپ نیسان"] },
  { name: "فولکس", models: ["پولو", "پاسات", "گل"] },
  { name: "مرسدس", models: ["کلاس C", "کلاس E", "سری ۳", "سری ۵", "سری ۷"] },
  { name: "بی‌ام‌و", models: ["سری ۳", "سری ۵", "سری ۷", "ایکس۵", "ایکس۵۳"] },
  { name: "چانگان", models: ["CS55", "السین", "ایادو", "CS35"] },
  { name: "جیلی", models: ["امگرند", "امگرند ۷", "تولوی"] },
  { name: "لیفان", models: ["۸۲۰", "۶۲۰", "X70", "X60", "۵۲۰", "میرا"] },
  { name: "هایما", models: ["S5", "S7", "V70"] },
  { name: "بایک", models: ["X25", "X35"] },
  { name: "هاوال", models: ["هاوال J", "هاوال H", "گولیون"] },
  { name: "چری", models: ["تیگو ۳", "تیگو ۵", "تیگو ۷ پرو", "تیگو ۸ پرو", "آریزو ۵", "آریزو ۶ پرو"] },
  { name: "جک", models: ["J7", "S5", "J5", "S3"] },
  { name: "رنو", models: ["کپچر", "تلیسمان", "فلوئنس", "لتیتود", "ساندرو", "مگان", "مگان کلاسیک", "تندر ۹۰ پلاس", "تندر ۹۰ استپ‌وی", "تندر ۹۰", "پارس تندر", "رنو ۵"] },
  { name: "شخصی", models: [] },
];
