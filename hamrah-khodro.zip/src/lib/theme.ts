/**
 * سیستم تم برنامه — ۹ تم پیش‌فرض (۱ اختصاصی + ۲ روشن + ۲ متوسط + ۲ میانه + ۲ تیره)
 * + تم‌های شخصیِ ساخته‌شده با «انتخاب رنگ» (هر رنگ یک طیف کامل روشن→تیره دارد).
 * هر تم (پیش‌فرض یا شخصی) قابل ویرایش (تغییر رنگ/نام) و حذف است؛ اختصاصی حذف نمی‌شود.
 * تم با data-theme روی <html> اعمال می‌شود و در localStorage ذخیره می‌گردد؛
 * تم‌های شخصی/ویرایش‌شده، متغیرهای CSS را از رنگ پایه تولید و پویا تزریق می‌کنند.
 */

export type BuiltinThemeId =
  | "paper"
  | "emerald"
  | "rosewater"
  | "turquoise"
  | "saffron"
  | "deepteal"
  | "graphite"
  | "midnight"
  | "forest";

/** شناسهٔ تم — پیش‌فرض یا «custom-*» */
export type ThemeId = BuiltinThemeId | `custom-${string}`;

export type ThemeGroup = "special" | "light" | "medium" | "mid" | "dark" | "mine";

export interface ThemePreview {
  primary: string;
  primaryFg: string;
  bg: string;
  card: string;
  text: string;
  sub: string;
  line: string;
}

export interface ThemeDef {
  id: ThemeId;
  /** شمارهٔ تم برای نمایش */
  no: number;
  name: string;
  desc: string;
  dark: boolean;
  group: ThemeGroup;
  preview: ThemePreview;
}

/** تم شخصی — ساخته‌شده با انتخاب رنگ */
export interface CustomThemeDef {
  id: `custom-${string}`;
  name: string;
  /** رنگ پایه (hex) — از طیف رنگی انتخاب شده */
  baseColor: string;
  dark: boolean;
  createdAt: number;
  /**
   * رنگ جداگانهٔ هر بخش تم — سربرگ / پس‌زمینه / کادرها.
   * هر بخش خانوادهٔ رنگ و شدت (گام طیف) خودش را دارد.
   */
  sections?: ThemeSectionColors;
}

/** ویرایش روی تم پیش‌فرض — رنگ/نام جدید به‌جای پیش‌فرض */
export interface ThemeOverride {
  name?: string;
  baseColor: string;
  dark: boolean;
  sections?: ThemeSectionColors;
}

/** رنگ‌های سه‌گانهٔ تم — سربرگ (نوارها و دکمه‌ها)، پس‌زمینه و کادرها */
export interface ThemeSectionColors {
  /** رنگ سربرگ صفحات و دکمه‌های اصلی (= primary) */
  header: string;
  /** رنگ پس‌زمینهٔ صفحه */
  background: string;
  /** رنگ کادرها و کارت‌ها */
  card: string;
}

export const THEME_KEY = "hamrah-khodro-theme";
export const CUSTOM_THEMES_KEY = "hamrah-khodro-custom-themes";
export const THEME_OVERRIDES_KEY = "hamrah-khodro-theme-overrides";
export const THEME_HIDDEN_KEY = "hamrah-khodro-theme-hidden";

/** تم پیش‌فرض برنامه — اختصاصی */
export const DEFAULT_THEME: BuiltinThemeId = "paper";

export const THEME_GROUP_LABELS: Record<ThemeGroup, string> = {
  special: "اختصاصی",
  light: "روشن",
  medium: "متوسط",
  mid: "میانه",
  dark: "تیره",
  mine: "تم‌های من",
};

/* ═════════════════════ تبدیل رنگ (hex ↔ hsl) ═════════════════════ */

export interface Hsl {
  h: number;
  s: number;
  l: number;
}

/** hex (#rgb یا #rrggbb) → hsl */
export function hexToHsl(hex: string): Hsl {
  let h = hex.replace("#", "").trim();
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let s = 0;
  let hue = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) hue = ((g - b) / d + (g < b ? 6 : 0)) * 60;
    else if (max === g) hue = ((b - r) / d + 2) * 60;
    else hue = ((r - g) / d + 4) * 60;
  }
  return { h: Math.round(hue), s: Math.round(s * 100), l: Math.round(l * 100) };
}

/** hsl → hex */
export function hslToHex(h: number, s: number, l: number): string {
  const sn = s / 100;
  const ln = l / 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = sn * Math.min(ln, 1 - ln);
  const f = (n: number) => ln - a * Math.max(-1, Math.min(Math.min(k(n) - 3, 9 - k(n)), 1));
  const toHex = (x: number) =>
    Math.round(255 * x)
      .toString(16)
      .padStart(2, "0");
  return `#${toHex(f(0))}${toHex(f(8))}${toHex(f(4))}`;
}

/** روشنایی ادراکی ۰..۲۵۵ برای تصمیم متن روشن/تیره روی رنگ */
function perceivedBrightness(hex: string): number {
  let h = hex.replace("#", "");
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return 0.299 * r + 0.587 * g + 0.114 * b;
}

/* ═════════════════════ تولید تم از رنگ پایه ═════════════════════ */

/**
 * تولید کامل متغیرهای CSS تم از یک رنگ پایه — حالت روشن یا تیره.
 * ساختار متغیرها مطابق globals.css است تا همهٔ اجزای برنامه بدون تغییر کار کنند.
 */
export function generateThemeVars(baseColor: string, dark: boolean): Record<string, string> {
  const { h, s } = hexToHsl(baseColor);
  if (dark) {
    const primary = hslToHex(h, Math.max(45, s), 68);
    return {
      background: hslToHex(h, 14, 10),
      foreground: hslToHex(h, 12, 92),
      card: hslToHex(h, 12, 14),
      "card-foreground": hslToHex(h, 12, 92),
      popover: hslToHex(h, 12, 14),
      "popover-foreground": hslToHex(h, 12, 92),
      primary,
      "primary-foreground": hslToHex(h, 45, 10),
      secondary: hslToHex(h, 10, 19),
      "secondary-foreground": hslToHex(h, 12, 86),
      muted: hslToHex(h, 10, 18),
      "muted-foreground": hslToHex(h, 8, 64),
      accent: hslToHex(h, 12, 22),
      "accent-foreground": hslToHex(h, 12, 90),
      destructive: "#ef4444",
      border: hslToHex(h, 10, 26),
      input: hslToHex(h, 10, 25),
      ring: primary,
      "chart-1": primary,
      "chart-2": hslToHex(h, 12, 60),
      "chart-3": hslToHex(h, 20, 55),
      "app-shell": hslToHex(h, 14, 8),
      sidebar: hslToHex(h, 14, 10),
      "sidebar-foreground": hslToHex(h, 12, 92),
      "sidebar-primary": primary,
      "sidebar-primary-foreground": hslToHex(h, 45, 10),
      "sidebar-accent": hslToHex(h, 12, 22),
      "sidebar-accent-foreground": hslToHex(h, 12, 90),
      "sidebar-border": hslToHex(h, 10, 26),
      "sidebar-ring": primary,
    };
  }
  const primary = baseColor;
  const primaryFg = perceivedBrightness(baseColor) < 150 ? "#ffffff" : hslToHex(h, 30, 16);
  return {
    background: hslToHex(h, Math.min(30, Math.round(s * 0.35)), 97),
    foreground: hslToHex(h, 15, 20),
    card: hslToHex(h, 18, 99),
    "card-foreground": hslToHex(h, 15, 20),
    popover: hslToHex(h, 18, 99),
    "popover-foreground": hslToHex(h, 15, 20),
    primary,
    "primary-foreground": primaryFg,
    secondary: hslToHex(h, Math.round(s * 0.35), 94),
    "secondary-foreground": hslToHex(h, Math.max(20, Math.round(s * 0.4)), 32),
    muted: hslToHex(h, 14, 94),
    "muted-foreground": hslToHex(h, 10, 45),
    accent: hslToHex(h, Math.max(20, Math.round(s * 0.5)), 93),
    "accent-foreground": hslToHex(h, Math.max(20, Math.round(s * 0.4)), 28),
    destructive: "#dc2626",
    border: hslToHex(h, 22, 87),
    input: hslToHex(h, 22, 84),
    ring: primary,
    "chart-1": primary,
    "chart-2": hslToHex(h, 15, 42),
    "chart-3": hslToHex(h, Math.round(s * 0.7), 60),
    "app-shell": hslToHex(h, 12, 95),
    sidebar: hslToHex(h, 12, 97),
    "sidebar-foreground": hslToHex(h, 15, 20),
    "sidebar-primary": primary,
    "sidebar-primary-foreground": primaryFg,
    "sidebar-accent": hslToHex(h, 20, 93),
    "sidebar-accent-foreground": hslToHex(h, 20, 28),
    "sidebar-border": hslToHex(h, 22, 87),
    "sidebar-ring": primary,
  };
}

/** پیش‌نمایش کارت تم از رنگ پایه */
export function previewFromBase(baseColor: string, dark: boolean): ThemePreview {
  const v = generateThemeVars(baseColor, dark);
  return {
    primary: v.primary,
    primaryFg: v["primary-foreground"],
    bg: v.background,
    card: v.card,
    text: v.foreground,
    sub: v["muted-foreground"],
    line: v.border,
  };
}

/* ═════════════════════ تم از رنگ‌های سه‌گانه (سربرگ/پس‌زمینه/کادر) ═════════════════════ */

/**
 * تولید متغیرهای CSS از رنگ‌های جداگانهٔ هر بخش:
 *  - سربرگ → primary (نوارهای رنگی بالای صفحات، دکمه‌ها، اکسنت‌ها)
 *  - پس‌زمینه → background + متن/خطوط مشتق‌شده از آن
 *  - کادر → card + کادرها و پاپ‌آپ‌ها
 * روشن/تیره بودن تم به‌صورت خودکار از روشنایی رنگ پس‌زمینه تشخیص داده می‌شود.
 */
export function generateThemeVarsFromSections(
  sections: ThemeSectionColors
): Record<string, string> {
  const { h: hh, s: hs } = hexToHsl(sections.header);
  const { h: bh, s: bs } = hexToHsl(sections.background);
  const { h: ch, s: cs } = hexToHsl(sections.card);
  const dark = perceivedBrightness(sections.background) < 128;

  const primary = sections.header;
  const primaryFg =
    perceivedBrightness(primary) < 150 ? "#ffffff" : hslToHex(hh, 30, 16);
  const cardFg =
    perceivedBrightness(sections.card) < 128
      ? hslToHex(ch, 12, 92)
      : hslToHex(ch, 15, 20);

  if (dark) {
    return {
      background: sections.background,
      foreground: hslToHex(bh, 12, 92),
      card: sections.card,
      "card-foreground": cardFg,
      popover: sections.card,
      "popover-foreground": cardFg,
      primary,
      "primary-foreground": primaryFg,
      secondary: hslToHex(bh, 10, 19),
      "secondary-foreground": hslToHex(bh, 12, 86),
      muted: hslToHex(bh, 10, 18),
      "muted-foreground": hslToHex(bh, 8, 64),
      accent: hslToHex(bh, 12, 22),
      "accent-foreground": hslToHex(bh, 12, 90),
      destructive: "#ef4444",
      border: hslToHex(bh, 10, 30),
      input: hslToHex(bh, 10, 28),
      ring: primary,
      "chart-1": primary,
      "chart-2": hslToHex(hh, 12, 60),
      "chart-3": hslToHex(hh, Math.round(hs * 0.7), 60),
      "app-shell": hslToHex(bh, 14, Math.max(4, hexToHsl(sections.background).l - 3)),
      sidebar: sections.background,
      "sidebar-foreground": hslToHex(bh, 12, 92),
      "sidebar-primary": primary,
      "sidebar-primary-foreground": primaryFg,
      "sidebar-accent": hslToHex(bh, 12, 22),
      "sidebar-accent-foreground": hslToHex(bh, 12, 90),
      "sidebar-border": hslToHex(bh, 10, 30),
      "sidebar-ring": primary,
    };
  }
  return {
    background: sections.background,
    foreground: hslToHex(bh, 15, 20),
    card: sections.card,
    "card-foreground": cardFg,
    popover: sections.card,
    "popover-foreground": cardFg,
    primary,
    "primary-foreground": primaryFg,
    secondary: hslToHex(bh, Math.round(bs * 0.35), 94),
    "secondary-foreground": hslToHex(bh, Math.max(20, Math.round(bs * 0.4)), 32),
    muted: hslToHex(bh, 14, 94),
    "muted-foreground": hslToHex(bh, 10, 45),
    accent: hslToHex(bh, Math.max(20, Math.round(bs * 0.5)), 93),
    "accent-foreground": hslToHex(bh, Math.max(20, Math.round(bs * 0.4)), 28),
    destructive: "#dc2626",
    border: hslToHex(bh, 22, 87),
    input: hslToHex(bh, 22, 84),
    ring: primary,
    "chart-1": primary,
    "chart-2": hslToHex(bh, 15, 42),
    "chart-3": hslToHex(hh, Math.round(hs * 0.7), 60),
    "app-shell": hslToHex(bh, 12, Math.min(97, hexToHsl(sections.background).l + 2)),
    sidebar: sections.background,
    "sidebar-foreground": hslToHex(bh, 15, 20),
    "sidebar-primary": primary,
    "sidebar-primary-foreground": primaryFg,
    "sidebar-accent": hslToHex(bh, 20, 93),
    "sidebar-accent-foreground": hslToHex(bh, 20, 28),
    "sidebar-border": hslToHex(bh, 22, 87),
    "sidebar-ring": primary,
  };
}

/** پیش‌نمایش کارت تم از رنگ‌های سه‌گانه */
export function previewFromSections(sections: ThemeSectionColors): ThemePreview {
  const v = generateThemeVarsFromSections(sections);
  return {
    primary: v.primary,
    primaryFg: v["primary-foreground"],
    bg: v.background,
    card: v.card,
    text: v.foreground,
    sub: v["muted-foreground"],
    line: v.border,
  };
}

/** تم تیره است؟ (از رنگ پس‌زمینه) */
export function isSectionsDark(sections: ThemeSectionColors): boolean {
  return perceivedBrightness(sections.background) < 128;
}

/* ═════════════════════ طیف رنگی انتخابگر ═════════════════════ */

/** خانواده‌های رنگ — هر خانواده یک طیف کامل دارد */
export const COLOR_FAMILIES: { name: string; h: number; s: number }[] = [
  { name: "قرمز", h: 355, s: 62 },
  { name: "سرخابی", h: 330, s: 58 },
  { name: "بنفش", h: 285, s: 50 },
  { name: "آبی", h: 218, s: 60 },
  { name: "فیروزه‌ای", h: 190, s: 62 },
  { name: "سبزآبی", h: 172, s: 58 },
  { name: "سبز", h: 150, s: 52 },
  { name: "لیمویی", h: 95, s: 46 },
  { name: "زرد", h: 52, s: 78 },
  { name: "نارنجی", h: 30, s: 82 },
  { name: "قهوه‌ای", h: 26, s: 44 },
  { name: "خاکستری", h: 220, s: 8 },
];

/** طیف روشن → تیره (درصد روشنایی) — از نزدیک‌سفید تا نزدیک‌مشکی */
export const SHADE_STEPS = [98, 95, 92, 87, 80, 72, 63, 54, 44, 34, 24, 15];

/** رنگ گام i از طیف خانوادهٔ f */
export function familyShade(f: { h: number; s: number }, index: number): string {
  return hslToHex(f.h, f.s, SHADE_STEPS[Math.max(0, Math.min(SHADE_STEPS.length - 1, index))]);
}

/* ═════════════════════ تم‌های پیش‌فرض (۹) ═════════════════════ */

export const THEMES: ThemeDef[] = [
  /* ---------------- اختصاصی (پیش‌فرض — قابل ویرایش، غیرقابل حذف) ---------------- */
  {
    id: "paper",
    no: 1,
    name: "اختصاصی",
    desc: "سفید سرد با حاشیهٔ فیروزه‌ای و اکسنت زمردی",
    dark: false,
    group: "special",
    preview: {
      primary: "#0d9488",
      primaryFg: "#ffffff",
      bg: "#f5f7f9",
      card: "#ffffff",
      text: "#1f2937",
      sub: "#6b7280",
      line: "#a5d6cd",
    },
  },

  /* ---------------- روشن (۲) ---------------- */
  {
    id: "emerald",
    no: 2,
    name: "روز",
    desc: "سفید سرزنده با سبز زمردی",
    dark: false,
    group: "light",
    preview: {
      primary: "#047857",
      primaryFg: "#ffffff",
      bg: "#ffffff",
      card: "#f0faf6",
      text: "#0b3b2e",
      sub: "#5f7a72",
      line: "#d3e6df",
    },
  },
  {
    id: "rosewater",
    no: 3,
    name: "گل‌بهی",
    desc: "سفید صورتی‌فام با رز ملایم",
    dark: false,
    group: "light",
    preview: {
      primary: "#c24068",
      primaryFg: "#fff5f8",
      bg: "#fffafc",
      card: "#fdf2f6",
      text: "#40202c",
      sub: "#7d6470",
      line: "#eed9e2",
    },
  },

  /* ---------------- متوسط (۲) ---------------- */
  {
    id: "turquoise",
    no: 4,
    name: "فیروزه",
    desc: "خاکستری فیروزه‌ای با آبی‌سبز خنک",
    dark: false,
    group: "medium",
    preview: {
      primary: "#0e7c86",
      primaryFg: "#f2fbfc",
      bg: "#eef4f5",
      card: "#f8fbfc",
      text: "#0b2b30",
      sub: "#5c7378",
      line: "#d6e4e6",
    },
  },
  {
    id: "saffron",
    no: 5,
    name: "زعفران",
    desc: "خاکستری گرم با نارنجی زعفرانی",
    dark: false,
    group: "medium",
    preview: {
      primary: "#bc6f0a",
      primaryFg: "#fff9ee",
      bg: "#f3ece1",
      card: "#faf5ec",
      text: "#3d2f1c",
      sub: "#7c6c55",
      line: "#e2d5c0",
    },
  },

  /* ---------------- میانه (۲) ---------------- */
  {
    id: "deepteal",
    no: 6,
    name: "فیروزه تیره",
    desc: "فیروزهٔ عمیق با آبی‌سبز روشن",
    dark: true,
    group: "mid",
    preview: {
      primary: "#5bcfd1",
      primaryFg: "#06282b",
      bg: "#223439",
      card: "#2b4147",
      text: "#e2eff1",
      sub: "#93a9ad",
      line: "#3d565b",
    },
  },
  {
    id: "graphite",
    no: 7,
    name: "گرافیت",
    desc: "زغالی خنثی با طلایی ملایم",
    dark: true,
    group: "mid",
    preview: {
      primary: "#d4ad66",
      primaryFg: "#241d0e",
      bg: "#2f2f34",
      card: "#3a3a40",
      text: "#e8e8ea",
      sub: "#9a9aa0",
      line: "#4a4a51",
    },
  },

  /* ---------------- تیره (۲) ---------------- */
  {
    id: "midnight",
    no: 8,
    name: "شب",
    desc: "تیرهٔ آرام با سبز روشن",
    dark: true,
    group: "dark",
    preview: {
      primary: "#34d399",
      primaryFg: "#06231a",
      bg: "#1a1d1b",
      card: "#242826",
      text: "#e9edeb",
      sub: "#9aa5a0",
      line: "#39403d",
    },
  },
  {
    id: "forest",
    no: 9,
    name: "جنگل",
    desc: "سبز تیره با سبز روشن",
    dark: true,
    group: "dark",
    preview: {
      primary: "#6ee7b7",
      primaryFg: "#0d2b1f",
      bg: "#1d2420",
      card: "#28322b",
      text: "#e2e9e4",
      sub: "#9db1a6",
      line: "#3c4a41",
    },
  },
];

/* ═════════════════════ ذخیره‌سازی تم‌های شخصی/ویرایش/حذف ═════════════════════ */

function readJson<T>(key: string, fallback: T): T {
  if (typeof localStorage === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

/** تم‌های شخصی */
export function getCustomThemes(): CustomThemeDef[] {
  const list = readJson<CustomThemeDef[]>(CUSTOM_THEMES_KEY, []);
  return Array.isArray(list) ? list.filter((t) => t && t.id && t.baseColor) : [];
}

export function saveCustomThemes(list: CustomThemeDef[]) {
  writeJson(CUSTOM_THEMES_KEY, list);
}

export function addCustomTheme(
  t: Omit<CustomThemeDef, "id" | "createdAt"> & { id?: string }
): CustomThemeDef {
  const id = (t.id ?? `custom-${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}`) as `custom-${string}`;
  const dark = t.sections ? isSectionsDark(t.sections) : t.dark;
  const def: CustomThemeDef = {
    id,
    name: t.name,
    baseColor: t.sections ? t.sections.header : t.baseColor,
    dark,
    sections: t.sections,
    createdAt: Date.now(),
  };
  const list = getCustomThemes();
  const existingIdx = list.findIndex((x) => x.id === id);
  if (existingIdx >= 0) list[existingIdx] = { ...list[existingIdx], ...def };
  else list.push(def);
  saveCustomThemes(list);
  return def;
}

/** ویرایش‌های اعمال‌شده روی تم‌های پیش‌فرض */
export function getThemeOverrides(): Partial<Record<BuiltinThemeId, ThemeOverride>> {
  return readJson<Partial<Record<BuiltinThemeId, ThemeOverride>>>(THEME_OVERRIDES_KEY, {});
}

export function saveThemeOverrides(o: Partial<Record<BuiltinThemeId, ThemeOverride>>) {
  writeJson(THEME_OVERRIDES_KEY, o);
}

/** تم‌های پیش‌فرضِ حذف‌شده (مخفی) — «اختصاصی» حذف نمی‌شود */
export function getHiddenThemes(): BuiltinThemeId[] {
  const list = readJson<BuiltinThemeId[]>(THEME_HIDDEN_KEY, []);
  return Array.isArray(list) ? list.filter((id) => id && id !== "paper") : [];
}

export function setHiddenThemes(list: BuiltinThemeId[]) {
  writeJson(THEME_HIDDEN_KEY, list.filter((id) => id !== "paper"));
}

/** بازگردانی همهٔ پیش‌فرض‌ها — حذف حذف‌ها و ویرایش‌ها */
export function resetThemeCustomizations() {
  try {
    localStorage.removeItem(THEME_HIDDEN_KEY);
    localStorage.removeItem(THEME_OVERRIDES_KEY);
  } catch {
    /* ignore */
  }
}

export function isBuiltinThemeId(id: string): id is BuiltinThemeId {
  return THEMES.some((t) => t.id === id);
}

/** تعریف مؤثر تم برای نمایش در فهرست — با احتساب ویرایش */
export interface ResolvedThemeDef {
  id: string;
  no: number | string;
  name: string;
  desc: string;
  dark: boolean;
  group: ThemeGroup;
  preview: ThemePreview;
  isCustom: boolean;
  /** ویرایش‌شده توسط کاربر */
  edited: boolean;
  /** قابل حذف است؟ (اختصاصی نه) */
  deletable: boolean;
}

export function resolveThemeDefs(): ResolvedThemeDef[] {
  const overrides = getThemeOverrides();
  const hidden = new Set(getHiddenThemes());
  const list: ResolvedThemeDef[] = [];
  for (const def of THEMES) {
    if (hidden.has(def.id as BuiltinThemeId)) continue;
    const ov = overrides[def.id as BuiltinThemeId];
    if (ov) {
      const dark = ov.sections ? isSectionsDark(ov.sections) : ov.dark;
      list.push({
        id: def.id,
        no: def.no,
        name: ov.name?.trim() || def.name,
        desc: "ویرایش‌شده با رنگ دلخواه",
        dark,
        group: dark ? "dark" : def.group === "special" ? "special" : "light",
        preview: ov.sections ? previewFromSections(ov.sections) : previewFromBase(ov.baseColor, ov.dark),
        isCustom: false,
        edited: true,
        deletable: def.id !== "paper",
      });
    } else {
      list.push({
        ...def,
        isCustom: false,
        edited: false,
        deletable: def.id !== "paper",
      });
    }
  }
  for (const c of getCustomThemes()) {
    list.push({
      id: c.id,
      no: "★",
      name: c.name || "تم شخصی",
      desc: c.dark ? "تم شخصی تیره" : "تم شخصی روشن",
      dark: c.sections ? isSectionsDark(c.sections) : c.dark,
      group: "mine",
      preview: c.sections ? previewFromSections(c.sections) : previewFromBase(c.baseColor, c.dark),
      isCustom: true,
      edited: false,
      deletable: true,
    });
  }
  return list;
}

/* ═════════════════════ اعمال و خواندن تم فعال ═════════════════════ */

const DYNAMIC_STYLE_ID = "hk-dynamic-theme";
const THEME_VARS_KEY = "hamrah-khodro-theme-vars";
const THEME_DARK_KEY = "hamrah-khodro-theme-dark";

/** اعمال تم روی سند + ذخیره در localStorage */
export function applyTheme(id: string) {
  if (typeof document === "undefined") return;
  let styleEl = document.getElementById(DYNAMIC_STYLE_ID) as HTMLStyleElement | null;

  const custom = getCustomThemes().find((t) => t.id === id);
  const override = isBuiltinThemeId(id) ? getThemeOverrides()[id] : undefined;
  let dark: boolean;
  let css: string | null = null;

  if (custom || override) {
    const conf = (custom ?? override)!;
    const sections = conf.sections;
    dark = sections ? isSectionsDark(sections) : conf.dark;
    const vars = sections
      ? generateThemeVarsFromSections(sections)
      : generateThemeVars(conf.baseColor, conf.dark);
    css = `[data-theme="${id}"]{${Object.entries(vars)
      .map(([k, v]) => `--${k}:${v};`)
      .join("")}}`;
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = DYNAMIC_STYLE_ID;
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = css;
    document.documentElement.setAttribute("data-theme", id);
  } else {
    styleEl?.remove();
    const def = THEMES.find((t) => t.id === id) ?? THEMES[0];
    dark = def.dark;
    id = def.id;
    document.documentElement.setAttribute("data-theme", id);
  }
  document.documentElement.classList.toggle("dark", dark);
  try {
    localStorage.setItem(THEME_KEY, id);
    localStorage.setItem(THEME_DARK_KEY, dark ? "1" : "0");
    if (css) localStorage.setItem(THEME_VARS_KEY, css);
    else localStorage.removeItem(THEME_VARS_KEY);
  } catch {
    /* ignore */
  }
}

/** خواندن تم ذخیره‌شده (پیش‌فرض: اختصاصی) — تم‌های حذف‌شده به اختصاصی برمی‌گردند */
export function getStoredTheme(): string {
  try {
    const v = localStorage.getItem(THEME_KEY);
    if (!v) return DEFAULT_THEME;
    if (isBuiltinThemeId(v)) {
      if (getHiddenThemes().includes(v)) return DEFAULT_THEME;
      return v;
    }
    if (getCustomThemes().some((t) => t.id === v)) return v;
  } catch {
    /* ignore */
  }
  return DEFAULT_THEME;
}

/** تعریف نمایشی تم فعال — برای بج منوی تنظیمات */
export function getThemeDef(id: string): ResolvedThemeDef {
  const list = resolveThemeDefs();
  const found = list.find((t) => t.id === id);
  if (found) return found;
  const paper = THEMES[0];
  return {
    ...paper,
    isCustom: false,
    edited: false,
    deletable: false,
  };
}
