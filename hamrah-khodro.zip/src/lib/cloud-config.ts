/**
 * تنظیمات ابری «همراه خودرو» — پیکربندی ثابت برنامه (نسخهٔ v3.8.0)
 *
 *  ⚠️ فقط توسعه‌دهنده این مقادیر را تغییر می‌دهد؛ کاربر نهایی هیچ‌چیز وارد نمی‌کند.
 *  Client ID از Google Cloud Console (پروژهٔ مالک برنامه) اینجا «تعبیه» شده است.
 *  جریان اتصال: دکمهٔ «به Google Drive وصل شوید» ← مرورگر سیستم با صفحهٔ رسمی
 *  انتخاب حساب گوگل باز می‌شود ← کاربر مجوزها را در همان صفحهٔ گوگل تأیید می‌کند
 *  ← گوگل به اسکیم اختصاصی برنامه برمی‌گرداند ← اتصال کامل می‌شود.
 *
 *  نیازمندی گوگل برای کلاینت نوع Android:
 *   - در Google Cloud Console ← Credentials ← کلاینت اندروید ← Advanced settings
 *     گزینهٔ «Enable custom URI scheme» باید فعال باشد (یک تیک، یک‌بار برای همیشه).
 *   - Package name: com.zai.hamrahkhodro + SHA-1 کلید امضای APK باید ثبت شده باشد.
 */

/** OAuth Client ID (نوع Android) — تعبیه‌شده در برنامه */
export const GOOGLE_CLIENT_ID =
  "876691396788-fbiuu666o7i3fujgek28t1mnb96mi3pv.apps.googleusercontent.com";

/** اسکیم بازگشت گوگل به برنامه (معکوس نام پکیج — الزام امنیتی گوگل) */
export const REDIRECT_SCHEME = "com.zai.hamrahkhodro";

/** آدرس بازگشت (redirect_uri) — با اسکیم اختصاصی برنامه */
export const REDIRECT_URI = "com.zai.hamrahkhodro:/oauth2callback";

/** صفحهٔ رسمی ورود گوگل که در مرورگر گوشی باز می‌شود */
export const GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
