/**
 * کمک‌تابع‌های سمت سرور — سریالایز و اعتبارسنجی
 */
import type { Record as DbRecord, Reminder, Vehicle, BrandModel, ServiceType } from "@prisma/client";

/** DateTime → رشته YYYY-MM-DD (بدون مشکل تایم‌زون) */
function dtToISO(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** رشته JSON → آرایه سرویس‌های مکمل [{name, price}] (برای رکورد سرویس) */
export function parseComplementary(json: string | null | undefined): { name: string; price: number | null }[] {
  if (!json) return [];
  try {
    const arr = JSON.parse(json);
    if (!Array.isArray(arr)) return [];
    return arr
      .map((it) => {
        // هر دو فرمت [{name}] و ["نام"] پشتیبانی می‌شود
        if (typeof it === "string") return { name: it.trim(), price: null };
        const name = typeof it?.name === "string" ? it.name.trim() : "";
        const price =
          it?.price === null || it?.price === undefined || it?.price === ""
            ? null
            : Number(it.price);
        return { name, price: price != null && Number.isFinite(price) ? Math.round(price) : null };
      })
      .filter((it) => it.name !== "");
  } catch {
    return [];
  }
}

/** رشته JSON → فهرست نام سرویس‌های مکمل (برای نوع سرویس — بدون قیمت) */
export function parseComplementaryNames(json: string | null | undefined): string[] {
  return parseComplementary(json).map((it) => it.name);
}

/** آرایهٔ نام‌های مکمل (string[] یا [{name}]) → رشته JSON — خروجی null برای تهی */
export function complementaryNamesToJson(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  if (!Array.isArray(v)) return null;
  const items = v
    .map((it) => (typeof it === "string" ? it.trim() : String(it?.name ?? "").trim()))
    .filter((name) => name !== "");
  return items.length > 0 ? JSON.stringify(items) : null;
}

/** آرایهٔ سرویس‌های مکمل → رشته JSON (خروجی null برای تهی) */
export function complementaryToJson(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  if (!Array.isArray(v)) return null;
  const items = v
    .map((it) => {
      const name = typeof (it as Record<string, unknown>)?.name === "string"
        ? String(it.name).trim()
        : "";
      const price = (it as Record<string, unknown>)?.price;
      return {
        name,
        price:
          price === null || price === undefined || price === ""
            ? null
            : Number.isFinite(Number(price))
              ? Math.round(Number(price))
              : null,
      };
    })
    .filter((it) => it.name !== "");
  return items.length > 0 ? JSON.stringify(items) : null;
}

export function serializeVehicle(v: Vehicle) {
  return {
    id: v.id,
    name: v.model || v.brand,
    brand: v.brand,
    model: v.model,
    year: v.year,
    yearType: v.yearType as "JALALI" | "GREGORIAN",
    plate: v.plate,
    vin: v.vin,
    color: v.color,
    imageData: v.imageData,
    fuelType: v.fuelType as "GASOLINE" | "DIESEL" | "HYBRID" | "ELECTRIC" | "CNG",
    transmission: v.transmission as "MANUAL" | "AUTOMATIC",
    status: v.status as "ACTIVE" | "IN_REPAIR" | "SOLD",
    mileage: v.mileage,
    purchasePrice: v.purchasePrice,
    purchaseDate: v.purchaseDate ? dtToISO(v.purchaseDate) : null,
    notes: v.notes,
    isDefault: v.isDefault,
    createdAt: v.createdAt.toISOString(),
  };
}

export function serializeRecord(r: DbRecord) {
  return {
    id: r.id,
    type: r.type as "SERVICE" | "FUEL" | "ODOMETER" | "NOTE",
    vehicleId: r.vehicleId,
    date: dtToISO(r.date),
    mileage: r.mileage,
    cost: r.cost,
    title: r.title,
    costMode: r.costMode as "TOTAL" | "SEPARATE" | null,
    partsCost: r.partsCost,
    laborCost: r.laborCost,
    hasOilFilter: r.hasOilFilter,
    oilFilterCost: r.oilFilterCost,
    hasAirFilter: r.hasAirFilter,
    airFilterCost: r.airFilterCost,
    complementary: parseComplementary(r.complementary),
    provider: r.provider,
    description: r.description,
    nextDueDate: r.nextDueDate ? dtToISO(r.nextDueDate) : null,
    nextDueKm: r.nextDueKm,
    liters: r.liters,
    pricePerLiter: r.pricePerLiter,
    fullTank: r.fullTank,
    prevRegistered: r.prevRegistered,
    consumption: r.consumption,
    station: r.station,
    noteTitle: r.noteTitle,
    noteBody: r.noteBody,
    createdAt: r.createdAt.toISOString(),
  };
}

export function serializeReminder(r: Reminder) {
  return {
    id: r.id,
    vehicleId: r.vehicleId,
    title: r.title,
    kind: r.kind as "DATE" | "KM",
    dueDate: r.dueDate ? dtToISO(r.dueDate) : null,
    dueKm: r.dueKm,
    repeatKind: r.repeatKind as "NONE" | "MONTHLY" | "YEARLY" | "KM",
    repeatEveryKm: r.repeatEveryKm,
    status: r.status as "ACTIVE" | "PENDING" | "DONE" | "OVERDUE",
    notes: r.notes,
    linkedRecordId: r.linkedRecordId,
    done: r.done,
    doneAt: r.doneAt ? r.doneAt.toISOString() : null,
    createdAt: r.createdAt.toISOString(),
  };
}

export function serializeBrand(b: BrandModel) {
  let models: string[] = [];
  try {
    models = JSON.parse(b.models) as string[];
  } catch {
    models = [];
  }
  return {
    id: b.id,
    name: b.name,
    models,
    isCustom: b.isCustom,
    createdAt: b.createdAt.toISOString(),
  };
}

export function serializeServiceType(s: ServiceType) {
  return {
    id: s.id,
    label: s.label,
    value: s.value,
    order: s.order,
    isDefault: s.isDefault,
    separateCost: s.separateCost,
    kind: (s.kind === "PART" ? "PART" : "SERVICE") as "SERVICE" | "PART",
    complementary: parseComplementaryNames(s.complementary),
    createdAt: s.createdAt.toISOString(),
  };
}

/** رشته YYYY-MM-DD → Date (UTC نیمه‌شب) */
export function parseISOMidnight(iso: string): Date {
  return new Date(iso + "T00:00:00.000Z");
}

/** بررسی فرمت YYYY-MM-DD */
export function isValidISODate(s: unknown): s is string {
  return typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);
}

export function toIntOrNull(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? Math.round(n) : null;
}

export function toFloatOrNull(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export function toStrOrNull(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s === "" ? null : s;
}

export function badRequest(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

export function serverError(e: unknown) {
  console.error("API error:", e);
  return Response.json({ error: "خطای داخلی سرور" }, { status: 500 });
}
