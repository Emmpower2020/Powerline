/**
 * کتابخانه فارسی — تبدیل تاریخ جلالی (الگوریتم jalaali-js)، اعداد فارسی و فرمت‌ها
 */

/* ---------------------------- تبدیل جلالی ---------------------------- */

function div(a: number, b: number) {
  return ~~(a / b);
}
function mod(a: number, b: number) {
  return a - Math.floor(a / b) * b;
}

function jalCal(jy: number) {
  const breaks = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
    2192, 2262, 2324, 2394, 2456, 3178,
  ];
  const bl = breaks.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];
  let jm = 0;
  let jump = 0;
  if (jy < jp || jy >= breaks[bl - 1]) {
    throw new Error("Invalid Jalaali year " + jy);
  }
  for (let i = 1; i < bl; i += 1) {
    jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy: number, gm: number, gd: number) {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function j2d(jy: number, jm: number, jd: number) {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

function d2j(jdn: number) {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    } else {
      k -= 186;
    }
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}

export function toJalaali(gy: number, gm: number, gd: number) {
  return d2j(g2d(gy, gm, gd));
}

export function toGregorian(jy: number, jm: number, jd: number) {
  return d2g(j2d(jy, jm, jd));
}

export function jalaaliMonthLength(jy: number, jm: number) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaaliYear(jy) ? 30 : 29;
}

export function isLeapJalaaliYear(jy: number) {
  return jalCal(jy).leap === 0;
}

/** شماره روز جلالی از مبدأ (برای جمع/کم کردن روز) */
export function jalaliDayNumber(jy: number, jm: number, jd: number) {
  return j2d(jy, jm, jd);
}

export function fromJalaliDayNumber(jdn: number) {
  return d2j(jdn);
}

/* ------------------------------ نام‌ها ------------------------------ */

export const PERSIAN_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export const PERSIAN_WEEKDAYS = [
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه",
  "شنبه",
];

/* --------------------------- اعداد فارسی --------------------------- */

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** تبدیل ارقام لاتین به فارسی */
export function fa(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return "";
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[+d]);
}

/** تبدیل ارقام فارسی/عربی به لاتین — ممیز عربی (٫) هم به نقطه تبدیل می‌شود */
export function en(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/٫/g, ".");
}

/** نرمال‌سازی متن فارسی برای جستجو — ی/ک عربی → فارسی، نیم‌فاصله → فاصله */
export function normFa(s: string): string {
  return s.replace(/ي/g, "ی").replace(/ك/g, "ک").replace(/\u200c/g, " ").trim();
}

/** نمایش پلاک با نام کامل حرف — «ا» تنها → «الف» (بقیهٔ حروف نامشان خودشان است) */
export function plateDisplay(plate: string | null | undefined): string {
  if (!plate) return "";
  return plate.replace(/(^|\s)ا($|\s)/g, "$1الف$2");
}

/** عدد با جداکننده هزارگان فارسی: ۱۲۳۴۵۶۷ → ۱٬۲۳۴٬۵۶۷ */
export function faNum(n: number | null | undefined, fractionDigits = 0): string {
  if (n === null || n === undefined || isNaN(n)) return "۰";
  const fixed = Number(n).toFixed(fractionDigits);
  const [intPart, fracPart] = fixed.split(".");
  const withSep = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, "٬");
  return fa(fracPart ? `${withSep}.${fracPart}` : withSep);
}

/** پول (تومان) */
export function faMoney(n: number | null | undefined): string {
  if (n === null || n === undefined || n === 0) return "۰ تومان";
  return `${faNum(n)} تومان`;
}

/** پول خلاصه: ۱٬۲۵۰٬۰۰۰ → ۱.۲۵ میلیون تومان */
export function faMoneyShort(n: number | null | undefined): string {
  if (n === null || n === undefined || n === 0) return "۰";
  if (n >= 1_000_000_000) return `${fa((n / 1_000_000_000).toFixed(1))} میلیارد`;
  if (n >= 1_000_000) return `${fa((n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1))} میلیون`;
  if (n >= 1000) return `${fa(Math.round(n / 1000))} هزار`;
  return faNum(n);
}

/* -------------------------- تاریخ جلالی -------------------------- */

export interface PersianDate {
  jy: number;
  jm: number;
  jd: number;
}

export function todayJalali(): PersianDate {
  const now = new Date();
  return toJalaali(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

/** ISO (YYYY-MM-DD) → تاریخ جلالی — بدون دردسر تایم‌زون */
export function isoToJalali(iso: string): PersianDate {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return toJalaali(y, m, d);
}

/** تاریخ جلالی → ISO (YYYY-MM-DD) */
export function jalaliToISO(j: PersianDate): string {
  const g = toGregorian(j.jy, j.jm, j.jd);
  const mm = String(g.gm).padStart(2, "0");
  const dd = String(g.gd).padStart(2, "0");
  return `${g.gy}-${mm}-${dd}`;
}

export function todayISO(): string {
  return jalaliToISO(todayJalali());
}

/** «۱۲ مرداد ۱۴۰۴» */
export function formatJalali(j: PersianDate): string {
  return `${fa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]} ${fa(j.jy)}`;
}

export function formatJalaliISO(iso: string): string {
  return formatJalali(isoToJalali(iso));
}

/** «۱۲ مرداد» */
export function formatJalaliShort(j: PersianDate): string {
  return `${fa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]}`;
}

/** «۱۴۰۴/۰۵/۱۲» — عددی فشرده برای خانه‌های گرید ۲×۲ */
export function formatJalaliNumericISO(iso: string): string {
  const j = isoToJalali(iso);
  return `${fa(j.jy)}/${fa(String(j.jm).padStart(2, "0"))}/${fa(String(j.jd).padStart(2, "0"))}`;
}

/** «مرداد ۱۴۰۴» */
export function formatJalaliMonth(jy: number, jm: number): string {
  return `${PERSIAN_MONTHS[jm - 1]} ${fa(jy)}`;
}

/** روز هفته از ISO */
export function weekdayFromISO(iso: string): string {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  const g = new Date(Date.UTC(y, m - 1, d));
  return PERSIAN_WEEKDAYS[g.getUTCDay()];
}

/** فاصله روز تا امروز (مثبت = آینده) */
export function daysUntilISO(iso: string): number {
  const today = todayJalali();
  const todayJdn = jalaliDayNumber(today.jy, today.jm, today.jd);
  const target = isoToJalali(iso);
  const targetJdn = jalaliDayNumber(target.jy, target.jm, target.jd);
  return targetJdn - todayJdn;
}

/** ISO همین امروز منهای n روز */
export function isoDaysAgo(n: number): string {
  const t = todayJalali();
  const j = fromJalaliDayNumber(jalaliDayNumber(t.jy, t.jm, t.jd) - n);
  return jalaliToISO(j);
}

/** n ماه بعد (تقریبی) */
export function isoMonthsLater(n: number): string {
  const t = todayJalali();
  let total = t.jy * 12 + (t.jm - 1) + n;
  const jy = Math.floor(total / 12);
  const jm = total % 12 + 1;
  const ml = jalaaliMonthLength(jy, jm);
  return jalaliToISO({ jy, jm, jd: Math.min(t.jd, ml) });
}

/** نزدیک‌ترین ماه جلالی را از رشته iso به شماره ماه مطلق تبدیل می‌کند (jy*12+jm) */
export function jalaliMonthIndex(iso: string): number {
  const j = isoToJalali(iso);
  return j.jy * 12 + j.jm;
}

/** «۳ روز پیش» / «۴ روز دیگر» / «امروز» */
export function relativeDays(days: number): string {
  if (days === 0) return "امروز";
  if (days === 1) return "فردا";
  if (days === -1) return "دیروز";
  if (days > 1) return `${fa(days)} روز دیگر`;
  return `${fa(-days)} روز پیش`;
}
