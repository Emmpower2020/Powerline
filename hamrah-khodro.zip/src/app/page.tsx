"use client";

/**
 * همراه خودرو — اپ موبایل مدیریت سرویس خودرو
 * صفحه اصلی: تب‌ها + شیت‌های فرم + ناوبری پایین
 * برنامه همیشه با تب‌ها بالا می‌آید؛ اگر خودرویی نباشد، هر تب راهنمای افزودن دارد.
 * سینک ابری: بعد از هر تغییر داده، اگر حساب گوگل متصل باشد آپلود خودکار واقعی به
 * Google Drive (پوشهٔ اختصاصی برنامه) انجام می‌شود — از طریق پل جاوای CloudBridge.
 * نوتیفیکیشن: یادآورهای نزدیک با هر بارگذاری داده و هر ۵ دقیقه بررسی می‌شوند.
 */

import * as React from "react";
import { Bell, BellRing, Loader2 } from "lucide-react";
import { BottomNav, type TabKey } from "@/components/app/BottomNav";
import { TabSwipe, type TabSwipeHandle } from "@/components/app/TabSwipe";
import { AppErrorBoundary } from "@/components/app/AppErrorBoundary";
import { OnboardingOverlay, isOnboarded } from "@/components/app/OnboardingOverlay";
import { RecordsTab } from "@/components/app/RecordsTab";
import { RemindersTab } from "@/components/app/RemindersTab";
import { ReportsTab } from "@/components/app/ReportsTab";
import { SettingsTab, type SettingsWindowKey } from "@/components/app/SettingsTab";
import { AddMenuSheet, type AddTarget } from "@/components/app/AddMenuSheet";
import { RecordFormSheet } from "@/components/app/RecordFormSheet";
import { ReminderFormSheet } from "@/components/app/ReminderFormSheet";
import { VehicleFormSheet } from "@/components/app/VehicleFormSheet";
import { ExitGuard } from "@/components/app/ExitGuard";
import { ConfirmDialogProvider } from "@/components/app/ConfirmDialog";
import { BusyIndicator } from "@/components/app/BusyIndicator";
import { BottomSheet } from "@/components/app/BottomSheet";
import { SubmitButton } from "@/components/app/fields";
import { computeReminderStatus, type ReminderThresholds } from "@/components/app/shared";
import {
  DEFAULT_NOTIFY_SETTINGS,
  checkAndNotify,
  loadNotifySettings,
  notificationPermission,
  requestNotificationPermission,
  thresholdsFromSettings,
  type NotificationSettings,
} from "@/lib/notifications";
import { useToast } from "@/hooks/use-toast";
import { fa } from "@/lib/persian";
import { autoResumeAuthFlow, queueAutoSync } from "@/lib/cloud-sync";
import { autoResumeFbAuthFlow, queueFirebaseAutoSync } from "@/lib/firebase-sync";
import {
  APP_NAME,
  type BrandItem,
  type RecordItem,
  type RecordType,
  type ReminderItem,
  type ServiceTypeItem,
  type VehicleItem,
  type VehicleStats,
} from "@/lib/types";

const ACTIVE_VEHICLE_KEY = "hamrah-khodro-active-vehicle";
/** آخرین باری که کاربر «بعداً» گفت — هر ۷ روز یک بار دوباره می‌پرسیم */
const NOTIF_ASK_KEY = "hamrah-khodro-notif-ask";

/** ⭐ v3.8.7: ترتیب فیزیکی تب‌ها در نوار پایین (RTL: reports راست‌ترین، settings چپ‌ترین).
 *  سوایپ «دنبال‌کنندهٔ انگشت»: کشیدن به راست → تب فیزیکی چپ (idx+1) با خود انگشت
 *  داخل می‌شود؛ کشیدن به چپ → تب فیزیکی راست (idx-1) — پنل‌ها زیر انگشت حرکت می‌کنند */
const TAB_ORDER: TabKey[] = ["reports", "records", "reminders", "settings"];

export default function Page() {
  const { toast } = useToast();
  const [tab, setTab] = React.useState<TabKey>("records");
  const [loading, setLoading] = React.useState(true);

  // درخواست مجوز اعلان — بعد از بالا آمدن برنامه (اگر هنوز مجوز گرفته نشده باشد)
  const [notifAskOpen, setNotifAskOpen] = React.useState(false);
  const [notifAsking, setNotifAsking] = React.useState(false);

  // داده‌ها
  const [vehicles, setVehicles] = React.useState<VehicleItem[]>([]);
  const [records, setRecords] = React.useState<RecordItem[]>([]);
  const [reminders, setReminders] = React.useState<ReminderItem[]>([]);
  const [stats, setStats] = React.useState<VehicleStats[]>([]);
  const [brands, setBrands] = React.useState<BrandItem[]>([]);
  const [serviceTypes, setServiceTypes] = React.useState<ServiceTypeItem[]>([]);
  const [activeVehicleId, setActiveVehicleId] = React.useState<string | null>(null);

  // شیت‌ها
  const [addMenuOpen, setAddMenuOpen] = React.useState(false);
  const [recordForm, setRecordForm] = React.useState<{
    mode: RecordType;
    initial: RecordItem | null;
  } | null>(null);
  const [reminderForm, setReminderForm] = React.useState<{ initial: ReminderItem | null } | null>(null);
  const [vehicleForm, setVehicleForm] = React.useState<{
    initial: VehicleItem | null;
    fromOnboarding: boolean;
  } | null>(null);

  // باز شدن خودکار زیرمنوی تنظیمات (مثلاً «خودروهای من» از حالت خالی)
  const [settingsAutoOpen, setSettingsAutoOpen] = React.useState<SettingsWindowKey>(null);

  // ⭐ v3.9.0: آموزش اولیه — بار اولِ بدون-خودرو؛ قابل رد کردن
  const [onboardingOpen, setOnboardingOpen] = React.useState(false);

  // تنظیمات نوتیفیکیشن — آستانهٔ «نزدیک» یادآورها
  const [notifySettings, setNotifySettings] = React.useState<NotificationSettings>(DEFAULT_NOTIFY_SETTINGS);

  /* --------------------------- بارگذاری داده --------------------------- */

  const refresh = React.useCallback(async () => {
    try {
      const [vRes, rRes, remRes, sRes, bRes, stRes] = await Promise.all([
        fetch("/api/vehicles"),
        fetch("/api/records"),
        fetch("/api/reminders"),
        fetch("/api/stats"),
        fetch("/api/brands"),
        fetch("/api/service-types"),
      ]);
      const [vData, rData, remData, sData, bData, stData] = await Promise.all([
        vRes.json(),
        rRes.json(),
        remRes.json(),
        sRes.json(),
        bRes.json(),
        stRes.json(),
      ]);
      if (vRes.ok) setVehicles(vData.vehicles ?? []);
      if (rRes.ok) setRecords(rData.records ?? []);
      if (remRes.ok) setReminders(remData.reminders ?? []);
      if (sRes.ok) setStats(sData.stats ?? []);
      if (bRes.ok) setBrands(bData.brands ?? []);
      if (stRes.ok) setServiceTypes(stData.serviceTypes ?? []);
    } catch (e) {
      console.error("refresh error", e);
    } finally {
      setLoading(false);
    }
  }, []);

  /** بارگذاری + سینک خودکار ابری — واقعی: اگر حساب (سرور Firebase یا Google) متصل و
   *  سینک خودکار روشن باشد، بعد از چند ثانیه اسنپ‌شات ذخیره می‌شود. هر دو مسیر صف
   *  می‌شوند و هر کدام که حساب فعال داشته باشد بی‌صدا کار می‌کند.
   *  خطا هرگز دادهٔ محلی را دست نمی‌زند. */
  const refreshAndSync = React.useCallback(async () => {
    await refresh();
    queueFirebaseAutoSync();
    queueAutoSync();
  }, [refresh]);

  React.useEffect(() => {
    // بازیابی خودروی فعال
    try {
      const saved = localStorage.getItem(ACTIVE_VEHICLE_KEY);
      if (saved) setActiveVehicleId(saved);
    } catch {
      /* ignore */
    }
    setNotifySettings(loadNotifySettings());
    refresh();
    // ⭐ v3.9.0: آموزش اولیه — فقط بار اول و وقتی هنوز خودرویی نیست
    try {
      if (!isOnboarded()) {
        const t = setTimeout(() => setOnboardingOpen(true), 700);
        return () => {
          clearTimeout(t);
          // ادامهٔ خودکار جریان اتصال نیمه‌تمام گوگل — در همین مسیر هم اجرا شود
          autoResumeAuthFlow((email) => {
            toast({ title: "به حساب گوگل وصل شد ✓", description: email });
            queueAutoSync();
          });
          autoResumeFbAuthFlow((email) => {
            toast({ title: "به حساب سرور پشتیبان وصل شد ✓", description: email });
            queueFirebaseAutoSync();
          });
        };
      }
    } catch {
      /* ignore */
    }
    // ادامهٔ خودکار جریان اتصال نیمه‌تمام گوگل (اگر کاربر از مرورگر برگشته و برنامه
    // در این بین باز/بسته شده باشد، اتصال همین‌جا بی‌صدا کامل می‌شود)
    autoResumeAuthFlow((email) => {
      toast({ title: "به حساب گوگل وصل شد ✓", description: email });
      queueAutoSync();
    });
    // ⭐ v3.9.3: ادامهٔ خودکار اتصال نیمه‌تمام فایربیس (بازگشت از مرورگر گوگل)
    autoResumeFbAuthFlow((email) => {
      toast({ title: "به حساب سرور پشتیبان وصل شد ✓", description: email });
      queueFirebaseAutoSync();
    });
  }, [refresh]);

  // بازیابی پشتیبان در APK — پل جاوا بعد از جایگزینی داده‌ها این رویداد را می‌فرستد
  React.useEffect(() => {
    const onRestored = () => {
      void refreshAndSync();
    };
    window.addEventListener("hk-restored", onRestored);
    return () => window.removeEventListener("hk-restored", onRestored);
  }, [refreshAndSync]);

  // خطای سینک خودکار ابری — یک توست اطلاع‌رسانی (اولین خطا بعد از موفقیت)
  React.useEffect(() => {
    const onSyncFailed = (e: Event) => {
      const message = (e as CustomEvent<{ message?: string }>).detail?.message;
      toast({
        title: "همگام‌سازی ابری ناموفق",
        description: message ?? "اتصال اینترنت را بررسی کنید — داده‌های محلی سالم است",
        variant: "destructive",
      });
    };
    window.addEventListener("hk-cloud-sync-failed", onSyncFailed);
    return () => window.removeEventListener("hk-cloud-sync-failed", onSyncFailed);
  }, [toast]);

  /* ------------- درخواست مجوز اعلان — یک بار بعد از بالا آمدن برنامه ------------- */
  React.useEffect(() => {
    if (loading) return;
    let lastAsked = 0;
    try {
      lastAsked = Number(localStorage.getItem(NOTIF_ASK_KEY) ?? "0") || 0;
    } catch {
      /* ignore */
    }
    const week = 7 * 24 * 60 * 60 * 1000;
    const perm = notificationPermission();
    if (perm === "default" && Date.now() - lastAsked > week) {
      const t = setTimeout(() => {
        setNotifAskOpen(true);
        // در APK، دیالوگ واقعی سیستم اندروید بی‌درنگ پرسیده می‌شود (مثل زمان نصب) —
        // کاربر با سیستم خود اندروید تأیید می‌کند، نه با فرم داخل برنامه
        try {
          const bridge = (globalThis as unknown as { AndroidApi?: { requestNotifPermission?: () => void } }).AndroidApi;
          if (typeof bridge?.requestNotifPermission === "function") {
            void enableNotifications();
          }
        } catch {
          /* ignore */
        }
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [loading]);

  /** فعال‌سازی اعلان — درخواست واقعی مجوز از سیستم/مرورگر + اطلاع فوری یادآورهای نزدیک */
  const enableNotifications = async () => {
    setNotifAsking(true);
    try {
      const p = await requestNotificationPermission();
      if (p === "granted") {
        toast({
          title: "اعلان‌ها فعال شد ✓",
          description: "یادآورهای نزدیک روی گوشی اطلاع داده می‌شوند",
        });
        // حالا که مجوز آمد، یادآورهای نزدیکِ فعلی فوراً با نوتیفیکیشن سیستم اطلاع شوند
        try {
          checkAndNotify(reminders, currentKmByVehicle, vehicleNames, notifySettings);
        } catch {
          /* ignore */
        }
      } else if (p === "denied") {
        toast({
          title: "مجوز اعلان رد شد",
          description: "از تنظیمات گوشی/مرورگر می‌توانید فعالش کنید",
          variant: "destructive",
        });
      } else {
        toast({ title: "مجوز اعلان داده نشد", description: "بعداً دوباره می‌پرسیم" });
      }
    } finally {
      setNotifAsking(false);
      setNotifAskOpen(false);
      try {
        localStorage.setItem(NOTIF_ASK_KEY, String(Date.now()));
      } catch {
        /* ignore */
      }
    }
  };

  // اگر خودروی فعال معتبر نیست، اولین خودرو
  React.useEffect(() => {
    if (vehicles.length > 0) {
      if (!activeVehicleId || !vehicles.some((v) => v.id === activeVehicleId)) {
        setActiveVehicleId(vehicles[0].id);
      }
    }
  }, [vehicles, activeVehicleId]);

  const changeActiveVehicle = React.useCallback((id: string) => {
    setActiveVehicleId(id);
    try {
      localStorage.setItem(ACTIVE_VEHICLE_KEY, id);
    } catch {
      /* ignore */
    }
  }, []);

  // با برگشتن از تنظیمات، تنظیمات نوتیفیکیشن دوباره خوانده می‌شود (ممکن است عوض شده باشد)
  React.useEffect(() => {
    if (tab === "records") setNotifySettings(loadNotifySettings());
  }, [tab]);

  /* --------------------------- محاسبات کمکی --------------------------- */

  const currentKmByVehicle = React.useMemo(() => {
    const m = new Map<string, number>();
    for (const v of vehicles) {
      m.set(v.id, v.mileage);
    }
    for (const r of records) {
      if (r.mileage !== null) {
        const cur = m.get(r.vehicleId) ?? 0;
        if (r.mileage > cur) m.set(r.vehicleId, r.mileage);
      }
    }
    return m;
  }, [vehicles, records]);

  const notifyThresholds: ReminderThresholds = React.useMemo(
    () => thresholdsFromSettings(notifySettings),
    [notifySettings]
  );

  const remindersBadge = React.useMemo(() => {
    let count = 0;
    for (const r of reminders) {
      if (r.done) continue;
      const st = computeReminderStatus(r, currentKmByVehicle.get(r.vehicleId) ?? 0, notifyThresholds);
      if (st.status === "overdue" || st.status === "soon") count++;
    }
    return count;
  }, [reminders, currentKmByVehicle, notifyThresholds]);

  const vehicleNames = React.useMemo(() => {
    const m = new Map<string, string>();
    vehicles.forEach((v) => m.set(v.id, v.name));
    return m;
  }, [vehicles]);

  /* ------------- نوتیفیکیشن یادآورهای نزدیک — با هر تغییر داده + هر ۵ دقیقه ------------- */

  React.useEffect(() => {
    if (loading) return;
    const run = () => {
      try {
        const { fired } = checkAndNotify(reminders, currentKmByVehicle, vehicleNames, notifySettings);
        if (fired.length > 0) {
          toast({
            title:
              fired.length > 1
                ? `🔔 ${fa(fired.length)} یادآور نزدیک شد`
                : `🔔 یادآور نزدیک: ${fired[0].reminder.title}`,
            description: fired
              .map((f) => `${f.reminder.title} — ${f.label}`)
              .join(" • ")
              .slice(0, 140),
          });
        }
      } catch {
        /* ignore */
      }
    };
    run();
    const iv = setInterval(run, 5 * 60 * 1000);
    return () => clearInterval(iv);
  }, [reminders, currentKmByVehicle, vehicleNames, notifySettings, loading, toast]);

  /* --------------------------- اکشن‌های مشترک --------------------------- */

  /* ⭐ v3.8.9: جابه‌جایی تب‌ها از طریق کاروسل — سوایپ دنبال‌کننده + انیمیشن نرم تپ
   * + «حافظهٔ اسکرول هر تب»: قبلاً با تعویض تب، اسکرول صفحه به‌جای قبلی می‌ماند و چون
   *   ارتفاع محتوای تب‌ها فرق دارد، مرورگر اسکرول را می‌بُرید/می‌پراند («صفحه می‌پره»).
   *   حالا موقعیت اسکرول تبِ ترک‌شده ذخیره و تبِ مقصد در همان جای قبلی خودش (اولین بار:
   *   بالای صفحه) ظاهر می‌شود. */
  const swipeHandle = React.useRef<TabSwipeHandle>(null);
  const tabScrollMemory = React.useRef<Map<TabKey, number>>(new Map());
  const commitTab = React.useCallback(
    (next: TabKey) => {
      setTab((prev) => {
        if (prev !== next) {
          try {
            tabScrollMemory.current.set(prev, window.scrollY);
          } catch {
            /* ignore */
          }
        }
        return next;
      });
      // بعد از رندر پنل جدید (دو rAF)، اسکرول به جایگاه ذخیرهٔ همان تب برمی‌گردد
      requestAnimationFrame(() =>
        requestAnimationFrame(() => {
          try {
            const target = tabScrollMemory.current.get(next);
            window.scrollTo(0, target ?? 0);
          } catch {
            /* ignore */
          }
        })
      );
    },
    []
  );
  const changeTab = React.useCallback(
    (next: TabKey) => {
      if (swipeHandle.current) swipeHandle.current.goTo(next);
      else commitTab(next);
    },
    [commitTab]
  );

  const openAddVehicle = React.useCallback(
    (fromOnboarding = false) => setVehicleForm({ initial: null, fromOnboarding }),
    []
  );
  // رفتن به تنظیمات + باز شدن مستقیم پنجرهٔ «خودروهای من»
  const goSettings = React.useCallback(() => {
    changeTab("settings");
    setSettingsAutoOpen("vehicles");
  }, [changeTab]);

  // رفتن به تب یادآورها (از بنر «یادآورهای نزدیک» صفحهٔ اصلی)
  const goReminders = React.useCallback(() => changeTab("reminders"), [changeTab]);

  /* ------------------------------ رندر ------------------------------ */

  return (
    <AppErrorBoundary>
      <div dir="rtl" className="min-h-dvh bg-[var(--app-shell)]">
        {/* دیالوگ تأیید درون‌برنامه‌ای — همیشه فعال (جایگزین confirm بومی) */}
        <ConfirmDialogProvider />
        {/* ⭐ v3.8.5: نشانگر انتظار سراسری — کپسول/پردهٔ «در حال انجام کار» برای همگام‌سازی و بازیابی ابری */}
        <BusyIndicator />
        {/* خروج با دوبار برگشت — محافظ تاریخچه */}
        <ExitGuard />
        {/* ⭐ v3.9.0: آموزش اولیه — سوایپ/ثبت خودرو/سینک؛ قابل رد کردن */}
        <OnboardingOverlay
          open={onboardingOpen}
          onClose={() => setOnboardingOpen(false)}
          onAddVehicle={() => openAddVehicle(true)}
        />
        <div className="relative mx-auto min-h-dvh max-w-md bg-background shadow-2xl">
          {loading ? (
            <LoadingScreen />
          ) : (
            <>
              {/* محتوای تب‌ها — ⭐ v3.8.7: کاروسل سوایپ دنبال‌کنندهٔ انگشت + انیمیشن نرم بین تب‌ها */}
              <main className="pb-2">
                <TabSwipe
                  order={TAB_ORDER}
                  active={tab}
                  onCommit={commitTab}
                  handleRef={swipeHandle}
                renderPanel={(t) => {
                  if (t === "records") {
                    return (
                      <RecordsTab
                        records={records}
                        vehicles={vehicles}
                        reminders={reminders}
                        currentKmByVehicle={currentKmByVehicle}
                        notifyThresholds={notifyThresholds}
                        onOpenRecord={(r) => setRecordForm({ mode: r.type, initial: r })}
                        onRefresh={refreshAndSync}
                        onAddVehicle={() => openAddVehicle(true)}
                        onGoSettings={goSettings}
                        onGoReminders={goReminders}
                      />
                    );
                  }
                  if (t === "reminders") {
                    return (
                      <RemindersTab
                        reminders={reminders}
                        vehicles={vehicles}
                        currentKmByVehicle={currentKmByVehicle}
                        notifyThresholds={notifyThresholds}
                        onRefresh={refreshAndSync}
                        onEdit={(r) => setReminderForm({ initial: r })}
                        onAdd={() => setReminderForm({ initial: null })}
                        onAddVehicle={() => openAddVehicle(true)}
                        onGoSettings={goSettings}
                      />
                    );
                  }
                  if (t === "reports") {
                    return (
                      <ReportsTab
                        stats={stats}
                        vehicleNames={vehicleNames}
                        records={records}
                        onAddVehicle={() => openAddVehicle(true)}
                        onGoSettings={goSettings}
                      />
                    );
                  }
                  return (
                    <SettingsTab
                      vehicles={vehicles}
                      records={records}
                      reminders={reminders}
                      currentKmByVehicle={currentKmByVehicle}
                      brands={brands}
                      serviceTypes={serviceTypes}
                      activeVehicleId={activeVehicleId}
                      onSetActive={changeActiveVehicle}
                      onAddVehicle={() => openAddVehicle(false)}
                      onEditVehicle={(v) => setVehicleForm({ initial: v, fromOnboarding: false })}
                      onDeleteVehicle={() => {
                        void refreshAndSync();
                        if (activeVehicleId) {
                          const next = vehicles.find((x) => x.id !== activeVehicleId);
                          if (next) changeActiveVehicle(next.id);
                          else setActiveVehicleId(null);
                        }
                      }}
                      onRefresh={refreshAndSync}
                      autoOpen={settingsAutoOpen}
                      onClearAutoOpen={() => setSettingsAutoOpen(null)}
                    />
                  );
                }}
              />
            </main>

            {/* ناوبری پایین — فوتر چسبان */}
            <BottomNav
              active={tab}
              onChange={changeTab}
              remindersBadge={remindersBadge}
              onAdd={() => setAddMenuOpen(true)}
            />

            {/* شیت‌ها */}
            <AddMenuSheet
              open={addMenuOpen}
              onClose={() => setAddMenuOpen(false)}
              onSelect={(target) => {
                if (target === "REMINDER") {
                  setReminderForm({ initial: null });
                } else {
                  setRecordForm({ mode: target, initial: null });
                }
              }}
            />

            <RecordFormSheet
              open={recordForm !== null}
              mode={recordForm?.mode ?? "SERVICE"}
              initial={recordForm?.initial ?? null}
              vehicles={vehicles}
              serviceTypes={serviceTypes}
              defaultVehicleId={activeVehicleId}
              currentKm={
                activeVehicleId ? (currentKmByVehicle.get(activeVehicleId) ?? 0) : 0
              }
              onClose={() => setRecordForm(null)}
              onSaved={refreshAndSync}
            />

            <ReminderFormSheet
              open={reminderForm !== null}
              initial={reminderForm?.initial ?? null}
              vehicles={vehicles}
              defaultVehicleId={activeVehicleId}
              currentKm={
                activeVehicleId ? (currentKmByVehicle.get(activeVehicleId) ?? 0) : 0
              }
              onClose={() => setReminderForm(null)}
              onSaved={refreshAndSync}
            />

            <VehicleFormSheet
              open={vehicleForm !== null}
              initial={vehicleForm?.initial ?? null}
              brands={brands}
              onClose={() => setVehicleForm(null)}
              onSaved={(v) => {
                void refreshAndSync();
                if (vehicleForm?.fromOnboarding || !activeVehicleId) {
                  changeActiveVehicle(v.id);
                }
              }}
              onRefreshBrands={refreshAndSync}
            />

            {/* درخواست مجوز اعلان — تا نوتیفیکیشن یادآورها کار کند */}
            <BottomSheet
              open={notifAskOpen}
              onClose={() => {
                setNotifAskOpen(false);
                try {
                  localStorage.setItem(NOTIF_ASK_KEY, String(Date.now()));
                } catch {
                  /* ignore */
                }
              }}
              title="اجازهٔ اعلان یادآورها"
              subtitle="برای اطلاع‌رسانی روی گوشی"
            >
              <div className="mb-4 flex flex-col items-center rounded-2xl border border-border/80 bg-card p-5 text-center">
                <span className="flex size-16 items-center justify-center rounded-full bg-primary/10">
                  <span className="flex size-11 items-center justify-center rounded-full bg-primary/15">
                    <BellRing className="size-6 text-primary" strokeWidth={2} />
                  </span>
                </span>
                <p className="mt-3 text-[14.5px] font-bold text-foreground">
                  همراه خودرو می‌خواهد اعلان نمایش دهد
                </p>
                <p className="mt-2 max-w-[300px] text-[13px] leading-6 text-muted-foreground">
                  وقتی تاریخ یا کارکرد یادآوری نزدیک شود، روی گوشی شما اطلاع داده می‌شود. برای فعال شدن،
                  اجازهٔ نمایش اعلان را بدهید.
                </p>
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
                  <Bell className="size-3.5" />
                  از «تنظیمات ← تنظیمات نوتیفیکیشن» هم همیشه قابل تغییر است
                </p>
              </div>
              <div className="flex flex-col gap-2 pb-2">
                <SubmitButton onClick={enableNotifications} disabled={notifAsking}>
                  <BellRing className="size-5" />
                  {notifAsking ? "در حال درخواست مجوز…" : "اجازهٔ نمایش اعلان"}
                </SubmitButton>
                <button
                  type="button"
                  onClick={() => {
                    setNotifAskOpen(false);
                    try {
                      localStorage.setItem(NOTIF_ASK_KEY, String(Date.now()));
                    } catch {
                      /* ignore */
                    }
                  }}
                  disabled={notifAsking}
                  className="flex h-12 w-full items-center justify-center rounded-xl bg-muted text-[15px] font-bold text-foreground transition-all active:scale-[.98] disabled:opacity-50"
                >
                  بعداً
                </button>
              </div>
            </BottomSheet>
          </>
        )}
        </div>
      </div>
    </AppErrorBoundary>
  );
}

/* ------------------------------ اسکلتون ------------------------------ */

function LoadingScreen() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4">
      <div className="flex size-20 items-center justify-center rounded-3xl bg-primary/12">
        <Loader2 className="size-10 animate-spin text-primary" />
      </div>
      <p className="text-[15px] font-bold text-muted-foreground">{APP_NAME} در حال بارگذاری...</p>
    </div>
  );
}
