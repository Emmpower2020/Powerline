import type { Metadata, Viewport } from "next";
import "@fontsource-variable/vazirmatn"; // فونت فارسی مدرن وزیرمتن (متغیر ۱۰۰–۹۰۰)
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { APP_NAME } from "@/lib/types";


export const metadata: Metadata = {
  title: `${APP_NAME} — مدیریت سرویس و سوخت خودرو`,
  description:
    "اپ مدیریت خودرو: ثبت سرویس، سوخت، کارکرد و یادآور با گزارش‌های کامل — آفلاین و فارسی.",
  keywords: ["مدیریت خودرو", "سرویس", "سوخت", "یادآور", "همراه خودرو"],
  icons: {
    icon: "/logo.svg",
  },
  /* ⭐ v3.8.7: تأیید مالکیت دامنه در Google Search Console — برای انتشار عمومی
     (Publish App) لازم است. در Vercel متغیر محیطی NEXT_PUBLIC_GSC_VERIFICATION را
     با مقدار «content» تگ تأیید کنسول پر کنید (راهنما: docs/publish-guide.md). */
  ...(process.env.NEXT_PUBLIC_GSC_VERIFICATION
    ? { verification: { google: process.env.NEXT_PUBLIC_GSC_VERIFICATION } }
    : {}),
};

export const viewport: Viewport = {
  themeColor: "#F4F6F7",
};

/** اعمال تم ذخیره‌شده قبل از رندر تا پرش رنگ نداشته باشیم — ۹ تم پیش‌فرض + تم‌های شخصی (تزریق پویای متغیرها) */
const THEME_INIT = `(function(){try{var t=localStorage.getItem("hamrah-khodro-theme");var css=localStorage.getItem("hamrah-khodro-theme-vars");var dk=localStorage.getItem("hamrah-khodro-theme-dark");if(css){var s=document.createElement("style");s.id="hk-dynamic-theme";s.textContent=css;document.head.appendChild(s);}var L=["paper","emerald","rosewater","turquoise","saffron"];var M=["deepteal","graphite"];var D=["midnight","forest"];var all=L.concat(M,D);if(!t||all.indexOf(t)<0&&String(t).indexOf("custom-")!==0){t="paper";}document.documentElement.setAttribute("data-theme",t);var dark=dk==="1"||(dk===null&&(M.indexOf(t)>=0||D.indexOf(t)>=0));if(dark){document.documentElement.classList.add("dark");}}catch(e){}})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className="antialiased bg-background text-foreground"
      >
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
        {children}
        <Toaster />
      </body>
    </html>
  );
}
