import { promises as fs } from "fs";
import path from "path";
import { fa } from "@/lib/persian";

/**
 * GET /api/files — فهرست همهٔ فایل‌های قابل دانلود پروژه
 * «کادر همهٔ فایل‌های پروژه» — طبق مادهٔ ۴-۴ کتاب قانون (لینک در چت + دکمه در سایت + فایل در public)
 *
 * سیاست نسخه‌های APK (مادهٔ بستهٔ ششم):
 *  - نام‌گذاری بر حسب نسخه: hamrah-khodro-v{MAJOR.MINOR.PATCH}.apk
 *  - فقط ۳ نسخهٔ آخر نگه‌داری و نمایش داده می‌شود (بقیه حذف می‌شوند)
 */

export const dynamic = "force-dynamic";

type FileKind = "APK" | "ZIP" | "JSON" | "IMAGE" | "DOC";

interface DownloadFile {
  name: string;
  path: string;
  size: number;
  label: string;
  desc: string;
  kind: FileKind;
  order: number;
  live: boolean;
}

/** تعداد نسخه‌های APK که نگه‌داری می‌شوند */
const APK_KEEP = 3;

/** استخراج شمارهٔ نسخه از نام فایل APK نسخه‌دار */
function parseApkVersion(name: string): number[] | null {
  const m = /^hamrah-khodro-v(\d+)\.(\d+)\.(\d+)\.apk$/.exec(name);
  if (!m) return null;
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}

/** مقایسهٔ دو نسخهٔ عددی */
function cmpVersion(a: number[], b: number[]): number {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return 0;
}

/** توضیح ویژگی‌های شاخص هر نسخه — برای نسخه‌های آینده به این جدول اضافه کنید */
const VERSION_NOTES: Record<string, string> = {
  "3.4.0":
    "رفع باگ «هنگ کردن» دکمهٔ حذف: دیالوگ تأیید بازنویسی شد و حالا همیشه روی همهٔ لایه‌ها (شیت‌ها و پنجره‌های تنظیمات) دیده می‌شود — قبلاً پشت شیت گم می‌شد و برنامه بی‌جواب می‌ماند؛ حذف نوع سرویس (داخل ویرایشگر و روی ردیف فهرست)، حذف رکورد، یادآور، خودرو و برند همه اصلاح شدند؛ با زدن روی کارت سوابق دیگر فرم ویرایش باز نمی‌شود — ویرایش فقط با دکمهٔ «ویرایش»",
  "3.3.0":
    "فرم‌های «افزودن خودرو» و «یادآور جدید» با همان چینش ثبت سرویس (گرید ۲×۲ فشرده) بازطراحی شدند؛ همهٔ کادرهای فرم خودرو کشویی شدند — برند، مدل، سال، رنگ، سوخت، گیربکس و وضعیت — و اگر گزینه‌ای موجود نبود همان‌جا قابل افزودن است؛ ثبت سوخت: رفع باگ کادر لیتر (اعداد اعشاری حالا درست تایپ می‌شوند) + فیلد جدید «قیمت هر لیتر» با محاسبهٔ خودکار هزینهٔ کل (و برعکس)؛ «تعویض روغن موتور» به‌صورت پیش‌فرض خدماتی است (یک قیمت + مکمل‌ها)، نه تعویض قطعه",
  "3.2.0":
    "پایداری راه‌اندازی: مهار خطاهای غیرمنتظره (CrashGuard) — اگر مشکلی پیش بیاید پیام فارسی می‌بینید و جزئیات در last-crash.txt ذخیره می‌شود؛ انتخاب عکس خودرو (کوچک‌سازی خودکار + ذخیره در پروفایل خودرو + نمایش روی کارت) با پشتیبانی کامل گالری اندروید؛ پلاک با ۴ خانهٔ کاملاً مستقل (تایپ در هر خانه بقیه را به‌هم نمی‌زند) و حروف با نام کامل (الف به‌جای ا) + فهرست ۶ آیتمی قابل پیمایش؛ رفع جستجوی برند و مدل (نرمال‌سازی ی/ک عربی + باز شدن خودکار برندِ منطبق)؛ حذف فیلدهای اضافی برند/مدل دستی؛ سال ساخت بدون جداکننده هزارگان؛ انتخاب نوع سرویس فقط با نام سرویس + «افزودن سرویس جدید» در انتهای فهرست",
  "3.1.0":
    "بهبود تجربهٔ فرم‌ها: حذف دکمهٔ حذف از فرم‌های ویرایش (حذف فقط از دکمهٔ روی کارت‌ها)، پلاک خودرو با طرح واقعی پلاک ایران (بدنهٔ سفید + نوار آبی ایران + پرش خودکار بین خانه‌ها)، خانهٔ «نوع سرویس» با حالت اول «نوع سرویس» و نمایش کامل نام سرویس انتخاب‌شده",
  "3.0.0":
    "بازسازی کامل موتور برنامه: رفع خطای «کارکرد معتبر نیست» در ثبت همهٔ رکوردها، فعال‌سازی واقعی حذف و ویرایش (دیالوگ تأیید داخلی + پشتیبانی اندروید)، پشتیبان‌گیری در پوشهٔ Download گوشی با یک دکمه، بازیابی از فایل پشتیبان، دیتابیس محلی روی حافظهٔ گوشی با ذخیرهٔ اتمی — بدون هیچ دادهٔ تستی، شروع تمیز",
  "2.9.0":
    "همان v2.8.0 با نام نسخهٔ جدید — گرید ۲×۲ و ویرایش/حذف همهٔ بخش‌ها؛ برای نصب از روی نسخهٔ قدیمی ابتدا برنامهٔ قبلی را حذف کنید (امضای بسته عوض شده) و سپس این نسخه را نصب کنید",
  "2.8.0":
    "فرم ثبت سرویس با گرید ۲×۲ (خودرو/تاریخ/کارکرد/نوع سرویس در کادرهای فشرده)، ۳ نوع یادآور سرویس بعدی (کارکرد/تاریخ/هر دو)، مکمل فقط فیلتر هوا و فیلتر روغن + افزودن مورد دلخواه، دکمهٔ ویرایش و حذف روی همهٔ کارت‌های سوابق",
  "2.7.0":
    "عنوان فیلدها بیرون کادر سمت راست و کادر کوچک‌تر (دو سوم عرض)، حذف سرویس‌های پیش‌فرض با دکمهٔ حذف کنار ویرایش، تعویض روغن با ۳ مکمل ثابت (فیلتر هوا، فیلتر روغن، تنظیم باد)",
}

const FILES_META: Record<string, { label: string; desc: string; kind: FileKind; order: number }> = {
  "hamrah-khodro-original.apk": {
    label: "APK مرجع پیوست‌شده",
    desc: "نسخهٔ اصلی که کاربر ارسال کرده بود — برای مقایسه",
    kind: "APK",
    order: 5,
  },
};

function inferKind(name: string): FileKind {
  const lower = name.toLowerCase();
  if (lower.endsWith(".apk")) return "APK";
  if (lower.endsWith(".zip")) return "ZIP";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")) return "IMAGE";
  if (lower.endsWith(".json")) return "JSON";
  return "DOC";
}

export async function GET() {
  try {
    const dir = path.join(process.cwd(), "public", "files");
    let names: string[] = [];
    try {
      names = await fs.readdir(dir);
    } catch {
      names = [];
    }

    /* ---- سیاست نگه‌داشت: فقط ۳ نسخهٔ آخر APK روی دیسک بماند ---- */
    const versioned = names
      .map((n) => ({ name: n, v: parseApkVersion(n) }))
      .filter((x): x is { name: string; v: number[] } => x.v !== null)
      .sort((a, b) => cmpVersion(b.v, a.v));

    const keep = new Set(versioned.slice(0, APK_KEEP).map((x) => x.name));
    for (const old of versioned.slice(APK_KEEP)) {
      try {
        await fs.rm(path.join(dir, old.name), { force: true });
      } catch {
        /* حذف نشد — مهم نیست */
      }
    }
    names = names.filter((n) => !parseApkVersion(n) || keep.has(n));

    const files: DownloadFile[] = await Promise.all(
      names
        .filter((n) => !n.startsWith("."))
        .map(async (name) => {
          const st = await fs.stat(path.join(dir, name));
          const meta = FILES_META[name];
          return {
            name,
            path: `/files/${name}`,
            size: st.size,
            label: meta?.label ?? name,
            desc: meta?.desc ?? "",
            kind: meta?.kind ?? inferKind(name),
            order: meta?.order ?? 50,
            live: false,
          };
        })
    );

    /* ---- برچسب فارسی نسخه‌های APK — جدیدترین اول، سپس قدیمی‌ترها ---- */
    const versionedFiles = files
      .map((f) => ({ f, v: parseApkVersion(f.name) }))
      .filter((x): x is { f: DownloadFile; v: number[] } => x.v !== null)
      .sort((a, b) => cmpVersion(b.v, a.v));
    versionedFiles.forEach(({ f, v }, i) => {
      const vs = v.join(".");
      f.label = `برنامهٔ اندروید همراه خودرو — نسخهٔ v${vs}`;
      f.desc =
        VERSION_NOTES[vs] ??
        `نسخهٔ v${vs} — جزو ${fa(APK_KEEP)} نسخهٔ آخر نگه‌داری‌شده`;
      f.kind = "APK";
      f.order = i + 1;
    });

    // برچسب فارسی برای زیپ پشتیبان و تصاویر (شمارهٔ نسخه در نام فایل تغییر می‌کند)
    for (const f of files) {
      if (f.name.endsWith("-backup.zip")) {
        f.label = "بستهٔ پشتیبان کامل پروژه";
        f.desc = "سورس کامل + دیتابیس + کتاب قانون — برای انتقال به ایجنت دیگر";
        f.kind = "ZIP";
        f.order = 4;
      } else if (f.name.startsWith("screenshot-")) {
        const n = f.name.replace("screenshot-", "").replace(/\D/g, "");
        f.label = `تصویر مرجع ${fa(n || "؟")}`;
        f.desc = "اسکرین‌شات برنامهٔ مرجع پیوست‌شده";
        f.kind = "IMAGE";
        f.order = 40;
      }
    }

    // اندازهٔ کتاب قانون در مسیر عمومی
    let instructionsSize = 0;
    try {
      const st = await fs.stat(path.join(process.cwd(), "public", "INSTRUCTIONS.md"));
      instructionsSize = st.size;
    } catch {
      /* بدون فایل */
    }

    // موارد مجازی: خروجی زندهٔ داده‌ها + کتاب قانون
    files.push({
      name: "hamrah-khodro-data.json",
      path: "/api/backup",
      size: 0,
      label: "خروجی زندهٔ داده‌ها (JSON)",
      desc: "همهٔ داده‌های برنامه — همیشه به‌روز با نام یکتای زمانی تهران",
      kind: "JSON",
      order: 6,
      live: true,
    });

    files.push({
      name: "INSTRUCTIONS.md",
      path: "/INSTRUCTIONS.md",
      size: instructionsSize,
      label: "کتاب قانون پروژه",
      desc: "دستورالعمل رسمی و قوانین کاربر — همیشه در دسترس",
      kind: "DOC",
      order: 7,
      live: false,
    });

    files.sort((a, b) => a.order - b.order);

    return Response.json({ files });
  } catch {
    return Response.json({ files: [] });
  }
}
