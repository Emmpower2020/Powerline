import { db } from "@/lib/db";
import {
  badRequest,
  complementaryToJson,
  parseISOMidnight,
  serverError,
  toFloatOrNull,
  toIntOrNull,
  toStrOrNull,
} from "@/lib/api-helpers";

/**
 * POST /api/restore — بازیابی داده‌ها از فایل پشتیبان JSON
 * بدنه: همان ساختار خروجی /api/backup (vehicles, records, reminders, brands?, serviceTypes?)
 * همهٔ داده‌های فعلی کاربر جایگزین می‌شود؛ اگر برند/نوع سرویس در فایل بود، آنها هم جایگزین می‌شوند.
 */

export const dynamic = "force-dynamic";

type Loose = Record<string, unknown>;

const VEHICLE_TYPES = {
  yearType: ["JALALI", "GREGORIAN"],
  fuelType: ["GASOLINE", "DIESEL", "HYBRID", "ELECTRIC", "CNG"],
  transmission: ["MANUAL", "AUTOMATIC"],
  status: ["ACTIVE", "IN_REPAIR", "SOLD"],
} as const;

const RECORD_TYPES = ["SERVICE", "FUEL", "ODOMETER", "NOTE"];

function pickStr(o: Loose, k: string, fallback: string): string {
  const v = o[k];
  return typeof v === "string" && v.trim() !== "" ? v : fallback;
}

function dtOrNull(v: unknown): Date | null {
  if (typeof v !== "string" || v.trim() === "") return null;
  const d = v.length === 10 ? parseISOMidnight(v) : new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export async function POST(req: Request) {
  let payload: Loose;
  try {
    payload = (await req.json()) as Loose;
  } catch {
    return badRequest("فایل پشتیبان معتبر نیست (JSON نامعتبر)");
  }

  const vehiclesIn = Array.isArray(payload.vehicles) ? (payload.vehicles as Loose[]) : null;
  const recordsIn = Array.isArray(payload.records) ? (payload.records as Loose[]) : null;
  const remindersIn = Array.isArray(payload.reminders) ? (payload.reminders as Loose[]) : null;

  if (!vehiclesIn || !recordsIn || !remindersIn) {
    return badRequest("فایل پشتیبان معتبر نیست — خودروها، سوابق یا یادآورها یافت نشد");
  }
  if (vehiclesIn.length === 0 && (recordsIn.length > 0 || remindersIn.length > 0)) {
    return badRequest("سوابقی بدون خودرو در فایل است — فایل پشتیبان معتبر نیست");
  }

  try {
    // اعتبارسنجی پیش از جایگزینی — همه یا هیچ
    const vehicleIds = new Set(
      vehiclesIn
        .map((v) => (typeof v.id === "string" && v.id.trim() !== "" ? v.id : null))
        .filter(Boolean) as string[]
    );
    if (vehicleIds.size !== vehiclesIn.length) {
      return badRequest("برخی خودروها شناسهٔ معتبر ندارند");
    }
    for (const v of vehiclesIn) {
      if (typeof v.model !== "string" || v.model.trim() === "") {
        return badRequest("مدل همهٔ خودروها باید مشخص باشد");
      }
    }
    for (const r of recordsIn) {
      if (!RECORD_TYPES.includes(String(r.type))) return badRequest("نوع رکورد نامعتبر در فایل");
      if (!vehicleIds.has(String(r.vehicleId))) return badRequest("رکورد بدون خودروی معتبر در فایل");
      if (typeof r.date !== "string" || !/^\d{4}-\d{2}-\d{2}/.test(r.date)) {
        return badRequest("تاریخ رکورد نامعتبر در فایل");
      }
    }
    for (const r of remindersIn) {
      if (typeof r.title !== "string" || r.title.trim() === "") {
        return badRequest("عنوان یادآور نامعتبر در فایل");
      }
      if (!vehicleIds.has(String(r.vehicleId))) return badRequest("یادآور بدون خودروی معتبر در فایل");
    }

    const brandsIn = Array.isArray(payload.brands) ? (payload.brands as Loose[]) : null;
    const typesIn = Array.isArray(payload.serviceTypes) ? (payload.serviceTypes as Loose[]) : null;

    const result = await db.$transaction(async (tx) => {
      // پاک‌سازی کامل داده‌های فعلی کاربر
      await tx.record.deleteMany();
      await tx.reminder.deleteMany();
      await tx.vehicle.deleteMany();

      // خودروها
      for (const v of vehiclesIn) {
        await tx.vehicle.create({
          data: {
            id: String(v.id),
            brand: pickStr(v, "brand", "سایر"),
            model: String(v.model),
            year: toIntOrNull(v.year),
            yearType: VEHICLE_TYPES.yearType.includes(String(v.yearType) as "JALALI")
              ? String(v.yearType)
              : "JALALI",
            plate: toStrOrNull(v.plate),
            vin: toStrOrNull(v.vin),
            color: toStrOrNull(v.color),
            imageData: toStrOrNull(v.imageData),
            fuelType: VEHICLE_TYPES.fuelType.includes(String(v.fuelType) as "GASOLINE")
              ? String(v.fuelType)
              : "GASOLINE",
            transmission: VEHICLE_TYPES.transmission.includes(String(v.transmission) as "MANUAL")
              ? String(v.transmission)
              : "MANUAL",
            status: VEHICLE_TYPES.status.includes(String(v.status) as "ACTIVE")
              ? String(v.status)
              : "ACTIVE",
            mileage: toIntOrNull(v.mileage) ?? 0,
            purchasePrice: toIntOrNull(v.purchasePrice),
            purchaseDate: dtOrNull(v.purchaseDate),
            notes: toStrOrNull(v.notes),
            isDefault: Boolean(v.isDefault),
            createdAt: dtOrNull(v.createdAt) ?? new Date(),
          },
        });
      }

      // سوابق
      for (const r of recordsIn) {
        await tx.record.create({
          data: {
            id: String(r.id ?? ""),
            type: String(r.type),
            vehicleId: String(r.vehicleId),
            date: parseISOMidnight(String(r.date).slice(0, 10)),
            mileage: toIntOrNull(r.mileage),
            cost: toIntOrNull(r.cost),
            title: toStrOrNull(r.title),
            costMode: r.costMode === "SEPARATE" ? "SEPARATE" : r.costMode === "TOTAL" ? "TOTAL" : null,
            partsCost: toIntOrNull(r.partsCost),
            laborCost: toIntOrNull(r.laborCost),
            hasOilFilter: Boolean(r.hasOilFilter),
            oilFilterCost: toIntOrNull(r.oilFilterCost),
            hasAirFilter: Boolean(r.hasAirFilter),
            airFilterCost: toIntOrNull(r.airFilterCost),
            complementary: complementaryToJson(r.complementary),
            provider: toStrOrNull(r.provider),
            description: toStrOrNull(r.description),
            nextDueDate: dtOrNull(r.nextDueDate),
            nextDueKm: toIntOrNull(r.nextDueKm),
            liters: toFloatOrNull(r.liters),
            pricePerLiter: toIntOrNull(r.pricePerLiter),
            fullTank: r.fullTank === undefined ? true : Boolean(r.fullTank),
            prevRegistered: r.prevRegistered === undefined ? true : Boolean(r.prevRegistered),
            consumption: toFloatOrNull(r.consumption),
            station: toStrOrNull(r.station),
            noteTitle: toStrOrNull(r.noteTitle),
            noteBody: toStrOrNull(r.noteBody),
            createdAt: dtOrNull(r.createdAt) ?? new Date(),
          },
        });
      }

      // یادآورها
      for (const r of remindersIn) {
        await tx.reminder.create({
          data: {
            id: String(r.id ?? ""),
            vehicleId: String(r.vehicleId),
            title: String(r.title),
            kind: r.kind === "KM" ? "KM" : "DATE",
            dueDate: dtOrNull(r.dueDate),
            dueKm: toIntOrNull(r.dueKm),
            repeatKind: ["NONE", "MONTHLY", "YEARLY", "KM"].includes(String(r.repeatKind))
              ? String(r.repeatKind)
              : "NONE",
            repeatEveryKm: toIntOrNull(r.repeatEveryKm),
            status: ["ACTIVE", "PENDING", "DONE", "OVERDUE"].includes(String(r.status))
              ? String(r.status)
              : "ACTIVE",
            notes: toStrOrNull(r.notes),
            linkedRecordId: toStrOrNull(r.linkedRecordId),
            done: Boolean(r.done),
            doneAt: dtOrNull(r.doneAt),
            createdAt: dtOrNull(r.createdAt) ?? new Date(),
          },
        });
      }

      // برندها (اختیاری)
      if (brandsIn) {
        await tx.brandModel.deleteMany();
        for (const b of brandsIn) {
          const models = Array.isArray(b.models) ? b.models.filter((m): m is string => typeof m === "string") : [];
          if (typeof b.name !== "string" || b.name.trim() === "") continue;
          await tx.brandModel.create({
            data: {
              id: String(b.id ?? ""),
              name: b.name,
              models: JSON.stringify(models),
              isCustom: Boolean(b.isCustom),
              createdAt: dtOrNull(b.createdAt) ?? new Date(),
            },
          });
        }
      }

      // انواع سرویس (اختیاری)
      if (typesIn) {
        await tx.serviceType.deleteMany();
        for (const t of typesIn) {
          if (typeof t.label !== "string" || t.label.trim() === "") continue;
          await tx.serviceType.create({
            data: {
              id: String(t.id ?? ""),
              label: t.label,
              value: pickStr(t, "value", t.label),
              order: toIntOrNull(t.order) ?? 0,
              isDefault: t.isDefault === undefined ? false : Boolean(t.isDefault),
              separateCost: Boolean(t.separateCost),
              kind: t.kind === "PART" ? "PART" : "SERVICE",
              complementary: complementaryToJson(t.complementary) ?? "[]",
              createdAt: dtOrNull(t.createdAt) ?? new Date(),
            },
          });
        }
      }

      return {
        vehicles: vehiclesIn.length,
        records: recordsIn.length,
        reminders: remindersIn.length,
        brands: brandsIn?.length ?? 0,
        serviceTypes: typesIn?.length ?? 0,
      };
    });

    return Response.json({ ok: true, ...result });
  } catch (e) {
    return serverError(e);
  }
}
