import { db } from "@/lib/db";
import { recalcConsumption } from "@/lib/consumption";
import {
  serializeRecord,
  parseISOMidnight,
  isValidISODate,
  toIntOrNull,
  toFloatOrNull,
  toStrOrNull,
  complementaryToJson,
  badRequest,
  serverError,
} from "@/lib/api-helpers";


export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.record.findUnique({ where: { id } });
    if (!existing) return badRequest("رکورد یافت نشد", 404);

    const data: Record<string, unknown> = {};

    if (body?.date !== undefined) {
      if (!isValidISODate(body.date)) return badRequest("تاریخ نامعتبر است");
      data.date = parseISOMidnight(body.date);
    }
    if (body?.vehicleId !== undefined) {
      const vehicleId = String(body.vehicleId);
      const vehicle = await db.vehicle.findUnique({ where: { id: vehicleId } });
      if (!vehicle) return badRequest("خودرو یافت نشد", 404);
      data.vehicleId = vehicleId;
    }
    if (body?.mileage !== undefined) {
      const v = toIntOrNull(body.mileage);
      if (v !== null && (v < 0 || v > 10_000_000)) return badRequest("کارکرد معتبر نیست");
      data.mileage = v;
    }
    if (body?.cost !== undefined) {
      const v = toIntOrNull(body.cost);
      if (v !== null && (v < 0 || v > 1_000_000_000_000)) return badRequest("مبلغ معتبر نیست");
      data.cost = v;
    }
    if (body?.title !== undefined) data.title = toStrOrNull(body.title);
    if (body?.costMode !== undefined) data.costMode = toStrOrNull(body.costMode);
    if (body?.partsCost !== undefined) data.partsCost = toIntOrNull(body.partsCost);
    if (body?.laborCost !== undefined) data.laborCost = toIntOrNull(body.laborCost);
    if (body?.hasOilFilter !== undefined) data.hasOilFilter = Boolean(body.hasOilFilter);
    if (body?.oilFilterCost !== undefined) data.oilFilterCost = toIntOrNull(body.oilFilterCost);
    if (body?.hasAirFilter !== undefined) data.hasAirFilter = Boolean(body.hasAirFilter);
    if (body?.airFilterCost !== undefined) data.airFilterCost = toIntOrNull(body.airFilterCost);
    if (body?.complementary !== undefined) {
      data.complementary = existing.type === "SERVICE" ? complementaryToJson(body.complementary) : null;
    }
    if (body?.provider !== undefined) data.provider = toStrOrNull(body.provider);
    if (body?.description !== undefined) data.description = toStrOrNull(body.description);
    if (body?.nextDueDate !== undefined) {
      data.nextDueDate =
        body.nextDueDate && isValidISODate(body.nextDueDate)
          ? parseISOMidnight(body.nextDueDate)
          : null;
    }
    if (body?.nextDueKm !== undefined) data.nextDueKm = toIntOrNull(body.nextDueKm);
    if (body?.liters !== undefined) {
      const v = toFloatOrNull(body.liters);
      if (v !== null && (v <= 0 || v > 500)) return badRequest("مقدار سوخت معتبر نیست");
      data.liters = v;
    }
    if (body?.fullTank !== undefined) data.fullTank = Boolean(body.fullTank);
    if (body?.prevRegistered !== undefined) data.prevRegistered = Boolean(body.prevRegistered);
    if (body?.station !== undefined) data.station = toStrOrNull(body.station);
    if (body?.noteTitle !== undefined) data.noteTitle = toStrOrNull(body.noteTitle);
    if (body?.noteBody !== undefined) data.noteBody = toStrOrNull(body.noteBody);
    if (body?.pricePerLiter !== undefined) data.pricePerLiter = toIntOrNull(body.pricePerLiter);

    // بازمحاسبه قیمت لیتر در فرم سوخت
    if (existing.type === "FUEL" && (body?.cost !== undefined || body?.liters !== undefined)) {
      const liters = (body?.liters !== undefined ? toFloatOrNull(body.liters) : existing.liters) ?? null;
      const cost = (body?.cost !== undefined ? toIntOrNull(body.cost) : existing.cost) ?? null;
      if (liters && liters > 0 && cost) {
        data.pricePerLiter = Math.round(cost / liters);
      }
    }

    const record = await db.record.update({ where: { id }, data });

    if (record.type === "FUEL") {
      await recalcConsumption(record.vehicleId);
    }

    // به‌روزرسانی کارکرد خودرو
    if (record.mileage) {
      const vehicle = await db.vehicle.findUnique({ where: { id: record.vehicleId } });
      if (vehicle && record.mileage > vehicle.mileage) {
        await db.vehicle.update({ where: { id: vehicle.id }, data: { mileage: record.mileage } });
      }
    }

    const fresh = await db.record.findUnique({ where: { id: record.id } });
    return Response.json(serializeRecord(fresh ?? record));
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.record.findUnique({ where: { id } });
    if (!existing) return badRequest("رکورد یافت نشد", 404);

    await db.record.delete({ where: { id } });
    // یادآورهای متصل را هم حذف کن
    await db.reminder.deleteMany({ where: { linkedRecordId: id } });

    if (existing.type === "FUEL") {
      await recalcConsumption(existing.vehicleId);
    }

    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
