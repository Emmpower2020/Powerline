import { db } from "@/lib/db";
import { recalcConsumption } from "@/lib/consumption";
import {
  serializeRecord,
  parseISOMidnight,
  isValidISODate,
  toIntOrNull,
  toFloatOrNull,
  toStrOrNull,
  complementaryToJson,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

const RECORD_TYPES = new Set(["SERVICE", "FUEL", "ODOMETER", "NOTE"]);
const COST_MODES = new Set(["TOTAL", "SEPARATE"]);


export async function GET() {
  try {
    const records = await db.record.findMany({
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    });
    return Response.json({
      records: records.map(serializeRecord),
    });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const type = String(body?.type ?? "");
    if (!RECORD_TYPES.has(type)) return badRequest("نوع رکورد نامعتبر است");

    const vehicleId = String(body?.vehicleId ?? "");
    if (!vehicleId) return badRequest("انتخاب خودرو الزامی است");
    const vehicle = await db.vehicle.findUnique({ where: { id: vehicleId } });
    if (!vehicle) return badRequest("خودرو یافت نشد", 404);

    if (!isValidISODate(body?.date)) return badRequest("تاریخ نامعتبر است");

    const mileage = toIntOrNull(body?.mileage);
    if (mileage !== null && (mileage < 0 || mileage > 10_000_000)) {
      return badRequest("کارکرد معتبر نیست");
    }

    const cost = toIntOrNull(body?.cost);
    if (cost !== null && (cost < 0 || cost > 1_000_000_000_000)) {
      return badRequest("مبلغ معتبر نیست");
    }

    const liters = toFloatOrNull(body?.liters);
    if (liters !== null && (liters <= 0 || liters > 500)) {
      return badRequest("مقدار سوخت معتبر نیست");
    }

    // اعتبارسنجی بر اساس نوع
    if (type === "SERVICE" && !toStrOrNull(body?.title)) {
      return badRequest("نوع سرویس را انتخاب کنید");
    }
    if (type === "FUEL" && liters === null) {
      return badRequest("مقدار سوخت را وارد کنید");
    }
    if (type === "ODOMETER" && mileage === null) {
      return badRequest("کارکرد را وارد کنید");
    }
    if (type === "NOTE" && !toStrOrNull(body?.noteBody)) {
      return badRequest("متن یادداشت را وارد کنید");
    }

    const costMode = body?.costMode !== undefined ? String(body.costMode) : null;
    if (costMode && !COST_MODES.has(costMode)) return badRequest("حالت هزینه نامعتبر است");

    let nextDueDate: Date | null = null;
    if (body?.nextDueDate && isValidISODate(body.nextDueDate)) {
      nextDueDate = parseISOMidnight(body.nextDueDate);
    }
    let purchaseDateUnused = null;
    void purchaseDateUnused;

    let pricePerLiter = toIntOrNull(body?.pricePerLiter);
    if (type === "FUEL" && liters && liters > 0 && cost) {
      pricePerLiter = Math.round(cost / liters);
    }

    const record = await db.record.create({
      data: {
        type,
        vehicleId,
        date: parseISOMidnight(body.date),
        mileage,
        cost,
        title: toStrOrNull(body?.title),
        costMode,
        partsCost: toIntOrNull(body?.partsCost),
        laborCost: toIntOrNull(body?.laborCost),
        hasOilFilter: type === "SERVICE" ? Boolean(body?.hasOilFilter) : false,
        oilFilterCost: toIntOrNull(body?.oilFilterCost),
        hasAirFilter: type === "SERVICE" ? Boolean(body?.hasAirFilter) : false,
        airFilterCost: toIntOrNull(body?.airFilterCost),
        complementary: type === "SERVICE" ? complementaryToJson(body?.complementary) : null,
        provider: toStrOrNull(body?.provider),
        description: toStrOrNull(body?.description),
        nextDueDate,
        nextDueKm: toIntOrNull(body?.nextDueKm),
        liters,
        pricePerLiter,
        fullTank: type === "FUEL" ? Boolean(body?.fullTank ?? true) : true,
        prevRegistered: type === "FUEL" ? Boolean(body?.prevRegistered ?? true) : true,
        consumption: null,
        station: toStrOrNull(body?.station),
        noteTitle: toStrOrNull(body?.noteTitle),
        noteBody: toStrOrNull(body?.noteBody),
      },
    });

    // به‌روزرسانی کارکرد خودرو
    if (mileage && mileage > vehicle.mileage) {
      await db.vehicle.update({ where: { id: vehicleId }, data: { mileage } });
    }

    // محاسبه مصرف سوخت
    if (type === "FUEL") {
      await recalcConsumption(vehicleId);
    }

    // یادآور سرویس بعدی (تاریخ یا کارکرد)
    if (type === "SERVICE" && (nextDueDate || body?.nextDueKm)) {
      const nextKm = toIntOrNull(body?.nextDueKm);
      const hasReminder = toStrOrNull(body?.nextDueTitle);
      if (nextDueDate || nextKm) {
        await db.reminder.create({
          data: {
            vehicleId,
            title: hasReminder ?? `سرویس بعدی: ${toStrOrNull(body?.title) ?? ""}`,
            kind: nextDueDate ? "DATE" : "KM",
            dueDate: nextDueDate,
            dueKm: nextKm,
            repeatKind: "NONE",
            status: "ACTIVE",
            linkedRecordId: record.id,
            notes: null,
          },
        }).catch(() => null);
      }
    }

    const fresh = await db.record.findUnique({ where: { id: record.id } });
    return Response.json(serializeRecord(fresh ?? record), { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
