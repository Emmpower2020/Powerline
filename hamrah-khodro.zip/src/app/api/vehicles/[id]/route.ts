import { db } from "@/lib/db";
import {
  serializeVehicle,
  toIntOrNull,
  toStrOrNull,
  isValidISODate,
  parseISOMidnight,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

const FUEL_TYPES = new Set(["GASOLINE", "DIESEL", "HYBRID", "ELECTRIC", "CNG"]);
const TRANSMISSIONS = new Set(["MANUAL", "AUTOMATIC"]);
const STATUSES = new Set(["ACTIVE", "IN_REPAIR", "SOLD"]);

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.vehicle.findUnique({ where: { id } });
    if (!existing) return badRequest("خودرو یافت نشد", 404);

    const data: Record<string, unknown> = {};
    if (body?.brand !== undefined) data.brand = toStrOrNull(body.brand) ?? "سایر";
    if (body?.model !== undefined) {
      const model = toStrOrNull(body.model);
      if (!model) return badRequest("مدل خودرو را وارد کنید");
      data.model = model;
    }
    if (body?.year !== undefined) {
      const year = toIntOrNull(body.year);
      if (year !== null && (year < 1300 || year > 2100)) return badRequest("سال ساخت معتبر نیست");
      data.year = year;
    }
    if (body?.yearType !== undefined) data.yearType = String(body.yearType) === "GREGORIAN" ? "GREGORIAN" : "JALALI";
    if (body?.plate !== undefined) data.plate = toStrOrNull(body.plate);
    if (body?.vin !== undefined) data.vin = toStrOrNull(body.vin);
    if (body?.color !== undefined) data.color = toStrOrNull(body.color);
    if (body?.imageData !== undefined) {
      const imageData = toStrOrNull(body.imageData);
      if (imageData && imageData.length > 3_000_000) return badRequest("عکس خیلی بزرگ است");
      data.imageData = imageData;
    }
    if (body?.fuelType !== undefined) {
      if (!FUEL_TYPES.has(String(body.fuelType))) return badRequest("نوع سوخت نامعتبر است");
      data.fuelType = String(body.fuelType);
    }
    if (body?.transmission !== undefined) {
      if (!TRANSMISSIONS.has(String(body.transmission))) return badRequest("نوع گیربکس نامعتبر است");
      data.transmission = String(body.transmission);
    }
    if (body?.status !== undefined) {
      if (!STATUSES.has(String(body.status))) return badRequest("وضعیت خودرو نامعتبر است");
      data.status = String(body.status);
    }
    if (body?.mileage !== undefined) {
      const km = toIntOrNull(body.mileage);
      if (km === null || km < 0 || km > 10_000_000) return badRequest("کارکرد معتبر نیست");
      data.mileage = km;
    }
    if (body?.purchasePrice !== undefined) data.purchasePrice = toIntOrNull(body.purchasePrice);
    if (body?.purchaseDate !== undefined) {
      data.purchaseDate = body.purchaseDate && isValidISODate(body.purchaseDate)
        ? parseISOMidnight(body.purchaseDate)
        : null;
    }
    if (body?.notes !== undefined) data.notes = toStrOrNull(body.notes);
    if (body?.isDefault === true) {
      // پیش‌فرض کردن: بقیه غیرفعال
      await db.vehicle.updateMany({ data: { isDefault: false } });
      data.isDefault = true;
    }

    const vehicle = await db.vehicle.update({ where: { id }, data });
    return Response.json(serializeVehicle(vehicle));
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.vehicle.findUnique({ where: { id } });
    if (!existing) return badRequest("خودرو یافت نشد", 404);

    await db.vehicle.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
