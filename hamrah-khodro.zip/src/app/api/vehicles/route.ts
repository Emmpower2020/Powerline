import { db } from "@/lib/db";
import {
  serializeVehicle,
  toIntOrNull,
  toStrOrNull,
  isValidISODate,
  parseISOMidnight,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

const FUEL_TYPES = new Set(["GASOLINE", "DIESEL", "HYBRID", "ELECTRIC", "CNG"]);
const TRANSMISSIONS = new Set(["MANUAL", "AUTOMATIC"]);
const STATUSES = new Set(["ACTIVE", "IN_REPAIR", "SOLD"]);

export async function GET() {
  try {
    const vehicles = await db.vehicle.findMany({
      orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
    });
    return Response.json({ vehicles: vehicles.map(serializeVehicle) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const model = toStrOrNull(body?.model);
    if (!model) return badRequest("مدل خودرو را وارد کنید");

    const brand = toStrOrNull(body?.brand) ?? "سایر";
    const year = toIntOrNull(body?.year);
    if (year !== null && (year < 1300 || year > 2100)) {
      return badRequest("سال ساخت معتبر نیست");
    }

    const mileage = toIntOrNull(body?.mileage);
    if (mileage !== null && (mileage < 0 || mileage > 10_000_000)) {
      return badRequest("کارکرد معتبر نیست");
    }

    const fuelType = String(body?.fuelType ?? "GASOLINE");
    if (!FUEL_TYPES.has(fuelType)) return badRequest("نوع سوخت نامعتبر است");

    const transmission = String(body?.transmission ?? "MANUAL");
    if (!TRANSMISSIONS.has(transmission)) return badRequest("نوع گیربکس نامعتبر است");

    const status = String(body?.status ?? "ACTIVE");
    if (!STATUSES.has(status)) return badRequest("وضعیت خودرو نامعتبر است");

    let purchaseDate: Date | null = null;
    if (body?.purchaseDate) {
      if (!isValidISODate(body.purchaseDate)) return badRequest("تاریخ خرید نامعتبر است");
      purchaseDate = parseISOMidnight(body.purchaseDate);
    }

    const imageData = toStrOrNull(body?.imageData);
    if (imageData && imageData.length > 3_000_000) {
      return badRequest("عکس خیلی بزرگ است");
    }

    // اگر اولین خودرو است، پیش‌فرض شود
    const count = await db.vehicle.count();

    const vehicle = await db.vehicle.create({
      data: {
        brand,
        model,
        year,
        yearType: String(body?.yearType ?? "JALALI"),
        plate: toStrOrNull(body?.plate),
        vin: toStrOrNull(body?.vin),
        color: toStrOrNull(body?.color),
        imageData,
        fuelType,
        transmission,
        status,
        mileage: mileage ?? 0,
        purchasePrice: toIntOrNull(body?.purchasePrice),
        purchaseDate,
        notes: toStrOrNull(body?.notes),
        isDefault: count === 0,
      },
    });
    return Response.json(serializeVehicle(vehicle), { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
