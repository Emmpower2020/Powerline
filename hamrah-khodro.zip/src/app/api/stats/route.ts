import { db } from "@/lib/db";
import { serverError } from "@/lib/api-helpers";
import {
  type PersianDate,
  PERSIAN_MONTHS,
  fa,
  isoToJalali,
  jalaliMonthIndex,
  todayJalali,
  jalaaliMonthLength,
  jalaliToISO,
} from "@/lib/persian";

/**
 * آمار هر خودرو:
 * - کارکرد فعلی، هزینه‌ها، تعداد سرویس/سوخت
 * - مصرف سوخت (روش باک‌پر به باک‌پر)
 * - سری ۶ ماه هزینه (سرویس/سوخت تفکیک‌شده)
 * - مقایسه با ماه قبل
 */

function buildMonthlySeries(
  records: { date: string; type: string; cost: number | null }[]
) {
  const today = todayJalali();
  const months: { label: string; monthIndex: number; service: number; fuel: number }[] = [];
  for (let k = 5; k >= 0; k--) {
    const total = today.jy * 12 + (today.jm - 1) - k;
    const jy = Math.floor(total / 12);
    const jm = (total % 12) + 1;
    months.push({
      label: `${PERSIAN_MONTHS[jm - 1]} ${fa(jy)}`,
      monthIndex: total,
      service: 0,
      fuel: 0,
    });
  }
  const map = new Map(months.map((m) => [m.monthIndex, m]));
  for (const r of records) {
    const idx = jalaliMonthIndex(r.date);
    const m = map.get(idx);
    if (m && r.cost) {
      if (r.type === "SERVICE") m.service += r.cost;
      else if (r.type === "FUEL") m.fuel += r.cost;
    }
  }
  return months;
}

function buildConsumption(
  fuelRecords: { date: string; mileage: number | null; liters: number | null; fullTank: boolean; consumption: number | null }[]
) {
  const sorted = [...fuelRecords]
    .filter((f) => f.mileage !== null)
    .sort((a, b) => (a.mileage! - b.mileage!));

  const points: { label: string; value: number }[] = [];
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    const cur = sorted[i];
    if (!prev.fullTank || !cur.fullTank) continue;
    const distance = cur.mileage! - prev.mileage!;
    if (distance <= 0 || !cur.liters || cur.liters <= 0) continue;
    const value = (cur.liters / distance) * 100;
    if (value > 0 && value < 50) {
      const j = isoToJalali(cur.date);
      points.push({
        label: `${fa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]}`,
        value: Math.round(value * 10) / 10,
      });
    }
  }
  return points;
}

export async function GET() {
  try {
    const vehicles = await db.vehicle.findMany({ orderBy: { createdAt: "asc" } });
    const records = await db.record.findMany({
      orderBy: { date: "desc" },
    });

    const today = todayJalali();
    const currentMonthIndex = today.jy * 12 + today.jm;
    const monthStart: PersianDate = { jy: today.jy, jm: today.jm, jd: 1 };
    const monthStartISO = jalaliToISO(monthStart);
    // شروع ماه قبل
    let prevYear = today.jy;
    let prevMonth = today.jm - 1;
    if (prevMonth === 0) {
      prevMonth = 12;
      prevYear -= 1;
    }
    const prevMonthStart: PersianDate = { jy: prevYear, jm: prevMonth, jd: 1 };
    const prevMonthStartISO = jalaliToISO(prevMonthStart);

    const stats = vehicles.map((v) => {
      const vRecords = records
        .filter((r) => r.vehicleId === v.id)
        .map((r) => ({ ...r, date: r.date.toISOString().slice(0, 10) }));

      const services = vRecords.filter((r) => r.type === "SERVICE");
      const fuels = vRecords.filter((r) => r.type === "FUEL");

      const currentKm = Math.max(v.mileage, ...vRecords.map((r) => r.mileage ?? 0), 0);

      const totalCost = vRecords.reduce((s, r) => s + (r.cost ?? 0), 0);
      const monthCost = vRecords
        .filter((r) => r.date >= monthStartISO)
        .reduce((s, r) => s + (r.cost ?? 0), 0);
      const prevMonthCost = vRecords
        .filter((r) => r.date >= prevMonthStartISO && r.date < monthStartISO)
        .reduce((s, r) => s + (r.cost ?? 0), 0);

      const fuelTotalLiters = fuels.reduce((s, r) => s + (r.liters ?? 0), 0);
      const fuelTotalCost = fuels.reduce((s, r) => s + (r.cost ?? 0), 0);

      const consumptionPoints = buildConsumption(
        fuels.map((f) => ({
          date: f.date,
          mileage: f.mileage,
          liters: f.liters,
          fullTank: f.fullTank,
          consumption: f.consumption,
        }))
      );
      const avgConsumption =
        consumptionPoints.length > 0
          ? Math.round(
              (consumptionPoints.reduce((s, p) => s + p.value, 0) /
                consumptionPoints.length) *
                10
            ) / 10
          : null;

      const lastService = services
        .filter((s) => s.mileage !== null)
        .sort((a, b) => (b.mileage! - a.mileage!))[0];

      return {
        vehicleId: v.id,
        currentKm,
        totalCost,
        monthCost,
        prevMonthCost,
        serviceCount: services.length,
        fuelCount: fuels.length,
        fuelTotalLiters: Math.round(fuelTotalLiters * 10) / 10,
        fuelTotalCost,
        avgConsumption,
        lastServiceKm: lastService?.mileage ?? null,
        monthlyCosts: buildMonthlySeries(vRecords),
        consumptionPoints,
      };
    });

    const monthDays = jalaaliMonthLength(today.jy, today.jm);

    return Response.json({ stats, today: { monthIndex: currentMonthIndex, monthDays } });
  } catch (e) {
    return serverError(e);
  }
}
