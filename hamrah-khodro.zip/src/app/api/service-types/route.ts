import { db } from "@/lib/db";
import {
  serializeServiceType,
  toStrOrNull,
  complementaryNamesToJson,
  parseComplementaryNames,
  badRequest,
  serverError,
} from "@/lib/api-helpers";
import { SERVICE_TYPE_DEFAULTS } from "@/lib/types";

const KINDS = new Set(["SERVICE", "PART"]);

/** پرچم seed در جدول Meta — بعد از حذف انواع سرویس توسط کاربر، seed مجدد انجام نمی‌شود */
const SEED_FLAG = "serviceTypesSeeded";

/** مکمل‌های قدیمی/جدید پیش‌فرض «تعویض روغن موتور» (v2.7 → v2.8) */
const OIL_LABEL = "تعویض روغن موتور";
/** مکمل‌های پیش‌فرض قدیمی — اگر رکورد دقیقاً یکی از این‌ها باشد، مهاجرت اجرا می‌شود */
const OIL_OLD_COMPS: string[][] = [
  ["فیلتر روغن", "فیلتر هوا", "تنظیم باد", "واشر مهر روغن"], // v2.6 و قبل
  ["فیلتر هوا", "فیلتر روغن", "تنظیم باد"], // v2.7
];
/** مکمل‌های جدید v2.8 — فقط فیلتر هوا و فیلتر روغن مطابق موکاپ */
const OIL_NEW_COMP = ["فیلتر هوا", "فیلتر روغن"];

/** انواع فیلتر مستقل که از پیش‌فرض‌های v2.7 حذف شده‌اند */
const FILTER_LABELS = ["تعویض فیلتر روغن", "تعویض فیلتر هوا"];

async function ensureSeeded() {
  const flag = await db.meta.findUnique({ where: { key: SEED_FLAG } });
  if (flag) return;
  const count = await db.serviceType.count();
  if (count === 0) {
    for (let i = 0; i < SERVICE_TYPE_DEFAULTS.length; i++) {
      const t = SERVICE_TYPE_DEFAULTS[i];
      await db.serviceType.create({
        data: {
          label: t.label,
          value: t.label,
          order: i,
          isDefault: true,
          separateCost: t.kind === "PART",
          kind: t.kind,
          complementary: complementaryNamesToJson(t.complementary ?? []) ?? "[]",
        },
      });
    }
  }
  await db.meta.upsert({
    where: { key: SEED_FLAG },
    update: {},
    create: { key: SEED_FLAG, value: new Date().toISOString() },
  });
}

/**
 * مهاجرت یک‌بارهٔ پیش‌فرض‌ها برای دیتابیس‌های موجود (idempotent):
 *  - «تعویض روغن موتور» پیش‌فرض: نوع = خدماتی (v3.3 — قبلاً تعویض قطعه بود)
 *    و مکمل‌ها = فقط فیلتر هوا و فیلتر روغن (v2.8)
 *    (فقط وقتی مکمل‌ها هنوز پیش‌فرض قدیمیِ دست‌نخورده‌اند — ویرایش کاربر حفظ می‌شود)
 *  - حذف «تعویض فیلتر روغن» و «تعویض فیلتر هوا» از انواع پیش‌فرض
 *    (فقط رکوردهای دست‌نخوردهٔ بدون مکمل — نسخهٔ شخصی‌سازی‌شده حفظ می‌شود)
 */
async function migrateDefaults() {
  const oil = await db.serviceType.findFirst({ where: { label: OIL_LABEL, isDefault: true } });
  if (oil) {
    const comp = parseComplementaryNames(oil.complementary);
    const untouched = OIL_OLD_COMPS.some(
      (old) => comp.length === old.length && comp.every((n, i) => n === old[i])
    );
    if (untouched) {
      await db.serviceType.update({
        where: { id: oil.id },
        data: {
          complementary: JSON.stringify(OIL_NEW_COMP),
          // v3.3: حالت پیش‌فرض «تعویض روغن موتور» = خدماتی (یک قیمت + مکمل‌ها)
          kind: "SERVICE",
          separateCost: false,
        },
      });
    } else if (oil.kind === "PART") {
      // مکمل‌ها شخصی‌سازی شده اما نوع هنوز پیش‌فرض قدیمی است — فقط نوع اصلاح می‌شود
      await db.serviceType.update({
        where: { id: oil.id },
        data: { kind: "SERVICE", separateCost: false },
      });
    }
  }

  const filters = await db.serviceType.findMany({
    where: { label: { in: FILTER_LABELS }, isDefault: true },
  });
  for (const f of filters) {
    if (parseComplementaryNames(f.complementary).length === 0) {
      await db.serviceType.delete({ where: { id: f.id } });
    }
  }
}

export async function GET() {
  try {
    await ensureSeeded();
    await migrateDefaults();
    const types = await db.serviceType.findMany({
      orderBy: { order: "asc" },
    });
    return Response.json({ serviceTypes: types.map(serializeServiceType) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const label = toStrOrNull(body?.label);
    if (!label) return badRequest("نام نوع سرویس را وارد کنید");

    const kind = body?.kind === "PART" ? "PART" : "SERVICE";
    if (body?.kind !== undefined && !KINDS.has(String(body.kind))) {
      return badRequest("نوع سرویس نامعتبر است (خدماتی یا تعویض قطعه)");
    }

    const max = await db.serviceType.aggregate({ _max: { order: true } });
    const order = (max._max.order ?? 0) + 1;

    const type = await db.serviceType.create({
      data: {
        label,
        value: label,
        order,
        isDefault: false,
        separateCost: kind === "PART",
        kind,
        complementary: complementaryNamesToJson(body?.complementary) ?? "[]",
      },
    });
    return Response.json(serializeServiceType(type), { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}

export async function PATCH(req: Request) {
  // تغییر ترتیب گروهی
  try {
    const body = await req.json();
    const items = Array.isArray(body?.items) ? body.items : [];
    for (const it of items) {
      const id = String((it as Record<string, unknown>)?.id ?? "");
      const order = Number((it as Record<string, unknown>)?.order);
      if (id && Number.isFinite(order)) {
        await db.serviceType.update({ where: { id }, data: { order } });
      }
    }
    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
