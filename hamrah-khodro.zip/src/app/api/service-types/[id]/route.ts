import { db } from "@/lib/db";
import {
  serializeServiceType,
  toStrOrNull,
  complementaryNamesToJson,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

const KINDS = new Set(["SERVICE", "PART"]);

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.serviceType.findUnique({ where: { id } });
    if (!existing) return badRequest("نوع سرویس یافت نشد", 404);

    const data: Record<string, unknown> = {};
    if (body?.label !== undefined) {
      const label = toStrOrNull(body.label);
      if (!label) return badRequest("نام نوع سرویس را وارد کنید");
      data.label = label;
    }
    if (body?.kind !== undefined) {
      const kind = String(body.kind);
      if (!KINDS.has(kind)) return badRequest("نوع سرویس نامعتبر است (خدماتی یا تعویض قطعه)");
      data.kind = kind;
      data.separateCost = kind === "PART";
    }
    if (body?.complementary !== undefined) {
      data.complementary = complementaryNamesToJson(body.complementary) ?? "[]";
    }

    const type = await db.serviceType.update({ where: { id }, data });
    return Response.json(serializeServiceType(type));
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.serviceType.findUnique({ where: { id } });
    if (!existing) return badRequest("نوع سرویس یافت نشد", 404);

    await db.serviceType.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
