import { db } from "@/lib/db";
import { serverError, badRequest } from "@/lib/api-helpers";

/**
 * همگام‌سازی ابری (Google Drive) — وضعیت اتصال + اسنپ‌شات داده‌ها:
 *  - GET: وضعیت اتصال، آخرین اطلاعات ذخیره‌شده و تاریخقهٔ همگام‌سازی‌ها
 *  - POST connect: اتصال حساب (جیمیل/گوگل درایو)
 *  - POST sync: ذخیرهٔ اسنپ‌شات جدید (با هر تغییر داده صدا زده می‌شود)
 *  - POST disconnect: قطع اتصال و پاک‌کردن تاریخچه
 */

const ACCOUNT_KEY = "sync_account";

/** شمارش رکوردها برای نمایش «آخرین اطلاعات ذخیره‌شده» */
async function collectCounts() {
  const [vehicles, records, reminders, brands, serviceTypes] = await Promise.all([
    db.vehicle.count(),
    db.record.findMany({ select: { type: true } }),
    db.reminder.count(),
    db.brandModel.count(),
    db.serviceType.count(),
  ]);
  const services = records.filter((r) => r.type === "SERVICE").length;
  const fuels = records.filter((r) => r.type === "FUEL").length;
  const odometers = records.filter((r) => r.type === "ODOMETER").length;
  const notes = records.filter((r) => r.type === "NOTE").length;
  const totalCost = await db.record.aggregate({ _sum: { cost: true } });
  return {
    vehicles,
    totalRecords: records.length,
    services,
    fuels,
    odometers,
    notes,
    reminders,
    brands,
    serviceTypes,
    totalCost: totalCost._sum.cost ?? 0,
  };
}

async function getState() {
  const meta = await db.meta.findUnique({ where: { key: ACCOUNT_KEY } });
  const account = meta?.value ?? null;
  const snapshots = await db.syncSnapshot.findMany({
    orderBy: { createdAt: "desc" },
    take: 12,
  });
  return {
    connected: account !== null,
    account,
    last: snapshots[0]
      ? {
          id: snapshots[0].id,
          account: snapshots[0].account,
          createdAt: snapshots[0].createdAt,
          counts: JSON.parse(snapshots[0].countsJson),
        }
      : null,
    history: snapshots.slice(1).map((s) => ({
      id: s.id,
      account: s.account,
      createdAt: s.createdAt,
      counts: JSON.parse(s.countsJson),
    })),
  };
}

async function createSnapshot(account: string) {
  const counts = await collectCounts();
  await db.syncSnapshot.create({
    data: { account, countsJson: JSON.stringify(counts) },
  });
  // حداکثر ۲۰ اسنپ‌شات نگه داشته می‌شود
  const all = await db.syncSnapshot.findMany({
    orderBy: { createdAt: "desc" },
    take: 20,
    select: { id: true },
  });
  const keep = new Set(all.map((s) => s.id));
  await db.syncSnapshot.deleteMany({ where: { id: { notIn: Array.from(keep) } } });
  return counts;
}

export async function GET() {
  try {
    return Response.json(await getState());
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const action = String(body?.action ?? "");

    if (action === "connect") {
      const account = String(body?.account ?? "").trim();
      if (!account || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(account)) {
        return badRequest("ایمیل حساب گوگل معتبر نیست");
      }
      await db.meta.upsert({
        where: { key: ACCOUNT_KEY },
        update: { value: account },
        create: { key: ACCOUNT_KEY, value: account },
      });
      await db.syncSnapshot.deleteMany({});
      await createSnapshot(account);
      return Response.json(await getState());
    }

    if (action === "sync") {
      const meta = await db.meta.findUnique({ where: { key: ACCOUNT_KEY } });
      if (!meta) return Response.json({ ok: false, connected: false });
      const counts = await createSnapshot(meta.value);
      return Response.json({ ok: true, connected: true, counts });
    }

    if (action === "disconnect") {
      await db.meta.deleteMany({ where: { key: ACCOUNT_KEY } });
      await db.syncSnapshot.deleteMany({});
      return Response.json({ connected: false, account: null, last: null, history: [] });
    }

    return badRequest("عملیات نامعتبر است");
  } catch (e) {
    return serverError(e);
  }
}
