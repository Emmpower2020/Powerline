import { db } from "@/lib/db";
import {
  serializeReminder,
  parseISOMidnight,
  isValidISODate,
  toIntOrNull,
  toStrOrNull,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

/**
 * تکرار یادآور: بعد از «انجام شد»، اگر تکرار داشته باشد یادآور بعدی ساخته می‌شود.
 * برای یادآور «هر دو» (تاریخ + کیلومتر): تکرار زمانی فقط تاریخ را پیش می‌برد و تکرار کیلومتری فقط کیلومتر را.
 */
async function applyRepeat(reminder: {
  id: string;
  vehicleId: string;
  title: string;
  kind: string;
  dueDate: Date | null;
  dueKm: number | null;
  repeatKind: string;
  repeatEveryKm: number | null;
  notes: string | null;
}) {
  if (reminder.repeatKind === "NONE") return;

  let nextDueDate: Date | null = reminder.dueDate;
  let nextDueKm: number | null = reminder.dueKm;
  let changed = false;

  if ((reminder.repeatKind === "MONTHLY" || reminder.repeatKind === "YEARLY") && reminder.dueDate) {
    const base = reminder.dueDate;
    nextDueDate = new Date(base);
    if (reminder.repeatKind === "MONTHLY") {
      nextDueDate.setUTCMonth(base.getUTCMonth() + 1);
    } else {
      nextDueDate.setUTCFullYear(base.getUTCFullYear() + 1);
    }
    changed = true;
  } else if (reminder.repeatKind === "KM" && reminder.dueKm) {
    nextDueKm = reminder.dueKm + (reminder.repeatEveryKm ?? 5000);
    changed = true;
  }

  if (!changed) return;

  await db.reminder.create({
    data: {
      vehicleId: reminder.vehicleId,
      title: reminder.title,
      kind: reminder.kind,
      dueDate: nextDueDate,
      dueKm: nextDueKm,
      repeatKind: reminder.repeatKind,
      repeatEveryKm: reminder.repeatEveryKm,
      notes: reminder.notes,
      status: "ACTIVE",
    },
  });
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.reminder.findUnique({ where: { id } });
    if (!existing) return badRequest("یادآور یافت نشد", 404);

    const data: Record<string, unknown> = {};

    if (body?.title !== undefined) {
      const title = toStrOrNull(body.title);
      if (!title) return badRequest("عنوان نمی‌تواند خالی باشد");
      data.title = title;
    }
    if (body?.vehicleId !== undefined) {
      const vehicleId = String(body.vehicleId);
      const v = await db.vehicle.findUnique({ where: { id: vehicleId } });
      if (!v) return badRequest("خودرو یافت نشد", 404);
      data.vehicleId = vehicleId;
    }
    if (body?.kind !== undefined) {
      const kind = String(body.kind);
      if (!["DATE", "KM", "BOTH"].includes(kind)) return badRequest("نوع یادآور نامعتبر است");
      data.kind = kind;
    }
    if (body?.dueDate !== undefined) {
      data.dueDate = isValidISODate(body.dueDate) ? parseISOMidnight(body.dueDate) : null;
    }
    if (body?.dueKm !== undefined) {
      const v = toIntOrNull(body.dueKm);
      if (v !== null && (v <= 0 || v > 10_000_000)) return badRequest("کیلومتر هدف معتبر نیست");
      data.dueKm = v;
    }
    if (body?.repeatKind !== undefined) {
      const rk = String(body.repeatKind);
      if (!["NONE", "MONTHLY", "YEARLY", "KM"].includes(rk)) return badRequest("نوع تکرار نامعتبر است");
      data.repeatKind = rk;
    }
    if (body?.repeatEveryKm !== undefined) data.repeatEveryKm = toIntOrNull(body.repeatEveryKm);
    if (body?.notes !== undefined) data.notes = toStrOrNull(body.notes);
    if (body?.status !== undefined) {
      const st = String(body.status);
      if (!["ACTIVE", "PENDING", "DONE", "OVERDUE"].includes(st)) return badRequest("وضعیت یادآور نامعتبر است");
      data.status = st;
    }

    // toggle «انجام شد» + تکرار
    if (body?.done !== undefined) {
      const done = Boolean(body.done);
      data.done = done;
      data.doneAt = done ? new Date() : null;
      data.status = done ? "DONE" : "ACTIVE";
      const updated = await db.reminder.update({ where: { id }, data });
      if (done && !existing.done) {
        await applyRepeat(updated);
      }
      return Response.json(serializeReminder(updated));
    }

    const updated = await db.reminder.update({ where: { id }, data });
    return Response.json(serializeReminder(updated));
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.reminder.findUnique({ where: { id } });
    if (!existing) return badRequest("یادآور یافت نشد", 404);

    await db.reminder.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
