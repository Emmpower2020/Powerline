import { db } from "@/lib/db";
import {
  serializeReminder,
  parseISOMidnight,
  isValidISODate,
  toIntOrNull,
  toStrOrNull,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

export async function GET() {
  try {
    const reminders = await db.reminder.findMany({
      orderBy: [{ done: "asc" }, { createdAt: "desc" }],
    });
    return Response.json({ reminders: reminders.map(serializeReminder) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const title = toStrOrNull(body?.title);
    if (!title) return badRequest("عنوان یادآور الزامی است");

    const vehicleId = String(body?.vehicleId ?? "");
    if (!vehicleId) return badRequest("انتخاب خودرو الزامی است");
    const vehicle = await db.vehicle.findUnique({ where: { id: vehicleId } });
    if (!vehicle) return badRequest("خودرو یافت نشد", 404);

    const kind = String(body?.kind ?? "DATE");
    if (!["DATE", "KM", "BOTH"].includes(kind)) return badRequest("نوع یادآور نامعتبر است");

    const repeatKind = String(body?.repeatKind ?? "NONE");
    if (!["NONE", "MONTHLY", "YEARLY", "KM"].includes(repeatKind)) {
      return badRequest("نوع تکرار نامعتبر است");
    }

    let dueDate: Date | null = null;
    let dueKm: number | null = null;

    // DATE: فقط تاریخ | KM: فقط کیلومتر | BOTH: هر دو الزامی است
    if (kind === "DATE" || kind === "BOTH") {
      if (!isValidISODate(body?.dueDate)) return badRequest("تاریخ هدف الزامی است");
      dueDate = parseISOMidnight(body.dueDate);
    }
    if (kind === "KM" || kind === "BOTH") {
      dueKm = toIntOrNull(body?.dueKm);
      if (dueKm === null || dueKm <= 0 || dueKm > 10_000_000) {
        return badRequest("کیلومتر هدف معتبر نیست");
      }
    }

    const repeatEveryKm = repeatKind === "KM" ? (toIntOrNull(body?.repeatEveryKm) ?? 5000) : null;

    const reminder = await db.reminder.create({
      data: {
        vehicleId,
        title,
        kind,
        dueDate,
        dueKm,
        repeatKind,
        repeatEveryKm,
        status: "ACTIVE",
        notes: toStrOrNull(body?.notes),
      },
    });

    return Response.json(serializeReminder(reminder), { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
