import { db } from "@/lib/db";
import {
  serializeBrand,
  toStrOrNull,
  badRequest,
  serverError,
} from "@/lib/api-helpers";
import { DEFAULT_BRANDS } from "@/lib/types";

/** بارگذاری اولیه برندهای پیش‌فرض اگر جدول خالی باشد */
async function ensureSeeded() {
  const count = await db.brandModel.count();
  if (count > 0) return;
  for (const b of DEFAULT_BRANDS) {
    await db.brandModel.create({
      data: {
        name: b.name,
        models: JSON.stringify(b.models),
        isCustom: b.name === "شخصی",
      },
    });
  }
}

/**
 * ادغام مدل‌های پیش‌فرض با رکوردهای موجود — فقط افزودنی:
 * برای هر برند پیش‌فرض (بر اساس name) اگر مدل‌هایی در DEFAULT_BRANDS هست که در رکورد DB نیست،
 * به رکورد اضافه می‌شود (اجتماع دو لیست). هیچ مدلی از DB حذف نمی‌شود و مدل‌های حذف‌شده از
 * DEFAULT_BRANDS (مثل تندر از چانگان یا برند دنا) دست نمی‌خورند. برندِ غایب هم ساخته نمی‌شود
 * تا برندهایی که کاربر عمداً حذف کرده دوباره ظاهر نشوند.
 */
async function mergeDefaultModels() {
  const dbBrands = await db.brandModel.findMany();
  for (const def of DEFAULT_BRANDS) {
    const rec = dbBrands.find((b) => b.name === def.name);
    if (!rec) continue;
    let current: string[] = [];
    try {
      const parsed: unknown = JSON.parse(rec.models);
      if (Array.isArray(parsed)) current = parsed.map((m) => String(m));
    } catch {
      current = [];
    }
    const known = new Set(current);
    const missing = def.models.filter((m) => !known.has(m));
    if (missing.length === 0) continue;
    await db.brandModel.update({
      where: { id: rec.id },
      data: { models: JSON.stringify([...current, ...missing]) },
    });
  }
}

export async function GET() {
  try {
    await ensureSeeded();
    await mergeDefaultModels();
    const brands = await db.brandModel.findMany({
      orderBy: { createdAt: "asc" },
    });
    return Response.json({ brands: brands.map(serializeBrand) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = toStrOrNull(body?.name);
    if (!name) return badRequest("نام برند را وارد کنید");

    // برند تکراری؟
    const existing = await db.brandModel.findFirst({ where: { name } });
    if (existing) return badRequest("این برند قبلاً ثبت شده است");

    const models = Array.isArray(body?.models)
      ? (body.models as unknown[]).map((m) => String(m).trim()).filter(Boolean)
      : [];

    const brand = await db.brandModel.create({
      data: {
        name,
        models: JSON.stringify(models),
        isCustom: true,
      },
    });
    return Response.json(serializeBrand(brand), { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
