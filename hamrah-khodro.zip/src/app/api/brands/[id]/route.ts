import { db } from "@/lib/db";
import {
  serializeBrand,
  toStrOrNull,
  badRequest,
  serverError,
} from "@/lib/api-helpers";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.brandModel.findUnique({ where: { id } });
    if (!existing) return badRequest("برند یافت نشد", 404);

    const data: Record<string, unknown> = {};
    if (body?.name !== undefined) {
      const name = toStrOrNull(body.name);
      if (!name) return badRequest("نام برند را وارد کنید");
      data.name = name;
    }
    if (body?.models !== undefined) {
      const models = Array.isArray(body.models)
        ? (body.models as unknown[]).map((m) => String(m).trim()).filter(Boolean)
        : [];
      data.models = JSON.stringify(models);
    }

    const brand = await db.brandModel.update({ where: { id }, data });
    return Response.json(serializeBrand(brand));
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.brandModel.findUnique({ where: { id } });
    if (!existing) return badRequest("برند یافت نشد", 404);

    await db.brandModel.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
