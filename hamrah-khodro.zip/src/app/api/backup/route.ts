import { db } from "@/lib/db";
import { serializeBrand } from "@/lib/api-helpers";
import { APP_NAME, APP_VERSION } from "@/lib/types";

/**
 * GET /api/backup — خروجی زندهٔ کامل داده‌ها به‌صورت JSON دانلودی
 * نام فایل: مهر زمانی به وقت تهران (یکتا در هر دانلود) — طبق مادهٔ ۱۲-۱ کتاب قانون
 */

export const dynamic = "force-dynamic";

/** مهر زمانی تهران با قالب YYYY-MM-DD-HHMM */
function tehranStamp(): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tehran",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(new Date());

  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  const hour = get("hour") === "24" ? "00" : get("hour");
  return `${get("year")}-${get("month")}-${get("day")}-${hour}${get("minute")}`;
}

export async function GET() {
  try {
    const [vehicles, records, reminders, brands, serviceTypes] = await Promise.all([
      db.vehicle.findMany({ orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }] }),
      db.record.findMany({ orderBy: { date: "desc" } }),
      db.reminder.findMany({ orderBy: { createdAt: "desc" } }),
      db.brandModel.findMany({ orderBy: { name: "asc" } }),
      db.serviceType.findMany({ orderBy: { order: "asc" } }),
    ]);

    const data = {
      app: APP_NAME,
      version: APP_VERSION,
      exportedAt: new Date().toISOString(),
      exportedAtTehran: new Date().toLocaleString("fa-IR", { timeZone: "Asia/Tehran" }),
      vehicles,
      records,
      reminders,
      brands: brands.map(serializeBrand),
      serviceTypes,
    };

    return new Response(JSON.stringify(data, null, 2), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="hamrah-khodro-backup-${tehranStamp()}.json"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    console.error("backup error", e);
    return Response.json({ error: "خطا در تهیهٔ خروجی پشتیبان" }, { status: 500 });
  }
}
