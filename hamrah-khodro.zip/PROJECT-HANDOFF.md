# سند انتقال پروژهٔ «همراه خودرو» (Hamrah Khodro)

> **این سند برای چیست؟** — این پروندهٔ انتقالی (Handoff) کل پروژهٔ «همراه خودرو» را آن‌قدر کامل توضیح می‌دهد که یک هوش مصنوعی یا توسعه‌دهندهٔ دیگر بتواند **عیناً همین پروژه را از صفر بازسازی کند**. همهٔ قراردادها، مختصات، رنگ‌ها، پیام‌های فارسی، باگ‌های تاریخی و درس‌های آموخته در همین‌جا است. سورس کامل هم در کنار همین سند در بستهٔ زیپ پروژه موجود است — این سند «نقشهٔ ذهنی» است و سورس «متن کامل».

---

## ۰) دستورالعمل برای هوش مصنوعی (اگر می‌خواهی بازسازی کنی)

1. این سند را کامل بخوان (بخش ۱۷ چک‌لیست ترتیب کار است).
2. استک اجباری: **Next.js 16 (App Router) + TypeScript + Tailwind CSS 4 + shadcn/ui (New York)** برای لایه وب، و **جاوا خالص (بدون Gradle)** برای لایهٔ پل اندروید.
3. زبان رابط کاربری: **فارسی، RTL کامل** (`<html lang="fa" dir="rtl">`)، فونت **Vazirmatn**، اعداد فارسی، تقویم **جلالی**.
4. سه چیزِ که اگر رعایت نشود پروژه از هم می‌پاشد:
   - قرارداد ورود Firebase حتماً `requestUri` باشد نه `uri` (بخش ۱۰.۴ — ریشهٔ خطای ماندگار پروژه).
   - dex جاوا فقط با ecj+d8 ساخته شود؛ اسمبلی دست‌نویس smali ممنوع (بخش ۱۳.۶ — درس VerifyError).
   - در فایل ZIP نهایی APK، `resources.arsc` و فونت‌ها **Stored** (بدون فشرده‌سازی) باشند (بخش ۱۳.۵).
5. سورس واقعی در همین زیپ است؛ هنگام تردید، سورس ملاک است و این سند برای «چرا این‌طوری» است.

---

## ۱) شناسنامهٔ پروژه

| مورد | مقدار |
|---|---|
| نام برنامه | همراه خودرو — مدیریت سرویس خودرو |
| بستهٔ اندروید | `com.zai.hamrahkhodro` |
| نسخهٔ فعلی | v3.9.6 (versionCode 34) |
| پلتفرم | APK اندروید (WebView wrapper) + وب (Next.js) |
| زبان رابط | فارسی (RTL) — تقویم جلالی، اعداد فارسی |
| حداقل/هدف SDK | minSdk 24 / targetSdk 34 |
| کارکرد آفلاین | کامل — اینترنت فقط برای سینک ابری |
| پشتیبان ابری | Firebase (ورود با حساب گوگل + Firestore) |
| پروژهٔ فایربیس فعلی | `hamrahprj` |
| keystore | `android-keys/hk-release.keystore` — alias `hamrah` — رمز `hamrah-khodro-2026` |

**معرفی:** دفترچهٔ ثبت سرویس، سوخت، کیلومتر و یادآور برای خودروهای شخصی. کاربر خودروهایش را ثبت می‌کند، برای هر ثبت‌وحکم سرویس/سوخت/کیلومتر/یادداشت وارد می‌کند، یادآور (تاریخ/کارکرد/هر دو، با تکرار) می‌سازد، گزارش هزینه و مصرف می‌بیند و می‌تواند همه‌چیز را با حساب گوگل روی سرور ابری فایربیس پشتیبان/بازیابی کند.

---

## ۲) معماری کلی — دو لایه

```
┌────────────────────────────────────────────────────────────┐
│  لایهٔ وب (Next.js 16 — static export)                      │
│  src/  →  کل UI و منطق؛ بیلد استاتیک → assets/www در APK    │
│  داده: در وبِ dev از /api/* (Prisma/SQLite)؛ در APK از پل   │
│        جاوا (AndroidApi.api) که fetch('/api/*') را رهگیری   │
│        می‌کند و از data.json محلی جواب می‌دهد                │
├────────────────────────────────────────────────────────────┤
│  لایهٔ جاوا (com.zai.hamrahkhodro — dex سفارشی)             │
│  MainActivity → WebView با دامنهٔ امن                       │
│  https://appassets.androidplatform.net/index.html           │
│  پل‌ها: AndroidApi (داده/نوتیف/فایل) + AndroidCloud (OAuth) │
│  FbSession: OAuth گوگل PKCE → Firebase Auth REST →          │
│             Firestore REST (تماماً بدون کتابخانهٔ خارجی)     │
└────────────────────────────────────────────────────────────┘
```

- **هیچ کتابخانهٔ فایربیس/گوگل در جاوا نیست** — همه‌چیز با `HttpURLConnection` + `org.json` (داخل اندروید) پیاده شده تا dex کوچک بماند و وابستگی صفر باشد.
- **بدون Gradle** — APK با «جراحی» روی یک APK پایه ساخته می‌شود (بخش ۱۳).

---

## ۳) استک فناوری و پکیج‌ها

- **Next.js 16 (App Router) + React 19 + TypeScript** — تک‌صفحه (`src/app/page.tsx`)
- **Tailwind CSS 4 + shadcn/ui (New York) + lucide-react** — کل سیستم UI
- **framer-motion** — شیت‌های کشویی (drag-to-close)
- **recharts** — نمودارهای گزارشات
- **@fontsource-variable/vazirmatn** — فونت (سلف‌هاست)
- **zustand / TanStack Query** — در صورت نیاز (پروژهٔ فعلی state را در page.tsx نگه می‌دارد)
- **Prisma + SQLite** — فقط برای حالت وب dev (`prisma/schema.prisma`، `DATABASE_URL` در `.env`)
- جاوا: `java.* + org.json` + این APIهای اندروید: Activity, Intent, Uri, SharedPreferences, WebView, JavascriptInterface, Base64, Log

---

## ۴) مدل داده (کامل — `src/lib/types.ts`)

```ts
APP_VERSION = "v3.9.6"; APP_NAME = "مدیریت خودرو";

VehicleItem { id, name, brand, model, year:number|null, yearType:"JALALI"|"GREGORIAN",
  plate:string|null /* «22 ب 457 ایران 11» */, vin, color, imageData?:string|null /* data-URL */,
  fuelType:"GASOLINE"|"DIESEL"|"HYBRID"|"ELECTRIC"|"CNG", transmission:"MANUAL"|"AUTOMATIC",
  status:"ACTIVE"|"IN_REPAIR"|"SOLD", mileage:number, purchasePrice:number|null,
  purchaseDate:string|null, notes, isDefault:boolean, createdAt }

RecordItem { id, type:"SERVICE"|"FUEL"|"ODOMETER"|"NOTE", vehicleId, date /* ISO YYYY-MM-DD */,
  mileage:number|null, cost:number|null,
  // SERVICE:
  title, costMode:"TOTAL"|"SEPARATE"|null, partsCost, laborCost,
  hasOilFilter:boolean, oilFilterCost, hasAirFilter, airFilterCost,
  complementary:{name:string; price:number|null}[], provider, description,
  nextDueDate, nextDueKm,
  // FUEL:
  liters, pricePerLiter, fullTank:boolean, prevRegistered:boolean,
  consumption:number|null /* L/100km */, station,
  // NOTE:
  noteTitle, noteBody, createdAt }

ReminderItem { id, vehicleId, title, kind:"DATE"|"KM"|"BOTH", dueDate, dueKm,
  repeatKind:"NONE"|"MONTHLY"|"YEARLY"|"KM", repeatEveryKm, 
  status:"ACTIVE"|"PENDING"|"DONE"|"OVERDUE", notes, linkedRecordId,
  done:boolean, doneAt, createdAt }

BrandItem { id, name, models:string[], isCustom:boolean, createdAt }
ServiceTypeItem { id, label, value, order, isDefault, separateCost:boolean,
  kind:"SERVICE"|"PART", complementary:string[], createdAt }
VehicleStats { vehicleId, currentKm, totalCost, monthCost, prevMonthCost, serviceCount,
  fuelCount, fuelTotalLiters, fuelTotalCost, avgConsumption:number|null,
  lastServiceKm, monthlyCosts:{label,monthIndex,service,fuel}[], consumptionPoints:{label,value}[] }
```

- **IDها سمت سرور/پل ساخته می‌شوند** (cuid در Prisma) — کلاینت هرگز ID تولید نمی‌کند.
- Prisma: مدل‌های `Vehicle, Record, Reminder, BrandModel (models به‌صورت JSON string), ServiceType, Meta` — حذف خودرو → **Cascade**.
- برچسب‌های فارسی: سرویس/سوخت/کیلومتر/یادداشت — بنزینی/دیزل/هیبریدی/برقی/دوگانه — دستی/اتوماتیک — فعال/در تعمیر/فروخته — بدون تکرار/ماهانه/سالانه/هر N کیلومتر — تاریخ/کارکرد/تاریخ و کیلومتر — خدماتی/تعویض قطعه.
- داده‌های پیش‌فرض: **۲۱ برند ایرانی/خارجی با مدل‌های کامل** (ایران خودرو ۳۵ مدل، سایپا ۱۹ مدل، …، «شخصی») + **۱۷ نوع سرویس** (مثل «تعویض روغن موتور» با مکمل‌های «فیلتر هوا/فیلتر روغن»، «تعویض لنت ترمز» از نوع PART با مکمل «تراشیدگی دیسک»، … تا «سایر») + ۶ پیشنهاد یادآور — هر دو در `src/lib/types.ts` (DEFAULT_BRANDS / SERVICE_TYPE_DEFAULTS / REMINDER_PRESETS).

---

## ۵) ساختار UI

- **تک‌صفحه** با ۴ تب — ترتیب نوار پایین (RTL): `reports | records | reminders | settings` + دکمهٔ **+** شناور وسط (`-top-6 right-1/2 translate-x-1/2`، دایرهٔ ۶۴px، حلقهٔ `ring-4 ring-background`). تب پیش‌فرض: `records`.
- **سربرگ چسبان** (sticky, `rounded-b-[28px] bg-primary`): عنوان هر تب گوشهٔ بالا-راست + «نام‌روزهفته • ۱۲ مرداد ۱۴۰۴» + سه دایرهٔ تزئینی سفید کم‌رنگ.
- **بج یادآور** روی آیکون زنگ نوار پایین: دایرهٔ ۱۸px قرمز (destructive) با عدد فارسی، سقف ۹۹ — شمار یادآورهای undone با وضعیت overdue|soon.
- **سوایپ تب‌ها (TabSwipe):** کاروسل دنبال‌کنندهٔ انگشت — درگ مستقیم DOM با transform (بدون رندر React)، commit اگر `|dx| > W*0.32` یا سرعت `> 0.55px/ms`؛ حافظهٔ اسکرول هر تب؛ گارد روی input/textarea/dialog/menu؛ شنونده‌های touch بومی `passive:false, capture:true`.
- **ریسپانسیو:** پوستهٔ `max-w-md mx-auto` (~۴۴۸px) داخل `min-h-dvh`؛ در موبایل تمام‌عرض.
- **ExitGuard:** دوبار-برگشت برای خروج (توست «برای خروج، دوباره دکمهٔ برگشت را بزنید»، پنجرهٔ ۲.۵ ثانیه).
- **لایه‌بندی z:** نوار پایین ۵۰، سربرگ ۳۰، پنجرهٔ تنظیمات ۷۰، BottomSheet ۸۰، BusyIndicator ۹۵، toast ۱۰۰، Onboarding ۱۱۰، ConfirmDialog ۱۲۰. همهٔ شیت‌ها/دیالوگ‌ها با **createPortal به body** (درس WebView: will-change کاروسل).
- `window.confirm` در WebView کار نمی‌کند → **ConfirmDialog** اختصاصی (صف پیام، دکمهٔ قرمز اگر عنوان شامل «حذف»).
- بازخورد لمسی: `button:active → scale(0.93) translateY(0.5px) brightness(0.8)` با transition 110ms.

---

## ۶) جزئیات تب‌ها

### ۶.۱ سوابق (RecordsTab)
- بخش «یادآورهای نزدیک» (حداکثر ۳ کارت بالای لیست) → جستجو (عنوان/توضیح/مرکز/ایستگاه/یادداشت/نام خودرو) + فیلتر خودرو و نوع + شمارندهٔ «N مورد».
- **گروه‌بندی ماهانهٔ جلالی** («مرداد ۱۴۰۴») مرتب نزولی.
- رنگ‌ها/آیکون‌ها: سرویس Wrench `#0E9F8E`، سوخت Fuel `#F59E0B`، کیلومتر Gauge `#8B5CF6`، یادداشت StickyNote `#EC4899`.
- کارت سوخت: «۴۵٫۰ لیتر — ۲۵٬۴۵۵ تومان/لیتر • مصرف ۷٫۸» + چیپ ایستگاه؛ سرویس: مکمل‌ها با « + » join؛ هزینه تومان extrabold سمت چپ؛ دکمه‌های «ویرایش»/«حذف».
- **فرم (RecordFormSheet):** گرید ۲×۲ (خودرو/تاریخ/کارکرد/نوع یا مقدار) + راهنمای «آخرین کارکرد ثبت‌شده». سرویس بر اساس kind: PART → قیمت قطعه + دستمزد؛ SERVICE → قیمت سرویس + مکمل‌های چک‌باکسی با قیمت + مرکز خدمات + سوییچ «ثبت سرویس بعدی» (km پیشنهادی = mileage+5000) + توضیحات. سوخت: سوییچ «باک پر شد» + **تبدیل دوسویهٔ قیمت هر لیتر ↔ هزینهٔ کل** + نوار محاسبهٔ زنده. یادداشت: عنوان + متن. اعتبارسنجی فارسی («خودرو را انتخاب کنید»، …).
- **نکتهٔ بحرانی:** payload فرم همیشه `type: mode` دارد (باگ تاریخی ۴۰۰ «نوع رکورد نامعتبر است»).

### ۶.۲ یادآورها (RemindersTab)
- وضعیت‌ها: done («انجام شد»، زمردی)، overdue (قرمز، «N روز گذشته»)، soon (زرد، «N روز مانده»/«امروز!»)، ok. آستانه‌ها: soonDays=7 / soonKm=500. نوع BOTH هر دو شرط؛ بدترینِ دو ملاک رنگ است؛ لیبل‌ها با « و » join («۳ روز و ۲۰۰ کیلومتر مانده»).
- ۴ دسته: عقب‌افتاده/نزدیک/فعال/انجام‌شده + جستجو + فیلتر خودرو + فیلتر وضعیت.
- **انجام‌شدن:** سرور `applyRepeat` را اجرا می‌کند — MONTHLY → +۱ ماه، YEARLY → +۱ سال، KM → dueKm + repeatEveryKm (پیش‌فرض ۵۰۰۰) و **یادآور بعدی رکورد جدید می‌شود**.
- فرم: kind تاریخ/کیلومتر/هر دو + تکرار؛ پیشنهاد dueKm = `ceil((currentKm+5000)/100)*100`.

### ۶.۳ گزارشات (ReportsTab)
- انتخابگر خودرو («همهٔ خودروها» + تک‌تک).
- کارت مقایسهٔ ماه («افزایش/کاهش N تومان نسبت به ماه قبل (X%)»).
- ۴ کارت: «هزینه این ماه» TEAL، «کارکرد فعلی/بیشترین» VIOLET، «میانگین مصرف» (لیتر/۱۰۰کیلومتر) AMBER، «مجموع هزینه» RED.
- **ماشین‌حساب مصرف سوخت:** دو حالت «بازهٔ تاریخ» (با PersianWheelDatePicker) و «انتخاب سوخت‌گیری‌ها»؛ الگوریتم **full-to-full** با احتساب سوخت‌های نیم‌بندِ بینابین.
- نمودارها (recharts): میله‌ای انباشتهٔ «هزینه‌های ۶ ماه اخیر» (سرویس TEAL + سوخت AMBER، ۶ ماه جلالی، `dir="ltr"`, XAxis reversed) + خطی «روند مصرف سوخت» (تک‌خودرو، AMBER، domain=dataMin-1..dataMax+1).

### ۶.۴ تنظیمات (SettingsTab)
1. **خودروهای من** — کارت با عکس، **پلاک واقعی** (قاب مشکی/کادر سفید/نوار آبی `#20337a`)، چیپ‌ها، گرید آمار، فعال‌سازی/ویرایش/حذف (Cascade با تأیید).
2. **مدیریت برند و مدل** — آکاردئون + افزودن/ویرایش درجا/حذف.
3. **انواع سرویس** — ویرایش نام/kind/مکمل‌ها.
4. **تم برنامه** — ۹ تم (اختصاصی paper «سفید سرد با اکسنت زمردی» پیش‌فرض؛ روز/گل‌بهی/فیروزه/زعفران/فیروزه تیره/گرافیت/شب/جنگل) + تم‌ساز شخصی (۱۲ خانوادهٔ رنگ × ۱۲ گام + سه‌رنگه سربرگ/پس‌زمینه/کادر) — با `data-theme` + متغیرهای oklch در globals.css + ضد-FOUC با اسکریپت inline.
5. **پشتیبان‌گیری و بازیابی** — ۳ تب: «سرور ابری» (Firebase — بخش ۱۰)، «Google Drive» (قدیمی)، «فایل پشتیبان».
6. **تنظیمات نوتیفیکیشن** — سوییچ کلی + چیپ‌های روز (۱/۲/۳/۵/۷/۱۴/۳۰) و کیلومتر (۱۰۰/۲۰۰/۵۰۰/۱۰۰۰/۲۰۰۰) + «تکرار اطلاع روزانهٔ عقب‌افتاده‌ها» + «نوتیفیکیشن تست».
7. **خروج از برنامه** + کارت «درباره» با «نسخه v3.9.6».

---

## ۷) فارسی / RTL / تقویم جلالی (`src/lib/persian.ts`)

- **تبدیل جلالی کامل (پیاده‌سازی jalaali-js):** آرایهٔ breaks `[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178]`، توابع `toJalaali/toGregorian/jalaaliMonthLength/isLeapJalaaliYear`؛ ماه‌های ۱-۶: ۳۱ روز، ۷-۱۱: ۳۰، ۱۲: ۲۹/۳۰.
- **اعداد:** `fa()` لاتین→فارسی، `en()` فارسی/عربی→لاتین، `faNum` با جداکنندهٔ «٬»، `faMoney` («تومان»)، `faMoneyShort` («۱٫۲۵ میلیون»/«۹۵۰ هزار»).
- **تاریخ‌ها:** «۱۲ مرداد ۱۴۰۴»، «۱۴۰۴/۰۵/۱۲»، «امروز/فردا/دیروز/N روز دیگر».
- **NumberInput:** حین فوکوس ارقام خام فارسی + `select()` خودکار کل مقدار (تایپ = جایگزینی)؛ بعد از blur فرمت هزارگان.
- **پلاک:** regex `^(\d{1,2})\s+(\S{1})\s+(\d{1,3})\s+ایران\s+(\d{1,2})$`؛ «ا» تنها → «الف»؛ ۳۱ حرف الفبا با نام.
- فونت: Vazirmatn Variable سلف‌هاست — **بیلد APK: Google Fonts حذف می‌شود** (patch در build-web-only.sh).

---

## ۸) لایهٔ ذخیره‌سازی + پشتیبان

- **اصل:** دادهٔ اصلی سمت سرور است — در وب از `/api/*` (۱۶ مسیر REST روی Prisma)؛ در APK همان قراردادها اما `fetch('/api/*')` توسط BRIDGE_INIT به `AndroidApi.api(method,url,body)` هدایت می‌شود (جواب `JSON.parse` از `data.json` محلی). کلاینت هیچ‌وقت رکورد را در localStorage نگه نمی‌دارد.
- **کلیدهای localStorage:** `hamrah-khodro-active-vehicle`، `hamrah-khodro-onboarded` ("1")، `hamrah-khodro-notif-ask`، `hamrah-khodro-notify-settings` (JSON)، `hamrah-khodro-notified/-sys`، `hamrah-khodro-theme(-vars/-dark/-custom-themes/-overrides/-hidden)`، `hamrah-khodro-cloud-auto/meta/last-hash/file-id` (Drive)، `hamrah-khodro-fb-meta/-auto/-lasthash/-config` (Firebase)، `hamrah-khodro-last-export`.
- **فرمت CloudSnapshot (خروجی `/api/backup`):** `{app:"همراه خودرو", version, exportedAt, exportedAtTehran, vehicles[], records[], reminders[], brands[], serviceTypes[]}` — نام فایل `hamrah-khodro-backup-YYYY-MM-DD-HHMM.json` به‌وقت تهران.
- **Restore/merge (mergeSnapshots):** ادغام بدون تکرار با کلید `id`، برنده = رکورد با timestamp جدیدتر؛ رکوردها فقط از خودروهای بازمانده؛ برندها با کلید `name` و اجتماع مدل‌ها؛ انواع سرویس با کلید `value`.
- **محافظ «سرور جلوتر است»:** اگر هنوز سینک موفقی نبوده و ابر پرتر است → آپلود ممنوع؛ شیت انتخاب: «ادغام محلی + سرور (پیشنهادی)» / «جایگزینی کامل با نسخهٔ سرور» (+ در Drive: «شروع تازه») — قبل از جایگزینی پشتیبان خودکار در Download.
- هش سبک ۳۲بیتی (`0xdeadbeef/0x41c6ce57`) برای جلوگیری از آپلود بی‌تغییر.

---

## ۹) نوتیفیکیشن + شیت‌های عمومی

- **بدون زمان‌بندی OS** — بررسی درون‌برنامه‌ای هر ۵ دقیقه + هر تغییر داده؛ `new Notification(title,{dir:"rtl",lang:"fa",tag})`؛ در APK پل اندروید مجوز واقعی اندروید ۱۳+ و نوتیف نوار وضعیت را می‌دهد (کلاس HKNotification با پولینگ `hasNotifPermission` هر ۵۰۰ms تا ۴۰ بار).
- **BusyIndicator:** حالت pill شناور (z-95) و حالت overlay پردهٔ `bg-background/85` **بدون backdrop-blur** (باگ WebView) + حلقهٔ دوتایی چرخان + نوار موج‌دار 1.4s؛ حداقل نمایش ۴۵۰/۷۵۰ms.
- **توست‌های کلیدی:** «ثبت شد ✓ / ویرایش شد ✓ / حذف شد / انجام شد ✓ / بازگشایی شد / خودرو اضافه شد ✓ / یادآور ساخته شد ✓ / به حساب گوگل وصل شد ✓ / در سرور پشتیبان ذخیره شد ✓ / همگام‌سازی ابری ناموفق (destructive) / پشتیبان گرفته شد ✓ / بازیابی از سرور انجام شد ✓ / از حساب پشتیبان خارج شدید / اتصال لغو شد / کپی شد ✓».
- **ShareSheet:** خروجی متنی «🚗 همراه خودرو — سوابق خودروها» با گروه‌بندی خودرو + محدوده (همه/۱۰/۲۰/۵۰ اخیر) + «فایل جدید»/«افزودن به فایل قبلی».

---

## ۱۰) سینک ابری Firebase — قرارداد کامل (مهم‌ترین بخش)

### ۱۰.۱ جریان کلی
1. کاربر «اتصال با حساب گوگل» را می‌زند → `fbStartAuthAsync` → **مرورگر سیستم** (Intent ACTION_VIEW — هرگز WebView) باز می‌شود.
2. گوگل بعد از ورود به `com.zai.hamrahkhodro:/fbcallback` برمی‌گردد → AuthActivity → روتر `CloudBridge.handleRedirect` → `FbSession.handleRedirect` کد را ذخیره می‌کند.
3. وب با پولینگ `fbPollAuth` (هر ۱۲۰۰ms) state را می‌خواند → `done` → `fbExchangeCodeAsync` → تبدیل کد → `signInWithIdp` → نشست.
4. سینک: کل snapshot به‌صورت JSON داخل فیلد `data` سند `hamrah_users/{uid}` در Firestore نوشته/خوانده می‌شود.

### ۱۰.۲ متدهای پل (`window.AndroidCloud`)
```
fbStartAuthAsync(callback)          → {"ok":true,"authUrl":...,"redirectUri":...} | {"ok":false,"error":"busy"|"network"|"custom_scheme_disabled"|"redirect_uri_mismatch"|"invalid_client"}
fbPollAuth()                        → {"state":"none|waiting|done|error|timeout|exchanging","hasCode"?,"error"?}
fbCancelAuth()                      → {"ok":true}
fbExchangeCodeAsync(callback)       → {"ok":true,"email":...,"uid":...} | {"ok":false,"error":"busy"|"no_code"|"code_used"|"network"|"exchange_failed"|"signin_failed","status"?,"message"?/*خام گوگل تا ۱۵۰۰ کاراکتر*/}
fbRequestAsync(method,url,ct,body,cb) → {"ok":true,"status":<http>,"body":"<raw>"} | {"ok":false,"error":"bad_url"|"disconnected"|"network"}
fbProbeAsync(probe,callback)        → probe ∈ network|identity|firestore
fbGetAccount()                      → {"connected":bool,"email"?,"uid"?}
fbDisconnectAsync(callback)         → {"ok":true}
```
- **مکانیزم callback:** وب یک تابع سراسری با نام یکتا می‌سازد (`__hkFbCb...`)، نامش را می‌passes؛ جاوا در پایان `callback + "(" + json + ");"` را با `evaluateJavascript` روی UI thread اجرا می‌کند (FbReq/FbDeliver؛ خطای نخ → `async_crash`).
- فایل prefs: **`hk_fbcloud`** (جدا از `hk_cloud` قدیمیِ Drive) — کلیدهای flow: `flow_state/verifier/token/code/error/started` — کلیدهای نشست: `s_uid/s_email/s_id_token/s_refresh_token/s_expires`.

### ۱۰.۳ OAuth گوگل (PKCE، بدون Client Secret)
- authorize: `https://accounts.google.com/o/oauth2/v2/auth?client_id=..&redirect_uri=com.zai.hamrahkhodro%3A%2Ffbcallback&response_type=code&scope=openid+email+profile&state=<hex>&code_challenge=<S256>&code_challenge_method=S256&prompt=select_account`
- **precheck:** همان URL با `setInstanceFollowRedirects(false)` — اگر Location به `accounts.google.com/signin/oauth/error` رفت → نگاشت خطا (Custom URI scheme خاموش / redirect_uri_mismatch / invalid_client).
- verifier = base64url(32 بایت SecureRandom)؛ challenge = base64url(SHA-256(verifier)).
- تبدیل کد: `POST https://oauth2.googleapis.com/token` فرم `grant_type=authorization_code&code&client_id&code_verifier&redirect_uri`.
- **تصاحب اتمیک کد:** قبل از شبکه، state به `exchanging` می‌رود (دو نخ نمی‌توانند یک کد را دوبار مصرف کنند)؛ خطای شبکه → بازگشت به `done` (قابل تلاش مجدد)؛ `invalid_grant` → `code_used`.
- توکن‌سازی مجدد: `POST https://securetoken.googleapis.com/v1/token?key=..` فرم `grant_type=refresh_token&refresh_token=..` (refresh token چرخشی ذخیره می‌شود).

### ۱۰.۴ ورود فایربیس — ⭐ قرارداد حیاتی
```
POST https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=<WEB_API_KEY>
Content-Type: application/json

{
  "postBody": "providerId=google.com&id_token=<GOOGLE_ID_TOKEN>&uri=https://localhost",
  "requestUri": "https://localhost",
  "returnSecureToken": true
}
```
- ⚠️ **تاریخی‌ترین درس پروژه:** نسخه‌های ≤v3.۹.۳ این پارامتر را `uri=` می‌فرستادند؛ گوگل همیشه `400 MISSING_REQUEST_URI` برمی‌گرداند → «ورود به سرور پشتیبان انجام نشد» برای همیشه تکرار می‌شد. حتماً `requestUri` (فیلد JSON استاندارد) + `postBody` فرم‌انگاری‌شده.
- پاسخ: `{localId, email, idToken, refreshToken, expiresIn}` → ذخیرهٔ نشست.
- proxy درخواست‌ها: فقط میزبان‌های `identitytoolkit / firestore / securetoken .googleapis.com` مجازند (`bad_url` OTHERWISE)؛ Bearer خودکار؛ روی 401 یک‌بار refresh و retry.

### ۱۰.۵ سند Firestore و قوانین
- سند: `hamrah_users/{uid}` با بدنهٔ `{"fields":{"data":{"stringValue":"<کل snapshot به‌صورت JSON>"},"updatedAt":{"timestampValue":"..."}}}` — یعنی **کل پشتیبان در یک فیلد رشته‌ای**.
- قوانین (دقیقاً همین):
```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
- شناسهٔ سند **نباید با `__` شروع شود** (رزرو است).

### ۱۰.۶ پروب‌ها (بدون نیاز به ورود)
| probe | URL | تفسیر |
|---|---|---|
| network | GET accounts.google.com | هر پاسخ HTTP = اینترنت ✓ |
| identity | POST signInWithPassword با ایمیل ساختگی `probe@hamrah.invalid` | 400 = فعال ✓ / 403 «has not been used» = غیرفعال |
| firestore | GET `.../databases/(default)/documents/hamrah_users` (بدون توکن) | 401/403 = فعال ✓ / 404 «database does not exist» = دیتابیس ساخته نشده |

### ۱۰.۷ نگاشت خطا → کارت فارسی (FbErrorCard)
الگوی «has not been used in project» → تشخیص API خاموش (identity/firestore از متن) + دکمهٔ لینک مستقیم کنسول؛ 404 «database not exist» → کارت ساخت دیتابیس؛ 403 PERMISSION_DENIED → کارت قوانین + **بلوک کپی قوانین**؛ 401 → قطع؛ 429 → محدودیت؛ `code_used` → «کد ورود قبلی یک‌بارمصرف است…». همهٔ کارت‌ها: «تلاش دوباره» + «راه‌اندازی گام‌به‌گام از ابتدا» + «جزئیات فنی خطا» (بدنهٔ خام گوگل).
- **شیت «راه‌اندازی گام‌به‌گام»:** ۶ گام شماره‌دار (اینترنت / Identity Toolkit / Firestore API / دیتابیس / قوانین / اتصال) با «بررسی وضعیت» خودکار.
- **دکمهٔ «لغو اتصال»:** فاز مرورگر → `fbCancelAuth` + توست «اتصال لغو شد»؛ فاز تبدیل کد → نتیجه دور انداخته می‌شود و اگر نشست ساخته شد خودکار قطع می‌شود.

### ۱۰.۸ UI سینک
خارج از حساب: کارت معرفی + «اتصال با حساب گوگل» + «راه‌اندازی گام‌به‌گام سرور». متصل: کارت ایمیل (dir=ltr) + «متصل به سرور پشتیبان (hamrahprj)» + خروج قرمز با تأیید + «آخرین همگام‌سازی: شنبه ۱۴:۰۵» + بج «N رکورد» + سوییچ «همگام‌سازی خودکار» + «همگام‌سازی الان» + «بازیابی از سرور».

---

## ۱۱) صحنهٔ آموزش (Onboarding — اسلاید ۱) — هندسهٔ کامل

۴ اسلاید: ۱) خوش‌آمد + **صحنهٔ جاده** ۲) سوایپ (سه کارت با keyframeهای hk-onboard-*) ۳) امنیت اطلاعات ۴) افزودن نخستین خودرو. Overlay: `z-[110] bg-background/97`، قابل رد، پرچم `hamrah-khodro-onboarded`.

**صحنه (کادر ۳۵۲×300، پس‌زمینهٔ گرگ‌ومیش `#33455E→#46586F(46%)→#6E6A6A(74%)→#93705A`):**

| لایه | مشخصات دقیق |
|---|---|
| خورشید | دایرهٔ ۶۴px در left 56% top 46px، radialGradient `rgba(255,224,160,.9)→.38→0` |
| ستاره‌ها | ۴ ستاره چشمک‌زن (hk-ob-star 3.2s) در (30,22)(122,12)(214,30)(296,16)، رنگ `#EAEFF5` |
| مناظر | پنجرهٔ top 44px تا bottom 90px؛ **۳ کپی عرض دقیق ۶۴۰px** با انیمیشن **26s linear infinite** (translateX -640px) — بی‌پرش؛ آسمان‌سازهٔ دور جدا با **90s** (پارالاکس) |
| دیوار آجری | ۸۸px؛ repeating-linear-gradient ملات افقی `rgba(94,78,90,.55) 0 1.5px, transparent 1.5px 12px` + عمودی دورهٔ ۳۴px + گرادیان `#4A3D48→#3F333E` |
| گرافیتی «زن زندگی آزادی» | SVG 216×88 در left 84 (اشغال ۸۴–۳۰۰)؛ متن ۱۹٫۵px وزن ۹۰۰ کرم `#F4F1E9`؛ فیلتر `feTurbulence fractalNoise baseFrequency="0.16 0.95" numOctaves=2 seed=11` + `feDisplacementMap scale=3.4` + هالهٔ مه blur 2.6/opacity .3؛ کل گروه `rotate(-2.6°)`؛ قلم‌زن stroke 3.2 + ۳ چکهٔ رنگ |
| تبلیغ دیواری «همراه خودرو» | SVG 92×84 در left 306 (اشغال ۳۰۶–۳۹۸)؛ **هم‌سبک شعار** — فیلتر مشابه seed 29 scale 2.9؛ قاب دست‌پاش کهربایی `#F5A53C` stroke 2.4؛ عنوان کرم ۱۳px `rotate(1.4°)`؛ ماشینک سدان کرم با شیشه‌های کهربایی `#C88A3C` `rotate(-2.4°)`؛ «دفترچهٔ سرویس خودرو» ۶٫۲px؛ «نصب رایگان» ۷٫۲px کهربایی؛ ۴ چکه + ۵ ذرهٔ مه؛ کل `rotate(-2.2°)` |
| چیدمان هر کپی ۶۴۰px | سرو کوچک ۸ | چراغ خیابانی ۶۶ | گرافیتی ۸۴–۳۰۰ | تبلیغ ۳۰۶–۳۹۸ | **گروه نیمکت ۳۹۶–۵۱۴** (سرو پشتی 132px، نیمکت 150px، دختر کتاب‌خوان، دختر همراه، گربه 60px روی زمین در +158) |
| درخت سرو | SVG 60×150؛ ۱۴ ردیف فلک با گرادیان `#41805F→#2E6247→#23503B`؛ تنه `#5E4A34` |
| چراغ خیابانی | حباب ۱۳px `#FFE3A6` با گلو دوتایی + میلهٔ `#2B333E` |
| نیمکت پارک | 150×64؛ پایه‌های خم‌دار `#333B46` + تخته‌ها `#9A6B41/#8F6138` با هایلایت `#C09059` |
| **دو دختر کنار هم** | هر دو SVG نشسته (باسن ۳۶px بالای سطح نشیمن، ساق‌های آویزان). **کتاب‌خوان:** موی بنفش-مشکی `#221B2E` + پنل مو (hk-ob-hair 4.2s ±1.6°) + **۳ تار انیمیت‌شده با فاز متفاوت** (hk-ob-lock-a/b/c: 3.3s/4.5s(delay .7s)/2.5s(delay 1.3s)، چرخش+skewX حول 50% 6%) + تار جلوی سینه (hk-ob-hair-f معکوس) + تارهای رهاشدهٔ معلق (hk-ob-loose: drift+fade 3.4s/4.6s)؛ صورت: ابرو، چشم مژه‌دار، لپ گلی `#E89A8A` opacity .35، لبخند دوتایی؛ بلوز سبزآبی `#4F7F7A` + دامن `#45716D` + کتاب `#F2EADA`. **همراه:** موی بلوطی `#4A3323` + پیرهن آجری `#9C5B54`، دو دست روی پا، سر متمایل |
| **گربهٔ خیابانی** | 64×58 نشسته رو به چپ روی زمین؛ پشم `#E0A66B→#C88A52`؛ دُم حلقه‌زده جلوی پنجه‌ها (stroke 5.4)؛ راه‌راه‌های پُر `#B1723F`؛ گوش مثلثی، چشم آرام، ۴ سبیل `rgba(250,240,225,.75)` |
| **خودروی کلاسیک** | SVG 300×104 عرض ۲۸۵px؛ کلاس hk-ob-car (bob ±2px، 1.9s)؛ بدنه سدان کرم `#F4EEDE→#E9E1CD→#C8BFA8` با کاپوت بلند؛ شیشه‌های مجزا `#54677D→#38485C` + بازتاب مورب؛ کمربند کروم `#D7DEE7`؛ جلوپنجرهٔ کروم + **چراغ گرد روشن** (radial `#FFF6D8→#FFE9A8`) + چراغ عقب `#E2483F`؛ سپرهای کروم؛ **مخروط نور** (hk-ob-beam سوسوی 2.6s) `rgba(255,232,150,.55)→0` تا لبهٔ ۳۰۰؛ چرخ‌ها: تایر `#20242B` + رینگ whitewall `#E8E4D6` + مرکز چرخان **hk-ob-wheel 0.9s** |
| جاده | آسفالت ۷۶px `#2A313B`؛ **خط‌چین وسط** کهربایی `rgba(245,165,36,0.95) 0 32px, transparent 32px 64px` با انیمیشن **2.4s**؛ پیاده‌رو ۱۴px `#4B545F` + کِرِب با درزهای ۴۶px |
| reduced-motion | همهٔ hk-ob-* و hk-onboard-* → `animation: none` |

---

## ۱۲) لایهٔ اندروید

- **MainActivity:** WebView تمام‌صفحه (`setJavaScriptEnabled`, `setDomStorageEnabled`, `setAllowFileAccess`)؛ لود از **AssetServer** روی دامنهٔ امن `https://appassets.androidplatform.net/index.html` (نه file://)؛ دومی bridge: **`"AndroidApi"`** (ApiBridge — data.json محلی، نوتیف، saveBackup به `Download/HamrahKhodro/`، pickRestoreFile، exitApp) و **`"AndroidCloud"`** (CloudBridge بخش ۱۰).
- **AuthActivity** (exported, BROWSABLE, `scheme="com.zai.hamrahkhodro"`) → روتر handleRedirect (مسیر `fbcallback` → FbSession؛ بقیه → Drive قدیمی `oauth2callback`).
- **BRIDGE_INIT (v3.7):** اسکریپتی که بلافاصله بعد از `<head>` در index.html تزریق می‌شود — `window.fetch` را می‌پوشاند: `/api/*` → `AndroidApi.api(method,url,body)` (جواب `{status,body}`) → Response ساختگی؛ + polyfill نوتیفیکیشن به پل اندروید.
- **CrashGuard:** استثناهای مهارنشده → `files/last-crash.txt` + دیالوگ فارسی به‌جای کرش خاموش.
- **دادهٔ اولیه:** `assets/seed.json` (فقط کاتالوگ برندها/انواع سرویس — بدون رکورد) → `data.json` در `getFilesDir()`.
- **امضا:** keystore داخل پروژه (`android-keys/hk-release.keystore`، PKCS12، alias `hamrah`، رمز `hamrah-khodro-2026`)؛ SHA-1 `08:BE:55:6D:7D:96:5F:E7:98:18:16:98:00:CC:B2:E1:66:05:20:47` — **از v3.8.0 تاکنون یکسان** → ارتقای مستقیم بدون حذف (داده‌ها و حساب متصل حفظ می‌شوند). اگر یک‌روز keytool دوباره ساخته شد، همه باید حذف/نصب مجدد کنند — هرگز نساز مگر از بین رفته باشد.

## ۱۳) خط بیلد APK (بدون Gradle)

**ابزارها** (پوشهٔ `/home/z/apk-build/`): `bt/android-14` (build-tools r34 از `https://dl.google.com/android/repository/build-tools_r34-linux.zip` — شامل aapt/aapt2/d8/zipalign/apksigner) + `tools/` (از Maven Central: `org.eclipse.jdt:ecj:3.36.0`، `org.smali:{smali,baksmali,dexlib2,util}:2.5.2`، `com.beust:jcommander:1.82`، `com.google.guava:guava:22.0`، `org.antlr:antlr-runtime:3.5.3` — کپی همین‌ها در ریشهٔ پروژه هم هست).

1. **بیلد وب:** `apk-build/build-web-only.sh` — کپی ایزوله (حذف node_modules و hardlink دوباره) → پچ layout (حذف Google Fonts، آیکون `/logo.svg`) → `rm -rf src/app/api` + `next.config.ts` با `output:"export"` → `bunx next build` → `out/` → تزریق BRIDGE_INIT در index.html → `www-final` + همگام‌سازی با شبیه‌ساز.
2. **بیلد dex (فقط اگر جاوا عوض شد):** `apk-build/build-dex-v395.sh` — ecj (source/target 8) روی `asyncsrc395/**` (کلاس‌های واقعی + استاب‌های کامپایلِ android.*/org.json) → d8 (`--release --min-api 21` فقط روی `com/**`) → baksmali → `splice_fb_v395.py` (۸ متد fb* را در CloudBridge.smali واقعی جایگزین/اضافه می‌کند + کلاس‌های FbSession/FbReq/FbDeliver را کپی کامل؛ پایه = dex استخراج‌شده از APK v3.9.4 که رنیم handleRedirect→handleRedirectDrive از قبل دارد) → smali assemble → `classes-v395.dex` (105,472 بایت — تولید مجدد اثبات‌شده: diff اسمبلی صفر).
3. **بسته‌بندی:** `apk-build/build-apk-v396.sh` — پایهٔ **v3.9.0** (هرگز حذف نشود!) → unzip → حذف META-INF → جایگزینی classes.dex + assets/www → جراحی مانیفست با `patch_manifest_v396.py` (**ویرایش باینری AXML هم‌طول**: versionName کاراکتر پنجم 3.9.0→X، versionCode داخل INT_DEC — بدون تغییر طول هیچ chunk) → `zip -r -n .arsc:.woff2` (**Stored برای arsc و فونت‌ها — الزام اندروید ۱۱+**) → `zipalign -f -p 4` → `apksigner sign --ks ... --ks-key-alias hamrah` → verify با aapt badging.
4. **توزیع:** `scripts/place-apk.sh <apk> <ver>` — کپی به ریشه/public/files/download + چرخش ۳ نسخهٔ آخر.
5. **شناسهٔ نسخه:** versionName = MAJOR.MINOR.PATCH (پچ هم‌طول!)، versionCode افزایشی.

**درس‌های خط بیلد:** ① اسمبلی دست‌نویس smali → VerifyError روی گوشی واقعی؛ همیشه ecj+d8. ② `resources.arsc` فشرده = رد نصب روی اندروید ۱۱+. ③ تغییر طول رشتهٔ مانیفست = جابه‌جایی همهٔ آفست‌ها؛ فقط هم‌طول. ④ Turbopack با symlink مشکل دارد → hardlink.

## ۱۴) شبیه‌ساز E2E (`mini-services/apk-mock` — پورت 3031)

- سرویس bun (`bun --hot index.ts`) که همان `www-final` نهایی را سرو می‌کند + **SHIM** بعد از `<head>` هر html تزریق می‌کند: `AndroidApi` کامل (CRCD در-حافظه + seed از seed.json) + `AndroidCloud` با قرارداد بایت‌به‌بایت گوگل (پیام‌های خطای عین گوگل).
- **سناریوها:** `fbSchemeDisabled/fbAuthApiDisabled/fbApiDisabled/fbRulesDenied/fbNoDatabase/fbCodeConsumed/offline/latency` + `fbEnableAll/reset/reinstallApp/wipeAppData/completeAuth/denyAuth/fbSeedDoc` + شمارنده‌های `__OPENED_URLS/__RESTORE_COUNT/__BACKUP_SAVED/__EXIT_CALLED/__hkFrames`.
- دسترسـی از پنل عمومی: `/?XTransformPort=3031` (Caddyfile).
- **سناریوها را بعد از reload صفحه ست کن** (شیم تازه تزریق می‌شود) و `completeAuth()` جایگزین ورود واقعی گوگل است.
- **درس:** کوتیشن تو-در-تو در رشتهٔ JSON سناریو = SyntaxError کل شیم؛ بک‌اسلش تکی داخل template literal = خطای regex.

## ۱۵) راه‌اندازی فایربیس از صفر

### ۱۵.۱ راه خودکار (توصیه‌شده)
```
bun run scripts/firebase-new-project.ts config/service-account.json           # راه‌اندازی همین پروژه از صفر
bun run scripts/firebase-new-project.ts config/service-account.json --create  # تلاش برای ساخت پروژهٔ جدید
bun run scripts/firebase-new-project.ts config/service-account.json --apply   # + پچ خودکار سورس
```
این اسکریپت همه‌چیز را خودکار انجام می‌دهد: فعال‌سازی APIها → ساخت اپ اندروید + ثبت SHA-1 → خواندن google-services.json جدید → فعال‌سازی ورود گوگل (API + پروب زنده) → بررسی Custom URI Scheme (پروب واقعی 302) → ساخت دیتابیس (default) → انتشار قوانین (+ تلاش IAM خودکار) → **تست E2E مسیر واقعی کاربر** (نشست → نوشتن/خواندن سند خود → ۴۰۳ سند دیگری) → ذخیرهٔ مقادیر در `config/new-project-values.json` → با `--apply` پچ `FbSession.java` (CLIENT_ID/API_KEY/URL دیتابیس) + `firebase-config.ts` + `config/google-services.json`.

**کلید از کجا؟** کنسول Firebase → ⚙️ Project settings → Service accounts → Generate new private key. (توجه: سرویس‌حساب یک پروژه معمولاً اجازهٔ «ساخت پروژهٔ جدید» ندارد → پروژهٔ جدید را در کنسول بساز (۳۰ ثانیه) و کلید آن را بده.)

### ۱۵.۲ راه دستی (۶ قدم — معادل شیت داخل برنامه)
1. **پروژه** در console.firebase.google.com بساز (بدون Analytics هم می‌شود).
2. **Identity Toolkit API** فعال: `console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=<pid>`
3. **Cloud Firestore API** فعال + **دیتابیس (default)** بساز (منطقهٔ مثلاً nam5) — «Create database» در کنسول فایربیس.
4. **ورود با گوگل** فعال: Authentication → Sign-in method → Google → Enable (+ ایمیل پشتیبانی).
5. **اپ اندروید** با پکیج `com.zai.hamrahkhodro` + SHA-1 امضا ثبت کن و در Google Cloud Console → Credentials → کلاینت اندروید → **Enable custom URI scheme** را روشن کن.
6. **قوانین** بخش ۱۰.۵ را در Firestore → Rules منتشر کن. — ⚠️ «مراحل Gradle» ویزاردِ Add app اصلاً لازم نیست (برنامه REST-محور است).

### ۱۵.۳ وضعیت تأییدشدهٔ پروژهٔ فعلی hamrahprj (سپتامبر ۲۰۲۶)
هر ۶ مورد بالا با پراب‌های واقعی سبز تأیید شده (APIها فعال، provider گوگل فعال، کلاینت + URI scheme سالم با 302، دیتابیس موجود، قوانین درست، تست E2E کاربر موفق) — **سرور مشکل ندارد**؛ اگر خطای «ورود به سرور پشتیبان انجام نشد» دیدی اول مطمئن شو نسخهٔ v3.9.4+ نصب است (نسخه‌های قدیمی‌تر باگ uri= داشتند) و صفحهٔ ورود گوگل در مرورگر سیستم (نه درون برنامه) باز می‌شود.

## ۱۶) تاریخچهٔ نسخه‌ها + درس‌ها

| نسخه | نکتهٔ کلیدی |
|---|---|
| v2.x–v3.2 | اپ تک‌لایه وب + بستهٔ APK اولیه (keystore اولیه از دست رفت) |
| v3.8.x | پل ابری Drive + keystore پایدار درون پروژه؛ v3.8.7 VerifyError (smali دست‌نویس) → v3.8.8 با کد بازتولیدشده |
| v3.9.0 | سینک فایربیس برای همه؛ پایهٔ بیلد همهٔ نسخه‌های بعدی |
| v3.9.1–3.9.3 | ⚠️ باگ `uri=` → ورود همیشه MISSING_REQUEST_URI |
| v3.9.4 | ✅ رفع ریشه با requestUri + تصاحب اتمیک کد + صحنهٔ جدید |
| v3.9.5 | fbProbeAsync + شیت گام‌به‌گام + دکمهٔ لغو اتصال |
| v3.9.6 | تشخیص «دیتابیس ساخته نشده» + تبلیغ اسپری + دخترهای بهتر؛ ریشهٔ نهایی (دیتابیس + نسخه‌های قدیمی) بسته شد |

**درس‌های کلیدی:** قرارداد REST را با پاسخ واقعی سرور تطبیق بده نه حدس؛ پیام خام گوگل را تا لایهٔ UI پاس بده تا کارت فارسی دقیق بسازی؛ هر لایه را با شبیه‌سازِ قرارداد-دقیق تست کن؛ سرویس‌حساب فایربیس اجازهٔ انتشار release قوانین ندارد (ruleset می‌سازد ولی release نه — راه‌حل: کنسول یا IAM)؛ شناسهٔ سند با __ شروع نشود؛ دیتابیس Firestore با API ساخته‌شدن «قوانین بستهٔ» پیش‌فرض دارد.

## ۱۷) چک‌لیست بازسازی گام‌به‌گام (برای AI)

1. Next.js 16 + TS + Tailwind 4 + shadcn/ui scaffolding؛ `lang="fa" dir="rtl"` + Vazirmatn.
2. `src/lib/types.ts` + `persian.ts` را بایت‌به‌بایت از سورس منتقل کن (قلب پروژه‌اند).
3. Prisma schema + ۱۶ API route (قراردادهای بخش ۶ + `/api/backup|restore|stats/files`).
4. UI: page.tsx (state مرکزی + ۴ تب) + BottomNav/TabSwipe/PageHeader/ConfirmDialog/BottomSheet(framer-motion)/BusyIndicator + فرم‌ها.
5. Onboarding + صحنهٔ بخش ۱۱ (از سورس کپی کن — مختصات حساس‌اند).
6. پل: BRIDGE_INIT + قرارداد fb* بخش ۱۰ + FbSession.java از `apk-build/asyncsrc395`.
7. شبیه‌ساز apk-mock را با سناریوها بازسازی کن و E2E بگیر.
8. فایربیس را با بخش ۱۵ راه بینداز؛ E2E کاربر (signInWithCustomToken → سند → ایزوله‌بودن) اجرا کن.
9. بیلد APK با بخش ۱۳؛ امضا با همان keystore (داخل زیپ).

## ۱۸) نقشهٔ زیپ (چیزی که کنار این سند است)

```
src/                    ← کل سورس وب (page.tsx + components/app/** + lib/** + app/api/**)
apk-build/              ← asyncsrc395 (جاوا) + اسکریپت‌های بیلد + splice + patch_manifest + dex نهایی
android-keys/           ← hk-release.keystore (رمز در بخش ۱)
config/                 ← google-services.json (hamrahprj) + TEMPLATE کلید + new-project-values.json
docs/                   ← firebase-setup.md / google-cloud-setup.md / publish-guide.md / commands-history.md
scripts/                ← firebase-new-project.ts / firebase-admin-setup.ts / firebase-diag.ts /
                          firebase-e2e-user.ts / place-apk.sh / dump-apk-seed.ts
mini-services/apk-mock/ ← شبیه‌سور E2E (پورت 3031) + www-final (بیلد استاتیک نهایی)
prisma/                 ← schema + seed
public/                 ← app-home.html / privacy.html / logo.svg (+ files/ در پروژهٔ کامل)
*.jar                   ← ابزار بیلد (ecj + smali + …) — build-tools جدا از dl.google.com دانلود شود
hamrah-khodro-v3.9.0.apk  ← ⚠️ پایهٔ بیلد — هرگز حذف نشود
hamrah-khodro-v3.9.6.apk  ← آخرین نسخهٔ ساخته‌شده
MANIFEST.json / Caddyfile / package.json / …
```

---
*این سند هم‌زمان با v3.9.6 (شهریور ۱۴۰۵ / سپتامبر ۲۰۲۶) تهیه شده و با سورسِ همین بستهٔ زیب همگام (sync) است.*
