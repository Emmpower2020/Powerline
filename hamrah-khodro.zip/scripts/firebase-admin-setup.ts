/**
 * راه‌اندازی خودکار سرور Firebase برای «همراه خودرو» (اجرای ادمین — فقط یک‌بار)
 * ─────────────────────────────────────────────────────────────────────────────
 *  این اسکریپت روی سندباکس اجرا می‌شود و کل تنظیمات سرور گوگل را کامل می‌کند:
 *
 *    ۱) توکن ادمین از Service Account (JWT امضا‌شده RS256 → oauth2.googleapis.com)
 *    ۲) بررسی وضعیت APIها (identitytoolkit / firestore) از Service Usage API
 *    ۳) بررسی پیکربندی ورود (Identity Toolkit Admin v2 — ارائه‌دهندهٔ گوگل)
 *    ۴) ساخت دیتابیس Firestore «(default)» اگر وجود نداشته باشد (+ پول عملیات)
 *    ۵) انتشار قوانین امنیتی پیشنهادی (هر کاربر فقط سند خودش)
 *    ۶) تست واقعی: نوشتن/خواندن/حذف سندِ probe در hamrah_users
 *    ۷) گزارش کامل فارسی
 *
 *  اجرا:  bun run scripts/firebase-admin-setup.ts [مسیر-کلید]
 *  کلید:  config/service-account.json  (پیش‌فرض)
 *         ← کنسول Firebase → ⚙️ Project settings → Service accounts →
 *            «Generate new private key» → دانلود JSON
 */

import * as fs from "node:fs";
import * as crypto from "node:crypto";

/* ────────────── ابزارها ────────────── */

const b64url = (buf: Buffer | string): string =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

function log(ok: boolean, msg: string): void {
  console.log(`${ok ? "  ✓" : "  ✗"}  ${msg}`);
}

function step(title: string): void {
  console.log(`\n■ ${title}`);
}

async function rest(
  method: string,
  url: string,
  token: string,
  body?: unknown
): Promise<{ status: number; text: string; json: any | null }> {
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, text, json };
}

/* ────────────── کلید سرویس‌حساب ────────────── */

interface ServiceAccount {
  type: string;
  project_id: string;
  private_key: string;
  client_email: string;
  token_uri: string;
}

const keyPath = process.argv[2] ?? "config/service-account.json";
if (!fs.existsSync(keyPath)) {
  console.error(`✗ فایل کلید پیدا نشد: ${keyPath}`);
  console.error(`  کلید را از کنسول Firebase → ⚙️ Project settings → Service accounts →`);
  console.error(`  «Generate new private key» دانلود و در همین مسیر قرار دهید.`);
  process.exit(1);
}

const sa = JSON.parse(fs.readFileSync(keyPath, "utf8")) as ServiceAccount;
if (!sa.private_key || !sa.client_email || !sa.project_id) {
  console.error("✗ فایل کلید ناقص است (private_key / client_email / project_id لازم است)");
  process.exit(1);
}
const PID = sa.project_id;
console.log(`\n╔══════════════════════════════════════════════════════════════╗`);
console.log(`║  راه‌اندازی خودکار سرور Firebase — پروژهٔ «${PID}»`);
console.log(`╚══════════════════════════════════════════════════════════════╝`);
console.log(`  سرویس‌حساب: ${sa.client_email}`);

/* ────────────── ۱) توکن ادمین ────────────── */

step("۱) ساخت توکن ادمین از Service Account");

const now = Math.floor(Date.now() / 1000);
const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
const claims = b64url(
  JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/cloud-platform https://www.googleapis.com/auth/datastore",
    aud: sa.token_uri ?? "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  })
);
const signer = crypto.createSign("RSA-SHA256");
signer.update(`${header}.${claims}`);
signer.end();
const signature = b64url(signer.sign(sa.private_key));
const jwt = `${header}.${claims}.${signature}`;

let accessToken = "";
{
  const res = await fetch(sa.token_uri ?? "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }).toString(),
  });
  const j: any = await res.json().catch(() => null);
  if (!res.ok || !j?.access_token) {
    log(false, `توکن گرفته نشد (HTTP ${res.status}): ${(j?.error_description ?? j?.error ?? res.statusText).slice(0, 200)}`);
    process.exit(1);
  }
  accessToken = j.access_token;
  log(true, `توکن ادمین گرفته شد (اعتبار ${j.expires_in ?? 3600}s)`);
}

/* ────────────── ۲) وضعیت APIها ────────────── */

step("۲) بررسی وضعیت APIهای پروژه");

async function checkService(serviceId: string, label: string): Promise<boolean> {
  const r = await rest("GET", `https://serviceusage.googleapis.com/v1/projects/${PID}/services/${serviceId}`, accessToken);
  const state = r.json?.state ?? "UNKNOWN";
  if (state === "ENABLED") {
    log(true, `${label} — فعال`);
    return true;
  }
  // ⭐ fallback زنده: سرویس‌حساب ادمین فایربیس اجازهٔ خواندن serviceusage ندارد —
  //    خودِ endpoint را زنده می‌پرابیم (هر پاسخ HTTP = API فعال)
  if (r.status === 403) {
    if (serviceId === "identitytoolkit.googleapis.com") {
      try {
        const cfg0 = await rest("GET", `https://identitytoolkit.googleapis.com/admin/v2/projects/${PID}/config`, accessToken);
        if (cfg0.status === 200) {
          log(true, `${label} — فعال (پراب زنده: admin config پاسخ داد)`);
          return true;
        }
      } catch { /* fallthrough */ }
    } else {
      try {
        const res = await fetch(`https://firestore.googleapis.com/v1/projects/${PID}/databases`);
        if (res.status !== 404 && !(res.status === 403 && (await res.text()).includes("has not been used"))) {
          log(true, `${label} — فعال (پراب زنده: endpoint پاسخ داد)`);
          return true;
        }
      } catch { /* fallthrough */ }
    }
  }
  log(false, `${label} — ${state}`);
  // تلاش برای فعال‌سازی خودکار
  console.log(`     … فعال‌سازی خودکار ${serviceId} …`);
  const en = await rest("POST", `https://serviceusage.googleapis.com/v1/projects/${PID}/services/${serviceId}:enable`, accessToken, {});
  if (en.status >= 200 && en.status < 300) {
    // پول تا حداکثر ۹۰ ثانیه
    for (let i = 0; i < 30; i++) {
      await new Promise((r2) => setTimeout(r2, 3000));
      const q = await rest("GET", `https://serviceusage.googleapis.com/v1/projects/${PID}/services/${serviceId}`, accessToken);
      if (q.json?.state === "ENABLED") {
        log(true, `${label} — با موفقیت فعال شد`);
        return true;
      }
    }
  }
  log(false, `فعال‌سازی ${serviceId} کامل نشد: ${en.text.slice(0, 200)}`);
  return false;
}

const identityOk = await checkService("identitytoolkit.googleapis.com", "Identity Toolkit API (ورود)");
const firestoreOk = await checkService("firestore.googleapis.com", "Cloud Firestore API (داده)");

/* ────────────── ۳) پیکربندی ورود ────────────── */

step("۳) بررسی پیکربندی ورود (ارائه‌دهندهٔ گوگل)");
let googleProviderOk = false;
{
  // ⭐ پراب زنده با همان قرارداد دقیق برنامه (FbSession.signInWithIdp):
  //    INVALID_IDP_RESPONSE = ارائه‌دهندهٔ گوگل فعال است (توکن ساختگی رد شد)
  //    OPERATION_NOT_ALLOWED / provider id is not enabled = غیرفعال
  const cfg0 = await rest("GET", `https://identitytoolkit.googleapis.com/admin/v2/projects/${PID}/config`, accessToken);
  const apiKey: string = cfg0.json?.client?.apiKey ?? "";
  if (apiKey) {
    const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        postBody: "providerId=google.com&id_token=FAKE.JWT.TOKEN&uri=https://localhost",
        requestUri: "https://localhost",
        returnSecureToken: true,
      }),
    });
    const txt = await res.text().catch(() => "");
    if (/INVALID_IDP_RESPONSE|Unable to (parse|verify)/i.test(txt)) {
      log(true, "ورود با حساب گوگل فعال است (پراب زندهٔ قرارداد برنامه ✓)");
      googleProviderOk = true;
    } else {
      log(false, `پاسخ پراب ورود گوگل غیرمنتظره بود: ${txt.slice(0, 180)}`);
    }
  } else {
    log(false, "کلید API از پیکربندی خوانده نشد — پراب ورود انجام نشد");
  }
}

/* ────────────── ۴) ساخت دیتابیس Firestore ────────────── */

step("۴) بررسی/ساخت دیتابیس Firestore");
let dbReady = false;
{
  const list = await rest("GET", `https://firestore.googleapis.com/v1/projects/${PID}/databases`, accessToken);
  const dbs: any[] = list.json?.databases ?? [];
  const def = dbs.find((d: any) => String(d.name ?? "").endsWith("/(default)"));
  if (def) {
    log(true, `دیتابیس «(default)» از قبل موجود است (${def.type ?? "?"} / ${def.locationId ?? "?"})`);
    dbReady = true;
  } else {
    log(false, "دیتابیس «(default)» وجود ندارد — همین الان ساخته می‌شود…");
    // POST /v1/projects/{pid}/databases?databaseId=(default)
    const create = await rest(
      "POST",
      `https://firestore.googleapis.com/v1/projects/${PID}/databases?databaseId=${encodeURIComponent("(default)")}`,
      accessToken,
      {
        type: "FIRESTORE_NATIVE",
        locationId: "nam5",
        deleteProtectionState: "DELETE_PROTECTION_DISABLED",
        pointInTimeRecoveryEnablement: "POINT_IN_TIME_RECOVERY_DISABLED",
      }
    );
    if (create.status >= 200 && create.status < 300 && create.json) {
      // عملیات طولانی — پول تا حداکثر ۴ دقیقه
      const opName: string = create.json.name ?? "";
      log(true, `درخواست ساخت ثبت شد — در حال آماده‌سازی (منطقهٔ nam5)…`);
      for (let i = 0; i < 80; i++) {
        await new Promise((r2) => setTimeout(r2, 3000));
        const op = await rest("GET", `https://firestore.googleapis.com/v1/${opName}`, accessToken);
        if (op.json?.done) {
          if (op.json?.error) {
            log(false, `ساخت دیتابیس خطا داد: ${JSON.stringify(op.json.error).slice(0, 250)}`);
          } else {
            log(true, "دیتابیس «(default)» ساخته شد ✓");
            dbReady = true;
          }
          break;
        }
        process.stdout.write(`     … ${3 * (i + 1)}s\r`);
      }
      if (!dbReady && !create.json?.error) {
        // شاید هنوز در جریان است — دوباره لیست را چک کن
        const l2 = await rest("GET", `https://firestore.googleapis.com/v1/projects/${PID}/databases`, accessToken);
        const d2 = (l2.json?.databases ?? []).find((d: any) => String(d.name ?? "").endsWith("/(default)"));
        if (d2) {
          log(true, "دیتابیس «(default)» ساخته شد ✓");
          dbReady = true;
        } else {
          log(false, "عملیات ساخت هنوز کامل نشده — چند دقیقه بعد دوباره اجرا کنید");
        }
      }
    } else {
      log(false, `ساخت دیتابیس ناموفق (HTTP ${create.status}): ${create.text.slice(0, 300)}`);
    }
  }
}

/* ────────────── ۵) قوانین امنیتی ────────────── */

step("۵) قوانین امنیتی (هر کاربر فقط سند خودش)");
let rulesOk = false;
{
  const RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write:
        if request.auth != null
        && request.auth.uid == uid;
    }
  }
}`;

  // ⭐ ۵-۰) قوانین فعلی را بخوان — اگر همین است، نیازی به انتشار مجدد نیست
  //    (انتشارِ release نیاز به اجازهٔ firebaserules.releases.* دارد که سرویس‌حساب
  //     فایربیس ندارد؛ اما خواندن ruleset اجازه دارد)
  {
    const rel = await rest("GET", `https://firebaserules.googleapis.com/v1/projects/${PID}/releases/cloud.firestore`, accessToken);
    if (rel.status === 200 && rel.json?.rulesetName) {
      const cur = await rest("GET", `https://firebaserules.googleapis.com/v1/${rel.json.rulesetName}`, accessToken);
      const files: any[] = cur.json?.source?.files ?? [];
      const content: string = String(files.find((f: any) => f.name === "firestore.rules")?.content ?? "");
      // مقایسهٔ معنایی: hamrah_users + request.auth.uid == uid
      const sameRules =
        /hamrah_users\/\{uid\}/.test(content) &&
        /request\.auth\s*!=\s*null/.test(content) &&
        /request\.auth\.uid\s*==\s*uid/.test(content) &&
        /allow\s+read\s*,\s*write/.test(content);
      if (sameRules) {
        log(true, `قوانین فعلی همین است که برنامه می‌خواهد ✓ (${rel.json.rulesetName})`);
        rulesOk = true;
      } else {
        log(false, `قوانین فعلی متفاوت است:\n${content.slice(0, 500)}`);
      }
    } else {
      log(false, "انتشار قوانین (release) پیدا نشد — دیتابیس بدون قوانین شروع شده");
    }
  }

  // ۵-۱) فقط اگر قوانین درست نبود: ruleset تازه بساز و منتشر کن
  if (!rulesOk) {
    const rs = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${PID}/rulesets`, accessToken, {
      source: { files: [{ name: "firestore.rules", content: RULES }] },
    });
    if (rs.status >= 200 && rs.status < 300 && rs.json?.name) {
      const rulesetName: string = rs.json.name;
      log(true, `قوانین جدید ساخته شد: ${rulesetName}`);
      // ۵-۲) انتشار روی cloud.firestore — اول POST (ایجاد) بعد PATCH (به‌روزرسانی)
      const releaseBody = { name: `projects/${PID}/releases/cloud.firestore`, rulesetName };
      const cre = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${PID}/releases`, accessToken, releaseBody);
      if (cre.status >= 200 && cre.status < 300) {
        log(true, "قوانین منتشر شد (انتشار جدید)");
        rulesOk = true;
      } else {
        const upd = await rest(
          "PATCH",
          `https://firebaserules.googleapis.com/v1/projects/${PID}/releases/cloud.firestore`,
          accessToken,
          releaseBody
        );
        if (upd.status >= 200 && upd.status < 300) {
          log(true, "قوانین منتشر شد (به‌روزرسانی انتشار موجود)");
          rulesOk = true;
        } else {
          log(false, `انتشار قوانین ناموفق (${cre.status}/${upd.status}): ${cre.text.slice(0, 250)}`);
          console.log("   ↳ اگر قوانین فعلی درست کار می‌کنند (تست گام ۶ ✓) همین حالت کافی است.");
        }
      }
    } else {
      log(false, `ساخت ruleset ناموفق (HTTP ${rs.status}): ${rs.text.slice(0, 250)}`);
    }
  }
}

/* ────────────── ۶) تست واقعی سند ────────────── */

step("۶) تست واقعی: نوشتن/خواندن/حذف سند");
let ioOk = false;
if (dbReady) {
  // ⭐ شناسهٔ سند نباید با __ شروع شود (رزرو است)
  const docUrl = `https://firestore.googleapis.com/v1/projects/${PID}/databases/(default)/documents/hamrah_users/setup_probe`;
  const w = await rest("PATCH", docUrl, accessToken, {
    fields: { probe: { stringValue: `ok-${new Date().toISOString()}` }, by: { stringValue: "firebase-admin-setup" } },
  });
  if (w.status >= 200 && w.status < 300) {
    log(true, "نوشتن سند تست موفق");
    const rd = await rest("GET", docUrl, accessToken);
    log(rd.status === 200, `خواندن سند تست (HTTP ${rd.status})`);
    const del = await rest("DELETE", docUrl, accessToken);
    log(del.status >= 200 && del.status < 300, `حذف سند تست (HTTP ${del.status})`);
    ioOk = rd.status === 200 && del.status < 300;
  } else {
    log(false, `نوشتن سند تست ناموفق (HTTP ${w.status}): ${w.text.slice(0, 250)}`);
  }
}

/* ────────────── ۷) گزارش ────────────── */

console.log(`\n╔════════════════════ گزارش نهایی ════════════════════`);
console.log(`║  Identity Toolkit API      : ${identityOk ? "✓ فعال" : "✗"}`);
console.log(`║  Cloud Firestore API       : ${firestoreOk ? "✓ فعال" : "✗"}`);
console.log(`║  ارائه‌دهندهٔ گوگل          : ${googleProviderOk ? "✓ فعال" : "✗"}`);
console.log(`║  دیتابیس (default)          : ${dbReady ? "✓ موجود" : "✗ ساخته نشد"}`);
console.log(`║  قوانین امنیتی              : ${rulesOk ? "✓ درست" : "✗"}`);
console.log(`║  تست نوشتن/خواندن           : ${ioOk ? "✓ موفق" : "✗"}`);
console.log(`╚════════════════════════════════════════════════════╝`);

if (identityOk && firestoreOk && googleProviderOk && dbReady && rulesOk && ioOk) {
  console.log(`\n✅ سرور پشتیبان کاملاً آماده است — در گوشی نسخهٔ v3.9.6 برنامه را نصب کنید و`);
  console.log(`   از «تنظیمات ← پشتیبان‌گیری و بازیابی ← اتصال با حساب گوگل» وارد شوید.`);
} else {
  console.log(`\n⚠ بعضی مراحل کامل نشد — متن مراحل ✗ را بفرستید تا بررسی شود.`);
}
