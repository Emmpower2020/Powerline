/**
 * تست E2E نهایی — دقیقاً مسیر برنامهٔ واقعی:
 *   custom token (امضای Service Account) → signInWithCustomToken → idToken کاربر
 *   → Firestore REST با Bearer idToken (قوانین امنیتی اعمال می‌شوند)
 *   ✓ نوشتن سند خودِ کاربر    ✓ خواندن سند خود    ✗ نوشتن سند دیگران (باید 403)
 * اجرا: bun run scripts/firebase-e2e-user.ts config/service-account.json
 */
import * as fs from "node:fs";
import * as crypto from "node:crypto";

const b64url = (buf: Buffer | string): string =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

const sa = JSON.parse(fs.readFileSync(process.argv[2] ?? "config/service-account.json", "utf8")) as {
  project_id: string; private_key: string; client_email: string; token_uri: string;
};
const PID = sa.project_id;
const API_KEY = "AIzaSyDitRMguD0DVjqiMxNCbVPuPS0s0D-7uZk"; // همان کلید تعبیه‌شدهٔ v3.9.6

function signJwt(payload: object): string {
  const h = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const c = b64url(JSON.stringify(payload));
  const s = crypto.createSign("RSA-SHA256");
  s.update(`${h}.${c}`);
  s.end();
  return `${h}.${c}.${b64url(s.sign(sa.private_key))}`;
}

/* ── ۱) نشست کاربر آزمایشی با signInWithCustomToken ── */
const TEST_UID = `hk_e2e_${Date.now().toString(36)}`;
const customToken = signJwt({
  uid: TEST_UID,
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + 3600,
  // ⭐ قالب رسمی admin SDK v14 — Identity Platform audience
  aud: "https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit",
  iss: sa.client_email,
  sub: sa.client_email,
});

const signinRes = await fetch(
  `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${API_KEY}`,
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  }
);
const signinJson: any = await signinRes.json().catch(() => null);
console.log(`── ۱) signInWithCustomToken: HTTP ${signinRes.status}`);
if (!signinRes.ok || !signinJson?.idToken) {
  console.log(JSON.stringify(signinJson, null, 2).slice(0, 500));
  process.exit(1);
}
const idToken = signinJson.idToken as string;
// localId ممکن است مستقیم نیاید — از claim خودِ توکن بخوان
const tokenClaims = JSON.parse(
  Buffer.from(idToken.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString()
) as { sub?: string; user_id?: string };
const localId = (signinJson.localId ?? tokenClaims.user_id ?? tokenClaims.sub ?? "") as string;
console.log(`   ✓ نشست کاربر ساخته شد (uid=${localId}) — توکن ${idToken.length} کاراکتر\n`);

/* ── درخواست Firestore با توکن کاربر (قوانین اعمال می‌شوند) ── */
async function userReq(method: string, path: string, body?: unknown) {
  const res = await fetch(`https://firestore.googleapis.com/v1/projects/${PID}/databases/(default)/documents${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${idToken}`,
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, text: await res.text() };
}

/* ── ۲) نوشتن سند خودِ کاربر (همان کاری که برنامه می‌کند) ── */
{
  const body = {
    fields: {
      data: { stringValue: JSON.stringify({ vehicles: [], records: [], reminders: [] }) },
      updatedAt: { timestampValue: new Date().toISOString() },
    },
  };
  const r = await userReq("PATCH", `/hamrah_users/${localId}`, body);
  console.log(`── ۲) نوشتن سند خودِ کاربر (PATCH hamrah_users/${localId}): HTTP ${r.status} ${r.status === 200 ? "✓" : r.text.slice(0, 200)}`);
}

/* ── ۳) خواندن سند خود ── */
{
  const r = await userReq("GET", `/hamrah_users/${localId}`);
  const hasData = r.status === 200 && r.text.includes('"data"');
  console.log(`── ۳) خواندن سند خود: HTTP ${r.status} ${hasData ? "✓ (فیلد data موجود)" : r.text.slice(0, 200)}`);
}

/* ── ۴) خواندن سند کاربرِ دیگر — باید 403 (قوانین) ── */
{
  const r = await userReq("GET", "/hamrah_users/somebody_else");
  console.log(`── ۴) خواندن سند کاربر دیگر: HTTP ${r.status} ${r.status === 403 ? "✓ (قوانین جلویش را گرفتند)" : "✗ انتظار 403 بود! " + r.text.slice(0, 150)}`);
}

/* ── ۵) نوشتن سند کاربرِ دیگر — باید 403 ── */
{
  const r = await userReq("PATCH", "/hamrah_users/somebody_else", { fields: { data: { stringValue: "hack" } } });
  console.log(`── ۵) نوشتن سند کاربر دیگر: HTTP ${r.status} ${r.status === 403 ? "✓ (قوانین جلویش را گرفتند)" : "✗ انتظار 403 بود! " + r.text.slice(0, 150)}`);
}

/* ── ۶) پاک‌سازی سند آزمایشی ── */
{
  const r = await userReq("DELETE", `/hamrah_users/${localId}`);
  console.log(`── ۶) پاک‌سازی سند آزمایشی: HTTP ${r.status} ${r.status < 300 ? "✓" : r.text.slice(0, 150)}`);
}

/* ── ۷) بدون توکن — باید 403 ── */
{
  const res = await fetch(`https://firestore.googleapis.com/v1/projects/${PID}/databases/(default)/documents/hamrah_users?pageSize=1`);
  console.log(`── ۷) لیست اسناد بدون توکن: HTTP ${res.status} ${res.status === 403 ? "✓ (بی‌احراز هیچ‌چیز لو نمی‌رود)" : "✗ " + (await res.text()).slice(0, 150)}`);
}

console.log(`\n=== تست E2E مسیر کاربر کامل شد ===`);
