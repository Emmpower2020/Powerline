/**
 * دیاگ نهایی سرور فایربیس hamrahprj — با خروجی کامل خطاها
 * اجرا: bun run scripts/firebase-diag.ts config/service-account.json
 */
import * as fs from "node:fs";
import * as crypto from "node:crypto";

const b64url = (buf: Buffer | string): string =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

const keyPath = process.argv[2] ?? "config/service-account.json";
const sa = JSON.parse(fs.readFileSync(keyPath, "utf8")) as {
  project_id: string; private_key: string; client_email: string; token_uri: string;
};
const PID = sa.project_id;

async function rest(method: string, url: string, token: string, body?: unknown) {
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try { json = JSON.parse(text); } catch { /* noop */ }
  return { status: res.status, text, json };
}

/* ── توکن ── */
const now = Math.floor(Date.now() / 1000);
const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
const claims = b64url(JSON.stringify({
  iss: sa.client_email,
  scope: "https://www.googleapis.com/auth/cloud-platform https://www.googleapis.com/auth/datastore",
  aud: sa.token_uri, iat: now, exp: now + 3600,
}));
const signer = crypto.createSign("RSA-SHA256");
signer.update(`${header}.${claims}`);
signer.end();
const jwt = `${header}.${claims}.${b64url(signer.sign(sa.private_key))}`;
const tokRes = await fetch(sa.token_uri, {
  method: "POST",
  headers: { "Content-Type": "application/x-www-form-urlencoded" },
  body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt }).toString(),
});
const tokJson: any = await tokRes.json().catch(() => null);
if (!tokRes.ok || !tokJson?.access_token) {
  console.error("TOKEN FAIL", tokRes.status, JSON.stringify(tokJson).slice(0, 300));
  process.exit(1);
}
const T = tokJson.access_token as string;
console.log(`\n=== توکن ادمین OK (پروژهٔ ${PID}) ===\n`);

/* ── ۱) پیکربندی ورود (کامل) ── */
console.log("── ۱) پیکربندی ورود identitytoolkit admin/v2 ──");
{
  const r = await rest("GET", `https://identitytoolkit.googleapis.com/admin/v2/projects/${PID}/config`, T);
  console.log(`HTTP ${r.status}`);
  if (r.json) console.log(JSON.stringify(r.json, null, 2).slice(0, 4000));
  else console.log(r.text.slice(0, 800));
}

/* ── ۲) انتشار قوانین فعلی ── */
console.log("\n── ۲) releases/cloud.firestore فعلی ──");
let releaseRuleset = "";
{
  const r = await rest("GET", `https://firebaserules.googleapis.com/v1/projects/${PID}/releases/cloud.firestore`, T);
  console.log(`HTTP ${r.status}`);
  console.log(r.text.slice(0, 1200));
  if (r.status === 200 && r.json?.rulesetName) releaseRuleset = r.json.rulesetName as string;
}

/* ── ۳) محتوای ruleset فعلی ── */
if (releaseRuleset) {
  console.log(`\n── ۳) محتوای ${releaseRuleset} ──`);
  const r = await rest("GET", `https://firebaserules.googleapis.com/v1/${releaseRuleset}`, T);
  console.log(`HTTP ${r.status}`);
  const files: any[] = r.json?.source?.files ?? [];
  for (const f of files) console.log(`--- ${f.name} ---\n${f.content ?? ""}`);
}

/* ── ۴) تلاش برای انتشار قوانین (خطای کامل) ── */
console.log("\n── ۴) تلاش انتشار قوانین (خطای کامل POST release) ──");
{
  const RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write:
        if request.auth != null
        && request.auth.uid == uid;
    }
  }
}`;
  const rs = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${PID}/rulesets`, T, {
    source: { files: [{ name: "firestore.rules", content: RULES }] },
  });
  console.log(`ruleset create: HTTP ${rs.status} → ${rs.json?.name ?? rs.text.slice(0, 200)}`);
  if (rs.status < 300 && rs.json?.name) {
    const body = { name: `projects/${PID}/releases/cloud.firestore`, rulesetName: rs.json.name };
    const upd = await rest("PATCH", `https://firebaserules.googleapis.com/v1/projects/${PID}/releases/cloud.firestore`, T, body);
    console.log(`release PATCH: HTTP ${upd.status}\n${upd.text.slice(0, 1500)}`);
    if (upd.status >= 300) {
      const cre = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${PID}/releases`, T, body);
      console.log(`release POST: HTTP ${cre.status}\n${cre.text.slice(0, 1500)}`);
    }
  }
}

/* ── ۵) دیتابیس ── */
console.log("\n── ۵) دیتابیس‌ها ──");
{
  const r = await rest("GET", `https://firestore.googleapis.com/v1/projects/${PID}/databases`, T);
  console.log(`HTTP ${r.status}`);
  console.log(JSON.stringify(r.json, null, 2).slice(0, 1500));
}

/* ── ۶) تست سند با شناسهٔ مجاز ── */
console.log("\n── ۶) تست نوشتن/خواندن/حذف سند probe ──");
{
  const url = `https://firestore.googleapis.com/v1/projects/${PID}/databases/(default)/documents/hamrah_users/setup_probe`;
  const w = await rest("PATCH", url, T, {
    fields: { probe: { stringValue: `ok-${new Date().toISOString()}` } },
  });
  console.log(`write: HTTP ${w.status} ${w.status >= 300 ? w.text.slice(0, 400) : "✓"}`);
  if (w.status < 300) {
    const rd = await rest("GET", url, T);
    console.log(`read:  HTTP ${rd.status} ${rd.status >= 300 ? rd.text.slice(0, 400) : "✓"}`);
    const del = await rest("DELETE", url, T);
    console.log(`del:   HTTP ${del.status} ${del.status >= 300 ? del.text.slice(0, 400) : "✓"}`);
  }
}

/* ── ۷) IAM policy (اگر اجازه بدهد) ── */
console.log("\n── ۷) IAM policy پروژه ──");
{
  const r = await rest("POST", `https://cloudresourcemanager.googleapis.com/v1/projects/${PID}:getIamPolicy`, T, {});
  console.log(`HTTP ${r.status}`);
  if (r.json?.bindings) {
    for (const b of r.json.bindings as any[]) {
      const members = (b.members ?? []).filter((m: string) => m.includes("firebase-adminsdk") || m.includes("serviceAccount:"));
      if (members.length) console.log(`  role: ${b.role}  →  ${members.join(", ")}`);
    }
  } else console.log(r.text.slice(0, 600));
}

/* ── ۸) پراب بدون احراز (شبیه برنامه قبل از ورود) ── */
console.log("\n── ۸) پراب بدون توکن (آنچه برنامه می‌بیند) ──");
{
  const res = await fetch(`https://firestore.googleapis.com/v1/projects/${PID}/databases/(default)/documents/hamrah_users?pageSize=1`);
  console.log(`documents list (بدون توکن): HTTP ${res.status}`);
  console.log((await res.text()).slice(0, 400));
}
