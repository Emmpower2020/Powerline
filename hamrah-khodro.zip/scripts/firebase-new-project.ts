/**
 * راه‌اندازی کامل «از صفر» پروژهٔ فایربیس برای «همراه خودرو» — هر پروژه‌ای، از ابتدا
 * ─────────────────────────────────────────────────────────────────────────────
 * این اسکریپت با یک کلید Service Account، تمام کارهای سرور را خودکار انجام می‌دهد:
 *
 *   ۰) (--create) تلاش برای ساخت پروژهٔ فایربیس کاملاً جدید از طریق Firebase Management API
 *   ۱) توکن ادمین از Service Account (JWT RS256 → oauth2.googleapis.com)
 *   ۲) فعال‌سازی Identity Toolkit API + Cloud Firestore API
 *   ۳) ثبت اپ اندروید (com.zai.hamrahkhodro) + SHA-1 امضای برنامه → کلاینت OAuth اندروید
 *      و دریافت google-services.json جدید (apiKey + appId + client_id)
 *   ۴) فعال‌سازی «ورود با گوگل» (تلاش API + پروب زندهٔ قرارداد برنامه)
 *   ۵) بررسی سالم‌بودن کلاینت + Custom URI Scheme (پروب واقعی accounts.google.com)
 *   ۶) ساخت دیتابیس Firestore «(default)» (+ پول عملیات)
 *   ۷) انتشار قوانین امنیتی hamrah_users/{uid} (+ تلاش برای خودکارسازی مجوز IAM)
 *   ۸) تست E2E مسیر واقعی کاربر (نشست → نوشتن/خواندن سند → ایزوله‌بودن قوانین)
 *   ۹) گزارش کامل + خروجی مقادیر + (--apply) جایگذاری خودکار در سورس برنامه
 *
 * اجرا:
 *   bun run scripts/firebase-new-project.ts config/service-account.json            ← راه‌اندازی همین پروژهٔ کلید
 *   bun run scripts/firebase-new-project.ts config/service-account.json --create   ← ساخت پروژهٔ جدید (نیازمند مجوز)
 *   bun run scripts/firebase-new-project.ts config/service-account.json --apply    ← پس از موفقیت، سورس هم پچ شود
 *
 * کلید از کجا؟  کنسول Firebase → ⚙️ Project settings → Service accounts →
 *               «Generate new private key» → دانلود JSON → config/service-account.json
 */

import * as fs from "node:fs";
import * as crypto from "node:crypto";

/* ────────────── ورودی‌ها ────────────── */

const args = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const DO_CREATE = process.argv.includes("--create");
const DO_APPLY = process.argv.includes("--apply");
const keyPath = args[0] ?? "config/service-account.json";

/** مقادیر ثابت برنامه (همیشه یکی است — مستقل از پروژهٔ فایربیس) */
const APP_PACKAGE = "com.zai.hamrahkhodro";
const APP_DISPLAY = "همراه خودرو";
const REDIRECT_URI = "com.zai.hamrahkhodro:/fbcallback";
/** SHA-1 امضای APK (keystore داخلی پروژه — MANIFEST.json) */
const APK_SHA1 = "08:BE:55:6D:7D:96:5F:E7:98:18:16:98:00:CC:B2:E1:66:05:20:47";
const APK_SHA1_HEX = "08be556d7d965fe79818169800ccb2e166052047";
const OAUTH_SCOPES = "openid email profile";
const RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write:
        if request.auth != null
        && request.auth.uid == uid;
    }
  }
}`;

/* ────────────── ابزارها ────────────── */

const b64url = (buf: Buffer | string): string =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

function log(ok: boolean, msg: string): void {
  console.log(`${ok ? "  ✓" : "  ✗"}  ${msg}`);
}
function info(msg: string): void {
  console.log(`  •  ${msg}`);
}
function step(title: string): void {
  console.log(`\n■ ${title}`);
}

async function rest(
  method: string,
  url: string,
  token: string | null,
  body?: unknown,
  contentType = "application/json"
): Promise<{ status: number; text: string; json: any | null }> {
  const res = await fetch(url, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(body !== undefined ? { "Content-Type": contentType } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, text, json };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/* ────────────── ۰) کلید سرویس‌حساب ────────────── */

if (!fs.existsSync(keyPath)) {
  console.error(`✗ فایل کلید پیدا نشد: ${keyPath}`);
  console.error(`  کلید را از کنسول Firebase → ⚙️ Project settings → Service accounts →`);
  console.error(`  «Generate new private key» دانلود و در همین مسیر قرار دهید.`);
  process.exit(1);
}
const sa = JSON.parse(fs.readFileSync(keyPath, "utf8")) as {
  project_id: string;
  private_name?: string;
  private_key: string;
  client_email: string;
  token_uri: string;
};
if (!sa.private_key || !sa.client_email || !sa.project_id) {
  console.error("✗ فایل کلید ناقص است (private_key / client_email / project_id لازم است)");
  process.exit(1);
}

console.log(`\n╔══════════════════════════════════════════════════════════════╗`);
console.log(`║  راه‌اندازی از صفر — پروژهٔ فایربیس «${sa.project_id}»`);
console.log(`╚══════════════════════════════════════════════════════════════╝`);
console.log(`  سرویس‌حساب: ${sa.client_email}`);
console.log(`  پکیج برنامه: ${APP_PACKAGE} | SHA-1: ${APK_SHA1_HEX}`);

/* ────────────── ۱) توکن ادمین ────────────── */

function saToken(pid: string, scopes: string): Promise<string> {
  return (async () => {
    const now = Math.floor(Date.now() / 1000);
    const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
    const claims = b64url(
      JSON.stringify({
        iss: sa.client_email,
        scope: scopes,
        aud: sa.token_uri ?? "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600,
      })
    );
    const signer = crypto.createSign("RSA-SHA256");
    signer.update(`${header}.${claims}`);
    signer.end();
    void pid;
    const jwt = `${header}.${claims}.${b64url(signer.sign(sa.private_key))}`;
    const res = await fetch(sa.token_uri ?? "https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: jwt,
      }).toString(),
    });
    const j: any = await res.json().catch(() => null);
    if (!res.ok || !j?.access_token) throw new Error(`HTTP ${res.status}: ${String(j?.error_description ?? j?.error ?? res.statusText).slice(0, 200)}`);
    return j.access_token as string;
  })();
}

step("۱) توکن ادمین");
let token = "";
try {
  token = await saToken(sa.project_id, "https://www.googleapis.com/auth/cloud-platform https://www.googleapis.com/auth/firebase https://www.googleapis.com/auth/datastore");
  log(true, "توکن ادمین گرفته شد");
} catch (e: any) {
  log(false, `توکن گرفته نشد: ${e?.message ?? e}`);
  process.exit(1);
}

/* ────────────── ۰+) ساخت پروژهٔ جدید (اختیاری) ────────────── */

if (DO_CREATE) {
  step("۰) ساخت پروژهٔ فایربیس جدید (Firebase Management API)");
  const NEW_PID = `${sa.project_id.replace(/[^a-z0-9-]/g, "")}`.slice(0, 22) || "hamrah-new";
  const create = await rest("POST", "https://firebase.googleapis.com/v1beta1/projects", token, {
    projectId: NEW_PID,
    displayName: "Hamrah Khodro Cloud",
  });
  if (create.status === 403 || create.status === 401) {
    log(false, `ساخت پروژهٔ جدید با این کلید مجاز نیست (HTTP ${create.status}):`);
    info(`"${create.text.slice(0, 180)}"`);
    info("سرویس‌حسابِ یک پروژه معمولاً اجازهٔ «ساخت پروژهٔ جدید» ندارد.");
    info("↳ راه‌حل: خودت در کنسول پروژهٔ جدید بساز (۳۰ ثانیه) و کلید سرویس‌حساب آن را بده:");
    info("   1) https://console.firebase.google.com → Add project → نام دلخواه (مثلاً hamrahprj2) → Create");
    info("   2) ⚙️ Project settings → Service accounts → Generate new private key");
    info("   3) همان JSON را بده تا بقیهٔ همهٔ کارها را همین اسکریپت خودکار انجام دهد.");
    process.exit(2);
  }
  if (create.status >= 200 && create.status < 300 && create.json?.name) {
    info(`درخواست ثبت شد (${create.json.name}) — در حال ساخت…`);
    let ready = false;
    for (let i = 0; i < 60; i++) {
      await sleep(5000);
      const op = await rest("GET", `https://firebase.googleapis.com/v1beta1/${create.json.name}`, token);
      if (op.json?.done) {
        if (op.json?.error) {
          log(false, `ساخت پروژه خطا داد: ${JSON.stringify(op.json.error).slice(0, 250)}`);
        } else {
          ready = true;
        }
        break;
      }
      process.stdout.write(`     … ${5 * (i + 1)}s\r`);
    }
    if (ready) {
      log(true, `پروژهٔ جدید «${NEW_PID}» ساخته شد ✓ — کلید این پروژه را جدا بساز و بده`);
      info("  (برای پروژهٔ جدید باید Service Account جدیدش را هم Generate کنی و با همان کلید دوباره بدون --create اجرا کنی)");
      process.exit(0);
    }
    process.exit(2);
  }
  log(false, `پاسخ غیرمنتظره (HTTP ${create.status}): ${create.text.slice(0, 250)}`);
  process.exit(2);
}

/* ────────────── ۲) فعال‌سازی APIها ────────────── */

step("۲) فعال‌سازی Identity Toolkit API و Cloud Firestore API");

async function ensureService(serviceId: string, label: string): Promise<boolean> {
  const r = await rest("GET", `https://serviceusage.googleapis.com/v1/projects/${sa.project_id}/services/${serviceId}`, token);
  if (r.json?.state === "ENABLED") {
    log(true, `${label} — از قبل فعال`);
    return true;
  }
  info(`${label} فعال نیست → در حال فعال‌سازی…`);
  const en = await rest("POST", `https://serviceusage.googleapis.com/v1/projects/${sa.project_id}/services/${serviceId}:enable`, token, {});
  for (let i = 0; i < 30; i++) {
    await sleep(3000);
    const q = await rest("GET", `https://serviceusage.googleapis.com/v1/projects/${sa.project_id}/services/${serviceId}`, token);
    if (q.json?.state === "ENABLED") {
      log(true, `${label} — فعال شد ✓`);
      return true;
    }
    process.stdout.write(`     … ${3 * (i + 1)}s\r`);
  }
  log(false, `${label} — فعال‌سازی کامل نشد (${en.status}): ${en.text.slice(0, 160)}`);
  info(`  ↳ فعال‌سازی دستی: https://console.developers.google.com/apis/api/${serviceId.split(".")[0]}.googleapis.com/overview?project=${sa.project_id}`);
  return false;
}

const identityOk = await ensureService("identitytoolkit.googleapis.com", "Identity Toolkit API (ورود)");
const firestoreOk = await ensureService("firestore.googleapis.com", "Cloud Firestore API (داده)");

/* ────────────── ۳) اپ اندروید + SHA-1 + پیکربندی ────────────── */

step("۳) اپ اندروید (کلاینت OAuth + SHA-1 + google-services.json)");
let androidClientId = "";
let webApiKey = "";
let mobilesdkAppId = "";
let googleServicesJson = "";
{
  // اپ موجود را پیدا کن یا بساز
  let appId = "";
  const list = await rest("GET", `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps`, token);
  const apps: any[] = list.json?.apps ?? [];
  const existing = apps.find((a) => a.packageName === APP_PACKAGE);
  if (existing) {
    appId = String(existing.name ?? "").split("/").pop() ?? "";
    log(true, `اپ اندروید از قبل ثبت است (appId=${appId})`);
  } else if (list.status === 200) {
    info("اپ اندروید ثبت نشده → ساخته می‌شود (کلاینت OAuth اندروید خودکار ساخته می‌شود)…");
    const create = await rest(
      "POST",
      `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps`,
      token,
      { packageName: APP_PACKAGE, displayName: APP_DISPLAY }
    );
    if (create.status >= 200 && create.status < 300 && create.json?.name) {
      // عملیات طولانی — پول
      for (let i = 0; i < 24; i++) {
        await sleep(3000);
        const l2 = await rest("GET", `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps`, token);
        const found = (l2.json?.apps ?? []).find((a: any) => a.packageName === APP_PACKAGE);
        if (found) {
          appId = String(found.name ?? "").split("/").pop() ?? "";
          break;
        }
        process.stdout.write(`     … ${3 * (i + 1)}s\r`);
      }
      if (appId) log(true, `اپ اندروید ساخته شد (appId=${appId})`);
      else log(false, "اپ ساخته شد اما appId خوانده نشد — دوباره اجرا کن");
    } else {
      log(false, `ساخت اپ اندروید ناموفق (HTTP ${create.status}): ${create.text.slice(0, 200)}`);
    }
  } else {
    log(false, `فهرست اپ‌ها خوانده نشد (HTTP ${list.status}): ${list.text.slice(0, 200)}`);
  }

  if (appId) {
    // SHA-1
    const shas = await rest("GET", `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps/${appId}/sha`, token);
    const certs: any[] = shas.json?.certificates ?? [];
    const hasIt = certs.some((c) => String(c.shaHash ?? "").toLowerCase() === APK_SHA1_HEX);
    if (hasIt) {
      log(true, "SHA-1 امضای برنامه روی کلاینت ثبت است");
    } else {
      const add = await rest("POST", `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps/${appId}/sha`, token, {
        shaHash: APK_SHA1,
        type: "SHA_1",
      });
      log(add.status >= 200 && add.status < 300, `ثبت SHA-1 (HTTP ${add.status})${add.status >= 300 ? ": " + add.text.slice(0, 160) : ""}`);
    }

    // پیکربندی (google-services.json)
    const cfg = await rest("GET", `https://firebase.googleapis.com/v1beta1/projects/${sa.project_id}/androidApps/${appId}/config`, token);
    const contents: string = cfg.json?.configFileContents ?? "";
    if (contents) {
      googleServicesJson = contents;
      try {
        const g = JSON.parse(contents);
        webApiKey = g.client?.[0]?.api_key?.[0]?.current_key ?? "";
        mobilesdkAppId = g.client?.[0]?.mobilesdk_app_id ?? "";
        const oauth: any[] = g.client?.[0]?.oauth_client ?? [];
        const androidClient = oauth.find((o) => o.client_type === 1) ?? oauth[0];
        androidClientId = androidClient?.client_id ?? "";
      } catch {
        /* parse later */
      }
      if (webApiKey) log(true, `Web API Key خوانده شد (${webApiKey.slice(0, 12)}…)`);
      if (androidClientId) log(true, `کلاینت OAuth اندروید: ${androidClientId}`);
      fs.writeFileSync("config/new-google-services.json", JSON.stringify(JSON.parse(contents), null, 2));
      info("google-services.json جدید در config/new-google-services.json ذخیره شد");
    } else {
      log(false, `خواندن پیکربندی اپ ناموفق (HTTP ${cfg.status}): ${cfg.text.slice(0, 200)}`);
    }
  }
}

// fallback برای API Key از پیکربندی Identity Toolkit
if (!webApiKey) {
  const cfg0 = await rest("GET", `https://identitytoolkit.googleapis.com/admin/v2/projects/${sa.project_id}/config`, token);
  webApiKey = cfg0.json?.client?.apiKey ?? "";
  log(!!webApiKey, `Web API Key از پیکربندی ورود ${webApiKey ? "خوانده شد" : "خوانده نشد"}`);
}

/* ────────────── ۴) ورود با گوگل ────────────── */

step("۴) فعال‌سازی «ورود با حساب گوگل»");
let googleProviderOk = false;
{
  // پراب زنده با همان قرارداد دقیق برنامه (FbSession.signInWithIdp):
  //   INVALID_IDP_RESPONSE = ارائه‌دهندهٔ گوگل فعال است (توکن ساختگی رد شد)
  //   OPERATION_NOT_ALLOWED / provider not enabled = غیرفعال
  async function probeGoogleProvider(): Promise<boolean> {
    if (!webApiKey) return false;
    const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${webApiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        postBody: "providerId=google.com&id_token=FAKE.JWT.TOKEN&uri=https://localhost",
        requestUri: "https://localhost",
        returnSecureToken: true,
      }),
    });
    const txt = await res.text().catch(() => "");
    return /INVALID_IDP_RESPONSE|Unable to (parse|verify)/i.test(txt);
  }

  googleProviderOk = await probeGoogleProvider();
  if (googleProviderOk) {
    log(true, "ورود با گوگل فعال است (پراب زندهٔ قرارداد برنامه ✓)");
  } else {
    info("ورود با گوگل فعال نیست → تلاش برای فعال‌سازی از طریق API…");
    // کشف قرارداد از discovery doc (روش اثبات‌شدهٔ همین پروژه)
    let patched = false;
    try {
      const disc = await rest("GET", "https://identitytoolkit.googleapis.com/$discovery/rest?version=v2", null);
      if (disc.json?.resources) {
        const resNames = Object.keys(disc.json.resources);
        info(`منابع API موجود: ${resNames.join(", ")}`);
        // روش‌های شناخته‌شده: projects.config (patch) و projects.idpConfigs (در صورت وجود)
        const proj = disc.json.resources.projects?.methods ?? [];
        info(`متدهای projects: ${Array.isArray(proj) ? proj.map((m: any) => m.httpMethod + " " + (m.flatPath ?? m.path ?? "?")).join(" | ") : "?"}`);
      }
    } catch {
      /* discovery در دسترس نیست */
    }
    // تلاش مستقیم: PATCH پیکربندی با idpConfigs (قرارداد Identity Platform)
    if (webApiKey) {
      const pat = await rest(
        "PATCH",
        `https://identitytoolkit.googleapis.com/admin/v2/projects/${sa.project_id}/config?updateMask=idpConfigs`,
        token,
        { idpConfigs: [{ provider: { code: "google.com", id: "google.com", name: "Google", }, enabled: true, clientId: "", clientSecret: "" }] }
      );
      patched = pat.status >= 200 && pat.status < 300;
      log(patched, `تلاش PATCH پیکربندی (HTTP ${pat.status})${patched ? "" : " — مجاز نبود"}`);
      if (!patched && pat.status !== 404) info(`   پاسخ: ${pat.text.slice(0, 160)}`);
    }
    googleProviderOk = await probeGoogleProvider();
    if (googleProviderOk) {
      log(true, "ورود با گوگل حالا فعال است ✓");
    } else {
      log(false, "فعال‌سازی ورود گوگل از طریق API ممکن نشد — یک قدم دستی لازم است:");
      info("  1) https://console.firebase.google.com/project/" + sa.project_id + "/authentication/providers");
      info("  2) روی «Google» بزن → کلید Enable را روشن کن → یک ایمیل پشتیبانی انتخاب کن → Save");
      info("  (۲۰ ثانیه) — بعد دوباره همین اسکریپت را اجرا کن تا تأیید شود.");
    }
  }
}

/* ────────────── ۵) کلاینت OAuth + Custom URI Scheme ────────────── */

step("۵) کلاینت OAuth اندروید + Custom URI Scheme");
let schemeOk = false;
{
  if (androidClientId) {
    // پروب واقعی: اگر گوگل redirect_uri سفارشی را بپذیرد → 302 به صفحهٔ ورود
    const url = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(androidClientId)}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=${encodeURIComponent(OAUTH_SCOPES)}&prompt=select_account`;
    try {
      const res = await fetch(url, { redirect: "manual" });
      const loc = res.headers.get("location") ?? "";
      if (res.status >= 300 && res.status < 400 && loc.startsWith("https://accounts.google.com/")) {
        schemeOk = true;
        log(true, `کلاینت + Custom URI Scheme سالم (302 → صفحهٔ ورود)`);
      } else {
        const body = res.status < 300 ? "" : (await res.text()).slice(0, 200);
        log(false, `پاسخ غیرمنتظره (HTTP ${res.status}): ${body || loc.slice(0, 160)}`);
        info("  ↳ در Google Cloud Console → APIs & Services → Credentials → کلاینت اندروید:");
        info(`     ${androidClientId}`);
        info("     Advanced settings → «Enable custom URI scheme» را روشن کن (این کلاینت تازه ساخته شده و ممکن است خاموش باشد).");
        info(`     لینک مستقیم: https://console.cloud.google.com/auth/clients?project=${sa.project_id}`);
      }
    } catch (e: any) {
      log(false, `پروب شبکه ناموفق: ${e?.message ?? e}`);
    }
  } else {
    log(false, "کلاینت اندروید موجود نیست — مرحلهٔ ۳ را بررسی کن");
  }
}

/* ────────────── ۶) دیتابیس Firestore ────────────── */

step("۶) ساخت دیتابیس Firestore «(default)»");
let dbReady = false;
{
  const list = await rest("GET", `https://firestore.googleapis.com/v1/projects/${sa.project_id}/databases`, token);
  const dbs: any[] = list.json?.databases ?? [];
  const def = dbs.find((d: any) => String(d.name ?? "").endsWith("/(default)"));
  if (def) {
    log(true, `دیتابیس «(default)» از قبل موجود است (${def.type ?? "?"} / ${def.locationId ?? "?"})`);
    dbReady = true;
  } else {
    info("دیتابیس وجود ندارد → ساخته می‌شود (منطقهٔ nam5 — چند دقیقه طول می‌کشد)…");
    const create = await rest(
      "POST",
      `https://firestore.googleapis.com/v1/projects/${sa.project_id}/databases?databaseId=${encodeURIComponent("(default)")}`,
      token,
      {
        type: "FIRESTORE_NATIVE",
        locationId: "nam5",
        deleteProtectionState: "DELETE_PROTECTION_DISABLED",
        pointInTimeRecoveryEnablement: "POINT_IN_TIME_RECOVERY_DISABLED",
      }
    );
    if (create.status >= 200 && create.status < 300 && create.json?.name) {
      const opName: string = create.json.name;
      for (let i = 0; i < 80; i++) {
        await sleep(3000);
        const op = await rest("GET", `https://firestore.googleapis.com/v1/${opName}`, token);
        if (op.json?.done) {
          if (op.json?.error) log(false, `خطا در ساخت: ${JSON.stringify(op.json.error).slice(0, 250)}`);
          else {
            log(true, "دیتابیس «(default)» ساخته شد ✓");
            dbReady = true;
          }
          break;
        }
        process.stdout.write(`     … ${3 * (i + 1)}s\r`);
      }
      if (!dbReady) {
        const l2 = await rest("GET", `https://firestore.googleapis.com/v1/projects/${sa.project_id}/databases`, token);
        dbReady = !!(l2.json?.databases ?? []).some((d: any) => String(d.name ?? "").endsWith("/(default)"));
        if (dbReady) log(true, "دیتابیس «(default)» ساخته شد ✓");
      }
    } else {
      log(false, `ساخت دیتابیس ناموفق (HTTP ${create.status}): ${create.text.slice(0, 300)}`);
    }
  }
}

/* ────────────── ۷) قوانین امنیتی ────────────── */

step("۷) قوانین امنیتی (هر کاربر فقط سند خودش)");
let rulesOk = false;
{
  async function readCurrentRules(): Promise<{ rulesetName: string; content: string } | null> {
    const rel = await rest("GET", `https://firebaserules.googleapis.com/v1/projects/${sa.project_id}/releases/cloud.firestore`, token);
    if (rel.status === 200 && rel.json?.rulesetName) {
      const cur = await rest("GET", `https://firebaserules.googleapis.com/v1/${rel.json.rulesetName}`, token);
      const files: any[] = cur.json?.source?.files ?? [];
      const content = String(files.find((f: any) => f.name === "firestore.rules")?.content ?? "");
      return { rulesetName: rel.json.rulesetName, content };
    }
    return null;
  }
  async function publishRules(): Promise<boolean> {
    const rs = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${sa.project_id}/rulesets`, token, {
      source: { files: [{ name: "firestore.rules", content: RULES }] },
    });
    if (!(rs.status >= 200 && rs.status < 300) || !rs.json?.name) {
      log(false, `ساخت ruleset ناموفق (HTTP ${rs.status}): ${rs.text.slice(0, 200)}`);
      return false;
    }
    const rulesetName = rs.json.name as string;
    const releaseBody = { name: `projects/${sa.project_id}/releases/cloud.firestore`, rulesetName };
    const cre = await rest("POST", `https://firebaserules.googleapis.com/v1/projects/${sa.project_id}/releases`, token, releaseBody);
    if (cre.status >= 200 && cre.status < 300) return true;
    const upd = await rest(
      "PATCH",
      `https://firebaserules.googleapis.com/v1/projects/${sa.project_id}/releases/cloud.firestore`,
      token,
      releaseBody
    );
    return upd.status >= 200 && upd.status < 300;
  }

  // ۷-۱) قوانین فعلی
  const cur = await readCurrentRules();
  const sameRules =
    !!cur &&
    /hamrah_users\/\{uid\}/.test(cur.content) &&
    /request\.auth\s*!=\s*null/.test(cur.content) &&
    /request\.auth\.uid\s*==\s*uid/.test(cur.content) &&
    /allow\s+read\s*,\s*write/.test(cur.content);
  if (sameRules) {
    log(true, `قوانین فعلی همین است که برنامه می‌خواهد ✓ (${cur!.rulesetName})`);
    rulesOk = true;
  } else if (cur) {
    info(`قوانین فعلی متفاوت است:\n${cur.content.slice(0, 400)}`);
  } else {
    info("انتشار قوانین موجود نیست (دیتابیس تازه با قوانین پیش‌فرضِ بسته شروع می‌شود)");
  }

  // ۷-۲) انتشار (در صورت نیاز)
  if (!rulesOk && dbReady) {
    info("در حال انتشار قوانین hamrah_users…");
    rulesOk = await publishRules();
    log(rulesOk, rulesOk ? "قوانین منتشر شد ✓" : "انتشار قوانین با کلید فعلی مجاز نبود");

    // ۷-۳) تلاش برای خوداعطای مجوز firebaserules.admin و تلاش مجدد
    if (!rulesOk) {
      info("تلاش برای افزودن مجوز firebaserules به سرویس‌حساب از طریق IAM…");
      try {
        const pol = await rest("POST", `https://cloudresourcemanager.googleapis.com/v1/projects/${sa.project_id}:getIamPolicy`, token, {});
        if (pol.status === 200 && pol.json?.bindings) {
          const role = "roles/firebaserules.admin";
          const member = `serviceAccount:${sa.client_email}`;
          const bindings: any[] = pol.json.bindings;
          const has = bindings.some((b) => b.role === role && (b.members ?? []).includes(member));
          if (!has) {
            bindings.push({ role, members: [member] });
            const set = await rest("POST", `https://cloudresourcemanager.googleapis.com/v1/projects/${sa.project_id}:setIamPolicy`, token, {
              policy: { ...pol.json, bindings },
            });
            if (set.status >= 200 && set.status < 300) {
              info("مجوز اضافه شد — انتشار مجدد قوانین…");
              await sleep(2000);
              rulesOk = await publishRules();
              log(rulesOk, rulesOk ? "قوانین منتشر شد ✓" : "باز هم انتشار نشد");
            } else {
              info(`تغییر IAM مجاز نبود (HTTP ${set.status}) — یک قدم دستی لازم است`);
            }
          }
        } else {
          info(`خواندن IAM مجاز نبود (HTTP ${pol.status})`);
        }
      } catch (e: any) {
        info(`IAM ناموفق: ${e?.message ?? e}`);
      }
    }

    if (!rulesOk) {
      log(false, "قوانین را دستی منتشر کن (۳۰ ثانیه):");
      info("  1) https://console.firebase.google.com/project/" + sa.project_id + "/firestore/rules");
      info("  2) محتوای زیر را جای‌گذاری کن و Publish بزن:");
      console.log(RULES.split("\n").map((l) => `     ${l}`).join("\n"));
    }
  }
}

/* ────────────── ۸) تست E2E مسیر کاربر ────────────── */

step("۸) تست E2E — مسیر واقعی کاربر (نشست + قوانین)");
let e2eOk = false;
{
  if (!webApiKey || !dbReady || !rulesOk) {
    info("تست E2E فقط وقتی اجرا می‌شود که apiKey + دیتابیس + قوانین همه آماده باشند — فعلاً رد شد");
  } else {
    try {
      const TEST_UID = `hk_setup_${Date.now().toString(36)}`;
      const nowS = Math.floor(Date.now() / 1000);
      const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
      const claims = b64url(
        JSON.stringify({
          uid: TEST_UID,
          iat: nowS,
          exp: nowS + 3600,
          aud: "https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit",
          iss: sa.client_email,
          sub: sa.client_email,
        })
      );
      const signer = crypto.createSign("RSA-SHA256");
      signer.update(`${header}.${claims}`);
      signer.end();
      const customToken = `${header}.${claims}.${b64url(signer.sign(sa.private_key))}`;

      const signinRes = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${webApiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: customToken, returnSecureToken: true }),
        }
      );
      const sj: any = await signinRes.json().catch(() => null);
      if (!signinRes.ok || !sj?.idToken) {
        log(false, `signInWithCustomToken ناموفق (HTTP ${signinRes.status}): ${JSON.stringify(sj).slice(0, 200)}`);
      } else {
        const idToken = sj.idToken as string;
        const claims2 = JSON.parse(
          Buffer.from(idToken.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString()
        ) as { sub?: string; user_id?: string };
        const localId = (sj.localId ?? claims2.user_id ?? claims2.sub ?? "") as string;
        log(true, `نشست کاربر آزمایشی ساخته شد (uid=${localId})`);

        const userReq = async (method: string, path: string, body?: unknown) => {
          const res = await fetch(`https://firestore.googleapis.com/v1/projects/${sa.project_id}/databases/(default)/documents${path}`, {
            method,
            headers: {
              Authorization: `Bearer ${idToken}`,
              ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
            },
            body: body !== undefined ? JSON.stringify(body) : undefined,
          });
          return { status: res.status, text: await res.text() };
        };
        const w = await userReq("PATCH", `/hamrah_users/${localId}`, {
          fields: { data: { stringValue: JSON.stringify({ vehicles: [], records: [], reminders: [] }) }, updatedAt: { timestampValue: new Date().toISOString() } },
        });
        log(w.status === 200, `نوشتن سند خود (HTTP ${w.status})${w.status !== 200 ? ": " + w.text.slice(0, 150) : ""}`);
        const rd = await userReq("GET", `/hamrah_users/${localId}`);
        log(rd.status === 200, `خواندن سند خود (HTTP ${rd.status})`);
        const other = await userReq("GET", "/hamrah_users/somebody_else");
        log(other.status === 403, `خواندن سند دیگران باید 403 باشد (HTTP ${other.status})`);
        await userReq("DELETE", `/hamrah_users/${localId}`).catch(() => undefined);
        e2eOk = w.status === 200 && rd.status === 200 && other.status === 403;
      }
    } catch (e: any) {
      log(false, `تست E2E خطا داد: ${e?.message ?? e}`);
    }
  }
}

/* ────────────── ۹) گزارش + خروجی ────────────── */

step("۹) گزارش نهایی و خروجی مقادیر");

const values = {
  projectId: sa.project_id,
  apiKey: webApiKey,
  appId: mobilesdkAppId,
  androidClientId,
  redirectUri: REDIRECT_URI,
  authDomain: `${sa.project_id}.firebaseapp.com`,
  generatedAt: new Date().toISOString(),
};
fs.writeFileSync("config/new-project-values.json", JSON.stringify(values, null, 2));
info("مقادیر پروژه در config/new-project-values.json ذخیره شد");

console.log(`\n╔════════════════════ گزارش نهایی ════════════════════`);
console.log(`║  Identity Toolkit API      : ${identityOk ? "✓ فعال" : "✗"}`);
console.log(`║  Cloud Firestore API       : ${firestoreOk ? "✓ فعال" : "✗"}`);
console.log(`║  اپ اندروید + SHA-1        : ${androidClientId ? "✓ " + androidClientId.slice(0, 22) + "…" : "✗"}`);
console.log(`║  Web API Key               : ${webApiKey ? "✓ " + webApiKey.slice(0, 12) + "…" : "✗"}`);
console.log(`║  ورود با گوگل              : ${googleProviderOk ? "✓ فعال" : "✗ فعال‌سازی دستی لازم"}`);
console.log(`║  کلاینت + URI Scheme       : ${schemeOk ? "✓ سالم" : "✗ بررسی دستی"}`);
console.log(`║  دیتابیس (default)          : ${dbReady ? "✓ موجود" : "✗"}`);
console.log(`║  قوانین امنیتی              : ${rulesOk ? "✓ درست" : "✗"}`);
console.log(`║  تست مسیر کاربر (E2E)      : ${e2eOk ? "✓ موفق" : "—"}`);
console.log(`╚════════════════════════════════════════════════════╝`);

/* ────────────── ۱۰) --apply: پچ سورس برنامه ────────────── */

if (DO_APPLY) {
  step("۱۰) جایگذاری مقادیر در سورس برنامه (--apply)");
  if (!webApiKey || !androidClientId) {
    log(false, "مقادیر لازم کامل نیست — پچ انجام نشد");
  } else {
    // ۱۰-۱) FbSession.java
    const fbPath = "apk-build/asyncsrc395/com/zai/hamrahkhodro/FbSession.java";
    if (fs.existsSync(fbPath)) {
      let src = fs.readFileSync(fbPath, "utf8");
      const swaps: Array<[RegExp, string]> = [
        [/CLIENT_ID\s*=\s*"[^"]+"/, `CLIENT_ID = "${androidClientId}"`],
        [/API_KEY\s*=\s*"[^"]+"/, `API_KEY = "${webApiKey}"`],
        [/projects\/[a-z0-9-]+\/databases\/\(default\)/, `projects/${sa.project_id}/databases/(default)`],
      ];
      let ok = true;
      for (const [re, to] of swaps) {
        if (re.test(src)) src = src.replace(re, to);
        else {
          ok = false;
          log(false, `الگوی موردنظر در ${fbPath} پیدا نشد: ${re}`);
        }
      }
      if (ok) {
        fs.writeFileSync(fbPath, src);
        log(true, `${fbPath} پچ شد (CLIENT_ID / API_KEY / FIRESTORE_DB_URL)`);
      }
    } else log(false, `${fbPath} پیدا نشد`);

    // ۱۰-۲) firebase-config.ts
    const cfgPath = "src/lib/firebase-config.ts";
    if (fs.existsSync(cfgPath)) {
      let src = fs.readFileSync(cfgPath, "utf8");
      const re = /export const FIREBASE_DEFAULT_CONFIG: FirebaseAppConfig = \{[\s\S]*?\};/;
      const to = `export const FIREBASE_DEFAULT_CONFIG: FirebaseAppConfig = {
  apiKey: "${webApiKey}",
  authDomain: "${sa.project_id}.firebaseapp.com",
  projectId: "${sa.project_id}",
  appId: "${mobilesdkAppId}",
  androidClientId: "${androidClientId}",
};`;
      if (re.test(src)) {
        src = src.replace(re, to);
        fs.writeFileSync(cfgPath, src);
        log(true, `${cfgPath} پچ شد (FIREBASE_DEFAULT_CONFIG)`);
      } else log(false, `الگوی FIREBASE_DEFAULT_CONFIG در ${cfgPath} پیدا نشد`);
    } else log(false, `${cfgPath} پیدا نشد`);

    // ۱۰-۳) config/google-services.json
    if (googleServicesJson) {
      fs.writeFileSync("config/google-services.json", JSON.stringify(JSON.parse(googleServicesJson), null, 2));
      log(true, "config/google-services.json جایگزین شد");
    }

    info("سورس آماده است — گام‌های بعدی (بازسازی APK):");
    info("  1) apk-build/build-web-only.sh        ← بیلد استاتیک وب جدید");
    info("  2) apk-build/build-dex-v395.sh        ← چون CLIENT_ID جاوا عوض شد (نیازمند ابزارها در /home/z/apk-build)");
    info("  3) نسخه/patch_manifest جدید + build-apk ← بسته‌بندی و امضا");
  }
}

/* ────────────── جمع‌بندی ────────────── */

const allOk = identityOk && firestoreOk && androidClientId && webApiKey && googleProviderOk && schemeOk && dbReady && rulesOk && e2eOk;
if (allOk) {
  console.log(`\n✅ سرور پشتیبان از صفر کامل آماده شد — برنامه با این مقادیر بدون هیچ تنظیم دستی کار می‌کند.`);
} else {
  console.log(`\n⚠ مراحل ✗ بالا را انجام بده و دوباره این اسکریپت را اجرا کن تا همه سبز شود.`);
}
