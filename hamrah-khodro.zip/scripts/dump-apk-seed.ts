/**
 * خروجی دادهٔ اولیه برای APK اندروید — seed.json
 * پس از ساخت دیتابیس تازه و seed، همهٔ داده‌ها به شکل سریالایز API ذخیره می‌شود.
 * اجرا:
 *   DATABASE_URL=file:/home/z/apk-build/seedwork/apk-seed.db bunx tsx prisma/seed.ts
 *   DATABASE_URL=file:/home/z/apk-build/seedwork/apk-seed.db bunx tsx scripts/dump-apk-seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "fs";
import {
  serializeVehicle,
  serializeRecord,
  serializeReminder,
  serializeBrand,
  serializeServiceType,
} from "../src/lib/api-helpers";

const db = new PrismaClient();

async function main() {
  const [vehicles, records, reminders, brands, serviceTypes] = await Promise.all([
    db.vehicle.findMany({ orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }] }),
    db.record.findMany({ orderBy: [{ date: "desc" }, { createdAt: "desc" }] }),
    db.reminder.findMany({ orderBy: [{ done: "asc" }, { createdAt: "desc" }] }),
    db.brandModel.findMany({ orderBy: { createdAt: "asc" } }),
    db.serviceType.findMany({ orderBy: { order: "asc" } }),
  ]);

  const payload = {
    vehicles: vehicles.map(serializeVehicle),
    records: records.map(serializeRecord),
    reminders: reminders.map(serializeReminder),
    brands: brands.map(serializeBrand),
    serviceTypes: serviceTypes.map(serializeServiceType),
  };

  const out = process.argv[2] ?? "/home/z/apk-build/seed.json";
  writeFileSync(out, JSON.stringify(payload, null, 2));
  console.log(
    `seed.json نوشته شد → ${out} (خودرو ${vehicles.length}، رکورد ${records.length}، یادآور ${reminders.length}، برند ${brands.length}، نوع سرویس ${serviceTypes.length})`
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
