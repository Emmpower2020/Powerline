#!/bin/bash
# place-apk.sh — نام‌گذاری نسخه‌دار APK + چرخش نگه‌داشت ۳ نسخهٔ آخر
# کاربرد: bun run scripts/place-apk.sh <مسیر-APK> <نسخه>   مثال: bun run scripts/place-apk.sh /home/z/apk-build/hamrah-khodro.apk 2.5.0
# سیاست: نام فایل = hamrah-khodro-v{نسخه}.apk — در ریشهٔ پروژه + public/files + download
#         فقط ۳ نسخهٔ آخر نگه‌داری می‌شوند؛ قدیمی‌ترها حذف می‌گردند.
set -e

APK="$1"
VER="$2"
if [ -z "$APK" ] || [ -z "$VER" ]; then
  echo "❌ کاربرد: $0 <مسیر-APK> <نسخه مثل 2.5.0>"
  exit 1
fi
if [ ! -f "$APK" ]; then
  echo "❌ فایل APK پیدا نشد: $APK"
  exit 1
fi

ROOT=/home/z/my-project
NAME="hamrah-khodro-v${VER}.apk"

# ۱) جای‌گذاری با نام نسخه‌دار در هر سه مسیر
for d in "$ROOT" "$ROOT/public/files" "$ROOT/download"; do
  cp -f "$APK" "$d/$NAME"
  rm -f "$d/hamrah-khodro.apk"   # حذف نام قدیمی بدون نسخه
done
echo "✅ $NAME در ریشه + public/files + download قرار گرفت"

# ۲) چرخش: فقط ۳ نسخهٔ آخر بماند
LIST=$(ls "$ROOT/public/files" 2>/dev/null | grep -E '^hamrah-khodro-v[0-9]+\.[0-9]+\.[0-9]+\.apk$' | sort -V)
TOTAL=$(echo "$LIST" | grep -c . || true)
if [ "$TOTAL" -gt 3 ]; then
  OLD=$(echo "$LIST" | head -n $((TOTAL - 3)))
  for f in $OLD; do
    rm -f "$ROOT/$f" "$ROOT/public/files/$f" "$ROOT/download/$f"
    echo "🗑 حذف نسخهٔ قدیمی: $f"
  done
fi

echo "📦 نسخه‌های موجود:"
ls "$ROOT/public/files" | grep -E '^hamrah-khodro-v' || true
