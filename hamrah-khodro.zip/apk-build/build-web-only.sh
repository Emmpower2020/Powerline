#!/bin/bash
# build-web-only.sh — بیلد استاتیک Next + تزریق BRIDGE_INIT + همگام‌سازی با apk-mock
set -euo pipefail
PROJ=/home/z/my-project
WORK=/home/z/apk-build/work
BSRC=$WORK/build-src

echo "── ۱) کپی ایزولهٔ سورس"
rm -rf "$BSRC"
mkdir -p "$BSRC"
cd "$PROJ"
rsync -a --exclude node_modules --exclude ".next*" --exclude "out" \
  --exclude "public/files" --exclude "dev.log" --exclude "tool-results" \
  --exclude "android-keys" --exclude "download" \
  --exclude "upload" --exclude "hamrah-khodro-*.zip" --exclude "hamrah-khodro-*.apk" \
  ./ "$BSRC/"
rm -rf "$BSRC/node_modules"
cp -al "$PROJ/node_modules" "$BSRC/node_modules"
test -d "$BSRC/src/app"

echo "── ۲) پچ برای بیلد استاتیک"
cd "$BSRC"
python3 - <<'PYEOF'
src = open('src/app/layout.tsx', encoding='utf-8').read()
src = src.replace('import { Geist, Geist_Mono } from "next/font/google";\n', '')
import re
src = re.sub(r'const geistSans = Geist\([^)]*\);\n\n', '', src)
src = re.sub(r'const geistMono = Geist_Mono\([^)]*\);\n\n', '', src)
src = src.replace('icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",', 'icon: "/logo.svg",')
src = re.sub(r'className=\{`\$\{geistSans\.variable\} \$\{geistMono\.variable\} antialiased bg-background text-foreground`\}', 'className="antialiased bg-background text-foreground"', src)
open('src/app/layout.tsx', 'w', encoding='utf-8').write(src)
print("layout patched")
PYEOF

rm -rf "$BSRC/src/app/api"

cat > "$BSRC/next.config.ts" <<'CFGEOF'
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  distDir: ".next-build",
  images: { unoptimized: true },
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
};

export default nextConfig;
CFGEOF

echo "── ۳) بیلد Next.js (استاتیک)"
cd "$BSRC"
rm -rf .next-build out
bunx next build 2>&1 | tail -4

WWW_OUT="$BSRC/out"
if [ ! -f "$WWW_OUT/index.html" ] && [ -f "$BSRC/.next-build/index.html" ]; then
  WWW_OUT="$BSRC/.next-build"
fi
echo "www output: $WWW_OUT"
test -f "$WWW_OUT/index.html"

echo "── ۴) پاک‌سازی و تزریق BRIDGE_INIT"
rm -rf "$WWW_OUT/files" "$WWW_OUT/apk"
python3 "$WORK/inject_bridge.py" "$WWW_OUT/index.html"

echo "── ۵) خروجی نهایی www + همگام‌سازی با apk-mock"
rm -rf "$WORK/www-final"
mkdir -p "$WORK/www-final"
cp -r "$WWW_OUT/." "$WORK/www-final/"
rm -rf "$WORK/www-final/robots.txt" 2>/dev/null || true
rm -rf "$PROJ/mini-services/apk-mock/www-final"
cp -r "$WORK/www-final" "$PROJ/mini-services/apk-mock/www-final"
echo "OK: mock www-final updated (hot-reload serves new build)"
