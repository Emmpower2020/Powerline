#!/usr/bin/env python3
"""
patch_manifest_v395.py — جراحی باینری AndroidManifest.xml برای v3.9.5
  - versionName: "3.9.0" → "3.9.5" (هم‌طول — تعویض درجا: جایگاه ۴ '0'→'5')
  - versionCode: 28 → 33 (تعویض مقدار INT_DEC درجا)
پایه: APK v3.9.0
"""
import struct
import sys


def main():
    path = sys.argv[1]
    data = bytearray(open(path, "rb").read())
    if data[:4] != b"\x03\x00\x08\x00":
        raise SystemExit("ERROR: not a binary AXML file")

    sp_type, sp_hdr, sp_size = struct.unpack_from("<HHI", data, 8)
    if sp_type != 0x0001:
        raise SystemExit("ERROR: first chunk is not a string pool")
    str_count, style_count, flags, strings_start, _styles_start = struct.unpack_from("<IIIII", data, 8 + 8)
    is_utf8 = bool(flags & 0x100)
    if is_utf8:
        raise SystemExit("ERROR: UTF-8 pool not expected")
    offsets_base = 8 + sp_hdr
    strings = []
    for i in range(str_count):
        off = struct.unpack_from("<I", data, offsets_base + 4 * i)[0]
        p = 8 + strings_start + off
        ln = struct.unpack_from("<H", data, p)[0]
        s = data[p + 2 : p + 2 + ln * 2].decode("utf-16-le")
        strings.append((p + 2, ln, s))

    try:
        idx_vn = next(i for i, (_, _, s) in enumerate(strings) if s == "versionName")
        idx_vc = next(i for i, (_, _, s) in enumerate(strings) if s == "versionCode")
    except StopIteration:
        raise SystemExit("ERROR: versionName/versionCode strings not found in pool")
    print(f"string pool: {str_count} strings — versionName idx={idx_vn}, versionCode idx={idx_vc}")

    patched_vn = False
    patched_vc = False

    pos = 8 + sp_size
    end = len(data)
    while pos + 8 <= end:
        ctype, _chdr, csize = struct.unpack_from("<HHI", data, pos)
        if csize <= 0:
            break
        if ctype == 0x0102:
            (_line, _comment, _ns, _name, attr_start, attr_size, attr_count) = struct.unpack_from(
                "<IIIIHHH", data, pos + 8
            )
            if attr_size == 0:
                attr_size = 20
            attrs_base = pos + 16 + attr_start
            for i in range(attr_count):
                a = attrs_base + i * attr_size
                a_ns, a_name, a_raw = struct.unpack_from("<III", data, a)
                v_size, _v_res0, v_type = struct.unpack_from("<HBB", data, a + 12)
                v_data = struct.unpack_from("<I", data, a + 16)[0]
                if a_name == idx_vn:
                    target = a_raw if a_raw != 0xFFFFFFFF else v_data
                    p, ln, s = strings[target]
                    if s != "3.9.0":
                        print(f"WARN: versionName string is {s!r} — skipping")
                        continue
                    # "3.9.0" → "3.9.5": جایگاه ۴
                    data[p + 2 * 4 : p + 2 * 5] = "5".encode("utf-16-le")
                    patched_vn = True
                if a_name == idx_vc and v_type == 0x10:
                    if v_data != 28:
                        print(f"WARN: versionCode is {v_data} — skipping")
                        continue
                    struct.pack_into("<I", data, a + 16, 33)
                    patched_vc = True
        pos += csize

    if not patched_vn:
        raise SystemExit("ERROR: versionName not patched")
    if not patched_vc:
        raise SystemExit("ERROR: versionCode not patched")
    open(path, "wb").write(bytes(data))
    print("OK: manifest patched → 3.9.5 / versionCode 33")


if __name__ == "__main__":
    main()
