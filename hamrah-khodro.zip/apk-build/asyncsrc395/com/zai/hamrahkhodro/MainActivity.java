package com.zai.hamrahkhodro;

import android.app.Activity;
import android.webkit.WebView;

/** Stub MainActivity — فقط getWebView واقعاً به dex نهایی اضافه می‌شود */
public class MainActivity extends Activity {
    private WebView webView;

    public WebView getWebView() {
        return webView;
    }
}
