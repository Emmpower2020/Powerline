package com.zai.hamrahkhodro;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.webkit.JavascriptInterface;

/**
 * CloudBridge (asyncsrc393) — فقط متدهای جدید فایربیس v3.9.3 + روتر ریدایرکت.
 *
 * متدهای استاب (اعضای موجود کلاس واقعی) فقط برای کامپایل‌اند و به dex نهایی
 * کپی نمی‌شوند؛ از خروجی baksmali فقط متدهای fb* و handleRedirect (روتر) برداشته و
 * به CloudBridge.smali واقعی پیوند می‌خورند (همان روش v3.8.8).
 */
public class CloudBridge {

    // ══════════ Stub — آینهٔ اعضای واقعی کلاس (برای کامپایل؛ کپی نمی‌شود) ══════════
    private final Activity activity;

    public CloudBridge(Activity activity) {
        this.activity = activity;
    }

    public String driveRequest(String method, String url, String contentType, String body) {
        return null;
    }

    public String exchangeCode() {
        return null;
    }

    public String disconnect() {
        return null;
    }
    // ══════════ پایان stub ══════════

    // ══════════ REAL v3.9.3 — پل فایربیس (این متدها به dex نهایی کپی می‌شوند) ══════════

    @JavascriptInterface
    public void fbStartAuthAsync(String callback) {
        try {
            new Thread(new FbReq(activity, 0, null, null, null, null, callback)).start();
        } catch (Throwable ignored) {
        }
    }

    @JavascriptInterface
    public void fbExchangeCodeAsync(String callback) {
        try {
            new Thread(new FbReq(activity, 1, null, null, null, null, callback)).start();
        } catch (Throwable ignored) {
        }
    }

    @JavascriptInterface
    public void fbRequestAsync(String method, String url, String contentType, String body, String callback) {
        try {
            new Thread(new FbReq(activity, 2, method, url, contentType, body, callback)).start();
        } catch (Throwable ignored) {
        }
    }

    @JavascriptInterface
    public void fbDisconnectAsync(String callback) {
        try {
            new Thread(new FbReq(activity, 3, null, null, null, null, callback)).start();
        } catch (Throwable ignored) {
        }
    }

    /** ⭐ v3.9.5 — بررسی وضعیت راه‌اندازی (network/identity/firestore) بدون نیاز به ورود */
    @JavascriptInterface
    public void fbProbeAsync(String probe, String callback) {
        try {
            new Thread(new FbReq(activity, 4, probe, null, null, null, callback)).start();
        } catch (Throwable ignored) {
        }
    }

    /** سریع و بدون شبکه — مستقیم در نخ bridge اجرا می‌شود */
    @JavascriptInterface
    public String fbPollAuth() {
        return FbSession.pollAuth(activity);
    }

    @JavascriptInterface
    public String fbCancelAuth() {
        return FbSession.cancelAuth(activity);
    }

    @JavascriptInterface
    public String fbGetAccount() {
        return FbSession.getAccount(activity);
    }

    // ══════════ REAL v3.9.3 — روتر ریدایرکت OAuth ══════════
    // مسیر «fbcallback» به نشست فایربیس می‌رود؛ بقیه به جریان Drive (متد rename شده).

    public static void handleRedirect(Context ctx, Uri uri) {
        try {
            String path = uri != null ? uri.getPath() : null;
            if (path != null && path.indexOf("fbcallback") >= 0) {
                FbSession.handleRedirect(ctx, uri);
                return;
            }
        } catch (Throwable ignored) {
        }
        handleRedirectDrive(ctx, uri);
    }

    /** Stub — در dex واقعی همان متد قدیمی handleRedirect با نام جدید است */
    public static void handleRedirectDrive(Context ctx, Uri uri) {
        // بدنهٔ واقعی در dex پایه (rename شده)
    }
}
