package com.zai.hamrahkhodro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import org.json.JSONObject;

/**
 * FbSession (v3.9.3) — نشست فایربیس «همراه خودرو» — تماماً روی نخ پس‌زمینه.
 *
 * مسیر: OAuth گوگل (مرورگر سیستم + PKCE، بدون Client Secret) → id_token →
 * Firebase Auth REST (signInWithIdp) → نشست فایربیس → پروکسی Firestore REST با Bearer.
 *
 * ⭐ همهٔ پیکربندی در کد تعبیه شده (پروژهٔ hamrahprj) — درخواست کاربر.
 * ⭐ پیام خطا خام گوگل پاس داده می‌شود تا لایهٔ وب با کارت فارسی + دکمهٔ اقدام نگاشتش کند.
 *
 * کلاس کاملاً خودکاست (java.* + org.json + چند API اندروید) و مستقیماً به dex اضافه
 * می‌شود — هیچ وابستگی‌ای به کلاس‌های دیگر برنامه ندارد جز MainActivity.getWebView()
 * که توسط FbDeliver اجرا می‌شود.
 */
public final class FbSession {

    private static final String TAG = "FbSession";
    private static final String PREFS = "hk_fbcloud";

    /** کلاینت OAuth اندروید پروژهٔ hamrahprj (SHA-1 امضای برنامه روی آن ثبت است) */
    private static final String CLIENT_ID =
        "358616461933-okqrjiuosruele895435ti2s2lpgvm46.apps.googleusercontent.com";
    /** Web API Key پروژهٔ hamrahprj */
    private static final String API_KEY = "AIzaSyDitRMguD0DVjqiMxNCbVPuPS0s0D-7uZk";
    /** مسیر بازگشت OAuth — همان اسکیم برنامه با مسیر مخصوص فایربیس */
    private static final String REDIRECT_URI = "com.zai.hamrahkhodro:/fbcallback";
    private static final String SCOPES = "openid email profile";

    private static final String AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
    private static final String TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
    private static final String IDP_ENDPOINT =
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp";
    private static final String PASSWORD_ENDPOINT =
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword";
    private static final String REFRESH_ENDPOINT =
        "https://securetoken.googleapis.com/v1/token";
    /** آدرس دیتابیس برای بررسی وضعیت Firestore (⭐ v3.9.5 — probe بدون ورود) */
    private static final String FIRESTORE_DB_URL =
        "https://firestore.googleapis.com/v1/projects/hamrahprj/databases/(default)";
    /** فقط این هاست‌ها از لایهٔ وب قابل فراخوانی‌اند (هر URL دیگری رد می‌شود) */
    private static final String[] ALLOWED_HOSTS = {
        "identitytoolkit.googleapis.com",
        "firestore.googleapis.com",
        "securetoken.googleapis.com",
    };

    private static final long FLOW_TIMEOUT_MS = 300000L;
    private static final int MAX_BODY = 0x800000; // ۸ مگابایت

    private FbSession() {}

    /* ───────────────────────────── ابزارها ───────────────────────────── */

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, 0);
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Throwable t) {
            return s;
        }
    }

    private static String urlDecode(String s) {
        if (s == null) return null;
        try {
            return java.net.URLDecoder.decode(s, "UTF-8");
        } catch (Throwable t) {
            return s;
        }
    }

    private static String b64url(byte[] b) {
        try {
            String s = android.util.Base64.encodeToString(b, android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
            return s;
        } catch (Throwable t) {
            // نباید رخ دهد — Base64 از API 8 موجود است
            return "";
        }
    }

    private static byte[] sha256(byte[] b) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(b);
        } catch (Throwable t) {
            return new byte[0];
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static String err(String code, String desc) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("error", code);
            if (desc != null) o.put("errorDescription", desc);
            return o.toString();
        } catch (Throwable t) {
            return "{\"ok\":false,\"error\":\"unknown\"}";
        }
    }

    /** خطا همراه پیام خام گوگل — لایهٔ وب تشخیص دقیق (Identity Toolkit/Firestore غیرفعال و…) می‌سازد */
    private static String errRaw(String code, String raw, int status) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("error", code);
            o.put("status", status);
            if (raw != null && raw.length() > 0) o.put("message", raw.length() > 1500 ? raw.substring(0, 1500) : raw);
            return o.toString();
        } catch (Throwable t) {
            return err(code, null);
        }
    }

    /* ───────────────────────────── HTTP ───────────────────────────── */

    private static final class HttpResult {
        final int code;
        final String body;
        HttpResult(int code, String body) { this.code = code; this.body = body; }
    }

    private static String readAll(InputStream in, int limit) {
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > limit) break;
                bo.write(buf, 0, n);
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return "";
        }
    }

    private static HttpResult httpPost(String url, String contentType, String body) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", contentType);
            c.setRequestProperty("Accept", "application/json");
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.flush();
            os.close();
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String resp = is != null ? readAll(is, MAX_BODY) : "";
            return new HttpResult(code, resp);
        } catch (Throwable t) {
            Log.w(TAG, "httpPost " + url, t);
            return new HttpResult(0, "");
        } finally {
            if (c != null) try { c.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private static HttpResult httpRequest(String method, String url, String contentType, String body, String bearer) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/json");
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
            if (body != null && body.length() > 0) {
                c.setDoOutput(true);
                if (contentType != null) c.setRequestProperty("Content-Type", contentType);
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(b.length);
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.flush();
                os.close();
            }
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String resp = is != null ? readAll(is, MAX_BODY) : "";
            return new HttpResult(code, resp);
        } catch (Throwable t) {
            Log.w(TAG, "httpRequest " + method + " " + url, t);
            return new HttpResult(0, "");
        } finally {
            if (c != null) try { c.disconnect(); } catch (Throwable ignored) {}
        }
    }

    /* ───────────────────────────── ورود (OAuth گوگل) ───────────────────────────── */

    /** باز کردن صفحهٔ مرورگر سیستم — باید در نخ UI اجرا شود */
    private static final class UiOpen implements Runnable {
        private final Activity activity;
        private final String url;
        UiOpen(Activity activity, String url) { this.activity = activity; this.url = url; }
        @Override public void run() {
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Throwable t) {
                Log.w(TAG, "open browser failed", t);
            }
        }
    }

    /**
     * پیش‌بررسی URL مجوز — همان ترفند v3.8: اگر «Enable custom URI scheme» تیک نخورده
     * باشد گوگل به صفحهٔ خطا ریدایرکت می‌کند؛ قبل از باز شدن مرورگر تشخیصش می‌دهیم.
     */
    private static String precheck(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            if (code >= 300 && code < 400 && loc != null
                    && loc.startsWith("https://accounts.google.com/signin/oauth/error")) {
                String d = urlDecode(loc);
                if (d != null) {
                    if (d.contains("Custom URI scheme is not enabled")) return "custom_scheme_disabled";
                    if (d.contains("redirect_uri_mismatch") || d.contains("Invalid Redirect")) return "redirect_uri_mismatch";
                    if (d.contains("invalid_client") || d.contains("Invalid client")) return "invalid_client";
                }
            }
            return null; // سالم
        } catch (Throwable t) {
            Log.w(TAG, "precheck", t);
            return "network";
        } finally {
            if (c != null) try { c.disconnect(); } catch (Throwable ignored) {}
        }
    }

    /** گام ۱ — شروع جریان ورود (نخ پس‌زمینه): PKCE + ذخیرهٔ وضعیت + باز شدن مرورگر */
    public static String startAuth(Activity activity) {
        SharedPreferences p = prefs(activity);
        String st = p.getString("flow_state", "none");
        if ("waiting".equals(st)) {
            return err("busy", "یک جریان اتصال در حال اجراست");
        }
        clearFlow(p);
        try {
            SecureRandom sr = new SecureRandom();
            byte[] vb = new byte[32];
            sr.nextBytes(vb);
            String verifier = b64url(vb);
            String challenge = b64url(sha256(verifier.getBytes(StandardCharsets.US_ASCII)));
            byte[] seed = new byte[8];
            sr.nextBytes(seed);
            String token = hex(seed);

            String url = AUTH_ENDPOINT
                + "?client_id=" + enc(CLIENT_ID)
                + "&redirect_uri=" + enc(REDIRECT_URI)
                + "&response_type=code"
                + "&scope=" + enc(SCOPES)
                + "&state=" + enc(token)
                + "&code_challenge=" + enc(challenge)
                + "&code_challenge_method=S256"
                + "&prompt=select_account";

            String pre = precheck(url);
            if (pre != null) {
                if ("network".equals(pre)) {
                    return err("network", "اتصال به سرور گوگل برقرار نشد — اینترنت گوشی را بررسی کنید");
                }
                if ("custom_scheme_disabled".equals(pre)) {
                    return err("custom_scheme_disabled",
                        "Custom URI scheme is not enabled for your Android client.");
                }
                return err(pre, pre);
            }

            p.edit()
                .putString("flow_state", "waiting")
                .putString("flow_verifier", verifier)
                .putString("flow_token", token)
                .putString("flow_code", "")
                .putString("flow_error", "")
                .putLong("flow_started", System.currentTimeMillis())
                .commit();

            activity.runOnUiThread(new UiOpen(activity, url));

            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("authUrl", url);
            o.put("redirectUri", REDIRECT_URI);
            return o.toString();
        } catch (Throwable t) {
            Log.w(TAG, "startAuth", t);
            return err("unknown", String.valueOf(t));
        }
    }

    /** دریافت ریدایرکت گوگل (از AuthActivity از طریق روتر CloudBridge.handleRedirect) */
    public static void handleRedirect(Context ctx, Uri uri) {
        try {
            if (ctx == null || uri == null) return;
            String s = uri.toString();
            if (s == null) return;
            String code = null, error = null, state = null;
            int qi = s.indexOf('?');
            if (qi >= 0) {
                String q = s.substring(qi + 1);
                int hi = q.indexOf('#');
                if (hi >= 0) q = q.substring(0, hi);
                String[] parts = q.split("&");
                for (String part : parts) {
                    int ei = part.indexOf('=');
                    if (ei <= 0) continue;
                    String k = part.substring(0, ei);
                    String v = urlDecode(part.substring(ei + 1));
                    if ("code".equals(k)) code = v;
                    else if ("error".equals(k)) error = v;
                    else if ("state".equals(k)) state = v;
                }
            }
            SharedPreferences p = prefs(ctx);
            String token = p.getString("flow_token", null);
            if (token != null && state != null && state.length() > 0 && !token.equals(state)) {
                Log.w(TAG, "state mismatch — ignore redirect");
                return;
            }
            if (code != null && code.length() > 0) {
                p.edit()
                    .putString("flow_state", "done")
                    .putString("flow_code", code)
                    .putString("flow_error", "")
                    .commit();
                Log.i(TAG, "fb auth code captured");
            } else if (error != null && error.length() > 0) {
                p.edit()
                    .putString("flow_state", "error")
                    .putString("flow_error", error)
                    .commit();
                Log.i(TAG, "fb auth error: " + error);
            }
        } catch (Throwable t) {
            Log.w(TAG, "handleRedirect", t);
        }
    }

    /** وضعیت جریان ورود — سریع و بدون شبکه (فراخوانی sync از JS) */
    public static String pollAuth(Context ctx) {
        try {
            SharedPreferences p = prefs(ctx);
            String st = p.getString("flow_state", "none");
            if ("waiting".equals(st) && System.currentTimeMillis() - p.getLong("flow_started", 0L) > FLOW_TIMEOUT_MS) {
                st = "timeout";
            }
            // v3.9.4: جریان exchanging مُرده (پروسه در میانهٔ تبدیل کشته شده) → none
            if ("exchanging".equals(st) && System.currentTimeMillis() - p.getLong("flow_started", 0L) > FLOW_TIMEOUT_MS) {
                clearFlow(p);
                st = "none";
            }
            JSONObject o = new JSONObject();
            o.put("state", st);
            if ("done".equals(st)) o.put("hasCode", true);
            if ("error".equals(st)) o.put("error", p.getString("flow_error", ""));
            return o.toString();
        } catch (Throwable t) {
            return "{\"state\":\"none\"}";
        }
    }

    public static String cancelAuth(Context ctx) {
        clearFlow(prefs(ctx));
        return "{\"ok\":true}";
    }

    private static void clearFlow(SharedPreferences p) {
        p.edit()
            .remove("flow_state").remove("flow_code").remove("flow_error")
            .remove("flow_verifier").remove("flow_token").remove("flow_started")
            .commit();
    }

    /* ───────────────────────────── تبدیل کد → نشست فایربیس ───────────────────────────── */

    /** گام ۳ — code → id_token → signInWithIdp → ذخیرهٔ نشست (نخ پس‌زمینه)
     *  ⭐ v3.9.4:
     *   ۱) بدنهٔ signInWithIdp حالا JSON استاندارد REST است: postBody + requestUri +
     *      returnSecureToken — نسخهٔ قبل «uri=» می‌فرستاد و گوگل 400 MISSING_REQUEST_URI
     *      برمی‌گرداند (ریشهٔ اصلی «ورود به سرور پشتیبان انجام نشد»).
     *   ۲) تصاحب اتمیک جریان (synchronized + حالت exchanging) — دیگر دو نخِ همزمان
     *      (بوت/پنجرهٔ تنظیمات) نمی‌توانند یک کد oauth را دوبار مصرف کنند.
     *   ۳) خطای invalid_grant (کد یک‌بارمصرف/منقضی) → code_used + پاک‌شدن جریان تا
     *      «تلاش دوباره» ورود تازهٔ مرورگر را باز کند. */
    public static synchronized String exchangeCode(Context ctx) {
        SharedPreferences p = prefs(ctx);
        String st = p.getString("flow_state", "none");
        if ("exchanging".equals(st)) {
            // حالت exchanging مانده از پروسهٔ کشته‌شده (>۵ دقیقه) → بازیابی؛ وگرنه busy
            if (System.currentTimeMillis() - p.getLong("flow_started", 0L) > FLOW_TIMEOUT_MS) {
                clearFlow(p);
                return err("code_used", "کد ورود منقضی شده — دوباره تلاش کنید تا صفحهٔ گوگل از نو باز شود");
            }
            return err("busy", "در حال تبدیل کد ورود است — کمی صبر کنید");
        }
        if (!"done".equals(st)) {
            return err("no_code", "کدی برای تبدیل وجود ندارد — ابتدا جریان اتصال را کامل کنید");
        }
        // تصاحب اتمیک — فقط یک نخ این کد را تبدیل می‌کند
        p.edit().putString("flow_state", "exchanging").commit();
        String code = p.getString("flow_code", "");
        String verifier = p.getString("flow_verifier", "");
        try {
            // ۱) تبدیل کد به توکن گوگل
            String body = "grant_type=authorization_code"
                + "&code=" + enc(code)
                + "&client_id=" + enc(CLIENT_ID)
                + "&code_verifier=" + enc(verifier)
                + "&redirect_uri=" + enc(REDIRECT_URI);
            HttpResult r = httpPost(TOKEN_ENDPOINT, "application/x-www-form-urlencoded", body);
            if (r.code == 0) {
                // شبکه خطا خورد و کد هنوز مصرف نشده — جریان برای تلاش مجدد برمی‌گردد
                p.edit().putString("flow_state", "done").commit();
                return err("network", "اتصال به گوگل برقرار نشد");
            }
            if (r.code != 200) {
                boolean used = r.body != null && r.body.contains("invalid_grant");
                clearFlow(p);
                if (used) return err("code_used", "کد ورود یک‌بارمصرف است — دوباره تلاش کنید تا صفحهٔ گوگل از نو باز شود");
                return errRaw("exchange_failed", r.body, r.code);
            }
            JSONObject j = new JSONObject(r.body);
            String idToken = j.optString("id_token", "");
            if (idToken.length() == 0) {
                clearFlow(p);
                return errRaw("exchange_failed", r.body, r.code);
            }

            // ۲) ورود به فایربیس با id_token — ⭐ بدنهٔ JSON استاندارد REST:
            //    postBody (providerId + id_token + uri) + requestUri (الزامی!) + returnSecureToken
            JSONObject jb = new JSONObject();
            jb.put("postBody", "providerId=google.com&id_token=" + idToken + "&uri=https://localhost");
            jb.put("requestUri", "https://localhost");
            jb.put("returnSecureToken", true);
            HttpResult r2 = httpPost(IDP_ENDPOINT + "?key=" + enc(API_KEY), "application/json", jb.toString());
            if (r2.code == 0) {
                // خطای شبکه — id_token هنوز معتبر است؛ جریان done می‌ماند تا دوباره تلاش شود
                p.edit().putString("flow_state", "done").commit();
                return err("network", "اتصال به فایربیس برقرار نشد");
            }
            if (r2.code != 200) {
                // id_token با خطای سرور رد شد — کد oauth در گوگل مصرف شده؛ جریان پاک شود
                clearFlow(p);
                return errRaw("signin_failed", r2.body, r2.code);
            }
            JSONObject j2 = new JSONObject(r2.body);
            String uid = j2.optString("localId", "");
            String email = j2.optString("email", "");
            String fbId = j2.optString("idToken", "");
            String fbRefresh = j2.optString("refreshToken", "");
            double expiresIn = j2.optDouble("expiresIn", 3600.0);
            if (uid.length() == 0 || fbId.length() == 0) {
                clearFlow(p);
                return errRaw("signin_failed", r2.body, r2.code);
            }

            p.edit()
                .putString("s_uid", uid)
                .putString("s_email", email)
                .putString("s_id_token", fbId)
                .putString("s_refresh_token", fbRefresh)
                .putLong("s_expires", System.currentTimeMillis() + (long) (expiresIn * 1000.0))
                .commit();
            clearFlow(p);

            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("email", email);
            o.put("uid", uid);
            return o.toString();
        } catch (Throwable t) {
            Log.w(TAG, "exchangeCode", t);
            clearFlow(prefs(ctx));
            return err("unknown", String.valueOf(t));
        }
    }

    /* ───────────────────────────── نشست ───────────────────────────── */

    public static String getAccount(Context ctx) {
        try {
            SharedPreferences p = prefs(ctx);
            String uid = p.getString("s_uid", "");
            String idToken = p.getString("s_id_token", "");
            if (uid.length() == 0 || idToken.length() == 0) {
                return "{\"connected\":false}";
            }
            JSONObject o = new JSONObject();
            o.put("connected", true);
            o.put("email", p.getString("s_email", ""));
            o.put("uid", uid);
            return o.toString();
        } catch (Throwable t) {
            return "{\"connected\":false}";
        }
    }

    /** توکن معتبر با نوسازی خودکار — null یعنی نشست باطل */
    private static String freshIdToken(Context ctx) {
        try {
            SharedPreferences p = prefs(ctx);
            String uid = p.getString("s_uid", "");
            String idToken = p.getString("s_id_token", "");
            String refresh = p.getString("s_refresh_token", "");
            if (uid.length() == 0 || idToken.length() == 0) return null;
            if (System.currentTimeMillis() < p.getLong("s_expires", 0L) - 60000L) return idToken;
            if (refresh.length() == 0) return null;
            // نوسازی از securetoken
            String body = "grant_type=refresh_token&refresh_token=" + enc(refresh);
            HttpResult r = httpPost(REFRESH_ENDPOINT + "?key=" + enc(API_KEY), "application/x-www-form-urlencoded", body);
            if (r.code != 200) {
                Log.w(TAG, "refresh failed " + r.code);
                return null;
            }
            JSONObject j = new JSONObject(r.body);
            String newId = j.optString("id_token", "");
            String newRefresh = j.optString("refresh_token", "");
            double expiresIn = j.optDouble("expires_in", 3600.0);
            if (newId.length() == 0) return null;
            p.edit()
                .putString("s_id_token", newId)
                .putString("s_refresh_token", newRefresh.length() > 0 ? newRefresh : refresh)
                .putLong("s_expires", System.currentTimeMillis() + (long) (expiresIn * 1000.0))
                .commit();
            return newId;
        } catch (Throwable t) {
            Log.w(TAG, "freshIdToken", t);
            return null;
        }
    }

    /**
     * پروکسی REST فایربیس — درخواست با Bearer نشست؛ در 401 یک‌بار نوسازی و تلاش مجدد.
     * خروجی: {"ok":true,"status":…,"body":"…"} یا {"ok":false,"error":"network|disconnected|bad_url"}
     */
    public static String request(Context ctx, String method, String url, String contentType, String body) {
        try {
            if (url == null) return err("bad_url", "آدرس نامعتبر");
            URL u = new URL(url);
            String host = u.getHost();
            boolean allowed = false;
            for (String h : ALLOWED_HOSTS) {
                if (h.equals(host)) { allowed = true; break; }
            }
            if (!allowed) return err("bad_url", "فقط سرویس‌های فایربیس قابل فراخوانی‌اند");

            String token = freshIdToken(ctx);
            if (token == null) return err("disconnected", "نشست فایربیس معتبر نیست");

            String m = method == null ? "GET" : method.toUpperCase();
            HttpResult r = httpRequest(m, url, contentType, body, token);
            if (r.code == 401) {
                // نوسازی اجباری و تلاش دوباره — یک‌بار
                SharedPreferences p = prefs(ctx);
                p.edit().putLong("s_expires", 0L).commit();
                String token2 = freshIdToken(ctx);
                if (token2 != null) {
                    r = httpRequest(m, url, contentType, body, token2);
                }
            }
            if (r.code == 0) return err("network", "اتصال به سرور برقرار نشد");
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("status", r.code);
            o.put("body", r.body == null ? "" : r.body);
            return o.toString();
        } catch (Throwable t) {
            Log.w(TAG, "request", t);
            return err("unknown", String.valueOf(t));
        }
    }

    /** خروج — نشست محلی پاک می‌شود (دادهٔ سرور دست‌نخورده می‌ماند) */
    public static String disconnect(Context ctx) {
        try {
            prefs(ctx).edit()
                .remove("s_uid").remove("s_email").remove("s_id_token")
                .remove("s_refresh_token").remove("s_expires")
                .commit();
            clearFlow(prefs(ctx));
            return "{\"ok\":true}";
        } catch (Throwable t) {
            return "{\"ok\":true}";
        }
    }

    /* ───────────────────── v3.9.5: بررسی وضعیت راه‌اندازی (شیت گام‌به‌گام) ───────────────────── */

    /**
     * بررسی وضعیت سرویس‌های گوگل بدون نیاز به ورود — برای «راه‌اندازی گام‌به‌گام»:
     *   network   → فقط دسترسی اینترنت به گوگل (هر پاسخ HTTP = موفق)
     *   identity  → Identity Toolkit API: درخواست ورود ساختگی؛ 4xx = API فعال،
     *               403 با «has not been used» = غیرفعال (لایهٔ وب پیام را نگاشت می‌کند)
     *   firestore → Cloud Firestore API بدون Bearer؛ 401 = API فعال، 403 «has not been used» = غیرفعال
     * خروجی: {"ok":true,"status":…,"body":"…"} یا {"ok":false,"error":"network|bad_probe"}
     */
    public static String probe(Context ctx, String kind) {
        try {
            if (kind == null) return err("bad_probe", "نوع بررسی نامعتبر است");
            if ("network".equals(kind)) {
                // هر پاسخ HTTP (حتی ریدایرکت) یعنی اینترنت و دسترسی به گوگل هست
                HttpResult r = httpRequest("GET", AUTH_ENDPOINT, null, null, null);
                if (r.code == 0) return err("network", "اتصال به سرور گوگل برقرار نشد");
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("status", r.code);
                return o.toString();
            }
            if ("identity".equals(kind)) {
                JSONObject b = new JSONObject();
                b.put("email", "probe@hamrah.invalid");
                b.put("password", "0123456789");
                b.put("returnSecureToken", true);
                HttpResult r = httpPost(PASSWORD_ENDPOINT + "?key=" + enc(API_KEY), "application/json", b.toString());
                if (r.code == 0) return err("network", "اتصال به سرور گوگل برقرار نشد");
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("status", r.code);
                o.put("body", r.body == null ? "" : r.body);
                return o.toString();
            }
            if ("firestore".equals(kind)) {
                HttpResult r = httpRequest("GET", FIRESTORE_DB_URL, null, null, null);
                if (r.code == 0) return err("network", "اتصال به سرور گوگل برقرار نشد");
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("status", r.code);
                o.put("body", r.body == null ? "" : r.body);
                return o.toString();
            }
            return err("bad_probe", "نوع بررسی ناشناخته: " + kind);
        } catch (Throwable t) {
            Log.w(TAG, "probe", t);
            return err("unknown", String.valueOf(t));
        }
    }
}
