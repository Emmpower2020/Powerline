package com.zai.hamrahkhodro;

import android.app.Activity;

/**
 * کار ابری فایربیس روی نخ پس‌زمینه — همان الگوی CloudBridge$AsyncReq v3.8.8
 * (کامپایلر تولید می‌کند → بایت‌کد کانونیک → Verifier اندروید همیشه قبول می‌کند).
 *  kind 0 = startAuth، 1 = exchangeCode، 2 = request، 3 = disconnect، 4 = probe (v3.9.5)
 */
final class FbReq implements Runnable {
    private final Activity activity;
    private final int kind;
    private final String a;
    private final String b;
    private final String c;
    private final String d;
    private final String callback;

    FbReq(Activity activity, int kind, String a, String b, String c, String d, String callback) {
        this.activity = activity;
        this.kind = kind;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.callback = callback;
    }

    @Override
    public void run() {
        if (callback == null) {
            return;
        }
        String json;
        try {
            if (kind == 0) {
                json = FbSession.startAuth(activity);
            } else if (kind == 1) {
                json = FbSession.exchangeCode(activity);
            } else if (kind == 2) {
                json = FbSession.request(activity, a, b, c, d);
            } else if (kind == 4) {
                json = FbSession.probe(activity, a);
            } else {
                json = FbSession.disconnect(activity);
            }
        } catch (Throwable t) {
            json = "{\"ok\":false,\"error\":\"async_crash\"}";
        }
        if (json == null) {
            json = "{\"ok\":false,\"error\":\"async_null\"}";
        }
        String js = callback + "(" + json + ");";
        try {
            activity.runOnUiThread(new FbDeliver(activity, js));
        } catch (Throwable ignored) {
        }
    }
}
