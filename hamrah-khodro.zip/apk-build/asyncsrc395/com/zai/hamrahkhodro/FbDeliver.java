package com.zai.hamrahkhodro;

import android.app.Activity;
import android.webkit.WebView;

/** تحویل نتیجهٔ ابری به JS در نخ UI — همان الگوی CloudBridge$AsyncDeliver */
final class FbDeliver implements Runnable {
    private final Activity activity;
    private final String js;

    FbDeliver(Activity activity, String js) {
        this.activity = activity;
        this.js = js;
    }

    @Override
    public void run() {
        try {
            WebView wv = ((MainActivity) activity).getWebView();
            if (wv != null) {
                wv.evaluateJavascript(js, null);
            }
        } catch (Throwable ignored) {
        }
    }
}
