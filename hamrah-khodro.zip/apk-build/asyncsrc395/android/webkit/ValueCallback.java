package android.webkit;
public interface ValueCallback<S> {
    void onReceiveValue(S value);
}
