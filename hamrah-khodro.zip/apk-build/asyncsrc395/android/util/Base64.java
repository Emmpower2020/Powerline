package android.util;
/** Stub — فقط برای کامپایل */
public class Base64 {
    public static final int DEFAULT = 0;
    public static final int NO_PADDING = 1;
    public static final int NO_WRAP = 2;
    public static final int URL_SAFE = 8;
    public static String encodeToString(byte[] input, int flags) { return null; }
}
