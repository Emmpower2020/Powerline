package android.util;
/** Stub — فقط برای کامپایل */
public class Log {
    public static int w(String tag, String msg) { return 0; }
    public static int w(String tag, String msg, Throwable tr) { return 0; }
    public static int i(String tag, String msg) { return 0; }
    public static int e(String tag, String msg) { return 0; }
}
