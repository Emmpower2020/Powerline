package android.content;
/** Stub — فقط برای کامپایل (کپی نمی‌شود به dex نهایی) */
public class Context {
    public SharedPreferences getSharedPreferences(String name, int mode) { return null; }
}
