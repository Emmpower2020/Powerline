package android.content;
/** Stub — فقط برای کامپایل (امضای متدها با پلتفرم واقعی یکسان است) */
public interface SharedPreferences {
    interface Editor {
        Editor putString(String key, String value);
        Editor putLong(String key, long value);
        Editor remove(String key);
        boolean commit();
    }
    Editor edit();
    String getString(String key, String defValue);
    long getLong(String key, long defValue);
}
