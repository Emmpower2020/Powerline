package android.content;
import android.net.Uri;
/** Stub — فقط برای کامپایل */
public class Intent {
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public Intent(String action) {}
    public Intent(String action, Uri uri) {}
}
