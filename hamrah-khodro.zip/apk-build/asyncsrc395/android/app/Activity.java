package android.app;
import android.content.Context;
import android.content.Intent;
/** Stub — فقط برای کامپایل */
public class Activity extends Context {
    public void runOnUiThread(Runnable action) {}
    public void startActivity(Intent intent) {}
}
