package android.net;
/** Stub — فقط برای کامپایل */
public class Uri {
    public static Uri parse(String uriString) { return null; }
    @Override public String toString() { return null; }
    public String getPath() { return null; }
    public String getScheme() { return null; }
}
