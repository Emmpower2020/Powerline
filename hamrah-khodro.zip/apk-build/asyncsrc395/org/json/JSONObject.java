package org.json;
/** Stub — فقط برای کامپایل (در اندروید واقعی موجود است) */
public class JSONObject {
    public JSONObject() {}
    public JSONObject(String json) {}
    public JSONObject put(String key, boolean value) { return this; }
    public JSONObject put(String key, int value) { return this; }
    public JSONObject put(String key, long value) { return this; }
    public JSONObject put(String key, double value) { return this; }
    public JSONObject put(String key, Object value) { return this; }
    public String optString(String key, String fallback) { return fallback; }
    public double optDouble(String key, double fallback) { return fallback; }
    @Override public String toString() { return "{}"; }
}
