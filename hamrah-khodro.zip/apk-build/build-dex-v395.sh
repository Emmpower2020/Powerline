#!/bin/bash
# build-dex-v395.sh — کامپایل asyncsrc395 (ecj) → d8 → baksmali → پیوند به smali واقعی → smali → classes-v395.dex
set -euo pipefail
WORK=/home/z/apk-build/work
BT=/home/z/apk-build/bt/android-14
TOOLS=/home/z/apk-build/tools
SRC=$WORK/asyncsrc395
SMALI_LIB="$TOOLS/smali-2.5.2.jar:$TOOLS/baksmali-2.5.2.jar:$TOOLS/dexlib2-2.5.2.jar:$TOOLS/util-2.5.2.jar:$TOOLS/guava-22.0.jar:$TOOLS/jcommander-1.82.jar:$TOOLS/antlr-runtime-3.5.3.jar"

echo "── ۱) کامپایل با ecj (بایت‌کد Java 8)"
rm -rf "$WORK/gen-classes" && mkdir -p "$WORK/gen-classes"
find "$SRC" -name '*.java' > /tmp/srcs395.txt
java -jar "$TOOLS/ecj-3.36.0.jar" -source 8 -target 8 -nowarn -encoding UTF-8 -d "$WORK/gen-classes" @/tmp/srcs395.txt 2>&1 | grep -v "^$" | head -10 || true
test -f "$WORK/gen-classes/com/zai/hamrahkhodro/FbSession.class"

echo "── ۲) d8 → dex قطعهٔ تولیدی"
rm -rf "$WORK/gen-dex" && mkdir -p "$WORK/gen-dex"
export LD_LIBRARY_PATH="$BT/lib64"
"$BT/d8" --release --min-api 21 --output "$WORK/gen-dex" \
  $(find "$WORK/gen-classes/com" -name '*.class')
test -f "$WORK/gen-dex/classes.dex"

echo "── ۳) baksmali → smali تولیدی"
rm -rf "$WORK/gen-smali" && mkdir -p "$WORK/gen-smali"
java -cp "$SMALI_LIB" org.jf.baksmali.Main disassemble -o "$WORK/gen-smali" "$WORK/gen-dex/classes.dex"
test -f "$WORK/gen-smali/com/zai/hamrahkhodro/FbSession.smali"

echo "── ۴) smali-out پایه (v3.9.4) — اگر نیست از dex v3.9.4 بساز"
if [ ! -f "$WORK/smali-out/com/zai/hamrahkhodro/CloudBridge.smali" ]; then
  java -cp "$SMALI_LIB" org.jf.baksmali.Main disassemble -o "$WORK/smali-out" "$WORK/classes-v394.dex"
fi
test -f "$WORK/smali-out/com/zai/hamrahkhodro/CloudBridge.smali"

echo "── ۵) پیوند متدهای v3.9.5 (fbProbeAsync + جایگزینی fb*)"
python3 "$WORK/splice_fb_v395.py"

echo "── ۶) smali → classes-v395.dex"
rm -f "$WORK/classes-v395.dex"
java -cp "$SMALI_LIB" org.jf.smali.Main assemble -o "$WORK/classes-v395.dex" "$WORK/smali-out"
test -f "$WORK/classes-v395.dex"
ls -la "$WORK/classes-v395.dex"

echo "── ۷) تأیید: رشته‌های کلیدی v3.9.5 در dex"
java -cp "$SMALI_LIB" org.jf.baksmali.Main disassemble -o /tmp/v395-check "$WORK/classes-v395.dex"
for s in fbProbeAsync "signInWithPassword" "probe@hamrah.invalid" "databases/(default)"; do
  grep -rq "$s" /tmp/v395-check/com/zai/hamrahkhodro/ && echo "  ✓ $s" || { echo "  ✗ $s MISSING"; exit 1; }
done
echo "OK: classes-v395.dex ساخته شد"
