#!/usr/bin/env python3
"""
inject_bridge.py — تزریق BRIDGE_INIT v3.7 به index.html خروجی استاتیک
  ۱) شیم fetch برای /api/* → AndroidApi.api (لایهٔ جاوای BridgeCore — دادهٔ محلی data.json)
  ۲) پلی‌فیل Notification از پل جاوا (ApiBridge — v3.6)
نسخهٔ v3.7: بلوک جعلی «همگام‌سازی ابری» (ذخیرهٔ ایمیل + اسنپ‌شات localStorage) حذف شد؛
سینک ابری واقعی از طریق window.AndroidCloud (CloudBridge جاوا) انجام می‌شود.
"""
import re
import sys

BRIDGE = r"""<script>(function(){
  if (!window.AndroidApi || typeof window.AndroidApi.api !== "function") return;
  var REAL_FETCH = window.fetch.bind(window);
  function jp(s){ try { return JSON.parse(s); } catch(e){ return null; } }
  function ok(status, body){ return Promise.resolve(new Response(JSON.stringify(body), { status: status, headers: { "Content-Type": "application/json; charset=utf-8" } })); }
  /* /api/* → پل جاوا (BridgeCore) — دادهٔ محلی همین گوشی */
  window.fetch = function(input, init){
    try {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      if (url.indexOf("/api/") === 0) {
        var m = ((init && init.method) || "GET").toUpperCase();
        var b = init && typeof init.body === "string" ? init.body : "";
        var rr = window.AndroidApi.api(m, url, b);
        var p = jp(rr);
        if (p && typeof p.status === "number") return ok(p.status, p.body);
      }
    } catch (e) { /* افتادن به fetch واقعی */ }
    return REAL_FETCH(input, init);
  };

  /* ───────── نوتیفیکیشن — اعلان واقعی اندروید از پل جاوا (فقط داخل APK) ─────────
     WebView خودش Notification ندارد؛ این پیاده‌سازی از AndroidApi استفاده می‌کند:
     requestNotifPermission → دیالوگ واقعی مجوز اندروید ۱۳+
     postNotification → اعلان واقعی در نوار وضعیت گوشی */
  try {
    if (window.AndroidApi && typeof window.AndroidApi.postNotification === "function") {
      function hkPerm() {
        try {
          if (typeof window.AndroidApi.hasNotifPermission === "function") {
            return window.AndroidApi.hasNotifPermission() ? "granted" : "default";
          }
        } catch (e) {}
        return "unsupported";
      }
      function HKNotification(title, options) {
        if (!(this instanceof HKNotification)) return new HKNotification(title, options);
        options = options || {};
        try {
          window.AndroidApi.postNotification(String(title || ""), String(options.body || ""), String(options.tag || title || "hk"));
        } catch (e) {}
      }
      HKNotification.permission = hkPerm();
      HKNotification.requestPermission = function (cb) {
        return new Promise(function (resolve) {
          var done = false;
          function finish(p) {
            if (done) return; done = true;
            HKNotification.permission = p;
            try { if (typeof cb === "function") cb(p); } catch (e) {}
            resolve(p);
          }
          try {
            if (typeof window.AndroidApi.requestNotifPermission === "function") {
              window.AndroidApi.requestNotifPermission();
            }
          } catch (e) {}
          var tries = 0;
          var iv = setInterval(function () {
            var p = hkPerm();
            tries++;
            if (p === "granted" || tries > 40) {
              clearInterval(iv);
              finish(p === "granted" ? "granted" : "denied");
            }
          }, 500);
        });
      };
      HKNotification.close = function () {};
      window.Notification = HKNotification;
    }
  } catch (e) {}
})();</script>"""


def main():
    path = sys.argv[1]
    html = open(path, encoding="utf-8").read()
    if "AndroidApi" in html and "REAL_FETCH" in html:
        # نسخهٔ قدیمی BRIDGE_INIT (v3.5/3.6) — جایگزینی کامل
        html = re.sub(
            r"<script>\(function\(\)\{\s*if \(!window\.AndroidApi.*?\)\);?</script>",
            "",
            html,
            flags=re.S,
        )
    marker = "<head>"
    idx = html.find(marker)
    assert idx >= 0, "<head> not found"
    insert_at = idx + len(marker)
    html = html[:insert_at] + BRIDGE + html[insert_at:]
    open(path, "w", encoding="utf-8").write(html)
    print(f"BRIDGE_INIT v3.7 injected into {path} (+{len(BRIDGE)} chars)")


if __name__ == "__main__":
    main()
