#!/usr/bin/env python3
"""
splice_fb_v395.py — پیوند متدهای فایربیس v3.9.5 به درخت smali واقعی CloudBridge.
پایه: classes-v394.dex (baksmali → smali-out) — یعنی rename و روتر v3.9.4 از قبل هست.
  ۱) جایگزینی ۷ متد fb* موجود با نسخه‌های تازه (بایت‌کد کانونیک ecj/d8/baksmali)
  ۲) افزودن متد جدید fbProbeAsync (⭐ v3.9.5 — بررسی وضعیت راه‌اندازی گام‌به‌گام)
  ۳) کپی کامل کلاس‌های خودکفا: FbSession(+UiOpen + probe) و FbReq(kind 4) و FbDeliver
AuthActivity.invoke CloudBridge.handleRedirect بدون تغییر می‌ماند.
"""
import re
import shutil
import sys

REAL = "/home/z/apk-build/work/smali-out/com/zai/hamrahkhodro"
GEN = "/home/z/apk-build/work/gen-smali/com/zai/hamrahkhodro"

FB_METHODS = [
    "fbStartAuthAsync",
    "fbExchangeCodeAsync",
    "fbRequestAsync",
    "fbDisconnectAsync",
    "fbPollAuth",
    "fbCancelAuth",
    "fbGetAccount",
    "fbProbeAsync",  # ⭐ v3.9.5 — جدید
]
NEW_CLASSES = ["FbSession.smali", "FbSession$UiOpen.smali", "FbReq.smali", "FbDeliver.smali"]


def extract_method(text: str, name: str, static: bool = False) -> str:
    """استخراج کامل یک متد (.method ... .end method) — با گِرَد دقیق امضا"""
    if static:
        pat = re.compile(
            r"^\.method public static " + re.escape(name) + r"\([^\n]*\n(?:.*?\n)*?^\.end method\n",
            re.M,
        )
    else:
        pat = re.compile(
            r"^\.method public " + re.escape(name) + r"\([^\n]*\n(?:.*?\n)*?^\.end method\n",
            re.M,
        )
    m = pat.search(text)
    if not m:
        raise SystemExit(f"ERROR: method {name} not found")
    return m.group(0)


def main() -> None:
    # ── CloudBridge: جایگزینی fb* + افزودن fbProbeAsync ──
    cb_path = f"{REAL}/CloudBridge.smali"
    cb = open(cb_path, encoding="utf-8").read()

    # rename و روتر v3.9.4 باید از قبل موجود باشند (پایه = dex v3.9.4)
    if ".method public static handleRedirectDrive(" not in cb:
        raise SystemExit("ERROR: handleRedirectDrive (rename v3.9.4) not found — base dex wrong?")
    if ".method public static handleRedirect(Landroid/content/Context;Landroid/net/Uri;)V" not in cb:
        raise SystemExit("ERROR: router handleRedirect not found — base dex wrong?")
    print("CloudBridge: rename + router v3.9.4 present ✓")

    gen_cb = open(f"{GEN}/CloudBridge.smali", encoding="utf-8").read()
    additions = []
    for name in FB_METHODS:
        good = extract_method(gen_cb, name)
        assert "Landroid/webkit/JavascriptInterface;" in good, f"{name} lacks @JavascriptInterface"
        if f".method public {name}(" in cb or f".method public static {name}(" in cb:
            old = extract_method(cb, name)
            cb = cb.replace(old, "")
            print(f"CloudBridge: {name} replaced")
        else:
            print(f"CloudBridge: {name} appended (new)")
        additions.append(good)

    cb = cb.rstrip("\n") + "\n\n" + "\n".join(additions) + "\n"
    open(cb_path, "w", encoding="utf-8").write(cb)
    print(f"CloudBridge: {len(FB_METHODS)} fb methods (incl. fbProbeAsync) written")

    # ── کپی کامل کلاس‌های جدید (FbSession با probe + FbReq با kind 4) ──
    for cls in NEW_CLASSES:
        shutil.copyfile(f"{GEN}/{cls}", f"{REAL}/{cls}")
        print(f"{cls}: copied (full replace)")

    print("SPLICE OK")


if __name__ == "__main__":
    main()
