#!/bin/bash
# build-apk-v395.sh — ساخت hamrah-khodro v3.9.5 (APK)
#  پایه: APK v3.9.0 + classes-v395.dex (CloudBridge + متدهای فایربیس + FbSession + probe)
#  ⭐ v3.9.5:
#   ۱) شیت «راه‌اندازی گام‌به‌گام سرور ابری» — فایربیس از ابتدا با «بررسی وضعیت» خودکار
#      (fbProbeAsync: network/identity/firestore — همان پاسخ‌های عین گوگل)
#   ۲) دکمهٔ «لغو اتصال» در هر دو مرحلهٔ اتصال به گوگل (مرورگر + تبدیل کد)
#   ۳) صحنهٔ آموزش: پوستر تبلیغاتی «همراه خودرو» روی دیوار کنار شعار اسپری‌شده
set -euo pipefail

PROJ=/home/z/my-project
WORK=/home/z/apk-build/work
BT=/home/z/apk-build/bt/android-14
export LD_LIBRARY_PATH="$BT/lib64"
KS=$PROJ/android-keys/hk-release.keystore
BASE_APK=$PROJ/public/files/hamrah-khodro-v3.9.0.apk
OUT_APK=$PROJ/public/files/hamrah-khodro-v3.9.5.apk
DEX=$WORK/classes-v395.dex

echo "── ۰) پایه: استخراج APK v3.9.0"
rm -rf "$WORK/apk-out"
mkdir -p "$WORK/apk-out"
unzip -q -o "$BASE_APK" -d "$WORK/apk-out"
rm -rf "$WORK/apk-out/META-INF"
test -f "$WORK/apk-out/classes.dex" && test -f "$WORK/apk-out/AndroidManifest.xml"

echo "── ۰.۲) جایگزینی classes.dex با dex v3.9.5 (فایربیس + probe)"
test -f "$DEX"
cp "$DEX" "$WORK/apk-out/classes.dex"

echo "── ۰.۵) پچ مانیفست: 3.9.0→3.9.5 / versionCode 28→33"
python3 "$WORK/patch_manifest_v395.py" "$WORK/apk-out/AndroidManifest.xml"

echo "── ۱) www-final (بیلد استاتیک همین نسخه)"
test -f "$WORK/www-final/index.html"

echo "── ۲) جایگزینی www در APK"
rm -rf "$WORK/apk-out/assets/www"
mkdir -p "$WORK/apk-out/assets/www"
cp -r "$WORK/www-final/." "$WORK/apk-out/assets/www/"

cd "$WORK/apk-out"
rm -f "$WORK/unsigned.apk" "$WORK/aligned.apk"
zip -q -r -n .arsc:.woff2 "$WORK/unsigned.apk" .

echo "── ۳) zipalign + امضا"
"$BT/zipalign" -f -p 4 "$WORK/unsigned.apk" "$WORK/aligned.apk"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias hamrah --ks-pass pass:hamrah-khodro-2026 --key-pass pass:hamrah-khodro-2026 --out "$OUT_APK" "$WORK/aligned.apk"
"$BT/apksigner" verify "$OUT_APK" && echo "OK: امضا تأیید شد"

echo "── ۴) بررسی نهایی"
"$BT/aapt" dump badging "$OUT_APK" | head -4
ls -la "$OUT_APK"

echo "── ۵) همگام‌سازی www-final داخل apk-mock (E2E همین بیلد)"
rm -rf "$PROJ/mini-services/apk-mock/www-final"
cp -r "$WORK/www-final" "$PROJ/mini-services/apk-mock/www-final"
echo "OK: APK ساخته شد: $OUT_APK"
