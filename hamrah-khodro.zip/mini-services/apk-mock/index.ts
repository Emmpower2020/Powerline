/**
 * apk-mock — شبیه‌ساز WebView اندروید برای تست بستهٔ خروجی APK v3.8.0
 *  - www-final را سرو می‌کند (خروجی استاتیک داخل APK)
 *  - AndroidApi را مثل جاوای ApiBridge تزریق می‌کند (fetchهای /api به پل می‌روند)
 *  - AndroidCloud را مثل جاوای CloudBridge v3.8 شبیه‌سازی می‌کند — با یک «گوگلِ» درحافظه:
 *      startBrowserAuth/pollBrowserAuth/exchangeCode (بدون Client ID — تعبیه‌شده + اسکیم اختصاصی)
 *      driveRequest: Drive API واقعی‌نما (list/create/multipart/download/401/network)
 *      disconnect: revoke
 *    شبیه‌سازی سناریوها از کنسول: __CLOUD_SIM.completeAuth() (بازگشت گوگل به برنامه) /
 *    .denyAuth() / .schemeDisabled = true (تیک کنسول فعال نیست) / .offline = true /
 *    .expireToken() / .reset()
 * پورت ثابت: 3031
 */
import { readFileSync, existsSync } from "node:fs";
import { join, extname } from "node:path";

const PORT = 3031;
const OUT = join(import.meta.dir, "www-final");
const SEED = join(import.meta.dir, "seed.json");

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".woff2": "font/woff2",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/plain; charset=utf-8",
  ".ico": "image/x-icon",
};

/** پیاده‌سازی جاوای ApiBridge/CloudBridge در JS — همان قرارداد JSON */
const SHIM = `
(function(){
  var DB = __SEED_JSON__;
  var ID = 0;
  function nid(){ ID++; return "mock" + Date.now().toString(36) + ID; }
  function res(status, body){ return JSON.stringify({ status: status, body: body }); }
  function parts(url){ var p = url.split("?")[0].split("/").filter(Boolean); return p; }
  function send(method, url, bodyStr){
    try {
      var p = parts(url);
      var body = bodyStr ? JSON.parse(bodyStr) : {};
      // /api/vehicles — name مثل API واقعی: model || brand
      if (p[1] === "vehicles" && p.length === 2) {
        function withName(v) { v.name = v.model || v.brand; return v; }
        if (method === "GET") return res(200, { vehicles: DB.vehicles.map(withName) });
        if (method === "POST") { var v = Object.assign({ id: nid(), createdAt: new Date().toISOString() }, body); DB.vehicles.unshift(v); return res(201, withName(v)); }
      }
      if (p[1] === "vehicles" && p.length === 3) {
        var vi = DB.vehicles.findIndex(function(x){ return x.id === p[2]; });
        if ((method === "PUT" || method === "PATCH") && vi >= 0) { DB.vehicles[vi] = Object.assign(DB.vehicles[vi], body); return res(200, Object.assign({}, DB.vehicles[vi], { name: DB.vehicles[vi].model || DB.vehicles[vi].brand })); }
        if (method === "DELETE" && vi >= 0) { DB.vehicles.splice(vi, 1); return res(200, { ok: true }); }
      }
      // /api/records
      if (p[1] === "records" && p.length === 2) {
        if (method === "GET") return res(200, { records: DB.records });
        if (method === "POST") { var r = Object.assign({ id: nid(), createdAt: new Date().toISOString() }, body); DB.records.unshift(r); return res(201, r); }
      }
      if (p[1] === "records" && p.length === 3) {
        var ri = DB.records.findIndex(function(x){ return x.id === p[2]; });
        if ((method === "PUT" || method === "PATCH") && ri >= 0) { DB.records[ri] = Object.assign(DB.records[ri], body); return res(200, DB.records[ri]); }
        if (method === "DELETE" && ri >= 0) { DB.records.splice(ri, 1); return res(200, { ok: true }); }
      }
      // /api/reminders
      if (p[1] === "reminders" && p.length === 2) {
        if (method === "GET") return res(200, { reminders: DB.reminders });
        if (method === "POST") { var m = Object.assign({ id: nid(), createdAt: new Date().toISOString() }, body); DB.reminders.unshift(m); return res(201, m); }
      }
      if (p[1] === "reminders" && p.length === 3) {
        var mi = DB.reminders.findIndex(function(x){ return x.id === p[2]; });
        if ((method === "PUT" || method === "PATCH") && mi >= 0) { DB.reminders[mi] = Object.assign(DB.reminders[mi], body); return res(200, DB.reminders[mi]); }
        if (method === "DELETE" && mi >= 0) { DB.reminders.splice(mi, 1); return res(200, { ok: true }); }
      }
      // /api/brands — GET/POST/PATCH/DELETE (افزودن برند/مدل دلخواه) و /api/service-types
      if (p[1] === "brands" && p.length === 2) {
        if (method === "GET") return res(200, { brands: DB.brands });
        if (method === "POST") {
          var nb = Object.assign({ id: nid(), isCustom: true, createdAt: new Date().toISOString() }, body);
          DB.brands.push(nb);
          return res(201, nb);
        }
      }
      if (p[1] === "brands" && p.length === 3) {
        var bi = DB.brands.findIndex(function(x){ return x.id === p[2]; });
        if ((method === "PUT" || method === "PATCH") && bi >= 0) { DB.brands[bi] = Object.assign(DB.brands[bi], body); return res(200, DB.brands[bi]); }
        if (method === "DELETE" && bi >= 0) { DB.brands.splice(bi, 1); return res(200, { ok: true }); }
      }
      if (p[1] === "service-types" && p.length === 2) return res(200, { serviceTypes: DB.serviceTypes });
      // /api/service-types/<id> — PATCH/DELETE مثل لایهٔ جاوا
      if (p[1] === "service-types" && p.length === 3) {
        var ti = DB.serviceTypes.findIndex(function(x){ return x.id === p[2]; });
        if (ti < 0) return res(404, { error: "نوع سرویس یافت نشد" });
        if (method === "DELETE") { DB.serviceTypes.splice(ti, 1); return res(200, { ok: true }); }
        if (method === "PATCH" || method === "PUT") { DB.serviceTypes[ti] = Object.assign(DB.serviceTypes[ti], body); return res(200, DB.serviceTypes[ti]); }
      }
      // /api/stats — خروجی خالی (برای بوت کافی است؛ گزارش‌ها حالت خالی دارند)
      if (p[1] === "stats") return res(200, { stats: [], today: { monthIndex: 16866, monthDays: 31 } });
      if (p[1] === "files") return res(200, { files: [] });
      // /api/backup + /api/restore — مثل BridgeCore
      if (p[1] === "backup" && method === "GET") {
        return res(200, { app: "همراه خودرو", version: "v3.0.0", exportedAt: new Date().toISOString(),
          vehicles: DB.vehicles, records: DB.records, reminders: DB.reminders,
          brands: DB.brands, serviceTypes: DB.serviceTypes });
      }
      if (p[1] === "restore" && method === "POST") {
        try {
          var data = JSON.parse(bodyStr || "{}");
          if (!data.vehicles || !data.records || !data.reminders) return res(400, { error: "فایل پشتیبان معتبر نیست — خودروها، سوابق یا یادآورها یافت نشد" });
          if (data.vehicles.length === 0 && data.records.length > 0) return res(400, { error: "سوابقی بدون خودرو در فایل است" });
          var ids = {};
          for (var i = 0; i < data.vehicles.length; i++) { if (!data.vehicles[i].id || !data.vehicles[i].model) return res(400, { error: "مدل/شناسهٔ خودرو نامعتبر" }); ids[data.vehicles[i].id] = 1; }
          for (var j = 0; j < data.records.length; j++) { if (!ids[data.records[j].vehicleId]) return res(400, { error: "رکورد بدون خودروی معتبر" }); }
          for (var k = 0; k < data.reminders.length; k++) { if (!ids[data.reminders[k].vehicleId]) return res(400, { error: "یادآور بدون خودروی معتبر" }); }
          DB.vehicles = data.vehicles; DB.records = data.records; DB.reminders = data.reminders;
          if (data.brands) DB.brands = data.brands;
          if (data.serviceTypes) DB.serviceTypes = data.serviceTypes;
          window.__RESTORE_COUNT = (window.__RESTORE_COUNT || 0) + 1;
          setTimeout(function(){ window.dispatchEvent(new Event("hk-restored")); }, 30);
          return res(200, { ok: true, vehicles: data.vehicles.length, records: data.records.length, reminders: data.reminders.length });
        } catch (e) { return res(400, { error: "JSON نامعتبر" }); }
      }
      return res(404, { error: "mock: " + url });
    } catch (e) {
      return res(500, { error: String(e) });
    }
  }
  window.AndroidApi = {
    api: function(method, url, body){ return send(method, url, body); },
    exitApp: function(){ window.__EXIT_CALLED = (window.__EXIT_CALLED || 0) + 1; },
    saveBackup: function(){ window.__BACKUP_SAVED = (window.__BACKUP_SAVED || 0) + 1; return JSON.stringify({ status: 200, body: { ok: true, path: "Download/HamrahKhodro/hamrah-khodro-backup-test.json" } }); },
    pickRestoreFile: function(){ window.__RESTORE_PICKED = true; },
    dataPath: function(){ return "/data/data/com.zai.hamrahkhodro/files/data.json"; },
    /* شبیه‌سازی نوتیفیکیشن — مثل ApiBridge جاوا (v3.6.0) */
    hasNotifPermission: function(){ return window.__NOTIF_GRANTED === true; },
    requestNotifPermission: function(){ window.__NOTIF_REQ_COUNT = (window.__NOTIF_REQ_COUNT || 0) + 1; setTimeout(function(){ window.__NOTIF_GRANTED = true; }, 900); },
    postNotification: function(title, body, tag){ window.__POSTED_NOTIFS = window.__POSTED_NOTIFS || []; window.__POSTED_NOTIFS.push({ title: title, body: body, tag: tag }); return window.__NOTIF_GRANTED === true; }
  };

  /* ═══════════ شبیه‌ساز CloudBridge جاوا v3.8 + «گوگلِ» درحافظه ═══════════ */
  var CLIENT_ID = "876691396788-fbiuu666o7i3fujgek28t1mnb96mi3pv.apps.googleusercontent.com";
  var REDIRECT_URI = "com.zai.hamrahkhodro:/oauth2callback";
  var SIM = {
    email: null,            // حساب متصل (وقتی واقعی وصل شود)
    tokens: null,           // { access, refresh, expiresAt }
    flow: null,             // جریان اتصال: { state, code, error, verifier, startedAt }
    drive: {},              // فایل‌های ابری: { id: { name, content, modifiedTime, revisions: [{id, content, modifiedTime}] } }
    nextId: 1,
    revId: 1,
    offline: false,         // تست قطع اینترنت
    schemeDisabled: false,  // تست: تیک «Enable custom URI scheme» در کنسول فعال نیست
    revokedExternally: false, // تست لغو مجوز از حساب گوگل
    driveApiDisabled: false,  // تست: Drive API در پروژه فعال نیست (403 FAILED_PRECONDITION)
    storageFull: false,      // تست: فضای واقعی Drive پر است (403 storageQuotaExceeded)
    rateLimit: false,        // تست: محدودیت تعداد درخواست (403 userRateLimitExceeded)
    insufficientPermission: false, // تست: مجوز Drive ناقص (403 Insufficient Permission)
    scopeInsufficient: false,     // تست: اسکوپ ناکافی (403 ACCESS_TOKEN_SCOPE_INSUFFICIENT)
    staleScope: false,           // تست: توکنِ قدیمی بدون drive.appdata (خطای واقعی کاربر v3.8.1)
    latencyMs: 0,                // ⭐ v3.8.7: تأخیر شبیه‌سازی‌شدهٔ هر فراخوانی ابری (تست «زنده‌بودن برنامه حین سینک»)
    calls: [],              // لاگ فراخوانی‌ها
  };
  window.__CLOUD_SIM = {
    get state(){ return SIM; },
    /* ⭐ v3.8.4: شبیه‌سازی حذف+نصب مجدد برنامه — دادهٔ محلی/توکن/localStorage پاک می‌شود
       اما فایل‌های ابری (سمت گوگل) دست‌نخورده می‌مانند — دقیقاً مثل واقعیت */
    reinstallApp: function(){
      DB.vehicles = []; DB.records = []; DB.reminders = [];
      SIM.email = null; SIM.tokens = null; SIM.flow = null;
      try { localStorage.clear(); } catch (e) {}
      window.dispatchEvent(new Event("hk-restored"));
    },
    wipeAppData: function(){
      DB.vehicles = []; DB.records = []; DB.reminders = [];
      window.dispatchEvent(new Event("hk-restored"));
    },
    disconnectAccount: function(){ SIM.email = null; SIM.tokens = null; SIM.flow = null; },
    /* ⭐ v3.8.4: بازتولید دقیق باگ نسخه‌های قدیمی — آپلود دادهٔ خالی روی پشتیبان پر
       (محتوای قبلی مثل گوگل در تاریخچهٔ revisions باقی می‌ماند) */
    simulateLegacyBug: function(){
      Object.keys(SIM.drive).forEach(function(id){
        var f = SIM.drive[id];
        if (f.name !== "hamrah-khodro-backup.json") return;
        var empty = JSON.stringify({ app: "همراه خودرو", version: "legacy-bug", exportedAt: new Date().toISOString(), vehicles: [], records: [], reminders: [], brands: [], serviceTypes: [] });
        f.revisions.push({ id: "rev" + (SIM.revId++), content: empty, modifiedTime: new Date().toISOString() });
        f.content = empty;
        f.modifiedTime = new Date().toISOString();
      });
    },
    get driveFiles(){ return SIM.drive; },
    /* سناریوها — از کنسول: __CLOUD_SIM.driveApiDisabled = true و … */
    get offline(){ return SIM.offline; }, set offline(v){ SIM.offline = !!v; },
    get schemeDisabled(){ return SIM.schemeDisabled; }, set schemeDisabled(v){ SIM.schemeDisabled = !!v; },
    get driveApiDisabled(){ return SIM.driveApiDisabled; }, set driveApiDisabled(v){ SIM.driveApiDisabled = !!v; },
    get storageFull(){ return SIM.storageFull; }, set storageFull(v){ SIM.storageFull = !!v; },
    get rateLimit(){ return SIM.rateLimit; }, set rateLimit(v){ SIM.rateLimit = !!v; },
    get insufficientPermission(){ return SIM.insufficientPermission; }, set insufficientPermission(v){ SIM.insufficientPermission = !!v; },
    get scopeInsufficient(){ return SIM.scopeInsufficient; }, set scopeInsufficient(v){ SIM.scopeInsufficient = !!v; },
    get staleScope(){ return SIM.staleScope; }, set staleScope(v){ SIM.staleScope = !!v; if (SIM.tokens) SIM.tokens.scope = SIM.staleScope ? "openid email" : fullScope(); },
    /* ⭐ v3.8.7: کنترل تأخیر ابری — مثلاً __CLOUD_SIM.latency = 900 (هر درخواست ۹۰۰ms) */
    get latency(){ return SIM.latencyMs; }, set latency(v){ SIM.latencyMs = Math.max(0, Number(v) || 0); },
    /* ⭐ v3.8.7: شمارندهٔ فریم برای تست «زنده‌ماندن رشتهٔ JS حین همگام‌سازی» —
       اگر حین سینک __hkFrames بالا برود یعنی برنامه قفل نشده */
    startFrameCounter: function(){
      if (window.__hkFramesLoop) return;
      window.__hkFrames = 0;
      var tick = function(){ window.__hkFrames++; window.__hkFramesLoop = requestAnimationFrame(tick); };
      window.__hkFramesLoop = requestAnimationFrame(tick);
    },
    stopFrameCounter: function(){
      if (window.__hkFramesLoop) cancelAnimationFrame(window.__hkFramesLoop);
      window.__hkFramesLoop = null;
    },
    /* شبیه‌سازی تأیید کاربر در صفحهٔ گوگل — گوگل به اسکیم اختصاصی برنامه برمی‌گردد */
    completeAuth: function(){
      if (SIM.flow && SIM.flow.state === "waiting") { SIM.flow.state = "done"; SIM.flow.code = "4/0AfakeAuthCode"; }
    },
    denyAuth: function(){
      if (SIM.flow && SIM.flow.state === "waiting") { SIM.flow.state = "error"; SIM.flow.error = "access_denied"; }
    },
    expireToken: function(){ if (SIM.tokens) SIM.tokens.expiresAt = Date.now() - 1000; },
    revokeExternal: function(){ SIM.revokedExternally = true; },
    reset: function(){ SIM.email = null; SIM.tokens = null; SIM.flow = null; SIM.drive = {}; SIM.nextId = 1; SIM.revId = 1; SIM.offline = false; SIM.schemeDisabled = false; SIM.revokedExternally = false; SIM.driveApiDisabled = false; SIM.storageFull = false; SIM.rateLimit = false; SIM.insufficientPermission = false; SIM.scopeInsufficient = false; SIM.staleScope = false; SIM.calls = []; },
  };
  function fakeAccessToken(){ return "ya29.fake_" + Math.random().toString(36).slice(2, 10); }
  function fullScope(){ return "openid email https://www.googleapis.com/auth/drive.appdata"; }
  function finishTokens(email){
    SIM.email = email;
    // staleScope → توکن بدون drive.appdata (شبیه خطای واقعی کاربر)؛ اتصال مجدد (prompt=consent) کاملش می‌کند
    SIM.tokens = { access: fakeAccessToken(), refresh: "1//0fakeRefresh", expiresAt: Date.now() + 3600e3, scope: SIM.staleScope ? "openid email" : fullScope() };
  }
  function ensureAccess(){
    if (!SIM.tokens) return null;
    if (SIM.revokedExternally) { SIM.tokens = null; SIM.email = null; return null; } // لغو مجوز → invalid_grant
    if (SIM.tokens.expiresAt < Date.now() + 30e3) SIM.tokens.access = fakeAccessToken(), SIM.tokens.expiresAt = Date.now() + 3600e3;
    return SIM.tokens.access;
  }
  function driveList(){ return Object.keys(SIM.drive).map(function(id){ return { id: id, name: SIM.drive[id].name, modifiedTime: SIM.drive[id].modifiedTime, size: SIM.drive[id].content.length }; }); }
  /* ثبت محتوای جدید به‌عنوان نسخهٔ (revision) جدید — مثل گوگل: هر آپلود یک نسخه می‌سازد */
  function pushRevision(f, content){
    f.revisions = f.revisions || [];
    f.revisions.push({ id: "rev" + (SIM.revId++), content: content, modifiedTime: new Date().toISOString() });
    if (f.revisions.length > 12) f.revisions.shift(); // گوگل نسخه‌های خیلی قدیمی را پاک می‌کند
    f.content = content;
    f.modifiedTime = new Date().toISOString();
  }

  window.AndroidCloud = {
    /* شروع اتصال — Client ID تعبیه‌شده؛ شبیه پیش‌بررسی جاوا (تیک کنسول) + باز شدن مرورگر */
    startBrowserAuth: function(){
      SIM.calls.push(["startBrowserAuth"]);
      if (SIM.offline) return JSON.stringify({ ok: false, error: "network" });
      if (SIM.flow && SIM.flow.state === "waiting") return JSON.stringify({ ok: false, error: "busy", errorDescription: "یک جریان اتصال در حال اجراست" });
      if (SIM.schemeDisabled) {
        // همان خطای واقعی گوگل وقتی «Enable custom URI scheme» فعال نیست
        return JSON.stringify({ ok: false, error: "custom_scheme_disabled", errorDescription: "Custom URI scheme is not enabled for your Android client." });
      }
      SIM.flow = { state: "waiting", code: null, error: null, verifier: "fakeVerifier1234567890abcdef", startedAt: Date.now() };
      var authUrl = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + CLIENT_ID + "&redirect_uri=" + encodeURIComponent(REDIRECT_URI) + "&response_type=code&scope=openid+email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fdrive.appdata&code_challenge=FAKE_CHALLENGE&code_challenge_method=S256&access_type=offline&prompt=select_account%20consent";
      return JSON.stringify({ ok: true, authUrl: authUrl, redirectUri: REDIRECT_URI });
    },
    pollBrowserAuth: function(){
      if (!SIM.flow) return JSON.stringify({ state: "none" });
      if (SIM.flow.state === "waiting" && Date.now() - SIM.flow.startedAt > 300e3) SIM.flow.state = "timeout";
      var out = { state: SIM.flow.state };
      if (SIM.flow.state === "done") out.hasCode = true;
      if (SIM.flow.state === "error") out.error = SIM.flow.error;
      return JSON.stringify(out);
    },
    cancelBrowserAuth: function(){ SIM.flow = null; return JSON.stringify({ ok: true }); },
    exchangeCode: function(){
      SIM.calls.push(["exchangeCode"]);
      if (SIM.offline) return JSON.stringify({ ok: false, error: "network" });
      if (!SIM.flow || SIM.flow.state !== "done" || !SIM.flow.code) return JSON.stringify({ ok: false, error: "no_code", errorDescription: "کدی برای تبدیل وجود ندارد — ابتدا جریان اتصال را کامل کنید" });
      // v3.8.2: prompt=select_account+consent → صفحهٔ تأیید اجباری → مجوز کامل تازه
      SIM.staleScope = false;
      finishTokens("browser.user@gmail.com");
      SIM.flow = null;
      return JSON.stringify({ ok: true, email: SIM.email, expiresIn: 3600 });
    },
    getAccount: function(){
      if (SIM.email && SIM.tokens && !SIM.revokedExternally) return JSON.stringify({ connected: true, email: SIM.email, expiresAt: SIM.tokens.expiresAt, scope: SIM.tokens.scope || fullScope() });
      return JSON.stringify({ connected: false });
    },
    driveRequest: function(method, url, contentType, body){
      SIM.calls.push(["drive", method, url]);
      if (SIM.offline) return JSON.stringify({ ok: false, error: "network" });
      var at = ensureAccess();
      if (!at) return JSON.stringify({ ok: false, error: "disconnected", disconnected: true });
      var u = String(url || "");
      var m = String(method || "GET").toUpperCase();
      /* ⭐ توکن بدون drive.appdata → گوگل به همهٔ درخواست‌ها 403 ACCESS_TOKEN_SCOPE_INSUFFICIENT می‌دهد */
      if (SIM.tokens && SIM.tokens.scope && String(SIM.tokens.scope).indexOf("drive.appdata") < 0) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          code: 403,
          message: "Request had insufficient authentication scopes.",
          status: "PERMISSION_DENIED",
          details: [{ reason: "ACCESS_TOKEN_SCOPE_INSUFFICIENT" }]
        } }) });
      }
      /* ⭐ سناریوهای خطای واقعی گوگل — دقیقاً همان body هایی که گوگل برمی‌گرداند */
      if (SIM.driveApiDisabled) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          code: 403,
          message: "Google Drive API has not been used in project 876691396788 before or it is disabled. Enable it by visiting https://console.developers.google.com/apis/api/drive.googleapis.com/overview?project=876691396788 then retry. If you enabled this API recently, wait a few minutes for the action to propagate to our systems and retry.",
          status: "FAILED_PRECONDITION"
        } }) });
      }
      if (SIM.storageFull) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          errors: [{ domain: "global", reason: "storageQuotaExceeded", message: "The user's Drive storage quota is exhausted. This can happen if the user is over their storage quota." }],
          code: 403,
          message: "The user's Drive storage quota is exhausted. This can happen if the user is over their storage quota."
        } }) });
      }
      if (SIM.rateLimit) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          errors: [{ domain: "usageLimits", reason: "userRateLimitExceeded", message: "User Rate Limit Exceeded" }],
          code: 403,
          message: "User Rate Limit Exceeded"
        } }) });
      }
      if (SIM.insufficientPermission) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          errors: [{ domain: "global", reason: "insufficientPermissions", message: "Insufficient Permission" }],
          code: 403,
          message: "Insufficient Permission"
        } }) });
      }
      if (SIM.scopeInsufficient) {
        return JSON.stringify({ ok: true, status: 403, body: JSON.stringify({ error: {
          code: 403,
          message: "Request had insufficient authentication scopes.",
          status: "PERMISSION_DENIED",
          details: [{ reason: "ACCESS_TOKEN_SCOPE_INSUFFICIENT" }]
        } }) });
      }
      // ⭐ v3.8.4: REVISIONS — دانلود محتوای یک نسخهٔ خاص (باید قبل از LIST/DOWNLOAD عمومی بررسی شود)
      var rdm = u.match(/\\/drive\\/v3\\/files\\/([^/?]+)\\/revisions\\/([^/?]+)\\?alt=media/);
      if (m === "GET" && rdm) {
        var rf = SIM.drive[rdm[1]];
        var rev = rf && rf.revisions && rf.revisions.filter(function(r){ return r.id === rdm[2]; })[0];
        if (!rev) return JSON.stringify({ ok: true, status: 404, body: JSON.stringify({ error: { code: 404, message: "Revision not found" } }) });
        return JSON.stringify({ ok: true, status: 200, body: rev.content });
      }
      // ⭐ v3.8.4: REVISIONS — فهرست نسخه‌های فایل (بدون محتوا)
      var rlm = u.match(/\\/drive\\/v3\\/files\\/([^/?]+)\\/revisions/);
      if (m === "GET" && rlm) {
        var rfl = SIM.drive[rlm[1]];
        if (!rfl) return JSON.stringify({ ok: true, status: 404, body: JSON.stringify({ error: { code: 404, message: "File not found" } }) });
        var revs = (rfl.revisions || []).map(function(r){ return { id: r.id, modifiedTime: r.modifiedTime, size: r.content.length }; });
        return JSON.stringify({ ok: true, status: 200, body: JSON.stringify({ revisions: revs }) });
      }
      // LIST
      if (m === "GET" && u.indexOf("/drive/v3/files") >= 0 && u.indexOf("alt=media") < 0) {
        return JSON.stringify({ ok: true, status: 200, body: JSON.stringify({ files: driveList() }) });
      }
      // DOWNLOAD
      var dm = u.match(/\\/drive\\/v3\\/files\\/([^/?]+)\\?alt=media/);
      if (m === "GET" && dm) {
        var f = SIM.drive[dm[1]];
        if (!f) return JSON.stringify({ ok: true, status: 404, body: JSON.stringify({ error: { code: 404, message: "File not found" } }) });
        return JSON.stringify({ ok: true, status: 200, body: f.content });
      }
      // PATCH media (به‌روزرسانی) — محتوای قبلی مثل گوگل در تاریخچهٔ revisions می‌ماند
      var pm = u.match(/\\/upload\\/drive\\/v3\\/files\\/([^/?]+)\\?uploadType=media/);
      if ((m === "PATCH" || m === "PUT") && pm) {
        var f2 = SIM.drive[pm[1]];
        if (!f2) return JSON.stringify({ ok: true, status: 404, body: JSON.stringify({ error: { code: 404, message: "File not found" } }) });
        pushRevision(f2, String(body || ""));
        return JSON.stringify({ ok: true, status: 200, body: JSON.stringify({ id: pm[1], modifiedTime: f2.modifiedTime, size: f2.content.length }) });
      }
      // POST multipart (ساخت فایل)
      if (m === "POST" && u.indexOf("/upload/drive/v3/files?uploadType=multipart") >= 0) {
        var ct = String(contentType || "");
        var bmm = ct.match(/boundary=([^;\\s]+)/);
        if (!bmm) return JSON.stringify({ ok: true, status: 400, body: JSON.stringify({ error: { code: 400, message: "Bad multipart" } }) });
        var boundary = bmm[1];
        var raw = String(body || "");
        // جدا کردن بخش‌ها: [فراداده][محتوا]
        var segs = raw.split("--" + boundary);
        var meta = {}, content = "";
        for (var i = 0; i < segs.length; i++) {
          var seg = segs[i];
          var hp = seg.indexOf("\\r\\n\\r\\n");
          if (hp < 0) continue;
          var head = seg.slice(0, hp);
          var c = seg.slice(hp + 4).replace(/\\r\\n$/, "");
          if (head.indexOf("application/json") >= 0 && head.length < 400 && c.indexOf("\\"parents\\"") >= 0) { try { meta = JSON.parse(c); } catch (e) {} }
          else if (c.length > 0 && !meta.content) { content = c; }
        }
        if (!meta.name) return JSON.stringify({ ok: true, status: 400, body: JSON.stringify({ error: { code: 400, message: "Metadata missing" } }) });
        var id = "fakefile" + (SIM.nextId++);
        SIM.drive[id] = { name: meta.name, content: "", modifiedTime: new Date().toISOString(), revisions: [] };
        pushRevision(SIM.drive[id], content);
        return JSON.stringify({ ok: true, status: 200, body: JSON.stringify({ id: id, name: meta.name, modifiedTime: SIM.drive[id].modifiedTime, size: content.length }) });
      }
      return JSON.stringify({ ok: true, status: 400, body: JSON.stringify({ error: { code: 400, message: "mock: unsupported " + m + " " + u } }) });
    },
    openUrl: function(url){ SIM.calls.push(["openUrl", url]); window.__OPENED_URLS = (window.__OPENED_URLS || []).concat([url]); return JSON.stringify({ ok: true }); },
    disconnect: function(){
      SIM.calls.push(["disconnect"]);
      var had = !!SIM.tokens;
      SIM.email = null; SIM.tokens = null; SIM.flow = null; SIM.revokedExternally = false;
      return JSON.stringify({ ok: true, revoked: had && !SIM.offline });
    },
    /* ═══ ⭐ v3.8.7: پل ناهمگام — مثل CloudBridge جاوای v3.8.7 ═══
       HTTP شبیه‌سازی‌شده روی «نخ پس‌زمینه» (setTimeout) انجام می‌شود؛ نتیجه با
       evaluateJavascript به تابع global به‌نام callback می‌رسد (آبجکت JSON).
       JS هرگز قفل نمی‌شود → برنامه حین سینک زنده است (رفع «هنگ»). */
    driveRequestAsync: function(method, url, contentType, body, callback){
      SIM.calls.push(["driveAsync", method, url]);
      var result = window.AndroidCloud.driveRequest(method, url, contentType, body);
      setTimeout(function(){
        try {
          var fn = window[callback];
          if (typeof fn === "function") fn(JSON.parse(result));
        } catch (e) { /* مثل جاوا: تحویل بی‌صدا شکست خورد */ }
      }, SIM.latencyMs || 0);
    },
    exchangeCodeAsync: function(callback){
      SIM.calls.push(["exchangeCodeAsync"]);
      var result = window.AndroidCloud.exchangeCode();
      setTimeout(function(){
        try {
          var fn = window[callback];
          if (typeof fn === "function") fn(JSON.parse(result));
        } catch (e) { /* ignore */ }
      }, SIM.latencyMs || 0);
    },
    disconnectAsync: function(callback){
      SIM.calls.push(["disconnectAsync"]);
      var result = window.AndroidCloud.disconnect();
      setTimeout(function(){
        try {
          var fn = window[callback];
          if (typeof fn === "function") fn(JSON.parse(result));
        } catch (e) { /* ignore */ }
      }, SIM.latencyMs || 0);
    },
  };

  /* ═══════════ شبیه‌ساز CloudBridge فایربیس v3.9.4 (سینک با حساب گوگل) ═══════════
     همان قرارداد متدهای fb* که به CloudBridge جاوا اضافه می‌شود:
       fbStartAuthAsync(cb) → {ok, authUrl} | {ok:false, error: custom_scheme_disabled|network|busy}
       fbPollAuth() → {state: none|waiting|exchanging|done|error|timeout}
       fbCancelAuth() → {ok:true}
       fbExchangeCodeAsync(cb) → {ok, email, uid} | {ok:false, error, message(خام گوگل)}
         ⭐ v3.9.4: تصاحب اتمیک (حالت exchanging → busy برای فراخوانی دوم) +
         خطای code_used (invalid_grant واقعی) + پاک‌شدن جریان بعد از خطای سرور
       fbGetAccount() → {connected, email, uid}
       fbRequestAsync(m,u,ct,b,cb) → {ok:true, status, body} — پروکسی Firestore با Bearer
       fbDisconnectAsync(cb) → {ok:true}
       fbProbeAsync(probe,cb) → {ok:true, status, body} — بررسی راه‌اندازی بدون ورود (v3.9.5)
     سناریوها از کنسول: __CLOUD_SIM.fbAuthApiDisabled / fbApiDisabled / fbRulesDenied /
     fbNoDatabase / fbSchemeDisabled / fbCodeConsumed — و completeAuth()/reset()/reinstallApp()/fbEnableAll() */
  var FB_CLIENT_ID = "358616461933-okqrjiuosruele895435ti2s2lpgvm46.apps.googleusercontent.com";
  var FB_REDIRECT = "com.zai.hamrahkhodro:/fbcallback";
  var FB = {
    session: null,   // { email, uid } — نشست فایربیس (سمت جاوا)
    flow: null,      // جریان OAuth گوگل
    docs: {},        // «Firestore»: { uid: { data: stringValue, updatedAt } }
    schemeDisabled: false,   // تیک Custom URI scheme کلاینت hamrahprj فعال نیست
    authApiDisabled: false,  // Identity Toolkit API غیرفعال (خطای ورود)
    apiDisabled: false,      // Cloud Firestore API غیرفعال
    rulesDenied: false,      // قوانین امنیتی دسترسی را بسته
    noDatabase: false,       // دیتابیس (default) ساخته نشده
    codeConsumed: false,     // کد oauth یک‌بارمصرف شده (invalid_grant واقعی)
  };
  function fbAuthUrl(){
    return "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + FB_CLIENT_ID +
      "&redirect_uri=" + encodeURIComponent(FB_REDIRECT) +
      "&response_type=code&scope=" + encodeURIComponent("openid email profile") +
      "&code_challenge=FAKE_FB_CHALLENGE&code_challenge_method=S256&prompt=select_account";
  }
  function fbErr(code, message){ return JSON.stringify({ ok:false, error: code, errorDescription: message }); }
  window.AndroidCloud.fbStartAuthAsync = function(callback){
    var out;
    if (SIM.offline) out = fbErr("network");
    else if (FB.flow && FB.flow.state === "waiting") out = fbErr("busy", "یک جریان اتصال در حال اجراست");
    else if (FB.schemeDisabled) out = fbErr("custom_scheme_disabled", "Custom URI scheme is not enabled for your Android client.");
    else {
      FB.flow = { state: "waiting", code: null, error: null, startedAt: Date.now() };
      out = JSON.stringify({ ok: true, authUrl: fbAuthUrl(), redirectUri: FB_REDIRECT });
    }
    setTimeout(function(){
      try { var fn = window[callback]; if (typeof fn === "function") fn(JSON.parse(out)); } catch (e) {}
    }, SIM.latencyMs || 0);
  };
  window.AndroidCloud.fbPollAuth = function(){
    if (!FB.flow) return JSON.stringify({ state: "none" });
    if (FB.flow.state === "waiting" && Date.now() - FB.flow.startedAt > 300e3) FB.flow.state = "timeout";
    var out = { state: FB.flow.state };
    if (FB.flow.state === "done") out.hasCode = true;
    if (FB.flow.state === "error") out.error = FB.flow.error;
    return JSON.stringify(out);
  };
  window.AndroidCloud.fbCancelAuth = function(){ FB.flow = null; return JSON.stringify({ ok: true }); };
  window.AndroidCloud.fbExchangeCodeAsync = function(callback){
    var out;
    if (SIM.offline) out = fbErr("network");
    // ⭐ v3.9.4: تصاحب اتمیک — فراخوانی دوم در میانهٔ تبدیل → busy (مثل synchronized جاوا)
    else if (FB.flow && FB.flow.state === "exchanging") out = fbErr("busy", "در حال تبدیل کد ورود است — کمی صبر کنید");
    else if (!FB.flow || FB.flow.state !== "done" || !FB.flow.code) out = fbErr("no_code", "کدی برای تبدیل وجود ندارد — ابتدا جریان اتصال را کامل کنید");
    else {
      // کد تصاحب شد — حالت exchanging تا پایان تبدیل
      FB.flow.state = "exchanging";
      if (FB.codeConsumed) {
        // ⭐ همان invalid_grant واقعی گوگل بعد از مصرف‌شدن/منقضی‌شدن کد oauth
        FB.flow = null;
        out = JSON.stringify({ ok: false, error: "code_used", status: 400, message: JSON.stringify({
          error: "invalid_grant", error_description: "Code was already redeemed."
        }) });
      } else if (FB.authApiDisabled) {
        // همان پاسخ واقعی گوگل وقتی Identity Toolkit API غیرفعال است (۴۰۳ + لینک فعال‌سازی داخل پیام)
        // ⭐ v3.9.4: جریان پاک می‌شود (کد در گوگل مصرف شده) — «تلاش دوباره» ورود تازه می‌سازد
        FB.flow = null;
        out = JSON.stringify({ ok: false, error: "auth_api_disabled", status: 403, message: JSON.stringify({
          error: { code: 403, status: "PERMISSION_DENIED",
            message: "Identity Toolkit API has not been used in project 358616461933 before or it is disabled. Enable it by visiting https://console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=358616461933 then retry. If you enabled this API recently, wait a few minutes for the action to propagate to our systems and retry." }
        }) });
      } else {
        // uid پایدار برای هر ایمیل — مثل Firebase واقعی (ورود دوباره با همان حساب = همان uid)
        FB.session = { email: "browser.user@gmail.com", uid: "uid-" + "browser.user@gmail.com".replace(/[^a-z0-9]/gi, "").toLowerCase() };
        FB.flow = null;
        out = JSON.stringify({ ok: true, email: FB.session.email, uid: FB.session.uid });
      }
    }
    setTimeout(function(){
      try { var fn = window[callback]; if (typeof fn === "function") fn(JSON.parse(out)); } catch (e) {}
    }, SIM.latencyMs || 0);
  };
  window.AndroidCloud.fbGetAccount = function(){
    if (FB.session) return JSON.stringify({ connected: true, email: FB.session.email, uid: FB.session.uid });
    return JSON.stringify({ connected: false });
  };
  window.AndroidCloud.fbRequestAsync = function(method, url, contentType, body, callback){
    var out = (function(){
      if (SIM.offline) return { ok: false, error: "network" };
      if (!FB.session) return { ok: false, error: "disconnected" };
      var m = String(method || "GET").toUpperCase();
      var u = String(url || "");
      /* ⭐ سناریوهای خطای واقعی گوگل — همان bodyهایی که برمی‌گردند */
      if (FB.apiDisabled) return { ok: true, status: 403, body: JSON.stringify({ error: { code: 403, status: "FAILED_PRECONDITION",
        message: "Cloud Firestore API has not been used in project 358616461933 before or it is disabled. Enable it by visiting https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=358616461933 then retry. If you enabled this API recently, wait a few minutes for the action to propagate to our systems and retry." } }) };
      if (FB.noDatabase) return { ok: true, status: 404, body: JSON.stringify({ error: { code: 404, status: "NOT_FOUND",
        message: "Database 'projects/hamrahprj/databases/(default)' does not exist. Please create the database first." } }) };
      if (FB.rulesDenied) return { ok: true, status: 403, body: JSON.stringify({ error: { code: 403, status: "PERMISSION_DENIED",
        message: "Missing or insufficient permissions." } }) };
      // اسناد hamrah_users/{uid} — GET/PATCH/DELETE
      var dm = u.match(/\\/documents\\/hamrah_users\\/([^/?]+)/);
      if (dm) {
        var docPath = "projects/hamrahprj/databases/(default)/documents/hamrah_users/" + dm[1];
        if (m === "GET") {
          var doc = FB.docs[dm[1]];
          if (!doc) return { ok: true, status: 404, body: JSON.stringify({ error: { code: 404, status: "NOT_FOUND", message: "Document not found: " + docPath } }) };
          return { ok: true, status: 200, body: JSON.stringify({ name: docPath, fields: { data: { stringValue: doc.data }, updatedAt: { timestampValue: doc.updatedAt } } }) };
        }
        if (m === "PATCH" || m === "PUT") {
          try {
            var b = JSON.parse(body);
            FB.docs[dm[1]] = { data: b.fields && b.fields.data ? b.fields.data.stringValue : "", updatedAt: new Date().toISOString() };
          } catch (e) {}
          return { ok: true, status: 200, body: JSON.stringify({ name: docPath, fields: {} }) };
        }
        if (m === "DELETE") { delete FB.docs[dm[1]]; return { ok: true, status: 200, body: "{}" }; }
      }
      // identitytoolkit/securetoken (نوسازی توکن در جاوا) — موفق
      if (u.indexOf("identitytoolkit") >= 0 || u.indexOf("securetoken") >= 0) return { ok: true, status: 200, body: "{}" };
      return { ok: true, status: 400, body: JSON.stringify({ error: { code: 400, message: "mock: unsupported " + m + " " + u } }) };
    })();
    setTimeout(function(){
      try { var fn = window[callback]; if (typeof fn === "function") fn(out); } catch (e) {}
    }, SIM.latencyMs || 0);
  };
  window.AndroidCloud.fbDisconnectAsync = function(callback){
    FB.session = null; FB.flow = null;
    var out = JSON.stringify({ ok: true });
    setTimeout(function(){
      try { var fn = window[callback]; if (typeof fn === "function") fn(JSON.parse(out)); } catch (e) {}
    }, SIM.latencyMs || 0);
  };
  /* ═══════════ v3.9.5 — fbProbeAsync: بررسی وضعیت راه‌اندازی (بدون ورود) ═══════════
     همان قرارداد FbSession.probe در جاوا — پاسخ‌های عین گوگل:
       network   → {ok:true, status:200} (یا offline → {ok:false, error:"network"})
       identity  → API فعال: 400 EMAIL_NOT_FOUND | غیرفعال: 403 + «has not been used…»
       firestore → API فعال: 401 CREDENTIALS_MISSING | غیرفعال: 403 + «has not been used…» */
  window.AndroidCloud.fbProbeAsync = function(probe, callback){
    var out = (function(){
      if (SIM.offline) return { ok: false, error: "network" };
      if (probe === "network") return { ok: true, status: 200, body: "" };
      if (probe === "identity") {
        if (FB.authApiDisabled) {
          return { ok: true, status: 403, body: JSON.stringify({ error: { code: 403, status: "PERMISSION_DENIED",
            message: "Identity Toolkit API has not been used in project 358616461933 before or it is disabled. Enable it by visiting https://console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=358616461933 then retry. If you enabled this API recently, wait a few minutes for the action to propagate to our systems and retry." } }) };
        }
        return { ok: true, status: 400, body: JSON.stringify({ error: { code: 400, message: "EMAIL_NOT_FOUND",
          errors: [{ message: "EMAIL_NOT_FOUND", domain: "global", reason: "invalid" }] } }) };
      }
      if (probe === "firestore") {
        if (FB.apiDisabled) {
          return { ok: true, status: 403, body: JSON.stringify({ error: { code: 403, status: "FAILED_PRECONDITION",
            message: "Cloud Firestore API has not been used in project 358616461933 before or it is disabled. Enable it by visiting https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=358616461933 then retry. If you enabled this API recently, wait a few minutes for the action to propagate to our systems and retry." } }) };
        }
        return { ok: true, status: 401, body: JSON.stringify({ error: { code: 401,
          message: "Request is missing required authentication credential. Expected OAuth 2 access token, login cookie or other valid authentication credential.",
          status: "UNAUTHENTICATED" } }) };
      }
      return { ok: false, error: "bad_probe" };
    })();
    setTimeout(function(){
      try { var fn = window[callback]; if (typeof fn === "function") fn(out); } catch (e) {}
    }, SIM.latencyMs || 0);
  };

  /* سناریوهای فایربیس روی __CLOUD_SIM + قلاب‌های تست */
  var CS = window.__CLOUD_SIM;
  ["fbSchemeDisabled","fbAuthApiDisabled","fbApiDisabled","fbRulesDenied","fbNoDatabase","fbCodeConsumed"].forEach(function(name){
    var key = name.slice(2,3).toLowerCase() + name.slice(3); // fbSchemeDisabled → schemeDisabled(FB)
    Object.defineProperty(CS, name, { get: function(){ return FB[key]; }, set: function(v){ FB[key] = !!v; }, configurable: true });
  });
  Object.defineProperty(CS, "fbAccount", { get: function(){ return FB.session; }, configurable: true });
  Object.defineProperty(CS, "fbDocs", { get: function(){ return FB.docs; }, configurable: true });
  CS.fbSeedDoc = function(uid, snapshot){
    FB.docs[uid] = { data: typeof snapshot === "string" ? snapshot : JSON.stringify(snapshot), updatedAt: new Date().toISOString() };
  };
  CS.fbEnableAll = function(){ FB.schemeDisabled = false; FB.authApiDisabled = false; FB.apiDisabled = false; FB.rulesDenied = false; FB.noDatabase = false; FB.codeConsumed = false; };
  /* completeAuth/denyAuth/reset/reinstallApp باید جریان fb را هم کامل/ریست کنند */
  var _oldComplete = CS.completeAuth;
  CS.completeAuth = function(){
    if (FB.flow && FB.flow.state === "waiting") { FB.flow.state = "done"; FB.flow.code = "4/0AfakeFbAuthCode"; }
    return _oldComplete();
  };
  var _oldDeny = CS.denyAuth;
  CS.denyAuth = function(){
    if (FB.flow && FB.flow.state === "waiting") { FB.flow.state = "error"; FB.flow.error = "access_denied"; }
    return _oldDeny();
  };
  var _oldReset = CS.reset;
  CS.reset = function(){
    FB.session = null; FB.flow = null; FB.docs = {};
    FB.schemeDisabled = false; FB.authApiDisabled = false; FB.apiDisabled = false; FB.rulesDenied = false; FB.noDatabase = false; FB.codeConsumed = false;
    return _oldReset();
  };
  var _oldReinstall = CS.reinstallApp;
  CS.reinstallApp = function(){
    FB.session = null; FB.flow = null; // اسناد ابری (FB.docs) مثل Firestore واقعی دست‌نخورده می‌مانند
    return _oldReinstall();
  };
})();
`;

const seedJson = readFileSync(SEED, "utf-8");
const shimCode = SHIM.replace("__SEED_JSON__", seedJson);

Bun.serve({
  port: PORT,
  fetch(req) {
    const url = new URL(req.url);
    let path = url.pathname;
    if (path === "/") path = "/index.html";
    const file = join(OUT, path);
    if (!existsSync(file)) return new Response("not found: " + path, { status: 404 });
    if (path.endsWith(".html")) {
      let html = readFileSync(file, "utf-8");
      // تزریق پل قبل از همهٔ اسکریپت‌ها — مثل addJavascriptInterface جاوا
      html = html.replace(/<head([^>]*)>/i, `<head$1><script>${shimCode}</script>`);
      return new Response(html, {
        headers: { "content-type": MIME[".html"], "cache-control": "no-store" },
      });
    }
    const type = MIME[extname(file)] ?? "application/octet-stream";
    // no-cache برای همهٔ استیک‌ها — مرورگر تست همیشه نسخهٔ جدید www-final را می‌گیرد
    return new Response(readFileSync(file), {
      headers: { "content-type": type, "cache-control": "no-cache" },
    });
  },
});

console.log("apk-mock running on http://localhost:" + PORT + " serving " + OUT);
