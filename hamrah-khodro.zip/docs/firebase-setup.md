# راهنمای راه‌اندازی Firebase — سینک ابری «با حساب گوگل» (v3.9.6)

## ⭐⭐⭐✅ حل نهایی (۱۸ سپتامبر ۲۰۲۶) — سرور پشتیبان ۱۰۰٪ آماده شد

با کلید Service Account که کاربر داد، اسکریپت ادمین اجرا و **کل زنجیره تأیید** شد؛
دیتابیس و قوانین در کنسول ساخته/منتشر شده بودند و اکنون وضعیت نهایی:

| مرحله | وضعیت | شاهد مستقیم |
|---|---|---|
| کلاینت OAuth اندروید + Custom URI scheme | ✅ سالم | `302` به صفحهٔ ورود (نه صفحهٔ خطای OAuth) — redirect_uri پذیرفته |
| Identity Toolkit API | ✅ **فعال** | پاسخ `400 PASSWORD_LOGIN_DISABLED` (سرویس جواب می‌دهد؛ ورود فقط با گوگل طراحی شده) |
| ارائه‌دهندهٔ ورود با گوگل (provider) | ✅ **فعال** | `signInWithIdp` با همان قرارداد برنامه → `INVALID_IDP_RESPONSE: Unable to parse Google id_token` — یعنی provider روشن است و فقط توکن ساختگی رد می‌شود |
| Cloud Firestore API | ✅ **فعال** | سرویس پاسخ می‌دهد |
| دیتابیس Firestore «(default)» | ✅ **موجود** | ساخته‌شده در `2026-09-17T21:00:09Z` (منطقهٔ nam5، FIRESTORE_NATIVE، free-tier) |
| قوانین امنیتی | ✅ **درست منتشر شده** | release `cloud.firestore` → ruleset `39a098c5…` — `hamrah_users/{uid}` فقط با `request.auth.uid == uid` |
| تست نوشتن/خواندن/حذف (ادمین) | ✅ **موفق** | هر سه `HTTP 200` |
| تست E2E مسیر کاربر واقعی | ✅ **موفق** | نشست واقعی (signInWithCustomToken) ← نوشتن/خواندن سند خودش `200`؛ سند دیگری `403`؛ بی‌توکن `403` — قوانین دقیقاً ایزولهٔ هر کاربر |

**نتیجه:** ریشهٔ «ورود به سرور پشتیبان انجام نشد» (دیتابیس نبودن + باگ `uri=` در ≤v3.9.2)
کاملاً رفع شده. **فقط v3.9.6 را نصب کنید و وارد شوید** — ورود، سینک و ذخیرهٔ خودکار کار می‌کنند.

> نکته: کلید Service Account در `config/service-account.json` (موجود است) — برای بازبینی مجدد:
> `bun run scripts/firebase-admin-setup.ts config/service-account.json` → گزارش همه-سبز
> تست کامل مسیر کاربر: `bun run scripts/firebase-e2e-user.ts config/service-account.json`

## سابقهٔ تشخیص (v3.9.6 — قبل از حل)

با پروب‌های مستقیم از سمت سرور ریشه پیدا شد: تمام زنجیرهٔ ورود سالم بود و فقط
**دیتابیس ساخته نشده بود** (کاربر در ویزارد کنسول گیر مراحل Gradle شده و «Create database»
را نزده بود) — این با تأیید ۱۸ سپتامبر حل شد.

## ⭐ تازهٔ v3.9.6 — تشخیص «دیتابیس نیست» قبل از ورود

پروب گام ۳ حالا **endpoint اسناد** را می‌خواند؛ اگر دیتابیس نباشد، همان موقع
(حتی بدون ورود) گام ۳ سبز (API فعال) و **گام ۴ زرد** با پیام «دیتابیس هنوز ساخته
نشده» + دکمهٔ کنسول نشان داده می‌شود — دیگر لازم نیست اول وصل شوید تا بفهمید.

اگر «ورود به سرور پشتیبان انجام نشد»، لازم نیست حدس بزنید کدام تنظیم ناقص است:
در **تنظیمات ← پشتیبان‌گیری و بازیابی ← تب سرور ابری** دکمهٔ
**«راه‌اندازی گام‌به‌گام سرور»** را بزنید — شیت راهنما باز می‌شود با ۶ گام:

۱. اینترنت و دسترسی به گوگل ← **بررسی خودکار** (پاسخ واقعی سرور)
۲. Identity Toolkit API (ورود) ← **بررسی خودکار**
۳. Cloud Firestore API (داده) ← **بررسی خودکار**
۴. ساخت دیتابیس Firestore ← راهنمای کنسول (بعد از اتصال، بررسی خودکار)
۵. قوانین امنیتی ← قطعه‌کد با دکمهٔ کپی (بعد از اتصال، بررسی خودکار)
۶. اتصال با حساب گوگل ← خودش تست کامل انتها-به-انتهاست

دکمهٔ **«بررسی وضعیت»** با پاسخِ واقعی سرورهای گوگل هر گام را ✓ سبز یا ⚠ هشدار
می‌کند و برای گام ناقص، **دکمهٔ مستقیم کنسول** همان‌جا هست. بعد از هر تغییر در
کنسول فقط «بررسی دوبارهٔ وضعیت» را بزنید.

> **مهم:** مراحل Gradle/SDK که ویزاردِ «Add app» کنسول فایربیس نشان می‌دهد
> (build.gradle، google-services plugin و…) برای این برنامه **لازم نیست** — ارتباط
> برنامه مستقیم با REST است و پیکربندی از قبل داخل آن تعبیه شده.

> **دکمهٔ لغو:** در هر دو مرحلهٔ اتصال به گوگل (صفحهٔ مرورگر باز است / تبدیل کد در
> جریان است) دکمهٔ «لغو اتصال» هست — جریان بسته می‌شود و اگر ورود در پس‌زمینه
> کامل شده باشد، خودکار قطع می‌شود.

## وضعیت پروژهٔ فعلی (hamrahprj) — ✅ تأیید مستقیم (۱۸ سپتامبر ۲۰۲۶)

**نتیجه:** سرور پشتیبان کاملاً آماده است (جدول بالا). اگر v3.9.2 یا قدیمی‌تر نصب
دارید (با باگ `uri=`/`MISSING_REQUEST_URI`)، همین باعث خطای ورود بوده — **v3.9.6 را
نصب کنید**؛ ورود، سینک و ذخیرهٔ خودکار کار می‌کنند. در برنامه هم شیت «راه‌اندازی
گام‌به‌گام» ← «بررسی وضعیت» حالا **گام‌های ۱ تا ۴ سبز** را نشان می‌دهد (گام ۴ یعنی
دیتابیس، که قبلاً زرد بود) — گام ۵ (قوانین) بعد از اتصال سبز می‌شود.

## معماری (بدون SDK)

OAuth گوگل (PKCE، بدون Client Secret) در مرورگر سیستم ← `id_token` ← Firebase Auth
REST (`signInWithIdp`) ← سند Firestore `hamrah_users/{uid}` — تماماً REST خالص روی نخ
پس‌زمینهٔ جاوا (`FbSession`) + برای «بررسی وضعیت» پروب‌های سبک `fbProbeAsync`
(بدون نیاز به ورود).

## پیکربندی تعبیه‌شده (پروژهٔ hamrahprj)

| کلید | مقدار |
|---|---|
| project_id | `hamrahprj` |
| project_number | `358616461933` |
| Android OAuth client | `358616461933-okqrjiuosruele895435ti2s2lpgvm46.apps.googleusercontent.com` |
| SHA-1 کلاینت | `08:BE:55:6D:79:65:FE:79:81:81:69:80:0C:CB:2E:16:60:52:47` (امضای برنامه) |
| Web API Key | `AIzaSyDitRMguD0DVjqiMxNCbVPuPS0s0D-7uZk` |

## اگر خواستید دستی چک کنید (همان ۴ قدم)

1. **فعال‌سازی Identity Toolkit API** (ورود):
   [console.developers.google.com/apis/api/identitytoolkit.googleapis.com](https://console.developers.google.com/apis/api/identitytoolkit.googleapis.com/overview?project=hamrahprj)
2. **فعال‌سازی Cloud Firestore API** (داده):
   [console.developers.google.com/apis/api/firestore.googleapis.com](https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=hamrahprj)
3. **ساخت دیتابیس Firestore**: [console.firebase.google.com/project/hamrahprj/firestore](https://console.firebase.google.com/project/hamrahprj/firestore)
   → Create database → منطقهٔ دلخواه → Start in test mode
4. **قوانین امنیتی** (تب Rules در همان Firestore) — جایگزینی و Publish:

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /hamrah_users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

همچنین در کلاینت اندرویدِ پروژه (Google Cloud ← Auth ← Clients) باید تیک
**Enable custom URI scheme** روشن باشد — این تیک برای بازگشت از مرورگر گوگل به برنامه
لازم است (یک‌بار برای همیشه).

بعد از هر تغییر در کنسول، در برنامه **«بررسی دوبارهٔ وضعیت»** (شیت گام‌به‌گام) یا
**«تلاش دوباره»** (کارت خطا) را بزنید.

## جدول عیب‌یابی — کارت‌های خودتشخیصی برنامه (v3.9.3+)

| پیام کارت | ریشهٔ فنی | دکمهٔ اقدام |
|---|---|---|
| «Identity Toolkit API … فعال نیست» | 403 `PERMISSION_DENIED` + `has not been used in project … or it is disabled` از `signInWithIdp` | فعال‌سازی Identity Toolkit API |
| «Cloud Firestore API … فعال نیست» | همان 403 از Firestore REST | فعال‌سازی Cloud Firestore API |
| «دیتابیس Firestore هنوز ساخته نشده» | 404 `Database … does not exist` | ساخت دیتابیس (Firebase) |
| «قوانین امنیتی … اجازه نمی‌دهند» | 403 `Missing or insufficient permissions` | باز کردن قوانین + کپی قوانین پیشنهادی |
| «Enable custom URI scheme … روشن کنید» | ریدایرکت گوگل به صفحهٔ خطای OAuth | کلاینت‌های OAuth پروژه |
| «کد ورود قبلی یک‌بارمصرف است» | `invalid_grant` (کد oauth مصرف/منقضی شده) | تلاش دوباره (صفحهٔ ورود از نو باز می‌شود) |

> نکتهٔ فنی: خطای «API غیرفعال» و «قوانین بسته» **هر دو 403 PERMISSION_DENIED** هستند —
> برنامه اول الگوی `has not been used … Enable it by visiting` را بررسی می‌کند (ترتیب
> شاخه‌های نگاشت خطا حیاتی است) و بعد سراغ قوانین می‌رود.

## نحوهٔ تست سمت توسعه (شبیه‌ساز)

`mini-services/apk-mock` (پورت 3031) پل جاوای فایربیس را با «گوگلِ درحافظه» شبیه‌سازی
می‌کند — از جمله `fbProbeAsync` (پاسخ‌های عین گوگل: `400 EMAIL_NOT_FOUND` = فعال،
`403 + has not been used` = غیرفعال، `401 UNAUTHENTICATED` = Firestore فعال).
سناریوها از کنسول مرورگر:

```js
__CLOUD_SIM.fbAuthApiDisabled = true   // Identity Toolkit غیرفعال (خطای ورود)
__CLOUD_SIM.fbApiDisabled = true       // Firestore API غیرفعال
__CLOUD_SIM.fbRulesDenied = true       // قوانین بسته
__CLOUD_SIM.fbNoDatabase = true        // دیتابیس ساخته نشده
__CLOUD_SIM.fbSchemeDisabled = true    // تیک Custom URI scheme خاموش
__CLOUD_SIM.fbCodeConsumed = true      // کد oauth یک‌بارمصرف (invalid_grant واقعی)
__CLOUD_SIM.latency = 4000             // تأخیر هر فراخوانی ابری (تست دکمهٔ لغو)
__CLOUD_SIM.completeAuth()             // شبیه‌سازی تأیید کاربر در گوگل
__CLOUD_SIM.fbEnableAll()              // «کاربر هرچه لازم بود در کنسول فعال کرد»
__CLOUD_SIM.fbSeedDoc(uid, snapshot)   // کاشت سند ابری برای تست بازیابی
__CLOUD_SIM.reinstallApp()             // حذف+نصب مجدد (دادهٔ محلی پاک، ابر می‌ماند)
__CLOUD_SIM.reset()                    // ریست کامل
```

`__OPENED_URLS` همهٔ لینک‌هایی که دکمه‌های کارت/شیت باز کرده‌اند را ثبت می‌کند (تست E2E).
