# راهنمای انتشار عمومی (Publish App) — همراه خودرو v3.9.3

> ⭐ v3.9.3: با سینک Firebase (docs/firebase-setup.md) محدودیت «۱۰۰ ایمیل Test User»
> دیگر مسئله نیست — کاربران با هر ایمیلی حساب پشتیبان می‌سازند و نیازی به PUBLISH APP
> ندارند. راهنمای زیر فقط برای ادامهٔ استفاده از Google Drive است.

> 📌 **خلاصهٔ یک‌خطی**: برنامه کاملاً **آفلاین + سینک** است؛ نسخهٔ وبی وجود ندارد.
> این راهنما فقط برای همین یک هدف است: گرفتن **مجوز Publish گوگل** تا سینک ابری برای **هر ایمیلی** کار کند.

## ⚡ فقط آدرس‌هایی که باید به گوگل بدهی (پس از گام ۱)

| فیلد فرم گوگل | مقداری که وارد می‌کنی |
|---|---|
| **Application home page** | `https://hamrah-khodro.vercel.app/app-home.html` |
| **Privacy policy URL** | `https://hamrah-khodro.vercel.app/privacy.html` |
| **App name** | همراه خودرو (Hamrah Khodro) |
| **User support email** | ایمیل خودت |
| **Authorized domains** | `hamrah-khodro.vercel.app` |

(اگر موقع ساخت پروژه در Vercel نام دیگری انتخاب کردی، همان نام را جایگزین `hamrah-khodro` کن — بقیهٔ متن همین است.)

گوگل برای فعال‌شدن دکمهٔ **Publish App** (خروج از حالت Testing و قابل‌استفاده برای همهٔ کاربران) سه پیش‌نیاز دارد. **هر سه آماده شده و فقط به حساب‌های خودتان نیاز دارد** — همهٔ کارهای فنی انجام شده است.

## آنچه آماده شده (این مخزن)

| پیش‌نیاز گوگل | وضعیت | فایل |
|---|---|---|
| ۱. صفحهٔ معرفی برنامه (App Home Page) | ✅ ساخته شد | `public/app-home.html` → آدرس: `https://<دامنهٔ-شما>/app-home.html` |
| ۲. سیاست حریم خصوصی (Privacy Policy URL) | ✅ ساخته شد | `public/privacy.html` → آدرس: `https://<دامنهٔ-شما>/privacy.html` |
| ۳. تأیید مالکیت دامنه در Google Search Console | ✅ زیرساخت آن آماده است | تگ `<meta name="google-site-verification">` از متغیر محیطی `NEXT_PUBLIC_GSC_VERIFICATION` خوانده می‌شود (`src/app/layout.tsx`) |

صفحهٔ معرفی: معرفی کامل برنامه، امکانات، دکمهٔ دانلود APK و لینک حریم خصوصی.
سیاست حریم خصوصی: دقیقاً همان چیزی که گوگل می‌خواهد — توضیح دامنهٔ مجوز `drive.appdata` (فقط پوشهٔ اختصاصی برنامه در Drive کاربر)، جدول محل ذخیرهٔ داده‌ها، حقوق کاربر، لغو دسترسی و….

> ⚠️ چرا خودم پابلیش نکردم؟ استقرار روی Vercel و تأیید در Search Console و زدن دکمهٔ Publish هر سه **ورود به حساب کاربری خودِ شما** (ایمیل/گوگل) لازم دارند که از داخل این محیط ممکن نیست. مراحل زیر برای هر کدام حداکثر ۲–۳ دقیقه است.

---

## گام ۱ — استقرار روی Vercel (≈۳ دقیقه)

1. در کامپیوتر خودتان این مخزن را در یک پوشه داشته باشید (همین پروژه).
2. [vercel.com](https://vercel.com) → Sign up / Login (سریع‌تر: با گوگل).
3. راه سریع بدون GitHub — نصب CLI و استقرار مستقیم:
   ```bash
   npm i -g vercel
   cd my-project          # ریشهٔ همین پروژه (جایی که package.json است)
   vercel login
   vercel --prod
   ```
   به سؤالات پاسخ ندهید لازم نیست — پیش‌فرض‌ها درست است: Framework = Next.js.
4. بعد از پایان، آدرس عمومی می‌گیرید؛ مثل:
   ```
   https://hamrah-khodro.vercel.app
   ```
5. تست: این دو آدرس باید باز شوند:
   - `https://hamrah-khodro.vercel.app/app-home.html` ← صفحهٔ معرفی
   - `https://hamrah-khodro.vercel.app/privacy.html` ← سیاست حریم خصوصی

> 💡 پروژهٔ Vercel را هنگام ساخت `hamrah-khodro` نام‌گذاری کنید تا آدرس خواناتر شود. دامنهٔ شخصی هم می‌توانید از Settings ← Domains وصل کنید — هر دوی آدرس بالا با دامنهٔ شخصی هم کار می‌کنند.

## گام ۲ — تأیید مالکیت در Google Search Console (≈۳ دقیقه)

**روش A — تگ HTML (پیشنهادی، برای همین سایت):**

1. [search.google.com/search-console](https://search.google.com/search-console) → با همان حساب گوگلِ Google Cloud وارد شوید.
2. «Add Property» → نوع **URL prefix** → آدرس دقیق سایت را وارد کنید؛ مثل `https://hamrah-khodro.vercel.app` (اگر دامنهٔ شخصی وصل کرده‌اید، همان را).
3. روش تأیید **HTML tag** را انتخاب کنید. گوگل تگی شبیه این نشان می‌دهد:
   ```html
   <meta name="google-site-verification" content="AbCdEf123456..." />
   ```
   فقط مقدار `content` را بردارید.
4. در Vercel: **Project ← Settings ← Environment Variables** متغیر جدید بسازید:
   - Name: `NEXT_PUBLIC_GSC_VERIFICATION`
   - Value: مقدار content (بدون کوتیشن)
   - Environment: Production
   - سپس **Deployments ← آخرین دیپلوی ← … ← Redeploy**.
5. در Search Console دکمهٔ **Verify** را بزنید ✓

**روش B — رکورد DNS (اگر دامنهٔ شخصی دارید):** در Search Console نوع **Domain** بسازید؛ رکورد TXT که می‌دهد را در DNS دامنه‌تان اضافه کنید — کل دامنه یک‌جا تأیید می‌شود و نیازی به تگ نیست.

## گام ۳ — ثبت آدرس‌ها و Publish در Google Cloud Console (≈۲ دقیقه)

1. [console.cloud.google.com](https://console.cloud.google.com) → پروژهٔ همراه خودرو (همانی که OAuth Client ID `876691396788-fbiuu666o7i3fujgek28t1mnb96mi3pv…` در آن است).
2. منوی **APIs & Services ← OAuth consent screen** (یا Google Auth Platform ← Audience).
3. در بخش **App information**:
   - **App home page:** `https://hamrah-khodro.vercel.app/app-home.html`
   - **Privacy policy URL:** `https://hamrah-khodro.vercel.app/privacy.html`
   - (هر دو با دامنهٔ خودتان؛ همین دامنه‌ای که در گام ۲ تأیید شده)
4. اگر بخش **Authorized domains** خالی است، دامنه را اضافه کنید: `hamrah-khodro.vercel.app`.
5. پایین صفحه، در بخش **Publishing status** دکمهٔ **PUBLISH APP** را بزنید → تأیید کنید.
6. وضعیت از «In testing» به **«In production»** تغییر می‌کند.

## بعد از Publish چه می‌شود؟

- سقف ۱۰۰ کاربرِ تستی حذف می‌شود؛ هر کسی با هر حساب گوگل می‌تواند وصل شود.
- چون تنها مجوز حساس برنامه `drive.appdata` است (نه `drive` کامل)، معمولاً به‌عنوان sensitive-scope-سبک رفتار می‌شود و گوگل ممکن است فقط توضیح کوتاه فرم تأیید یا ویدیوی ۱–۲ دقیقه‌ای از «چرا این مجوز لازم است» بخواهد — همان صفحهٔ معرفی و سیاست حریم خصوصی پاسخ همان سؤالات است:
  - «برنامه فقط برای پشتیبان‌گیری از داده‌های خود کاربر در Drive او از drive.appdata استفاده می‌کند و هیچ فایل شخصی دیگری را نمی‌بیند.»
- دکمهٔ Publish برای همهٔ نسخه‌های APK (از v3.8.0 به بعد) یک‌بار برای همیشه فعال می‌ماند؛ لازم نیست برای هر نسخهٔ جدید تکرار کنید.

## چک‌لیست نهایی

- [ ] `vercel --prod` اجرا شد و `/app-home.html` و `/privacy.html` از اینترنت باز می‌شوند
- [ ] Search Console → وضعیت Property: **Verified**
- [ ] OAuth consent screen → هر دو آدرس ثبت شده‌اند و دامنهٔ آن‌ها در Authorized domains است
- [ ] دکمهٔ **PUBLISH APP** زده شد؛ Publishing status = **In production**
- [ ] روی گوشی: برنامه ← حساب ابری ← «به Google Drive وصل شوید» با یک حساب گوگل دیگر (خارج از test users) تست شود
